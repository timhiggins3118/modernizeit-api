#!/usr/bin/env node
import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import { VpcStack } from './vpc-stack';
import { ComputeStack } from './compute-stack';


import { StorageStack } from "./storage-stack";

/**
 * testapp02 Infrastructure
 * Generated: 2025-12-24T08:18:58.893708
 *
 * Deployment order:
 * 1. VPC Stack
 * 2. Database Stack (if needed)
 * 3. Storage Stack (if needed)
 * 4. Compute Stack
 * 5. API Stack (if needed)
 */
const app = new cdk.App();

const env = {
  account: process.env.CDK_DEFAULT_ACCOUNT,
  region: process.env.CDK_DEFAULT_REGION || 'us-east-1',
};

// 1. VPC
const vpcStack = new VpcStack(app, 'testapp02-vpc', { env });







// 3. Storage
const storageStack = new StorageStack(app, "testapp02-storage", { env });

// 4. Compute
const computeStack = new ComputeStack(app, 'testapp02-compute', {
  env,
  vpc: vpcStack.vpc,
});







app.synth();
