#!/bin/bash
echo "Starting application..."
docker-compose up --build -d
echo "Application started at http://localhost:8080"
