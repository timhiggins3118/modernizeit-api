#!/bin/bash
set -e
echo "Building application..."
mvn clean package -DskipTests
echo "Build complete!"
