package com.modernizeit.generated;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * IFPR321 - COBOL to Java Translation
 * Generated: 2025-12-23 17:08:04
 * Source: IFPR321.CBL
 * 
 * Line references (L:nnn) map to original COBOL source.
 */
public class IFPR321 {

    // ============================================================================
    // TEST HARNESS - NOT PART OF TRANSFORMATION FLOW
    // ============================================================================
    // This main() is auto-generated for IntelliJ exploration/debugging.
    // Limitations: File I/O stubbed, external CALLs empty, default data values.
    // To run: Right-click this file in IntelliJ -> Run 'IFPR321.main()'
    // ============================================================================
    public static void main(String[] args) {
        System.out.println("=== IFPR321 Test Harness ===");
        System.out.println("COBOL-to-Java translation. File I/O and CALLs are stubbed.");
        IFPR321 program = new IFPR321();
        try {
            System.out.println("Calling 000-MAIN-CONTROL...");
            program.mainControl_000();
            System.out.println("Program completed.");
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
    // ============================================================================

    // === CONSTANTS ===
    private static final String LOW_VALUE = "\u0000";
    private static final String HIGH_VALUE = "\u00FF";

    private static final String GTN_END = "N";              // L:788 GTN-END
    private static final String OPT_OK = "SPACES";          // L:789 OPT-OK
    private static final String PCT_OPEN = "N";             // L:790 PCT-OPEN
    private static final String TAX_CREDIT_YN = "N";        // L:811 TAX-CREDIT-YN
    private static final String TAX_PARA_YN = "N";          // L:813 TAX-PARA-YN
    private static final String ANS = "SPACES";             // L:819 ANS
    private static final String POST_OPT_CODE = "SPACES";   // L:820 POST-OPT-CODE
    private static final String CHK_PURGE_YN = "SPACES";    // L:821 CHK-PURGE-YN
    private static final String C_CLIENT_ENV = "SPACES";    // L:822 C-CLIENT-ENV
    private static final String EXPAND_DED_ARREARS_SW = "SPACE";// L:824 EXPAND-DED-ARREARS-SW

    // === EXTERNAL FILE RECORD FIELDS (Stubs) ===
    // These fields come from file records or COPY members - need proper FD parsing
    private String cl1ClientNo = "";
    private int cl1OptNo = 0;
    private String cl1OptValue = "";
    private String calCdeCycle = "";
    private int calNumber = 0;
    private int calPrdNo = 0;
    private int calYear = 0;
    private String prelimProfile = "";
    private String profOpt = "";
    private String wsProfile = "";
    private boolean purgeError = false;
    private String sdbfnu = "";
    private String sdexco = "";
    private String sdhgnu = "";
    private String sdhhnu = "";
    private String sdixsa = "";
    private String sdiysa = "";
    private String sdmznu = "";
    private String s0bfnu = "";
    private String s0cwte = "";
    private String s0hdnu = "";
    private String s0henu = "";
    private String s0hfnu = "";
    private String ws = "";
    private String c = "";
    private int I = 0;
    private String timCheckType = "";
    private int timTblElement = 0;
    private int timNoCycles = 0;
    private String timGroup = "";
    private String timCode = "";
    private short timClientNo = (short)0;
    private BigDecimal timAmount = BigDecimal.ZERO;
    private int timDateEnd = 0;
    private int timCheckNo = 0;
    private String timCdeCycle = "";
    private String io = "";
    private boolean ok = false;
    private String calClrQtd = "";
    private String timType = "";
    private int timEmpNo = 0;
    private String cdeTaxWs = "";
    private BigDecimal s0l4sa = BigDecimal.ZERO;
    private BigDecimal s0l3sa = BigDecimal.ZERO;
    private String atEnd = "10";
    private String per = "";
    private String perCdeCycle = "";
    private String perMarStatStt = "";
    private String perMarStatFed = "";
    private String perExmTable = "";
    private String wsPerExmTable = "";
    private int perExmFed = 0;
    private int perEmpNo = 0;
    private short perClientNo = (short)0;
    private String perActive = "";
    private int ernEmpNo = 0;
    private short ernClientNo = (short)0;
    private int benEmpNo = 0;
    private short benClientNo = (short)0;
    private int empNo = 0;
    private short clientNo = (short)0;
    private String timStoreWrk = "";
    private String timDeptWrk = "";
    private String timCorpWrk = "";
    private String cnl = "";
    private int cnlIdxWs = 0;
    private int[] benDedNo = new int[100];
    private String[] benDedPara = new String[100];
    private BigDecimal[] benDedPercent = new BigDecimal[100];
    private BigDecimal[] benDedAmt = new BigDecimal[100];
    private BigDecimal[] benArrsCtr = new BigDecimal[100];
    private int[] benDedTktn = new int[100];
    private BigDecimal[] benDedBal = new BigDecimal[100];
    private String clnCycle = "";
    private int J = 0;
    private BigDecimal[] benBegDate = new BigDecimal[100];
    private BigDecimal[] benEndDate = new BigDecimal[100];
    private boolean takeWkDed = false;
    private boolean takeSmDed = false;
    private boolean takeBwDed = false;
    private boolean takeMtDed = false;
    private int CnlIdxWs = 0;
    private int[] benOrderNo = new int[100];
    private boolean dedRoutineError = false;
    private boolean setArrears = false;
    private String tcpCode = "";
    private BigDecimal tcpAmount = BigDecimal.ZERO;
    private String tcpType = "";
    private BigDecimal tcpHours = BigDecimal.ZERO;
    private BigDecimal tcpRate = BigDecimal.ZERO;
    private int tcpFileSeq = 0;
    private String tcpStoreWrk = "";
    private String tcpDeptWrk = "";
    private String tcpCorpWrk = "";
    private int tcpSeqNo = 0;
    private String tcpDirDepVoucher = "";
    private String tcpDocumentNo = "";
    private int tcpDocumentDate = 0;
    private int tcpStoreNo = 0;
    private int tcpDeptNo = 0;
    private int tcpCorpNo = 0;
    private String tcpSubGroup = "";
    private String tcpStoreGl = "";
    private String tcpGroup = "";
    private int tcpEmpNo = 0;
    private String tcpEmpName = "";
    private String tcpDeptGl = "";
    private int tcpDateEnd = 0;
    private int tcpCompNo = 0;
    private short tcpClientNo = (short)0;
    private String tcpCheckType = "";
    private int tcpCheckNo = 0;
    private String tcpCdeCycle = "";
    private String tcpAcctGl = "";
    private int tblIdx = 0;
    private String tblWorkKey = "";
    private int tblLevel = 0;
    private BigDecimal tblFicaPct = BigDecimal.ZERO;
    private BigDecimal tblWageLimitYtd = BigDecimal.ZERO;
    private BigDecimal tblTaxLimitYtd = BigDecimal.ZERO;
    private String tblMarStatus = "";
    private BigDecimal tblFlatTaxAmt = BigDecimal.ZERO;
    private BigDecimal tblFicaLimit = BigDecimal.ZERO;
    private String tblCdeTax = "";
    private String[] wsTblKey = new String[100];
    private int tb1OptId = 0;
    private String tb1OptValue = "";
    private String tb1CdeTax = "";
    private String tb1MarStatus = "";
    private BigDecimal[] perTaxPara = new BigDecimal[10];
    private String[] perTaxFlg = new String[20];
    private int perStoreNo = 0;
    private int perCorpNo = 0;
    private int perDeptNo = 0;
    private String perCdeStt = "";
    private BigDecimal perRteSalary = BigDecimal.ZERO;
    private String perCdeOth = "";
    private BigDecimal perSchdlHrs = BigDecimal.ZERO;
    private String perTaxFlgFed = "";
    private BigDecimal perRteHourly = BigDecimal.ZERO;
    private BigDecimal[] perBankDepAmt = new BigDecimal[5];
    private String perSchdl = "";
    private String[] perBankPnFlag = new String[5];
    private String[] perBankAcctType = new String[5];
    private int perExmStt = 0;
    private String perEmpName = "";
    private String[] perCdeTax = new String[20];
    private int[] perExmCnt = new int[20];
    private int perCompNo = 0;
    private String perKey = "";
    private String perJobClass = "";
    private int[] perBankAbaNo = new int[5];
    private String[] perBankAcct = new String[5];
    private String perCdeCit = "";
    private String perCdeLoc = "";
    private String perTaxFlgCit = "";
    private String perTaxFlgFica = "";
    private String perTaxFlgLoc = "";
    private String perTaxFlgOth = "";
    private String perTaxFlgStt = "";
    private int[] wsPerExemptCnt = new int[50];
    private int pe1Inx = 0;
    private String pe1Ok = "";
    private short pe1ClientNo = (short)0;
    private int pe1EmpNo = 0;
    private String pe1MarStat = "";
    private int pe1SeqNo = 0;
    private String pe1TaxCde = "";
    private int pe1TaxExm = 0;
    private String pe1TaxFlg = "";
    private String pe1TaxPara = "";
    private BigDecimal pe1TaxQtd = BigDecimal.ZERO;
    private BigDecimal pe1TaxYtd = BigDecimal.ZERO;
    private short pe3ClientNo = (short)0;
    private BigDecimal pe3DiffAmt = BigDecimal.ZERO;
    private String pe3DiffFlg = "";
    private int pe3EmpNo = 0;
    private BigDecimal pe3Multiplier = BigDecimal.ZERO;
    private int pe3SeqNo = 0;
    private BigDecimal cl2AnnlHrs = BigDecimal.ZERO;
    private short cl2ClientNo = (short)0;
    private String cl2LvClass = "";
    private String cl2LvFormula = "";
    private BigDecimal cl2PersHrs = BigDecimal.ZERO;
    private BigDecimal cl2SickHrs = BigDecimal.ZERO;
    private String cl3ActFlg = "";
    private short cl3ClientNo = (short)0;
    private BigDecimal cl3DiffAmt = BigDecimal.ZERO;
    private String cl3DiffFlg = "";
    private String cl3ErnCode = "";
    private int cl3ErnSeq = 0;
    private BigDecimal cl3Multiplier = BigDecimal.ZERO;
    private String cl3Ok = "";
    private String cl3TaxblCit = "";
    private String cl3TaxblFed = "";
    private String cl3TaxblFica = "";
    private String cl3TaxblFuta = "";
    private String cl3TaxblLoc = "";
    private String cl3TaxblOth = "";
    private String cl3TaxblStt = "";
    private String cl3TaxblSuca = "";
    private String[] clnActFlg = new String[50];
    private String clnBankCode = "";
    private int clnBankCompNo = 0;
    private int clnCalNo = 0;
    private int clnCalYr = 0;
    private short clnClientNo = (short)0;
    private int clnCompNo = 0;
    private int clnCppNo = 0;
    private BigDecimal[] clnDiffAmt = new BigDecimal[50];
    private String[] clnDiffFlg = new String[50];
    private String[] clnErnCode = new String[50];
    private BigDecimal[] clnMultiplier = new BigDecimal[50];
    private String[] clnTaxblCit = new String[50];
    private String[] clnTaxblFed = new String[50];
    private String[] clnTaxblFica = new String[50];
    private String[] clnTaxblFuta = new String[50];
    private String[] clnTaxblLoc = new String[50];
    private String[] clnTaxblOth = new String[50];
    private String[] clnTaxblStt = new String[50];
    private String[] clnTaxblSuca = new String[50];
    private short cn1ClientNo = (short)0;
    private String cn1DedNo = "";
    private int cn1IdxWs = 0;
    private int cn1OptNo = 0;
    private String cn1OptValue = "";
    private String cnlActFlg = "";
    private String cnlAssocDedNo = "";
    private short cnlClientNo = (short)0;
    private String cnlCycleFreq = "";
    private String cnlDedNo = "";
    private int cnlOrderNo = 0;
    private String cnlSetArrFlg = "";
    private String cnlTaxblCit = "";
    private String cnlTaxblFed = "";
    private String cnlTaxblFica = "";
    private String cnlTaxblLoc = "";
    private String cnlTaxblOth = "";
    private String cnlTaxblStt = "";
    private String[] cnlTaxblTableWs = new String[100];
    private String cnlTypeTable = "";
    private String[] cnlTypeTableWs = new String[100];
    private String cnlYtdPrt = "";
    private BigDecimal[] benAccQtd = new BigDecimal[100];
    private BigDecimal[] benAccYtd = new BigDecimal[100];
    private BigDecimal benAnnlAccRte = BigDecimal.ZERO;
    private BigDecimal benAnnlAcrdYtd = BigDecimal.ZERO;
    private BigDecimal benAnnlBal = BigDecimal.ZERO;
    private String benAnnlClass = "";
    private BigDecimal benAnnlLimit = BigDecimal.ZERO;
    private BigDecimal[] benDedOpt = new BigDecimal[100];
    private String benKey = "";
    private BigDecimal benPersAccRte = BigDecimal.ZERO;
    private BigDecimal benPersBal = BigDecimal.ZERO;
    private String benPersClass = "";
    private BigDecimal benPersLimit = BigDecimal.ZERO;
    private int[] benSeqNo = new int[100];
    private BigDecimal benSickAccRte = BigDecimal.ZERO;
    private BigDecimal benSickBal = BigDecimal.ZERO;
    private String benSickClass = "";
    private BigDecimal benSickLimit = BigDecimal.ZERO;
    private String calDedFlgs = "";
    private String[] ernCode = new String[50];
    private BigDecimal[] ernCppSum = new BigDecimal[50];
    private int ernDatePaidLst = 0;
    private BigDecimal[] ernEarnQtd = new BigDecimal[50];
    private BigDecimal[] ernEarnYtd = new BigDecimal[50];
    private BigDecimal ernErnYtdGross = BigDecimal.ZERO;
    private BigDecimal[] ernHrsQtd = new BigDecimal[50];
    private BigDecimal[] ernHrsYtd = new BigDecimal[50];
    private BigDecimal ernHrsYtdGross = BigDecimal.ZERO;
    private String ernKey = "";
    private BigDecimal[] ernTaxQtd = new BigDecimal[20];
    private BigDecimal[] ernTaxYtd = new BigDecimal[20];
    private BigDecimal ernTaxYtdCit = BigDecimal.ZERO;
    private BigDecimal ernTaxYtdFed = BigDecimal.ZERO;
    private BigDecimal ernTaxYtdFica = BigDecimal.ZERO;
    private BigDecimal ernTaxYtdLoc = BigDecimal.ZERO;
    private BigDecimal ernTaxYtdOth = BigDecimal.ZERO;
    private BigDecimal ernTaxYtdStt = BigDecimal.ZERO;
    private BigDecimal ernYtdAdveic = BigDecimal.ZERO;
    private BigDecimal[] hrsCppSum = new BigDecimal[50];
    private boolean taxExempt = false;
    private boolean taxKeyFound = false;
    private String[] taxName = new String[50];
    private boolean taxRoutineOk = false;
    private boolean addlTax = false;
    private boolean fedPctTax = false;
    private boolean fixedTax = false;
    private boolean lessTax = false;
    private boolean pctWageTax = false;
    private boolean piggyBackTax = false;
    private String depAcctType = "";
    private BigDecimal depAllotAmt = BigDecimal.ZERO;
    private String depBkAba = "";
    private String depBkAccount = "";
    private int depCheckDate = 0;
    private int depCheckNo = 0;
    private short depClientNo = (short)0;
    private int depDepositNo = 0;
    private String depEmpName = "";
    private int depEmpNo = 0;
    private String depPnFlag = "";
    private int depSeqNo = 0;
    private BigDecimal depTransAmt = BigDecimal.ZERO;
    private String depTransCode = "";
    private String depTransSign = "";
    private short gtnClientNo = (short)0;
    private int gtnEmpNo = 0;
    private int gtnEndDate = 0;
    private String gtnErrorType = "";
    private String gtnProfile = "";
    private int gtnSeqNo = 0;
    private String gtnText = "";
    private BigDecimal timHours = BigDecimal.ZERO;
    private BigDecimal timRate = BigDecimal.ZERO;
    private BigDecimal jjaapt = BigDecimal.ZERO;
    private BigDecimal jjabpt = BigDecimal.ZERO;
    private BigDecimal jjacpt = BigDecimal.ZERO;
    private BigDecimal jjadpt = BigDecimal.ZERO;
    private String jjbfnu = "";
    private String jjbhco = "";
    private String jjf7nu = "";
    private String ojacnu = "";
    private String ojbfnu = "";
    private BigDecimal ojewsb = BigDecimal.ZERO;
    private BigDecimal ojnlvu = BigDecimal.ZERO;
    private String ojt3co = "";
    private String[] dedTaxblTableSum = new String[165];
    private BigDecimal endMultiply = BigDecimal.ZERO;
    private String[] lvFlagsWs = new String[50];
    private boolean purgeOk = false;
    private String payrollCurrentTransRecord = "";
    private String payrollTaxTableRecord = "";
    private boolean taxKeyNotFound = false;
    private boolean taxRoutineError = false;
    private String[] taxSubGroup = new String[50];
    private int tb1Level = 0;
    private BigDecimal tblExemptAddlAmt = BigDecimal.ZERO;
    private String tblKey = "";
    private BigDecimal tblLowerWageLimit = BigDecimal.ZERO;
    private BigDecimal tblTaxLimitCpp = BigDecimal.ZERO;
    private String tcpBankCode = "";
    private int tcpBankComp = 0;
    private String tcpCorpGl = "";
    private String tcpJobClass = "";
    private String tcpUpdateYn = "";
    private int timCompNo = 0;
    private int timCorpNo = 0;
    private int timDeptNo = 0;
    private int timSeqNo = 0;
    private int timStoreNo = 0;
    private String workTimCode = "";
    private String wsMwTblCdeStKey = "";
    private String[] wsTblRecord = new String[100];

    // === WORKING STORAGE FIELDS ===
    private String gtnEnd = "N";                            // L:788 GTN-END
    private String optOk = "SPACES";                        // L:789 OPT-OK
    private String pctOpen = "N";                           // L:790 PCT-OPEN
    private BigDecimal timDateEndHold = BigDecimal.ZERO;    // L:791 TIM-DATE-END-HOLD
    private BigDecimal timCheckNoHold = BigDecimal.ZERO;    // L:792 TIM-CHECK-NO-HOLD
    private String timCheckTypeHold = "";                   // L:793 TIM-CHECK-TYPE-HOLD
    private String timCdeCycleHold = "";                    // L:794 TIM-CDE-CYCLE-HOLD
    private String timCodeHold = "";                        // L:795 TIM-CODE-HOLD
    private String holdPerTaxFlg = "";                      // L:796 HOLD-PER-TAX-FLG
    private BigDecimal holdDiffAmt = BigDecimal.ZERO;       // L:797 HOLD-DIFF-AMT
    private String holdDiffFlg = "";                        // L:798 HOLD-DIFF-FLG
    private BigDecimal holdMultiplier = BigDecimal.ZERO;    // L:799 HOLD-MULTIPLIER
    private String holdMarStatFed = "";                     // L:800 HOLD-MAR-STAT-FED
    private String holdMarStatStt = "";                     // L:801 HOLD-MAR-STAT-STT
    private String holdMarStatLoc = "";                     // L:802 HOLD-MAR-STAT-LOC
    private String holdMarStatCit = "";                     // L:803 HOLD-MAR-STAT-CIT
    private String holdMarStatOth = "";                     // L:804 HOLD-MAR-STAT-OTH
    private String perMarStatLoc = "";                      // L:805 PER-MAR-STAT-LOC
    private String perMarStatCit = "";                      // L:806 PER-MAR-STAT-CIT
    private String perMarStatOth = "";                      // L:807 PER-MAR-STAT-OTH
    private BigDecimal ernDedGrossWs = BigDecimal.ZERO;     // L:808 ERN-DED-GROSS-WS
    private BigDecimal njBaseWeekLimit = BigDecimal.ZERO;   // L:809 NJ-BASE-WEEK-LIMIT
    private BigDecimal paBaseWeekLimit = BigDecimal.ZERO;   // L:810 PA-BASE-WEEK-LIMIT
    private String taxCreditYn = "N";                       // L:811 TAX-CREDIT-YN
    private String editNet = "";                            // L:812 EDIT-NET
    private String taxParaYn = "N";                         // L:813 TAX-PARA-YN
    private BigDecimal taxAmtWs = BigDecimal.ZERO;          // L:814 TAX-AMT-WS
    private String wsGtnErr = "";                           // L:815 WS-GTN-ERR
    private BigDecimal wsBnkSeq = BigDecimal.ZERO;          // L:816 WS-BNK-SEQ
    private String dspAmt = "";                             // L:817 DSP-AMT
    private BigDecimal dspPct = BigDecimal.ZERO;            // L:818 DSP-PCT
    private String ans = "SPACES";                          // L:819 ANS
    private String postOptCode = "SPACES";                  // L:820 POST-OPT-CODE
    private String chkPurgeYn = "SPACES";                   // L:821 CHK-PURGE-YN
    private String cClientEnv = "SPACES";                   // L:822 C-CLIENT-ENV
    private BigDecimal wkBdeNewArrearsCounter = BigDecimal.ZERO;// L:823 WK-BDE-NEW-ARREARS-COUNTER
    private String expandDedArrearsSw = "SPACE";            // L:824 EXPAND-DED-ARREARS-SW
    private BigDecimal wsFdDedAmtToTake = BigDecimal.ZERO;  // L:825 WS-FD-DED-AMT-TO-TAKE
    private String savedTcpDirDepVoucher = "";              // L:826 SAVED-TCP-DIR-DEP-VOUCHER
    private BigDecimal savedTcpSeqNo = BigDecimal.ZERO;     // L:828 SAVED-TCP-SEQ-NO
    private String wsCaller = "";                           // L:829 WS-CALLER
    private String ioOk = "00";                             // L:832 IO-OK
    private String ioFileFull = "24";                       // L:833 IO-FILE-FULL
    private String ioAtEnd = "10";                          // L:834 IO-AT-END
    private String ioDupKey = "22";                         // L:835 IO-DUP-KEY
    private String ioBadKey = "23";                         // L:836 IO-BAD-KEY
    private String ioBusy = "9D";                           // L:837 IO-BUSY
    private String xprogName = "IFPR321";                   // L:839 XPROG-NAME
    private BigDecimal cpuTime = BigDecimal.ZERO;           // L:840 CPU-TIME
    private String recOk = "";                              // L:844 REC-OK
    private String benStat = "";                            // L:845 BEN-STAT
    private String clnStat = "";                            // L:846 CLN-STAT
    private String cnlStat = "";                            // L:847 CNL-STAT
    private String ernStat = "";                            // L:848 ERN-STAT
    private String perStat = "";                            // L:849 PER-STAT
    private String tblStat = "";                            // L:850 TBL-STAT
    private String timStat = "";                            // L:851 TIM-STAT
    private String tcpStat = "";                            // L:852 TCP-STAT
    private String calStat = "";                            // L:853 CAL-STAT
    private String saveStat = "";                           // L:854 SAVE-STAT
    private String fsw = "";                                // L:855 FSW
    private String okFlag = "";                             // L:856 OK-FLAG
    private String taxRoutineFlag = "";                     // L:859 TAX-ROUTINE-FLAG
    private String taxKeyFlag = "";                         // L:862 TAX-KEY-FLAG
    private String setArrFlag = "";                         // L:865 SET-ARR-FLAG
    private String dedRoutineFlag = "";                     // L:868 DED-ROUTINE-FLAG
    private String okLit = "OK";                            // L:872 OK-LIT
    private String notOkLit = "NO";                         // L:873 NOT-OK-LIT
    private String purgeFlag = "";                          // L:874 PURGE-FLAG
    private BigDecimal empCount = BigDecimal.ZERO;          // L:877 EMP-COUNT
    private String wsCycleDefault = "WK";                   // L:878 WS-CYCLE-DEFAULT
    private String fedLiteral = "FWT ";                     // L:883 FED-LITERAL
    private String sttLiteral = "SPACES";                   // L:885 STT-LITERAL
    private String locLiteral = "SPACES";                   // L:887 LOC-LITERAL
    private String citLiteral = "SPACES";                   // L:888 CIT-LITERAL
    private String othLiteral = "SPACES";                   // L:889 OTH-LITERAL
    private String ficaLiteral = "FICA";                    // L:890 FICA-LITERAL
    private String eicLiteral = "EIC";                      // L:891 EIC-LITERAL
    private String[] cnlNoWs = new String[201];             // L:912 CNL-NO-WS
    private String[][] cnlTypeWs = new String[201][10];     // L:914 CNL-TYPE-WS
    private String[] cnlFreqWs = new String[201];           // L:915 CNL-FREQ-WS
    private BigDecimal[] cnlOrderWs = new BigDecimal[201];  // L:916 CNL-ORDER-WS
    private String[] cnlSetArrWs = new String[201];         // L:917 CNL-SET-ARR-WS
    private String[] cnlAssocDedNoWs = new String[201];     // L:918 CNL-ASSOC-DED-NO-WS
    private String[] cnlTaxblFedWs = new String[201];       // L:920 CNL-TAXBL-FED-WS
    private String[] cnlTaxblSttWs = new String[201];       // L:921 CNL-TAXBL-STT-WS
    private String[] cnlTaxblLocWs = new String[201];       // L:922 CNL-TAXBL-LOC-WS
    private String[] cnlTaxblCitWs = new String[201];       // L:923 CNL-TAXBL-CIT-WS
    private String[] cnlTaxblOthWs = new String[201];       // L:924 CNL-TAXBL-OTH-WS
    private String[] cnlTaxblFicaWs = new String[201];      // L:925 CNL-TAXBL-FICA-WS
    private String[] cnlTaxblEicWs = new String[201];       // L:926 CNL-TAXBL-EIC-WS
    private String[] cnlActFlgWs = new String[201];         // L:927 CNL-ACT-FLG-WS
    private String[] cnlYtdPrtWs = new String[201];         // L:928 CNL-YTD-PRT-WS
    private BigDecimal[] cnlOptNoWs = new BigDecimal[201];  // L:929 CNL-OPT-NO-WS
    private BigDecimal[] cnlL1PctWs = new BigDecimal[201];  // L:930 CNL-L1-PCT-WS
    private BigDecimal[] cnlL1MatWs = new BigDecimal[201];  // L:931 CNL-L1-MAT-WS
    private BigDecimal[] cnlL2PctWs = new BigDecimal[201];  // L:932 CNL-L2-PCT-WS
    private BigDecimal[] cnlL2MatWs = new BigDecimal[201];  // L:933 CNL-L2-MAT-WS
    private BigDecimal[] cnlMaxArrears = new BigDecimal[201];// L:934 CNL-MAX-ARREARS
    private String wkDedTaken = "";                         // L:936 WK-DED-TAKEN
    private String bwDedTaken = "";                         // L:938 BW-DED-TAKEN
    private String smDedTaken = "";                         // L:940 SM-DED-TAKEN
    private String mtDedTaken = "";                         // L:942 MT-DED-TAKEN
    private String wsDedFlgs = "";                          // L:945 WS-DED-FLGS
    private String wsDedCycWk = "";                         // L:947 WS-DED-CYC-WK
    private String wsDedCycBw = "";                         // L:948 WS-DED-CYC-BW
    private String wsDedCycSm = "";                         // L:949 WS-DED-CYC-SM
    private String wsDedCycMt = "";                         // L:950 WS-DED-CYC-MT
    private BigDecimal wsDateEnd = BigDecimal.ZERO;         // L:951 WS-DATE-END
    private BigDecimal wsDateEndPacked = BigDecimal.ZERO;   // L:952 WS-DATE-END-PACKED
    private BigDecimal wsDateCheck = BigDecimal.ZERO;       // L:953 WS-DATE-CHECK
    private BigDecimal wsDateCheckPacked = BigDecimal.ZERO; // L:954 WS-DATE-CHECK-PACKED
    private String skipPurgeVerify = "";                    // L:955 SKIP-PURGE-VERIFY
    private String skipDirDep = "";                         // L:956 SKIP-DIR-DEP
    private String wcTaxOptWs = "";                         // L:957 WC-TAX-OPT-WS
    private String ficaOnlyOptWs = "";                      // L:958 FICA-ONLY-OPT-WS
    private String clnSetArrOptWs = "";                     // L:959 CLN-SET-ARR-OPT-WS
    private BigDecimal clnBenDeductOptWs = BigDecimal.ZERO; // L:960 CLN-BEN-DEDUCT-OPT-WS
    private BigDecimal clnBaDeductOptWs = BigDecimal.ZERO;  // L:961 CLN-BA-DEDUCT-OPT-WS
    private String clnDirdepWaitOptWs = "";                 // L:962 CLN-DIRDEP-WAIT-OPT-WS
    private String clnDirdepVoucherOptWs = "";              // L:963 CLN-DIRDEP-VOUCHER-OPT-WS
    private String clnShift1To2OptWs = "";                  // L:964 CLN-SHIFT-1-TO-2-OPT-WS
    private String clnShift1To3OptWs = "";                  // L:965 CLN-SHIFT-1-TO-3-OPT-WS
    private String clnShift1ToAllOptWs = "";                // L:966 CLN-SHIFT-1-TO-ALL-OPT-WS
    private String clnDeptLaborFwwOptWs = "";               // L:967 CLN-DEPT-LABOR-FWW-OPT-WS
    private BigDecimal clnGrossLimitOptWs = BigDecimal.ZERO;// L:968 CLN-GROSS-LIMIT-OPT-WS
    private BigDecimal clnHoursLimitOptWs = BigDecimal.ZERO;// L:969 CLN-HOURS-LIMIT-OPT-WS
    private BigDecimal grossNetErrorCntWs = BigDecimal.ZERO;// L:970 GROSS-NET-ERROR-CNT-WS
    private String cln4K90RegOptWs = "SPACE";               // L:971 CLN-4K90-REG-OPT-WS
    private BigDecimal clnXsickSeq01 = BigDecimal.ZERO;     // L:972 CLN-XSICK-SEQ01
    private BigDecimal clnXsickSeq02 = BigDecimal.ZERO;     // L:973 CLN-XSICK-SEQ02
    private BigDecimal clnXsickSeq03 = BigDecimal.ZERO;     // L:974 CLN-XSICK-SEQ03
    private BigDecimal clnXsickSeq04 = BigDecimal.ZERO;     // L:975 CLN-XSICK-SEQ04
    private BigDecimal clnXsickSeq05 = BigDecimal.ZERO;     // L:976 CLN-XSICK-SEQ05
    private BigDecimal clnXsickSeq06 = BigDecimal.ZERO;     // L:977 CLN-XSICK-SEQ06
    private BigDecimal clnXsickSeq07 = BigDecimal.ZERO;     // L:978 CLN-XSICK-SEQ07
    private BigDecimal clnXsickSeq08 = BigDecimal.ZERO;     // L:979 CLN-XSICK-SEQ08
    private BigDecimal clnXsickSeq09 = BigDecimal.ZERO;     // L:980 CLN-XSICK-SEQ09
    private BigDecimal clnXsickSeq10 = BigDecimal.ZERO;     // L:981 CLN-XSICK-SEQ10
    private BigDecimal clnCtLeaveLimit = BigDecimal.ZERO;   // L:982 CLN-CT-LEAVE-LIMIT
    private String clnOpt62Ws = "SPACE";                    // L:983 CLN-OPT62-WS
    private String wsCliOpt608Sw = "SPACE";                 // L:984 WS-CLI-OPT-608-SW
    private BigDecimal wk608SickAcrdTotal = BigDecimal.ZERO;// L:985 WK-608-SICK-ACRD-TOTAL
    private BigDecimal wk608SickAcrdDiff = BigDecimal.ZERO; // L:986 WK-608-SICK-ACRD-DIFF
    private String wsCliOpt630Sw = "SPACE";                 // L:987 WS-CLI-OPT-630-SW
    private String[] cn1NoWs = new String[30];              // L:992 CN1-NO-WS
    private BigDecimal[] cn1OptNoWs = new BigDecimal[30];   // L:993 CN1-OPT-NO-WS
    private BigDecimal brkClientNo = BigDecimal.ZERO;       // L:997 BRK-CLIENT-NO
    private BigDecimal brkEmpNo = BigDecimal.ZERO;          // L:998 BRK-EMP-NO
    private BigDecimal brkCorpWrk = BigDecimal.ZERO;        // L:999 BRK-CORP-WRK
    private BigDecimal brkStoreWrk = BigDecimal.ZERO;       // L:1000 BRK-STORE-WRK
    private BigDecimal brkDeptWrk = BigDecimal.ZERO;        // L:1001 BRK-DEPT-WRK
    private String brkCheckType = "";                       // L:1002 BRK-CHECK-TYPE
    private BigDecimal brkCheckNo = BigDecimal.ZERO;        // L:1003 BRK-CHECK-NO
    private BigDecimal brkDateEnd = BigDecimal.ZERO;        // L:1004 BRK-DATE-END
    private BigDecimal im = BigDecimal.ZERO;                // L:1005 IM
    private BigDecimal jm = BigDecimal.ZERO;                // L:1006 JM
    private BigDecimal i = BigDecimal.ZERO;                 // L:1007 I
    private BigDecimal j = BigDecimal.ZERO;                 // L:1008 J
    private BigDecimal k = BigDecimal.ZERO;                 // L:1009 K
    private BigDecimal l = BigDecimal.ZERO;                 // L:1010 L
    private BigDecimal m = BigDecimal.ZERO;                 // L:1011 M
    private BigDecimal s = BigDecimal.ZERO;                 // L:1012 S
    private BigDecimal pctNdx = BigDecimal.ZERO;            // L:1013 PCT-NDX
    private BigDecimal dedSub = BigDecimal.ZERO;            // L:1014 DED-SUB
    private BigDecimal depSub = BigDecimal.ZERO;            // L:1015 DEP-SUB
    private BigDecimal cnlSub = BigDecimal.ZERO;            // L:1016 CNL-SUB
    private BigDecimal sub = BigDecimal.ZERO;               // L:1017 SUB
    private String endOfQtr = "N";                          // L:1018 END-OF-QTR
    private String endOfYr = "N";                           // L:1019 END-OF-YR
    private String cnlParaYn = "N";                         // L:1020 CNL-PARA-YN
    private String cnlActYn = "Y";                          // L:1021 CNL-ACT-YN
    private String wsBalFlg = "N";                          // L:1022 WS-BAL-FLG
    private String zeroYn = "Y";                            // L:1023 ZERO-YN
    private BigDecimal pctWs = BigDecimal.ZERO;             // L:1024 PCT-WS
    private BigDecimal totalWs = BigDecimal.ZERO;           // L:1025 TOTAL-WS
    private BigDecimal totRegWagesWs = BigDecimal.ZERO;     // L:1026 TOT-REG-WAGES-WS
    private BigDecimal totOvtWagesWs = BigDecimal.ZERO;     // L:1027 TOT-OVT-WAGES-WS
    private BigDecimal totRegHoursWs = BigDecimal.ZERO;     // L:1028 TOT-REG-HOURS-WS
    private BigDecimal totOvtHoursWs = BigDecimal.ZERO;     // L:1029 TOT-OVT-HOURS-WS
    private BigDecimal totEarnWs = BigDecimal.ZERO;         // L:1030 TOT-EARN-WS
    private BigDecimal pctTotEarnWs = BigDecimal.ZERO;      // L:1031 PCT-TOT-EARN-WS
    private BigDecimal holdTotEarnWs = BigDecimal.ZERO;     // L:1032 HOLD-TOT-EARN-WS
    private BigDecimal totEarnYtdWs = BigDecimal.ZERO;      // L:1033 TOT-EARN-YTD-WS
    private BigDecimal totHoursWs = BigDecimal.ZERO;        // L:1034 TOT-HOURS-WS
    private BigDecimal totDollarsWs = BigDecimal.ZERO;      // L:1035 TOT-DOLLARS-WS
    private BigDecimal dedAccYtdWs = BigDecimal.ZERO;       // L:1036 DED-ACC-YTD-WS
    private BigDecimal deductExemptAmtWs = BigDecimal.ZERO; // L:1037 DEDUCT-EXEMPT-AMT-WS
    private BigDecimal dependPayppdAmtWs = BigDecimal.ZERO; // L:1038 DEPEND-PAYPPD-AMT-WS
    private BigDecimal deductStdAmtWs = BigDecimal.ZERO;    // L:1039 DEDUCT-STD-AMT-WS
    private BigDecimal deductExemptAddlAmtWs = BigDecimal.ZERO;// L:1040 DEDUCT-EXEMPT-ADDL-AMT-WS
    private BigDecimal wsDedTktn = BigDecimal.ZERO;         // L:1042 WS-DED-TKTN
    private BigDecimal wsNoToTake = BigDecimal.ZERO;        // L:1044 WS-NO-TO-TAKE
    private BigDecimal wsNoTaken = BigDecimal.ZERO;         // L:1045 WS-NO-TAKEN
    private BigDecimal noToTakeWs = BigDecimal.ZERO;        // L:1046 NO-TO-TAKE-WS
    private BigDecimal dedAmtWs = BigDecimal.ZERO;          // L:1047 DED-AMT-WS
    private BigDecimal dedMaxWs = BigDecimal.ZERO;          // L:1048 DED-MAX-WS
    private BigDecimal dedAmtLvl1Ws = BigDecimal.ZERO;      // L:1049 DED-AMT-LVL1-WS
    private BigDecimal dedPctLvl1Ws = BigDecimal.ZERO;      // L:1050 DED-PCT-LVL1-WS
    private BigDecimal dedMatLvl1Ws = BigDecimal.ZERO;      // L:1051 DED-MAT-LVL1-WS
    private BigDecimal dedMaxLvl1Ws = BigDecimal.ZERO;      // L:1052 DED-MAX-LVL1-WS
    private BigDecimal dedAmtLvl2Ws = BigDecimal.ZERO;      // L:1053 DED-AMT-LVL2-WS
    private BigDecimal dedPctLvl2Ws = BigDecimal.ZERO;      // L:1054 DED-PCT-LVL2-WS
    private BigDecimal dedMatLvl2Ws = BigDecimal.ZERO;      // L:1055 DED-MAT-LVL2-WS
    private BigDecimal dedMaxLvl2Ws = BigDecimal.ZERO;      // L:1056 DED-MAX-LVL2-WS
    private BigDecimal dedPctWs = BigDecimal.ZERO;          // L:1058 DED-PCT-WS
    private BigDecimal totRegEarnWs = BigDecimal.ZERO;      // L:1059 TOT-REG-EARN-WS
    private String taxEntityCde = "";                       // L:1060 TAX-ENTITY-CDE
    private BigDecimal taxEntity = BigDecimal.ZERO;         // L:1061 TAX-ENTITY
    private String taxFlgWs = "";                           // L:1062 TAX-FLG-WS
    private String advEicTax = "";                          // L:1077 ADV-EIC-TAX
    private BigDecimal taxYtdFicaWs = BigDecimal.ZERO;      // L:1078 TAX-YTD-FICA-WS
    private BigDecimal taxYtdFicmWs = BigDecimal.ZERO;      // L:1079 TAX-YTD-FICM-WS
    private BigDecimal totTaxYtdWs = BigDecimal.ZERO;       // L:1080 TOT-TAX-YTD-WS
    private BigDecimal ficaDistBalWs = BigDecimal.ZERO;     // L:1081 FICA-DIST-BAL-WS
    private BigDecimal emprDistBalWs = BigDecimal.ZERO;     // L:1082 EMPR-DIST-BAL-WS
    private BigDecimal tsaAmountWs = BigDecimal.ZERO;       // L:1083 TSA-AMOUNT-WS
    private BigDecimal baAmountWs = BigDecimal.ZERO;        // L:1085 BA-AMOUNT-WS
    private BigDecimal benAmountWs = BigDecimal.ZERO;       // L:1086 BEN-AMOUNT-WS
    private BigDecimal baPctWs = BigDecimal.ZERO;           // L:1087 BA-PCT-WS
    private BigDecimal teOptPctWs = BigDecimal.ZERO;        // L:1088 TE-OPT-PCT-WS
    private BigDecimal azPctWs = BigDecimal.ZERO;           // L:1089 AZ-PCT-WS
    private BigDecimal lowerWageLimitWs = BigDecimal.ZERO;  // L:1090 LOWER-WAGE-LIMIT-WS
    private BigDecimal pctExcessWageWs = BigDecimal.ZERO;   // L:1091 PCT-EXCESS-WAGE-WS
    private BigDecimal flatTaxAmtWs = BigDecimal.ZERO;      // L:1092 FLAT-TAX-AMT-WS
    private BigDecimal taxLimitYtdWs = BigDecimal.ZERO;     // L:1093 TAX-LIMIT-YTD-WS
    private BigDecimal wageLimitYtdWs = BigDecimal.ZERO;    // L:1094 WAGE-LIMIT-YTD-WS
    private BigDecimal taxLimitCppWs = BigDecimal.ZERO;     // L:1095 TAX-LIMIT-CPP-WS
    private BigDecimal annualWageWs = BigDecimal.ZERO;      // L:1096 ANNUAL-WAGE-WS
    private BigDecimal taxableWageWs = BigDecimal.ZERO;     // L:1097 TAXABLE-WAGE-WS
    private BigDecimal excessWageWs = BigDecimal.ZERO;      // L:1098 EXCESS-WAGE-WS
    private BigDecimal excessTaxWs = BigDecimal.ZERO;       // L:1099 EXCESS-TAX-WS
    private BigDecimal factorWs = BigDecimal.ZERO;          // L:1100 FACTOR-WS
    private BigDecimal premRateWs = BigDecimal.ZERO;        // L:1101 PREM-RATE-WS
    private BigDecimal rateWs = BigDecimal.ZERO;            // L:1102 RATE-WS
    private BigDecimal baseRteSalaryWs = BigDecimal.ZERO;   // L:1103 BASE-RTE-SALARY-WS
    private BigDecimal baseRteHourlyWs = BigDecimal.ZERO;   // L:1104 BASE-RTE-HOURLY-WS
    private BigDecimal baseRteOvrtmeWs = BigDecimal.ZERO;   // L:1105 BASE-RTE-OVRTME-WS
    private BigDecimal baseRteDistBalWs = BigDecimal.ZERO;  // L:1106 BASE-RTE-DIST-BAL-WS
    private BigDecimal baseHrsDistBalWs = BigDecimal.ZERO;  // L:1107 BASE-HRS-DIST-BAL-WS
    private BigDecimal cdeCycleNumWs = BigDecimal.ZERO;     // L:1108 CDE-CYCLE-NUM-WS
    private BigDecimal fwwHrsWs = BigDecimal.ZERO;          // L:1109 FWW-HRS-WS
    private String editAmt = "";                            // L:1110 EDIT-AMT
    private String saveTransactionRecord = "";              // L:1111 SAVE-TRANSACTION-RECORD
    private BigDecimal saveSeqNo = BigDecimal.ZERO;         // L:1112 SAVE-SEQ-NO
    private BigDecimal errEmpNo = BigDecimal.ZERO;          // L:1113 ERR-EMP-NO
    private BigDecimal errDateEnd = BigDecimal.ZERO;        // L:1114 ERR-DATE-END
    private BigDecimal ficaMedShrWs = BigDecimal.ZERO;      // L:1115 FICA-MED-SHR-WS
    private BigDecimal ficaFcaShrWs = BigDecimal.ZERO;      // L:1116 FICA-FCA-SHR-WS
    private BigDecimal ficaMedEmplrWs = BigDecimal.ZERO;    // L:1117 FICA-MED-EMPLR-WS
    private BigDecimal ficaFcaEmplrWs = BigDecimal.ZERO;    // L:1118 FICA-FCA-EMPLR-WS
    private BigDecimal ernTaxYtdFicm = BigDecimal.ZERO;     // L:1119 ERN-TAX-YTD-FICM
    private String lvCodesWs = "";                          // L:1123 LV-CODES-WS
    private BigDecimal totLvHrsWs = BigDecimal.ZERO;        // L:1129 TOT-LV-HRS-WS
    private BigDecimal annlBalWs = BigDecimal.ZERO;         // L:1130 ANNL-BAL-WS
    private BigDecimal accumHoursWs = BigDecimal.ZERO;      // L:1131 ACCUM-HOURS-WS
    private BigDecimal xsickHoursWs = BigDecimal.ZERO;      // L:1132 XSICK-HOURS-WS
    private BigDecimal accumHoursActualWs = BigDecimal.ZERO;// L:1133 ACCUM-HOURS-ACTUAL-WS
    private BigDecimal accumHrsLimitWs = BigDecimal.ZERO;   // L:1134 ACCUM-HRS-LIMIT-WS
    private BigDecimal accumHrsLimitYtdWs = BigDecimal.ZERO;// L:1135 ACCUM-HRS-LIMIT-YTD-WS
    private BigDecimal ytdLimitWs = BigDecimal.ZERO;        // L:1136 YTD-LIMIT-WS
    private BigDecimal totalAccruedWs = BigDecimal.ZERO;    // L:1137 TOTAL-ACCRUED-WS
    private BigDecimal totalAccruedYtdWs = BigDecimal.ZERO; // L:1138 TOTAL-ACCRUED-YTD-WS
    private BigDecimal mdMinStdDed = BigDecimal.ZERO;       // L:1145 MD-MIN-STD-DED
    private BigDecimal iaStdDedTier = BigDecimal.ZERO;      // L:1146 IA-STD-DED-TIER
    private BigDecimal paMoptLowWageLimit = BigDecimal.ZERO;// L:1147 PA-MOPT-LOW-WAGE-LIMIT
    private BigDecimal paCoptLowWageLimit = BigDecimal.ZERO;// L:1148 PA-COPT-LOW-WAGE-LIMIT
    private BigDecimal paEoptLowWageLimit = BigDecimal.ZERO;// L:1149 PA-EOPT-LOW-WAGE-LIMIT
    private BigDecimal paLoptLowWageLimit = BigDecimal.ZERO;// L:1150 PA-LOPT-LOW-WAGE-LIMIT
    private BigDecimal paSoptLowWageLimit = BigDecimal.ZERO;// L:1151 PA-SOPT-LOW-WAGE-LIMIT
    private BigDecimal paSopuLowWageLimit = BigDecimal.ZERO;// L:1152 PA-SOPU-LOW-WAGE-LIMIT
    private BigDecimal wiLowWageTaxRate = BigDecimal.ZERO;  // L:1153 WI-LOW-WAGE-TAX-RATE
    private BigDecimal moFedWithLimitS = BigDecimal.ZERO;   // L:1154 MO-FED-WITH-LIMIT-S
    private BigDecimal moFedWithLimitM = BigDecimal.ZERO;   // L:1155 MO-FED-WITH-LIMIT-M
    private BigDecimal orFedWithLimit = BigDecimal.ZERO;    // L:1156 OR-FED-WITH-LIMIT
    private BigDecimal tempOrFedWithLimit = BigDecimal.ZERO;// L:1157 TEMP-OR-FED-WITH-LIMIT
    private BigDecimal orFedDeductionAmt = BigDecimal.ZERO; // L:1158 OR-FED-DEDUCTION-AMT
    private BigDecimal wsOrSavedExemptAmt = BigDecimal.ZERO;// L:1159 WS-OR-SAVED-EXEMPT-AMT
    private BigDecimal wsOr2NdLevel = BigDecimal.ZERO;      // L:1160 WS-OR-2ND-LEVEL
    private BigDecimal moFedLimit = BigDecimal.ZERO;        // L:1161 MO-FED-LIMIT
    private BigDecimal orFedLimit = BigDecimal.ZERO;        // L:1162 OR-FED-LIMIT
    private BigDecimal azTaxMin = BigDecimal.ZERO;          // L:1163 AZ-TAX-MIN
    private BigDecimal ctTaxableWage = BigDecimal.ZERO;     // L:1164 CT-TAXABLE-WAGE
    private BigDecimal ctStateTax = BigDecimal.ZERO;        // L:1165 CT-STATE-TAX
    private BigDecimal ctStateTaxRemain = BigDecimal.ZERO;  // L:1166 CT-STATE-TAX-REMAIN
    private BigDecimal ctPayPrdsRemain = BigDecimal.ZERO;   // L:1167 CT-PAY-PRDS-REMAIN
    private BigDecimal wsCurrentPeriod = BigDecimal.ZERO;   // L:1168 WS-CURRENT-PERIOD
    private BigDecimal ctStdDeductAmt = BigDecimal.ZERO;    // L:1169 CT-STD-DEDUCT-AMT
    private BigDecimal msStateTaxWhole = BigDecimal.ZERO;   // L:1170 MS-STATE-TAX-WHOLE
    private BigDecimal okStateTaxWhole = BigDecimal.ZERO;   // L:1171 OK-STATE-TAX-WHOLE
    private BigDecimal wsCnlMaxArrears = BigDecimal.ZERO;   // L:1172 WS-CNL-MAX-ARREARS
    private BigDecimal dedAmtWsFd = BigDecimal.ZERO;        // L:1173 DED-AMT-WS-FD
    private BigDecimal fdCount = BigDecimal.ZERO;           // L:1174 FD-COUNT
    private BigDecimal genericTaxWhole = BigDecimal.ZERO;   // L:1175 GENERIC-TAX-WHOLE
    private String wsRoundTaxAmountSw = "";                 // L:1176 WS-ROUND-TAX-AMOUNT-SW
    private BigDecimal wsPaytblpf01Level = BigDecimal.ZERO; // L:1177 WS-PAYTBLPF01-LEVEL
    private BigDecimal wsPaytblpf01TaxOption = BigDecimal.ZERO;// L:1178 WS-PAYTBLPF01-TAX-OPTION
    private BigDecimal wsPaytblpf01TaxOptValue1 = BigDecimal.ZERO;// L:1179 WS-PAYTBLPF01-TAX-OPT-VALUE1
    private String wsPaytblpf01TaxOptCode1 = "";            // L:1180 WS-PAYTBLPF01-TAX-OPT-CODE1
    private BigDecimal wsPaytblpf01XtraExemptAmt1 = BigDecimal.ZERO;// L:1181 WS-PAYTBLPF01-XTRA-EXEMPT-AMT1
    private BigDecimal wsPaytblpf01XtraExemptCnt1 = BigDecimal.ZERO;// L:1182 WS-PAYTBLPF01-XTRA-EXEMPT-CNT1
    private BigDecimal wsPaytblpf01TaxOptValue2 = BigDecimal.ZERO;// L:1183 WS-PAYTBLPF01-TAX-OPT-VALUE2
    private String wsPaytblpf01TaxOptCode2 = "";            // L:1184 WS-PAYTBLPF01-TAX-OPT-CODE2
    private BigDecimal wsPaytblpf01XtraExemptAmt2 = BigDecimal.ZERO;// L:1185 WS-PAYTBLPF01-XTRA-EXEMPT-AMT2
    private BigDecimal wsPaytblpf01XtraExemptCnt2 = BigDecimal.ZERO;// L:1186 WS-PAYTBLPF01-XTRA-EXEMPT-CNT2
    private BigDecimal wsOrPaytblpf01Level = BigDecimal.ZERO;// L:1187 WS-OR-PAYTBLPF01-LEVEL
    private BigDecimal wsOrPaytblpf01TaxOption = BigDecimal.ZERO;// L:1188 WS-OR-PAYTBLPF01-TAX-OPTION
    private BigDecimal wsOrPaytblpf01TaxOptVal1 = BigDecimal.ZERO;// L:1189 WS-OR-PAYTBLPF01-TAX-OPT-VAL1
    private String wsOrPaytblpf01TaxOptCode1 = "";          // L:1190 WS-OR-PAYTBLPF01-TAX-OPT-CODE1
    private BigDecimal wsOrFlatTaxAdjAmt = BigDecimal.ZERO; // L:1191 WS-OR-FLAT-TAX-ADJ-AMT
    private BigDecimal wsAlPaytblpf01Level = BigDecimal.ZERO;// L:1192 WS-AL-PAYTBLPF01-LEVEL
    private BigDecimal wsAlPaytblpf01TaxOption = BigDecimal.ZERO;// L:1193 WS-AL-PAYTBLPF01-TAX-OPTION
    private BigDecimal wsAlPaytblpf01TaxOptVal1 = BigDecimal.ZERO;// L:1194 WS-AL-PAYTBLPF01-TAX-OPT-VAL1
    private String wsAlPaytblpf01TaxOptCode1 = "";          // L:1195 WS-AL-PAYTBLPF01-TAX-OPT-CODE1
    private BigDecimal wsAlExemptAmt = BigDecimal.ZERO;     // L:1196 WS-AL-EXEMPT-AMT
    private BigDecimal mdGrossEarnWs = BigDecimal.ZERO;     // L:1197 MD-GROSS-EARN-WS
    private BigDecimal maGrossEarnWs = BigDecimal.ZERO;     // L:1198 MA-GROSS-EARN-WS
    private BigDecimal maAnnualTaxCppFicaSum = BigDecimal.ZERO;// L:1199 MA-ANNUAL-TAX-CPP-FICA-SUM
    private BigDecimal maAnnualWage = BigDecimal.ZERO;      // L:1200 MA-ANNUAL-WAGE
    private String maZeroTaxYn = "";                        // L:1201 MA-ZERO-TAX-YN
    private BigDecimal w = BigDecimal.ZERO;                 // L:1205 W
    private BigDecimal w1 = BigDecimal.ZERO;                // L:1206 W1
    private BigDecimal w2 = BigDecimal.ZERO;                // L:1207 W2
    private BigDecimal w3 = BigDecimal.ZERO;                // L:1208 W3
    private BigDecimal sa = BigDecimal.ZERO;                // L:1209 SA
    private BigDecimal x = BigDecimal.ZERO;                 // L:1210 X
    private BigDecimal y = BigDecimal.ZERO;                 // L:1211 Y
    private BigDecimal n = BigDecimal.ZERO;                 // L:1212 N
    private BigDecimal a = BigDecimal.ZERO;                 // L:1213 A
    private BigDecimal b = BigDecimal.ZERO;                 // L:1214 B
    private BigDecimal e = BigDecimal.ZERO;                 // L:1215 E
    private BigDecimal f = BigDecimal.ZERO;                 // L:1216 F
    private BigDecimal p1 = BigDecimal.ZERO;                // L:1217 P1
    private BigDecimal p2 = BigDecimal.ZERO;                // L:1218 P2
    private BigDecimal p3 = BigDecimal.ZERO;                // L:1219 P3
    private BigDecimal ll1 = BigDecimal.ZERO;               // L:1220 LL1
    private BigDecimal ll2 = BigDecimal.ZERO;               // L:1221 LL2
    private BigDecimal ll3 = BigDecimal.ZERO;               // L:1222 LL3
    private String ws3TaxLevelsExist = "";                  // L:1224 WS-3-TAX-LEVELS-EXIST
    private BigDecimal wsFicaUprTaxLimitYtd = BigDecimal.ZERO;// L:1226 WS-FICA-UPR-TAX-LIMIT-YTD
    private BigDecimal wsFicaUprTaxLimitYtd1 = BigDecimal.ZERO;// L:1227 WS-FICA-UPR-TAX-LIMIT-YTD-1
    private BigDecimal wsFicaUprTaxLimitYtd2 = BigDecimal.ZERO;// L:1228 WS-FICA-UPR-TAX-LIMIT-YTD-2
    private BigDecimal wsFicaUprTaxLimitYtd3 = BigDecimal.ZERO;// L:1229 WS-FICA-UPR-TAX-LIMIT-YTD-3
    private BigDecimal wsFicaLwrTaxLimitYtd = BigDecimal.ZERO;// L:1230 WS-FICA-LWR-TAX-LIMIT-YTD
    private BigDecimal wsFicaLwrTaxLimitYtd1 = BigDecimal.ZERO;// L:1231 WS-FICA-LWR-TAX-LIMIT-YTD-1
    private BigDecimal wsFicaLwrTaxLimitYtd2 = BigDecimal.ZERO;// L:1232 WS-FICA-LWR-TAX-LIMIT-YTD-2
    private BigDecimal wsFicaLwrTaxLimitYtd3 = BigDecimal.ZERO;// L:1233 WS-FICA-LWR-TAX-LIMIT-YTD-3
    private BigDecimal wsFicaUprWageLimitYtd = BigDecimal.ZERO;// L:1234 WS-FICA-UPR-WAGE-LIMIT-YTD
    private BigDecimal wsFicaUprWageLimitYtd1 = BigDecimal.ZERO;// L:1235 WS-FICA-UPR-WAGE-LIMIT-YTD-1
    private BigDecimal wsFicaUprWageLimitYtd2 = BigDecimal.ZERO;// L:1236 WS-FICA-UPR-WAGE-LIMIT-YTD-2
    private BigDecimal wsFicaUprWageLimitYtd3 = BigDecimal.ZERO;// L:1237 WS-FICA-UPR-WAGE-LIMIT-YTD-3
    private BigDecimal wsFicaLwrWageLimitYtd = BigDecimal.ZERO;// L:1238 WS-FICA-LWR-WAGE-LIMIT-YTD
    private BigDecimal wsFicaLwrWageLimitYtd1 = BigDecimal.ZERO;// L:1239 WS-FICA-LWR-WAGE-LIMIT-YTD-1
    private BigDecimal wsFicaLwrWageLimitYtd2 = BigDecimal.ZERO;// L:1240 WS-FICA-LWR-WAGE-LIMIT-YTD-2
    private BigDecimal wsFicaLwrWageLimitYtd3 = BigDecimal.ZERO;// L:1241 WS-FICA-LWR-WAGE-LIMIT-YTD-3
    private BigDecimal wsFicaUprPercent = BigDecimal.ZERO;  // L:1243 WS-FICA-UPR-PERCENT
    private BigDecimal wsFicaUprPercent1 = BigDecimal.ZERO; // L:1244 WS-FICA-UPR-PERCENT-1
    private BigDecimal wsFicaUprPercent2 = BigDecimal.ZERO; // L:1245 WS-FICA-UPR-PERCENT-2
    private BigDecimal wsFicaUprPercent3 = BigDecimal.ZERO; // L:1246 WS-FICA-UPR-PERCENT-3
    private BigDecimal wsFicaLwrPercent = BigDecimal.ZERO;  // L:1247 WS-FICA-LWR-PERCENT
    private BigDecimal wsFicaLwrPercent2 = BigDecimal.ZERO; // L:1248 WS-FICA-LWR-PERCENT-2
    private BigDecimal wsFicaLwrPercent3 = BigDecimal.ZERO; // L:1249 WS-FICA-LWR-PERCENT-3
    private BigDecimal wsFicmUprTaxLimitYtd = BigDecimal.ZERO;// L:1250 WS-FICM-UPR-TAX-LIMIT-YTD
    private BigDecimal wsFicmLwrTaxLimitYtd = BigDecimal.ZERO;// L:1251 WS-FICM-LWR-TAX-LIMIT-YTD
    private BigDecimal wsFicmUprWageLimitYtd = BigDecimal.ZERO;// L:1252 WS-FICM-UPR-WAGE-LIMIT-YTD
    private BigDecimal wsFicmLwrWageLimitYtd = BigDecimal.ZERO;// L:1253 WS-FICM-LWR-WAGE-LIMIT-YTD
    private BigDecimal wsFicmUprPercent = BigDecimal.ZERO;  // L:1255 WS-FICM-UPR-PERCENT
    private BigDecimal wsFicmLwrPercent = BigDecimal.ZERO;  // L:1256 WS-FICM-LWR-PERCENT
    private BigDecimal wsFicmYtd = BigDecimal.ZERO;         // L:1258 WS-FICM-YTD
    private BigDecimal wsMinWageRteHourly = BigDecimal.ZERO;// L:1260 WS-MIN-WAGE-RTE-HOURLY
    private BigDecimal tblRem = BigDecimal.ZERO;            // L:1261 TBL-REM
    private BigDecimal tblCnt = BigDecimal.ZERO;            // L:1262 TBL-CNT
    private BigDecimal wsTblIdxLimit = BigDecimal.ZERO;     // L:1263 WS-TBL-IDX-LIMIT
    private String[] wsCdeTax = new String[6000];           // L:1269 WS-CDE-TAX
    private String[] wsMarStatus = new String[6000];        // L:1270 WS-MAR-STATUS
    private BigDecimal[] wsLevel = new BigDecimal[6000];    // L:1271 WS-LEVEL
    private BigDecimal[] wsLowerWageLimit = new BigDecimal[6000];// L:1272 WS-LOWER-WAGE-LIMIT
    private BigDecimal[] wsPctExcessWage = new BigDecimal[6000];// L:1274 WS-PCT-EXCESS-WAGE
    private BigDecimal[] wsFlatTaxAmt = new BigDecimal[6000];// L:1275 WS-FLAT-TAX-AMT
    private BigDecimal[] wsExemptAmt = new BigDecimal[6000];// L:1276 WS-EXEMPT-AMT
    private BigDecimal[] wsStdDedAmt = new BigDecimal[6000];// L:1277 WS-STD-DED-AMT
    private BigDecimal[] wsStdDedPct = new BigDecimal[6000];// L:1279 WS-STD-DED-PCT
    private BigDecimal[] wsUnempLimit = new BigDecimal[6000];// L:1280 WS-UNEMP-LIMIT
    private BigDecimal[] wsTaxLimitYtd = new BigDecimal[6000];// L:1281 WS-TAX-LIMIT-YTD
    private BigDecimal[] wsWageLimitYtd = new BigDecimal[6000];// L:1282 WS-WAGE-LIMIT-YTD
    private BigDecimal[] wsTaxLimitCpp = new BigDecimal[6000];// L:1283 WS-TAX-LIMIT-CPP
    private BigDecimal[] wsExemptAddlAmt = new BigDecimal[6000];// L:1284 WS-EXEMPT-ADDL-AMT
    private String[] wsTaxCreditYn = new String[6000];      // L:1285 WS-TAX-CREDIT-YN
    private BigDecimal wsStateMinWageRteHourly = BigDecimal.ZERO;// L:1287 WS-STATE-MIN-WAGE-RTE-HOURLY
    private BigDecimal wsStateMinWageHoursDiff = BigDecimal.ZERO;// L:1288 WS-STATE-MIN-WAGE-HOURS-DIFF
    private BigDecimal wsGrossHoursMultByHrRate = BigDecimal.ZERO;// L:1289 WS-GROSS-HOURS-MULT-BY-HR-RATE
    private BigDecimal wsGrossHoursMultByStMin = BigDecimal.ZERO;// L:1290 WS-GROSS-HOURS-MULT-BY-ST-MIN
    private String wsMwTblCdeTax = "";                      // L:1292 WS-MW-TBL-CDE-TAX
    private String wsMwTblMarStatus = "";                   // L:1293 WS-MW-TBL-MAR-STATUS
    private String wsMwSttLiteral = "SPACES";               // L:1294 WS-MW-STT-LITERAL
    private String wsClientDedOpt36Sw = "N";                // L:1297 WS-CLIENT-DED-OPT-36-SW
    private String wsClientDedOpt30Sw = "N";                // L:1298 WS-CLIENT-DED-OPT-30-SW
    private String wsDedWithOpt36FoundSw = "N";             // L:1299 WS-DED-WITH-OPT-36-FOUND-SW
    private String wsDedWithOpt35FoundSw = "N";             // L:1300 WS-DED-WITH-OPT-35-FOUND-SW
    private String wsSalEmpNoHrsSw = "N";                   // L:1301 WS-SAL-EMP-NO-HRS-SW
    private BigDecimal wsFdAdjustedAmt = BigDecimal.ZERO;   // L:1302 WS-FD-ADJUSTED-AMT
    private BigDecimal wsDedOpt35Value = BigDecimal.ZERO;   // L:1303 WS-DED-OPT-35-VALUE
    private String cdeTax13 = "";                           // L:1308 CDE-TAX-13
    private String cdeTax4 = "";                            // L:1309 CDE-TAX-4
    private String cdeMarStatusWs = "";                     // L:1310 CDE-MAR-STATUS-WS
    private String tempCdeMarStatusWs = "";                 // L:1312 TEMP-CDE-MAR-STATUS-WS
    private String orMarStatusChangeSw = "";                // L:1313 OR-MAR-STATUS-CHANGE-SW
    private String savCdeTaxWs = "";                        // L:1315 SAV-CDE-TAX-WS
    private String timCode4 = "";                           // L:1319 TIM-CODE-4
    private BigDecimal holdTaxPara = BigDecimal.ZERO;       // L:1322 HOLD-TAX-PARA
    private BigDecimal holdCppFica = BigDecimal.ZERO;       // L:1325 HOLD-CPP-FICA
    private BigDecimal holdCppFicm = BigDecimal.ZERO;       // L:1328 HOLD-CPP-FICM
    private BigDecimal wsPerExmFed = BigDecimal.ZERO;       // L:1334 WS-PER-EXM-FED
    private BigDecimal wsPerExmStt = BigDecimal.ZERO;       // L:1335 WS-PER-EXM-STT
    private BigDecimal wsPerExmLoc = BigDecimal.ZERO;       // L:1336 WS-PER-EXM-LOC
    private BigDecimal wsPerExmCit = BigDecimal.ZERO;       // L:1337 WS-PER-EXM-CIT
    private BigDecimal wsPerExmOth = BigDecimal.ZERO;       // L:1338 WS-PER-EXM-OTH
    private BigDecimal wsPerExmFica = BigDecimal.ZERO;      // L:1339 WS-PER-EXM-FICA
    private BigDecimal wsPerExmEic = BigDecimal.ZERO;       // L:1340 WS-PER-EXM-EIC
    private String clientNoO = "";                          // L:1343 CLIENT-NO-O
    private String empNoO = "";                             // L:1345 EMP-NO-O
    private BigDecimal corpWrkO = BigDecimal.ZERO;          // L:1347 CORP-WRK-O
    private BigDecimal storeWrkO = BigDecimal.ZERO;         // L:1349 STORE-WRK-O
    private BigDecimal deptWrkO = BigDecimal.ZERO;          // L:1351 DEPT-WRK-O
    private String messageO = "";                           // L:1353 MESSAGE-O
    private BigDecimal[] corpWrkTrn = new BigDecimal[33];   // L:1357 CORP-WRK-TRN
    private BigDecimal[] storeWrkTrn = new BigDecimal[33];  // L:1358 STORE-WRK-TRN
    private BigDecimal[] deptWrkTrn = new BigDecimal[33];   // L:1359 DEPT-WRK-TRN
    private String[] typeTrn = new String[33];              // L:1360 TYPE-TRN
    private String[] codeTrn = new String[33];              // L:1361 CODE-TRN
    private BigDecimal[] hoursTrn = new BigDecimal[33];     // L:1362 HOURS-TRN
    private BigDecimal[] rateTrn = new BigDecimal[33];      // L:1363 RATE-TRN
    private BigDecimal[] amountTrn = new BigDecimal[33];    // L:1364 AMOUNT-TRN
    private BigDecimal[] seqTrn = new BigDecimal[33];       // L:1365 SEQ-TRN
    private BigDecimal[] corpWrkDist = new BigDecimal[33];  // L:1370 CORP-WRK-DIST
    private BigDecimal[] storeWrkDist = new BigDecimal[33]; // L:1371 STORE-WRK-DIST
    private BigDecimal[] deptWrkDist = new BigDecimal[33];  // L:1372 DEPT-WRK-DIST
    private BigDecimal[] hoursDist = new BigDecimal[33];    // L:1373 HOURS-DIST
    private BigDecimal[] amountDist = new BigDecimal[33];   // L:1374 AMOUNT-DIST
    private BigDecimal[] ficaDist = new BigDecimal[33];     // L:1375 FICA-DIST
    private BigDecimal[] emprDist = new BigDecimal[33];     // L:1376 EMPR-DIST
    private String[] ernCppFedTaxability = new String[35];  // L:1382 ERN-CPP-FED-TAXABILITY
    private String[] ernCppSttTaxability = new String[35];  // L:1383 ERN-CPP-STT-TAXABILITY
    private String[] ernCppCitTaxability = new String[35];  // L:1384 ERN-CPP-CIT-TAXABILITY
    private String[] ernCppLocTaxability = new String[35];  // L:1385 ERN-CPP-LOC-TAXABILITY
    private String[] ernCppOthTaxability = new String[35];  // L:1386 ERN-CPP-OTH-TAXABILITY
    private String[] ernCppFicaTaxability = new String[35]; // L:1387 ERN-CPP-FICA-TAXABILITY
    private String[] ernCppFutaTaxability = new String[35]; // L:1388 ERN-CPP-FUTA-TAXABILITY
    private String[] ernCppSucaTaxability = new String[35]; // L:1389 ERN-CPP-SUCA-TAXABILITY
    private BigDecimal ernCppNetSum = BigDecimal.ZERO;      // L:1396 ERN-CPP-NET-SUM
    private BigDecimal ernCppGrossSum = BigDecimal.ZERO;    // L:1397 ERN-CPP-GROSS-SUM
    private BigDecimal ernCppGrsLessTxSum = BigDecimal.ZERO;// L:1398 ERN-CPP-GRS-LESS-TX-SUM
    private BigDecimal hrsCppGrossSum = BigDecimal.ZERO;    // L:1405 HRS-CPP-GROSS-SUM
    private BigDecimal[] taxCppSum = new BigDecimal[7];     // L:1408 TAX-CPP-SUM
    private BigDecimal taxCppFedSum = BigDecimal.ZERO;      // L:1410 TAX-CPP-FED-SUM
    private BigDecimal taxCppSttSum = BigDecimal.ZERO;      // L:1411 TAX-CPP-STT-SUM
    private BigDecimal taxCppLocSum = BigDecimal.ZERO;      // L:1412 TAX-CPP-LOC-SUM
    private BigDecimal taxCppCitSum = BigDecimal.ZERO;      // L:1413 TAX-CPP-CIT-SUM
    private BigDecimal taxCppOthSum = BigDecimal.ZERO;      // L:1414 TAX-CPP-OTH-SUM
    private BigDecimal taxCppFicaSum = BigDecimal.ZERO;     // L:1416 TAX-CPP-FICA-SUM
    private BigDecimal taxCppEicSum = BigDecimal.ZERO;      // L:1417 TAX-CPP-EIC-SUM
    private BigDecimal taxCppFicmSum = BigDecimal.ZERO;     // L:1419 TAX-CPP-FICM-SUM
    private String[] dedNoSum = new String[165];            // L:1423 DED-NO-SUM
    private BigDecimal[] dedOrderNo = new BigDecimal[165];  // L:1424 DED-ORDER-NO
    private BigDecimal[] dedTblElementSum = new BigDecimal[165];// L:1425 DED-TBL-ELEMENT-SUM
    private BigDecimal[] dedSeqNoSum = new BigDecimal[165]; // L:1426 DED-SEQ-NO-SUM
    private String[] dedParaSum = new String[165];          // L:1427 DED-PARA-SUM
    private BigDecimal[] dedNoToTakeSum = new BigDecimal[165];// L:1428 DED-NO-TO-TAKE-SUM
    private BigDecimal[] dedNoTakenSum = new BigDecimal[165];// L:1429 DED-NO-TAKEN-SUM
    private BigDecimal[] dedArrsCtrSum = new BigDecimal[165];// L:1430 DED-ARRS-CTR-SUM
    private String[] dedSetArrSum = new String[165];        // L:1431 DED-SET-ARR-SUM
    private BigDecimal[] dedAmtSum = new BigDecimal[165];   // L:1432 DED-AMT-SUM
    private BigDecimal[] dedPctSum = new BigDecimal[165];   // L:1433 DED-PCT-SUM
    private BigDecimal[] dedBalSum = new BigDecimal[165];   // L:1434 DED-BAL-SUM
    private BigDecimal[] dedOptSum = new BigDecimal[165];   // L:1435 DED-OPT-SUM
    private BigDecimal[] dedAccYtdSum = new BigDecimal[165];// L:1436 DED-ACC-YTD-SUM
    private String[] dedAssocDedNoSum = new String[165];    // L:1437 DED-ASSOC-DED-NO-SUM
    private String[] dedErrSum = new String[165];           // L:1438 DED-ERR-SUM
    private String[] dedTaxblFed = new String[165];         // L:1443 DED-TAXBL-FED
    private String[] dedTaxblStt = new String[165];         // L:1444 DED-TAXBL-STT
    private String[] dedTaxblLoc = new String[165];         // L:1445 DED-TAXBL-LOC
    private String[] dedTaxblCit = new String[165];         // L:1446 DED-TAXBL-CIT
    private String[] dedTaxblOth = new String[165];         // L:1447 DED-TAXBL-OTH
    private String[] dedTaxblFica = new String[165];        // L:1448 DED-TAXBL-FICA
    private String[] dedTaxblEic = new String[165];         // L:1449 DED-TAXBL-EIC
    private String[] dedYtdPrtSum = new String[165];        // L:1450 DED-YTD-PRT-SUM
    private BigDecimal[] dedOptNoSum = new BigDecimal[165]; // L:1451 DED-OPT-NO-SUM
    private BigDecimal[] dedL1PctWs = new BigDecimal[165];  // L:1452 DED-L1-PCT-WS
    private BigDecimal[] dedL1MatWs = new BigDecimal[165];  // L:1453 DED-L1-MAT-WS
    private BigDecimal[] dedL2PctWs = new BigDecimal[165];  // L:1454 DED-L2-PCT-WS
    private BigDecimal[] dedL2MatWs = new BigDecimal[165];  // L:1455 DED-L2-MAT-WS
    private BigDecimal lvSickAccRteSum = BigDecimal.ZERO;   // L:1456 LV-SICK-ACC-RTE-SUM
    private BigDecimal lvAnnlAccRteSum = BigDecimal.ZERO;   // L:1457 LV-ANNL-ACC-RTE-SUM
    private BigDecimal lvPersAccRteSum = BigDecimal.ZERO;   // L:1458 LV-PERS-ACC-RTE-SUM
    private BigDecimal lvAccRteSum = BigDecimal.ZERO;       // L:1459 LV-ACC-RTE-SUM
    private BigDecimal[] bnkAbaNo = new BigDecimal[3];      // L:1461 BNK-ABA-NO
    private String[] bnkAcctType = new String[3];           // L:1462 BNK-ACCT-TYPE
    private String[] bnkPnFlag = new String[3];             // L:1463 BNK-PN-FLAG
    private String[] bnkAcct = new String[3];               // L:1464 BNK-ACCT
    private BigDecimal[] bnkDepAmt = new BigDecimal[3];     // L:1465 BNK-DEP-AMT
    private BigDecimal annlTaxblFed = BigDecimal.ZERO;      // L:1482 ANNL-TAXBL-FED
    private BigDecimal annlTaxblStt = BigDecimal.ZERO;      // L:1483 ANNL-TAXBL-STT
    private BigDecimal annlTaxblLoc = BigDecimal.ZERO;      // L:1484 ANNL-TAXBL-LOC
    private BigDecimal annlTaxblCit = BigDecimal.ZERO;      // L:1485 ANNL-TAXBL-CIT
    private BigDecimal annlTaxblOth = BigDecimal.ZERO;      // L:1486 ANNL-TAXBL-OTH
    private BigDecimal annlTaxblFica = BigDecimal.ZERO;     // L:1487 ANNL-TAXBL-FICA
    private BigDecimal annlTaxblEic = BigDecimal.ZERO;      // L:1488 ANNL-TAXBL-EIC
    private BigDecimal annlTaxblFicaYtd = BigDecimal.ZERO;  // L:1489 ANNL-TAXBL-FICA-YTD
    private String wcDedNo = "";                            // L:1502 WC-DED-NO
    private BigDecimal wcDedSeq = BigDecimal.ZERO;          // L:1503 WC-DED-SEQ
    private BigDecimal wcDedAmt = BigDecimal.ZERO;          // L:1504 WC-DED-AMT
    private BigDecimal wsProdHrs = BigDecimal.ZERO;         // L:1505 WS-PROD-HRS
    private BigDecimal wkOptTrnAmount = BigDecimal.ZERO;    // L:1507 WK-OPT-TRN-AMOUNT
    private BigDecimal wkOprTrnAmount = BigDecimal.ZERO;    // L:1508 WK-OPR-TRN-AMOUNT
    private String wkOptTaxCode = "";                       // L:1509 WK-OPT-TAX-CODE
    private String wkOprTaxCode = "";                       // L:1510 WK-OPR-TAX-CODE
    private BigDecimal fdErnCppGrsLessTxSum = BigDecimal.ZERO;// L:1512 FD-ERN-CPP-GRS-LESS-TX-SUM
    private BigDecimal theNumber = BigDecimal.ZERO;         // L:1515 THE-NUMBER
    private BigDecimal wholeNumber = BigDecimal.ZERO;       // L:1517 WHOLE-NUMBER
    private BigDecimal decimal = BigDecimal.ZERO;           // L:1518 DECIMAL
    private BigDecimal wholeNumberDiv100 = BigDecimal.ZERO; // L:1519 WHOLE-NUMBER-DIV-100
    private BigDecimal lowNumber = BigDecimal.ZERO;         // L:1520 LOW-NUMBER
    private BigDecimal midRange50 = BigDecimal.ZERO;        // L:1521 MID-RANGE-50
    private String masttrtn = "";                           // L:1527 MASTTRTN
    private BigDecimal mast01 = BigDecimal.ZERO;            // L:1529 MAST01
    private BigDecimal mast02 = BigDecimal.ZERO;            // L:1531 MAST02
    private BigDecimal mast03 = BigDecimal.ZERO;            // L:1533 MAST03
    private BigDecimal mast04 = BigDecimal.ZERO;            // L:1535 MAST04
    private BigDecimal mast05 = BigDecimal.ZERO;            // L:1537 MAST05
    private String mast06 = "SPACE";                        // L:1539 MAST06
    private String orrtn = "";                              // L:1546 ORRTN
    private String or0001 = "SPACE";                        // L:1548 OR0001
    private BigDecimal or0002 = BigDecimal.ZERO;            // L:1550 OR0002
    private String or0003 = "SPACE";                        // L:1552 OR0003
    private String or0004 = "SPACE";                        // L:1554 OR0004
    private String p0rtn = "";                              // L:1561 P0RTN
    private BigDecimal wp0001 = BigDecimal.ZERO;            // L:1563 WP0001
    private BigDecimal wp0002 = BigDecimal.ZERO;            // L:1565 WP0002
    private BigDecimal wp0003 = BigDecimal.ZERO;            // L:1567 WP0003
    private BigDecimal wp0004 = BigDecimal.ZERO;            // L:1569 WP0004
    private String wp0005 = "";                             // L:1571 WP0005
    private String w4rtn = "";                              // L:1577 W4RTN
    private BigDecimal w40001 = BigDecimal.ZERO;            // L:1579 W40001
    private BigDecimal w40002 = BigDecimal.ZERO;            // L:1581 W40002
    private BigDecimal w40003 = BigDecimal.ZERO;            // L:1583 W40003
    private String w40004 = "";                             // L:1585 W40004
    private String w40005 = "";                             // L:1587 W40005
    private String w40006 = "";                             // L:1589 W40006
    private String w40007 = "";                             // L:1591 W40007
    private BigDecimal w40008 = BigDecimal.ZERO;            // L:1593 W40008
    private BigDecimal w40009 = BigDecimal.ZERO;            // L:1595 W40009
    private BigDecimal w40010 = BigDecimal.ZERO;            // L:1597 W40010
    private BigDecimal w40011 = BigDecimal.ZERO;            // L:1599 W40011
    private String taxartn = "";                            // L:1604 TAXARTN
    private BigDecimal taxacln = BigDecimal.ZERO;           // L:1606 TAXACLN
    private String taxaern = "SPACES";                      // L:1608 TAXAERN
    private String taxafed = "SPACE";                       // L:1610 TAXAFED
    private String taxastt = "SPACE";                       // L:1612 TAXASTT
    private String taxacit = "SPACE";                       // L:1614 TAXACIT
    private String taxaloc = "SPACE";                       // L:1616 TAXALOC
    private String taxaoth = "SPACE";                       // L:1618 TAXAOTH
    private String taxafica = "SPACE";                      // L:1620 TAXAFICA
    private String taxafuta = "SPACE";                      // L:1622 TAXAFUTA
    private String taxasuca = "SPACE";                      // L:1624 TAXASUCA
    private String taxaerr = "SPACE";                       // L:1626 TAXAERR
    private String martn = "";                              // L:1628 MARTN
    private String ma0001 = "";                             // L:1629 MA0001
    private String ma0002 = "";                             // L:1630 MA0002
    private String ma0003 = "";                             // L:1631 MA0003
    private String ma0004 = "";                             // L:1632 MA0004
    private String cRetCode = "";                           // L:1636 C-RET-CODE
    private BigDecimal cClient = BigDecimal.ZERO;           // L:1637 C-CLIENT
    private short cComp = 0;                                // L:1638 C-COMP
    private BigDecimal cCorp = BigDecimal.ZERO;             // L:1639 C-CORP
    private BigDecimal cStore = BigDecimal.ZERO;            // L:1640 C-STORE
    private String cDed = "";                               // L:1641 C-DED
    private BigDecimal cRate = BigDecimal.ZERO;             // L:1642 C-RATE
    private BigDecimal cErnSeq = BigDecimal.ZERO;           // L:1643 C-ERN-SEQ
    private String cProdYn = "";                            // L:1644 C-PROD-YN
    private String cProfOpt = "";                           // L:1645 C-PROF-OPT
    private String cDataAreaName = "";                      // L:1646 C-DATA-AREA-NAME
    private String cPrelimProfile = "";                     // L:1647 C-PRELIM-PROFILE
    private String wsPrelimProfile = "";                    // L:1649 WS-PRELIM-PROFILE
    private String wsProf13 = "";                           // L:1652 WS-PROF-13
    private String prmClient = "";                          // L:1655 PRM-CLIENT
    private BigDecimal prmClientNo = BigDecimal.ZERO;       // L:1656 PRM-CLIENT-NO
    private String prmSeq = "";                             // L:1658 PRM-SEQ
    private BigDecimal prmSeqNo = BigDecimal.ZERO;          // L:1659 PRM-SEQ-NO
    private String parmProfile = "";                        // L:1662 PARM-PROFILE
    private String parmSeq = "";                            // L:1663 PARM-SEQ
    private String parmClient = "";                         // L:1664 PARM-CLIENT

    // === MISSING FIELDS (multi-line COBOL definitions) ===
    private BigDecimal[] nontaxbl = new BigDecimal[10];
    private BigDecimal[] annlTaxbl = new BigDecimal[10];
    private BigDecimal inc = BigDecimal.ZERO;
    private BigDecimal nontaxblFed = BigDecimal.ZERO;
    private BigDecimal nontaxblStt = BigDecimal.ZERO;
    private BigDecimal nontaxblLoc = BigDecimal.ZERO;
    private BigDecimal nontaxblCit = BigDecimal.ZERO;
    private BigDecimal nontaxblOth = BigDecimal.ZERO;
    private BigDecimal nontaxblFica = BigDecimal.ZERO;
    private BigDecimal nontaxblEic = BigDecimal.ZERO;
    private BigDecimal nontaxblFicaYtd = BigDecimal.ZERO;
    private BigDecimal ibmCt = BigDecimal.ZERO;
    private BigDecimal ernErnQtdNet = BigDecimal.ZERO;
    private BigDecimal ernErnYtdNet = BigDecimal.ZERO;

    // === GROUP STRUCTURES (Inner Classes) ===

    public static class PrCheckRun {                        // L:744 PR-CHECK-RUN
        // No child fields
    }

    public static class PrPriorPeriod {                     // L:750 PR-PRIOR-PERIOD
        // No child fields
    }

    public static class PrOptionPercent {                   // L:756 PR-OPTION-PERCENT
        // No child fields
    }

    public static class PrQtdYtdFicm {                      // L:762 PR-QTD-YTD-FICM
        // No child fields
    }

    public static class IoLiteralTables {                   // L:831 IO-LITERAL-TABLES
        public String ioOk = "00";                          // L:832 IO-OK
        public String ioFileFull = "24";                    // L:833 IO-FILE-FULL
        public String ioAtEnd = "10";                       // L:834 IO-AT-END
        public String ioDupKey = "22";                      // L:835 IO-DUP-KEY
        public String ioBadKey = "23";                      // L:836 IO-BAD-KEY
        public String ioBusy = "9D";                        // L:837 IO-BUSY
    }

    public static class WorkAreaNonVolatile {               // L:842 WORK-AREA-NON-VOLATILE
        public String okFlag = "";                          // L:856 OK-FLAG
        public String taxRoutineFlag = "";                  // L:859 TAX-ROUTINE-FLAG
        public String taxKeyFlag = "";                      // L:862 TAX-KEY-FLAG
        public String setArrFlag = "";                      // L:865 SET-ARR-FLAG
        public String dedRoutineFlag = "";                  // L:868 DED-ROUTINE-FLAG
        public String purgeFlag = "";                       // L:874 PURGE-FLAG
        public BigDecimal empCount = BigDecimal.ZERO;       // L:877 EMP-COUNT
        public String wsCycleDefault = "WK";                // L:878 WS-CYCLE-DEFAULT
        public BigDecimal wsDateEnd = BigDecimal.ZERO;      // L:951 WS-DATE-END
        public BigDecimal wsDateEndPacked = BigDecimal.ZERO;// L:952 WS-DATE-END-PACKED
        public BigDecimal wsDateCheck = BigDecimal.ZERO;    // L:953 WS-DATE-CHECK
        public BigDecimal wsDateCheckPacked = BigDecimal.ZERO;// L:954 WS-DATE-CHECK-PACKED
        public String skipPurgeVerify = "";                 // L:955 SKIP-PURGE-VERIFY
        public String skipDirDep = "";                      // L:956 SKIP-DIR-DEP
        public String wcTaxOptWs = "";                      // L:957 WC-TAX-OPT-WS
        public String ficaOnlyOptWs = "";                   // L:958 FICA-ONLY-OPT-WS
        public String clnSetArrOptWs = "";                  // L:959 CLN-SET-ARR-OPT-WS
        public BigDecimal clnBenDeductOptWs = BigDecimal.ZERO;// L:960 CLN-BEN-DEDUCT-OPT-WS
        public BigDecimal clnBaDeductOptWs = BigDecimal.ZERO;// L:961 CLN-BA-DEDUCT-OPT-WS
        public String clnDirdepWaitOptWs = "";              // L:962 CLN-DIRDEP-WAIT-OPT-WS
        public String clnDirdepVoucherOptWs = "";           // L:963 CLN-DIRDEP-VOUCHER-OPT-WS
        public String clnShift1To2OptWs = "";               // L:964 CLN-SHIFT-1-TO-2-OPT-WS
        public String clnShift1To3OptWs = "";               // L:965 CLN-SHIFT-1-TO-3-OPT-WS
        public String clnShift1ToAllOptWs = "";             // L:966 CLN-SHIFT-1-TO-ALL-OPT-WS
        public String clnDeptLaborFwwOptWs = "";            // L:967 CLN-DEPT-LABOR-FWW-OPT-WS
        public BigDecimal clnGrossLimitOptWs = BigDecimal.ZERO;// L:968 CLN-GROSS-LIMIT-OPT-WS
        public BigDecimal clnHoursLimitOptWs = BigDecimal.ZERO;// L:969 CLN-HOURS-LIMIT-OPT-WS
        public BigDecimal grossNetErrorCntWs = BigDecimal.ZERO;// L:970 GROSS-NET-ERROR-CNT-WS
        public String cln4K90RegOptWs = "SPACE";            // L:971 CLN-4K90-REG-OPT-WS
        public BigDecimal clnXsickSeq01 = BigDecimal.ZERO;  // L:972 CLN-XSICK-SEQ01
        public BigDecimal clnXsickSeq02 = BigDecimal.ZERO;  // L:973 CLN-XSICK-SEQ02
        public BigDecimal clnXsickSeq03 = BigDecimal.ZERO;  // L:974 CLN-XSICK-SEQ03
        public BigDecimal clnXsickSeq04 = BigDecimal.ZERO;  // L:975 CLN-XSICK-SEQ04
        public BigDecimal clnXsickSeq05 = BigDecimal.ZERO;  // L:976 CLN-XSICK-SEQ05
        public BigDecimal clnXsickSeq06 = BigDecimal.ZERO;  // L:977 CLN-XSICK-SEQ06
        public BigDecimal clnXsickSeq07 = BigDecimal.ZERO;  // L:978 CLN-XSICK-SEQ07
        public BigDecimal clnXsickSeq08 = BigDecimal.ZERO;  // L:979 CLN-XSICK-SEQ08
        public BigDecimal clnXsickSeq09 = BigDecimal.ZERO;  // L:980 CLN-XSICK-SEQ09
        public BigDecimal clnXsickSeq10 = BigDecimal.ZERO;  // L:981 CLN-XSICK-SEQ10
        public BigDecimal clnCtLeaveLimit = BigDecimal.ZERO;// L:982 CLN-CT-LEAVE-LIMIT
        public String clnOpt62Ws = "SPACE";                 // L:983 CLN-OPT62-WS
        public String wsCliOpt608Sw = "SPACE";              // L:984 WS-CLI-OPT-608-SW
        public BigDecimal wk608SickAcrdTotal = BigDecimal.ZERO;// L:985 WK-608-SICK-ACRD-TOTAL
        public BigDecimal wk608SickAcrdDiff = BigDecimal.ZERO;// L:986 WK-608-SICK-ACRD-DIFF
        public String wsCliOpt630Sw = "SPACE";              // L:987 WS-CLI-OPT-630-SW
    }

    public static class FileStatusArea {                    // L:843 FILE-STATUS-AREA
        public String recOk = "";                           // L:844 REC-OK
        public String benStat = "";                         // L:845 BEN-STAT
        public String clnStat = "";                         // L:846 CLN-STAT
        public String cnlStat = "";                         // L:847 CNL-STAT
        public String ernStat = "";                         // L:848 ERN-STAT
        public String perStat = "";                         // L:849 PER-STAT
        public String tblStat = "";                         // L:850 TBL-STAT
        public String timStat = "";                         // L:851 TIM-STAT
        public String tcpStat = "";                         // L:852 TCP-STAT
        public String calStat = "";                         // L:853 CAL-STAT
        public String saveStat = "";                        // L:854 SAVE-STAT
        public String fsw = "";                             // L:855 FSW
    }

    public static class OkLiterals {                        // L:871 OK-LITERALS
        public String okLit = "OK";                         // L:872 OK-LIT
        public String notOkLit = "NO";                      // L:873 NOT-OK-LIT
    }

    public static class ErnLiteralsTable {                  // L:879 ERN-LITERALS-TABLE
        // No child fields
    }

    public static class ErnCode {                           // L:880 ERN-CODE
        // No child fields
    }

    public static class TaxLiterals {                       // L:882 TAX-LITERALS
        public String fedLiteral = "FWT ";                  // L:883 FED-LITERAL
        public String ficaLiteral = "FICA";                 // L:890 FICA-LITERAL
        public String eicLiteral = "EIC";                   // L:891 EIC-LITERAL
    }

    public static class SttLocCitOthLiterals {              // L:884 STT-LOC-CIT-OTH-LITERALS
        public String sttLiteral = "SPACES";                // L:885 STT-LITERAL
        public String locLiteral = "SPACES";                // L:887 LOC-LITERAL
        public String citLiteral = "SPACES";                // L:888 CIT-LITERAL
        public String othLiteral = "SPACES";                // L:889 OTH-LITERAL
    }

    public static class TaxNames {                          // L:893 TAX-NAMES
        // No child fields
    }

    public static class TaxName {                           // L:894 TAX-NAME
        // No child fields
    }

    public static class TaxSubGroup {                       // L:896 TAX-SUB-GROUP
        // No child fields
    }

    public static class TaxEntityLiterals {                 // L:898 TAX-ENTITY-LITERALS
    }

    public static class TaxEntityNames {                    // L:906 TAX-ENTITY-NAMES
        // No child fields
    }

    public static class TaxEntityName {                     // L:907 TAX-ENTITY-NAME
        // No child fields
    }

    public static class DeductionControlTable {             // L:909 DEDUCTION-CONTROL-TABLE
        // No child fields
    }

    public static class DeductionControlEntry {             // L:910 DEDUCTION-CONTROL-ENTRY
        public String[] cnlNoWs = new String[201];          // L:912 CNL-NO-WS
        public String[] cnlFreqWs = new String[201];        // L:915 CNL-FREQ-WS
        public BigDecimal[] cnlOrderWs = new BigDecimal[201];// L:916 CNL-ORDER-WS
        public String[] cnlSetArrWs = new String[201];      // L:917 CNL-SET-ARR-WS
        public String[] cnlAssocDedNoWs = new String[201];  // L:918 CNL-ASSOC-DED-NO-WS
        public String[] cnlActFlgWs = new String[201];      // L:927 CNL-ACT-FLG-WS
        public String[] cnlYtdPrtWs = new String[201];      // L:928 CNL-YTD-PRT-WS
        public BigDecimal[] cnlOptNoWs = new BigDecimal[201];// L:929 CNL-OPT-NO-WS
        public BigDecimal[] cnlL1PctWs = new BigDecimal[201];// L:930 CNL-L1-PCT-WS
        public BigDecimal[] cnlL1MatWs = new BigDecimal[201];// L:931 CNL-L1-MAT-WS
        public BigDecimal[] cnlL2PctWs = new BigDecimal[201];// L:932 CNL-L2-PCT-WS
        public BigDecimal[] cnlL2MatWs = new BigDecimal[201];// L:933 CNL-L2-MAT-WS
        public BigDecimal[] cnlMaxArrears = new BigDecimal[201];// L:934 CNL-MAX-ARREARS
    }

    public static class CnlTypeTableWs {                    // L:913 CNL-TYPE-TABLE-WS
        public String[][] cnlTypeWs = new String[201][10];  // L:914 CNL-TYPE-WS
    }

    public static class CnlTaxblTableWs {                   // L:919 CNL-TAXBL-TABLE-WS
        public String[] cnlTaxblFedWs = new String[201];    // L:920 CNL-TAXBL-FED-WS
        public String[] cnlTaxblSttWs = new String[201];    // L:921 CNL-TAXBL-STT-WS
        public String[] cnlTaxblLocWs = new String[201];    // L:922 CNL-TAXBL-LOC-WS
        public String[] cnlTaxblCitWs = new String[201];    // L:923 CNL-TAXBL-CIT-WS
        public String[] cnlTaxblOthWs = new String[201];    // L:924 CNL-TAXBL-OTH-WS
        public String[] cnlTaxblFicaWs = new String[201];   // L:925 CNL-TAXBL-FICA-WS
        public String[] cnlTaxblEicWs = new String[201];    // L:926 CNL-TAXBL-EIC-WS
    }

    public static class WsDeductionTaken {                  // L:935 WS-DEDUCTION-TAKEN
        public String wkDedTaken = "";                      // L:936 WK-DED-TAKEN
        public String bwDedTaken = "";                      // L:938 BW-DED-TAKEN
        public String smDedTaken = "";                      // L:940 SM-DED-TAKEN
        public String mtDedTaken = "";                      // L:942 MT-DED-TAKEN
    }

    public static class WsDedFlgsTaken {                    // L:944 WS-DED-FLGS-TAKEN
        public String wsDedFlgs = "";                       // L:945 WS-DED-FLGS
    }

    public static class WsDedCycTaken {                     // L:946 WS-DED-CYC-TAKEN
        public String wsDedCycWk = "";                      // L:947 WS-DED-CYC-WK
        public String wsDedCycBw = "";                      // L:948 WS-DED-CYC-BW
        public String wsDedCycSm = "";                      // L:949 WS-DED-CYC-SM
        public String wsDedCycMt = "";                      // L:950 WS-DED-CYC-MT
    }

    public static class DeductionOptionsTable {             // L:988 DEDUCTION-OPTIONS-TABLE
        // No child fields
    }

    public static class DeductionOptionsEntry {             // L:990 DEDUCTION-OPTIONS-ENTRY
        public String[] cn1NoWs = new String[30];           // L:992 CN1-NO-WS
        public BigDecimal[] cn1OptNoWs = new BigDecimal[30];// L:993 CN1-OPT-NO-WS
    }

    public static class WorkAreaVolatile {                  // L:995 WORK-AREA-VOLATILE
        public BigDecimal im = BigDecimal.ZERO;             // L:1005 IM
        public BigDecimal jm = BigDecimal.ZERO;             // L:1006 JM
        public BigDecimal i = BigDecimal.ZERO;              // L:1007 I
        public BigDecimal j = BigDecimal.ZERO;              // L:1008 J
        public BigDecimal k = BigDecimal.ZERO;              // L:1009 K
        public BigDecimal l = BigDecimal.ZERO;              // L:1010 L
        public BigDecimal m = BigDecimal.ZERO;              // L:1011 M
        public BigDecimal s = BigDecimal.ZERO;              // L:1012 S
        public BigDecimal pctNdx = BigDecimal.ZERO;         // L:1013 PCT-NDX
        public BigDecimal dedSub = BigDecimal.ZERO;         // L:1014 DED-SUB
        public BigDecimal depSub = BigDecimal.ZERO;         // L:1015 DEP-SUB
        public BigDecimal cnlSub = BigDecimal.ZERO;         // L:1016 CNL-SUB
        public BigDecimal sub = BigDecimal.ZERO;            // L:1017 SUB
        public String endOfQtr = "N";                       // L:1018 END-OF-QTR
        public String endOfYr = "N";                        // L:1019 END-OF-YR
        public String cnlParaYn = "N";                      // L:1020 CNL-PARA-YN
        public String cnlActYn = "Y";                       // L:1021 CNL-ACT-YN
        public String wsBalFlg = "N";                       // L:1022 WS-BAL-FLG
        public String zeroYn = "Y";                         // L:1023 ZERO-YN
        public BigDecimal pctWs = BigDecimal.ZERO;          // L:1024 PCT-WS
        public BigDecimal totalWs = BigDecimal.ZERO;        // L:1025 TOTAL-WS
        public BigDecimal totRegWagesWs = BigDecimal.ZERO;  // L:1026 TOT-REG-WAGES-WS
        public BigDecimal totOvtWagesWs = BigDecimal.ZERO;  // L:1027 TOT-OVT-WAGES-WS
        public BigDecimal totRegHoursWs = BigDecimal.ZERO;  // L:1028 TOT-REG-HOURS-WS
        public BigDecimal totOvtHoursWs = BigDecimal.ZERO;  // L:1029 TOT-OVT-HOURS-WS
        public BigDecimal totEarnWs = BigDecimal.ZERO;      // L:1030 TOT-EARN-WS
        public BigDecimal pctTotEarnWs = BigDecimal.ZERO;   // L:1031 PCT-TOT-EARN-WS
        public BigDecimal holdTotEarnWs = BigDecimal.ZERO;  // L:1032 HOLD-TOT-EARN-WS
        public BigDecimal totEarnYtdWs = BigDecimal.ZERO;   // L:1033 TOT-EARN-YTD-WS
        public BigDecimal totHoursWs = BigDecimal.ZERO;     // L:1034 TOT-HOURS-WS
        public BigDecimal totDollarsWs = BigDecimal.ZERO;   // L:1035 TOT-DOLLARS-WS
        public BigDecimal dedAccYtdWs = BigDecimal.ZERO;    // L:1036 DED-ACC-YTD-WS
        public BigDecimal deductExemptAmtWs = BigDecimal.ZERO;// L:1037 DEDUCT-EXEMPT-AMT-WS
        public BigDecimal dependPayppdAmtWs = BigDecimal.ZERO;// L:1038 DEPEND-PAYPPD-AMT-WS
        public BigDecimal deductStdAmtWs = BigDecimal.ZERO; // L:1039 DEDUCT-STD-AMT-WS
        public BigDecimal deductExemptAddlAmtWs = BigDecimal.ZERO;// L:1040 DEDUCT-EXEMPT-ADDL-AMT-WS
        public BigDecimal noToTakeWs = BigDecimal.ZERO;     // L:1046 NO-TO-TAKE-WS
        public BigDecimal dedAmtWs = BigDecimal.ZERO;       // L:1047 DED-AMT-WS
        public BigDecimal dedMaxWs = BigDecimal.ZERO;       // L:1048 DED-MAX-WS
        public BigDecimal dedAmtLvl1Ws = BigDecimal.ZERO;   // L:1049 DED-AMT-LVL1-WS
        public BigDecimal dedPctLvl1Ws = BigDecimal.ZERO;   // L:1050 DED-PCT-LVL1-WS
        public BigDecimal dedMatLvl1Ws = BigDecimal.ZERO;   // L:1051 DED-MAT-LVL1-WS
        public BigDecimal dedMaxLvl1Ws = BigDecimal.ZERO;   // L:1052 DED-MAX-LVL1-WS
        public BigDecimal dedAmtLvl2Ws = BigDecimal.ZERO;   // L:1053 DED-AMT-LVL2-WS
        public BigDecimal dedPctLvl2Ws = BigDecimal.ZERO;   // L:1054 DED-PCT-LVL2-WS
        public BigDecimal dedMatLvl2Ws = BigDecimal.ZERO;   // L:1055 DED-MAT-LVL2-WS
        public BigDecimal dedMaxLvl2Ws = BigDecimal.ZERO;   // L:1056 DED-MAX-LVL2-WS
        public BigDecimal dedPctWs = BigDecimal.ZERO;       // L:1058 DED-PCT-WS
        public BigDecimal totRegEarnWs = BigDecimal.ZERO;   // L:1059 TOT-REG-EARN-WS
        public String taxEntityCde = "";                    // L:1060 TAX-ENTITY-CDE
        public BigDecimal taxEntity = BigDecimal.ZERO;      // L:1061 TAX-ENTITY
        public String taxFlgWs = "";                        // L:1062 TAX-FLG-WS
        public String advEicTax = "";                       // L:1077 ADV-EIC-TAX
        public BigDecimal taxYtdFicaWs = BigDecimal.ZERO;   // L:1078 TAX-YTD-FICA-WS
        public BigDecimal taxYtdFicmWs = BigDecimal.ZERO;   // L:1079 TAX-YTD-FICM-WS
        public BigDecimal totTaxYtdWs = BigDecimal.ZERO;    // L:1080 TOT-TAX-YTD-WS
        public BigDecimal ficaDistBalWs = BigDecimal.ZERO;  // L:1081 FICA-DIST-BAL-WS
        public BigDecimal emprDistBalWs = BigDecimal.ZERO;  // L:1082 EMPR-DIST-BAL-WS
        public BigDecimal tsaAmountWs = BigDecimal.ZERO;    // L:1083 TSA-AMOUNT-WS
        public BigDecimal baAmountWs = BigDecimal.ZERO;     // L:1085 BA-AMOUNT-WS
        public BigDecimal benAmountWs = BigDecimal.ZERO;    // L:1086 BEN-AMOUNT-WS
        public BigDecimal baPctWs = BigDecimal.ZERO;        // L:1087 BA-PCT-WS
        public BigDecimal teOptPctWs = BigDecimal.ZERO;     // L:1088 TE-OPT-PCT-WS
        public BigDecimal azPctWs = BigDecimal.ZERO;        // L:1089 AZ-PCT-WS
        public BigDecimal lowerWageLimitWs = BigDecimal.ZERO;// L:1090 LOWER-WAGE-LIMIT-WS
        public BigDecimal pctExcessWageWs = BigDecimal.ZERO;// L:1091 PCT-EXCESS-WAGE-WS
        public BigDecimal flatTaxAmtWs = BigDecimal.ZERO;   // L:1092 FLAT-TAX-AMT-WS
        public BigDecimal taxLimitYtdWs = BigDecimal.ZERO;  // L:1093 TAX-LIMIT-YTD-WS
        public BigDecimal wageLimitYtdWs = BigDecimal.ZERO; // L:1094 WAGE-LIMIT-YTD-WS
        public BigDecimal taxLimitCppWs = BigDecimal.ZERO;  // L:1095 TAX-LIMIT-CPP-WS
        public BigDecimal annualWageWs = BigDecimal.ZERO;   // L:1096 ANNUAL-WAGE-WS
        public BigDecimal taxableWageWs = BigDecimal.ZERO;  // L:1097 TAXABLE-WAGE-WS
        public BigDecimal excessWageWs = BigDecimal.ZERO;   // L:1098 EXCESS-WAGE-WS
        public BigDecimal excessTaxWs = BigDecimal.ZERO;    // L:1099 EXCESS-TAX-WS
        public BigDecimal factorWs = BigDecimal.ZERO;       // L:1100 FACTOR-WS
        public BigDecimal premRateWs = BigDecimal.ZERO;     // L:1101 PREM-RATE-WS
        public BigDecimal rateWs = BigDecimal.ZERO;         // L:1102 RATE-WS
        public BigDecimal baseRteSalaryWs = BigDecimal.ZERO;// L:1103 BASE-RTE-SALARY-WS
        public BigDecimal baseRteHourlyWs = BigDecimal.ZERO;// L:1104 BASE-RTE-HOURLY-WS
        public BigDecimal baseRteOvrtmeWs = BigDecimal.ZERO;// L:1105 BASE-RTE-OVRTME-WS
        public BigDecimal baseRteDistBalWs = BigDecimal.ZERO;// L:1106 BASE-RTE-DIST-BAL-WS
        public BigDecimal baseHrsDistBalWs = BigDecimal.ZERO;// L:1107 BASE-HRS-DIST-BAL-WS
        public BigDecimal cdeCycleNumWs = BigDecimal.ZERO;  // L:1108 CDE-CYCLE-NUM-WS
        public BigDecimal fwwHrsWs = BigDecimal.ZERO;       // L:1109 FWW-HRS-WS
        public String editAmt = "";                         // L:1110 EDIT-AMT
        public String saveTransactionRecord = "";           // L:1111 SAVE-TRANSACTION-RECORD
        public BigDecimal saveSeqNo = BigDecimal.ZERO;      // L:1112 SAVE-SEQ-NO
        public BigDecimal errEmpNo = BigDecimal.ZERO;       // L:1113 ERR-EMP-NO
        public BigDecimal errDateEnd = BigDecimal.ZERO;     // L:1114 ERR-DATE-END
        public BigDecimal ficaMedShrWs = BigDecimal.ZERO;   // L:1115 FICA-MED-SHR-WS
        public BigDecimal ficaFcaShrWs = BigDecimal.ZERO;   // L:1116 FICA-FCA-SHR-WS
        public BigDecimal ficaMedEmplrWs = BigDecimal.ZERO; // L:1117 FICA-MED-EMPLR-WS
        public BigDecimal ficaFcaEmplrWs = BigDecimal.ZERO; // L:1118 FICA-FCA-EMPLR-WS
        public BigDecimal ernTaxYtdFicm = BigDecimal.ZERO;  // L:1119 ERN-TAX-YTD-FICM
    }

    public static class BrkKey {                            // L:996 BRK-KEY
        public BigDecimal brkClientNo = BigDecimal.ZERO;    // L:997 BRK-CLIENT-NO
        public BigDecimal brkEmpNo = BigDecimal.ZERO;       // L:998 BRK-EMP-NO
        public BigDecimal brkCorpWrk = BigDecimal.ZERO;     // L:999 BRK-CORP-WRK
        public BigDecimal brkStoreWrk = BigDecimal.ZERO;    // L:1000 BRK-STORE-WRK
        public BigDecimal brkDeptWrk = BigDecimal.ZERO;     // L:1001 BRK-DEPT-WRK
        public String brkCheckType = "";                    // L:1002 BRK-CHECK-TYPE
        public BigDecimal brkCheckNo = BigDecimal.ZERO;     // L:1003 BRK-CHECK-NO
        public BigDecimal brkDateEnd = BigDecimal.ZERO;     // L:1004 BRK-DATE-END
    }

    public static class WsDedTktnTable {                    // L:1041 WS-DED-TKTN-TABLE
        public BigDecimal wsDedTktn = BigDecimal.ZERO;      // L:1042 WS-DED-TKTN
    }

    public static class WsDedTktnTableRe {                  // L:1043 WS-DED-TKTN-TABLE-RE
        public BigDecimal wsNoToTake = BigDecimal.ZERO;     // L:1044 WS-NO-TO-TAKE
        public BigDecimal wsNoTaken = BigDecimal.ZERO;      // L:1045 WS-NO-TAKEN
    }

    public static class LeaveAccrFields {                   // L:1121 LEAVE-ACCR-FIELDS
        public BigDecimal totLvHrsWs = BigDecimal.ZERO;     // L:1129 TOT-LV-HRS-WS
        public BigDecimal annlBalWs = BigDecimal.ZERO;      // L:1130 ANNL-BAL-WS
        public BigDecimal accumHoursWs = BigDecimal.ZERO;   // L:1131 ACCUM-HOURS-WS
        public BigDecimal xsickHoursWs = BigDecimal.ZERO;   // L:1132 XSICK-HOURS-WS
        public BigDecimal accumHoursActualWs = BigDecimal.ZERO;// L:1133 ACCUM-HOURS-ACTUAL-WS
        public BigDecimal accumHrsLimitWs = BigDecimal.ZERO;// L:1134 ACCUM-HRS-LIMIT-WS
        public BigDecimal accumHrsLimitYtdWs = BigDecimal.ZERO;// L:1135 ACCUM-HRS-LIMIT-YTD-WS
        public BigDecimal ytdLimitWs = BigDecimal.ZERO;     // L:1136 YTD-LIMIT-WS
        public BigDecimal totalAccruedWs = BigDecimal.ZERO; // L:1137 TOTAL-ACCRUED-WS
        public BigDecimal totalAccruedYtdWs = BigDecimal.ZERO;// L:1138 TOTAL-ACCRUED-YTD-WS
    }

    public static class LvHrsTable {                        // L:1122 LV-HRS-TABLE
        public String lvCodesWs = "";                       // L:1123 LV-CODES-WS
    }

    public static class LvHrsTableRe {                      // L:1124 LV-HRS-TABLE-RE
        // No child fields
    }

    public static class LvFlagsWs {                         // L:1125 LV-FLAGS-WS
        // No child fields
    }

    public static class WsLouisianaStateTax {               // L:1204 WS-LOUISIANA-STATE-TAX
        public BigDecimal w = BigDecimal.ZERO;              // L:1205 W
        public BigDecimal w1 = BigDecimal.ZERO;             // L:1206 W1
        public BigDecimal w2 = BigDecimal.ZERO;             // L:1207 W2
        public BigDecimal w3 = BigDecimal.ZERO;             // L:1208 W3
        public BigDecimal sa = BigDecimal.ZERO;             // L:1209 SA
        public BigDecimal x = BigDecimal.ZERO;              // L:1210 X
        public BigDecimal y = BigDecimal.ZERO;              // L:1211 Y
        public BigDecimal n = BigDecimal.ZERO;              // L:1212 N
        public BigDecimal a = BigDecimal.ZERO;              // L:1213 A
        public BigDecimal b = BigDecimal.ZERO;              // L:1214 B
        public BigDecimal e = BigDecimal.ZERO;              // L:1215 E
        public BigDecimal f = BigDecimal.ZERO;              // L:1216 F
        public BigDecimal p1 = BigDecimal.ZERO;             // L:1217 P1
        public BigDecimal p2 = BigDecimal.ZERO;             // L:1218 P2
        public BigDecimal p3 = BigDecimal.ZERO;             // L:1219 P3
        public BigDecimal ll1 = BigDecimal.ZERO;            // L:1220 LL1
        public BigDecimal ll2 = BigDecimal.ZERO;            // L:1221 LL2
        public BigDecimal ll3 = BigDecimal.ZERO;            // L:1222 LL3
    }

    public static class WsTblTableArea {                    // L:1225 WS-TBL-TABLE-AREA
        public BigDecimal wsFicaUprTaxLimitYtd = BigDecimal.ZERO;// L:1226 WS-FICA-UPR-TAX-LIMIT-YTD
        public BigDecimal wsFicaUprTaxLimitYtd1 = BigDecimal.ZERO;// L:1227 WS-FICA-UPR-TAX-LIMIT-YTD-1
        public BigDecimal wsFicaUprTaxLimitYtd2 = BigDecimal.ZERO;// L:1228 WS-FICA-UPR-TAX-LIMIT-YTD-2
        public BigDecimal wsFicaUprTaxLimitYtd3 = BigDecimal.ZERO;// L:1229 WS-FICA-UPR-TAX-LIMIT-YTD-3
        public BigDecimal wsFicaLwrTaxLimitYtd = BigDecimal.ZERO;// L:1230 WS-FICA-LWR-TAX-LIMIT-YTD
        public BigDecimal wsFicaLwrTaxLimitYtd1 = BigDecimal.ZERO;// L:1231 WS-FICA-LWR-TAX-LIMIT-YTD-1
        public BigDecimal wsFicaLwrTaxLimitYtd2 = BigDecimal.ZERO;// L:1232 WS-FICA-LWR-TAX-LIMIT-YTD-2
        public BigDecimal wsFicaLwrTaxLimitYtd3 = BigDecimal.ZERO;// L:1233 WS-FICA-LWR-TAX-LIMIT-YTD-3
        public BigDecimal wsFicaUprWageLimitYtd = BigDecimal.ZERO;// L:1234 WS-FICA-UPR-WAGE-LIMIT-YTD
        public BigDecimal wsFicaUprWageLimitYtd1 = BigDecimal.ZERO;// L:1235 WS-FICA-UPR-WAGE-LIMIT-YTD-1
        public BigDecimal wsFicaUprWageLimitYtd2 = BigDecimal.ZERO;// L:1236 WS-FICA-UPR-WAGE-LIMIT-YTD-2
        public BigDecimal wsFicaUprWageLimitYtd3 = BigDecimal.ZERO;// L:1237 WS-FICA-UPR-WAGE-LIMIT-YTD-3
        public BigDecimal wsFicaLwrWageLimitYtd = BigDecimal.ZERO;// L:1238 WS-FICA-LWR-WAGE-LIMIT-YTD
        public BigDecimal wsFicaLwrWageLimitYtd1 = BigDecimal.ZERO;// L:1239 WS-FICA-LWR-WAGE-LIMIT-YTD-1
        public BigDecimal wsFicaLwrWageLimitYtd2 = BigDecimal.ZERO;// L:1240 WS-FICA-LWR-WAGE-LIMIT-YTD-2
        public BigDecimal wsFicaLwrWageLimitYtd3 = BigDecimal.ZERO;// L:1241 WS-FICA-LWR-WAGE-LIMIT-YTD-3
        public BigDecimal wsFicaUprPercent = BigDecimal.ZERO;// L:1243 WS-FICA-UPR-PERCENT
        public BigDecimal wsFicaUprPercent1 = BigDecimal.ZERO;// L:1244 WS-FICA-UPR-PERCENT-1
        public BigDecimal wsFicaUprPercent2 = BigDecimal.ZERO;// L:1245 WS-FICA-UPR-PERCENT-2
        public BigDecimal wsFicaUprPercent3 = BigDecimal.ZERO;// L:1246 WS-FICA-UPR-PERCENT-3
        public BigDecimal wsFicaLwrPercent = BigDecimal.ZERO;// L:1247 WS-FICA-LWR-PERCENT
        public BigDecimal wsFicaLwrPercent2 = BigDecimal.ZERO;// L:1248 WS-FICA-LWR-PERCENT-2
        public BigDecimal wsFicaLwrPercent3 = BigDecimal.ZERO;// L:1249 WS-FICA-LWR-PERCENT-3
        public BigDecimal wsFicmUprTaxLimitYtd = BigDecimal.ZERO;// L:1250 WS-FICM-UPR-TAX-LIMIT-YTD
        public BigDecimal wsFicmLwrTaxLimitYtd = BigDecimal.ZERO;// L:1251 WS-FICM-LWR-TAX-LIMIT-YTD
        public BigDecimal wsFicmUprWageLimitYtd = BigDecimal.ZERO;// L:1252 WS-FICM-UPR-WAGE-LIMIT-YTD
        public BigDecimal wsFicmLwrWageLimitYtd = BigDecimal.ZERO;// L:1253 WS-FICM-LWR-WAGE-LIMIT-YTD
        public BigDecimal wsFicmUprPercent = BigDecimal.ZERO;// L:1255 WS-FICM-UPR-PERCENT
        public BigDecimal wsFicmLwrPercent = BigDecimal.ZERO;// L:1256 WS-FICM-LWR-PERCENT
        public BigDecimal wsFicmYtd = BigDecimal.ZERO;      // L:1258 WS-FICM-YTD
        public BigDecimal wsMinWageRteHourly = BigDecimal.ZERO;// L:1260 WS-MIN-WAGE-RTE-HOURLY
        public BigDecimal tblRem = BigDecimal.ZERO;         // L:1261 TBL-REM
        public BigDecimal tblCnt = BigDecimal.ZERO;         // L:1262 TBL-CNT
        public BigDecimal wsTblIdxLimit = BigDecimal.ZERO;  // L:1263 WS-TBL-IDX-LIMIT
    }

    public static class WsTblRecord {                       // L:1266 WS-TBL-RECORD
        public BigDecimal[] wsLevel = new BigDecimal[6000]; // L:1271 WS-LEVEL
        public BigDecimal[] wsLowerWageLimit = new BigDecimal[6000];// L:1272 WS-LOWER-WAGE-LIMIT
        public BigDecimal[] wsPctExcessWage = new BigDecimal[6000];// L:1274 WS-PCT-EXCESS-WAGE
        public BigDecimal[] wsFlatTaxAmt = new BigDecimal[6000];// L:1275 WS-FLAT-TAX-AMT
        public BigDecimal[] wsExemptAmt = new BigDecimal[6000];// L:1276 WS-EXEMPT-AMT
        public BigDecimal[] wsStdDedAmt = new BigDecimal[6000];// L:1277 WS-STD-DED-AMT
        public BigDecimal[] wsStdDedPct = new BigDecimal[6000];// L:1279 WS-STD-DED-PCT
        public BigDecimal[] wsUnempLimit = new BigDecimal[6000];// L:1280 WS-UNEMP-LIMIT
        public BigDecimal[] wsTaxLimitYtd = new BigDecimal[6000];// L:1281 WS-TAX-LIMIT-YTD
        public BigDecimal[] wsWageLimitYtd = new BigDecimal[6000];// L:1282 WS-WAGE-LIMIT-YTD
        public BigDecimal[] wsTaxLimitCpp = new BigDecimal[6000];// L:1283 WS-TAX-LIMIT-CPP
        public BigDecimal[] wsExemptAddlAmt = new BigDecimal[6000];// L:1284 WS-EXEMPT-ADDL-AMT
        public String[] wsTaxCreditYn = new String[6000];   // L:1285 WS-TAX-CREDIT-YN
    }

    public static class WsTblKey {                          // L:1268 WS-TBL-KEY
        public String[] wsCdeTax = new String[6000];        // L:1269 WS-CDE-TAX
        public String[] wsMarStatus = new String[6000];     // L:1270 WS-MAR-STATUS
    }

    public static class WsMwTblCdeStKey {                   // L:1291 WS-MW-TBL-CDE-ST-KEY
        public String wsMwTblCdeTax = "";                   // L:1292 WS-MW-TBL-CDE-TAX
        public String wsMwTblMarStatus = "";                // L:1293 WS-MW-TBL-MAR-STATUS
    }

    public static class WsSavedTblIdx {                     // L:1296 WS-SAVED-TBL-IDX
        // No child fields
    }

    public static class TblWorkKey {                        // L:1305 TBL-WORK-KEY
        // No child fields
    }

    public static class TblWorkKeyWs {                      // L:1306 TBL-WORK-KEY-WS
        public String cdeMarStatusWs = "";                  // L:1310 CDE-MAR-STATUS-WS
    }

    public static class CdeTaxWs {                          // L:1307 CDE-TAX-WS
        public String cdeTax13 = "";                        // L:1308 CDE-TAX-13
        public String cdeTax4 = "";                         // L:1309 CDE-TAX-4
    }

    public static class WorkTimCode {                       // L:1317 WORK-TIM-CODE
        public String timCode4 = "";                        // L:1319 TIM-CODE-4
    }

    public static class HoldTaxParaX {                      // L:1321 HOLD-TAX-PARA-X
        public BigDecimal holdTaxPara = BigDecimal.ZERO;    // L:1322 HOLD-TAX-PARA
    }

    public static class HoldCppFicaX {                      // L:1324 HOLD-CPP-FICA-X
        public BigDecimal holdCppFica = BigDecimal.ZERO;    // L:1325 HOLD-CPP-FICA
    }

    public static class HoldCppFicmX {                      // L:1327 HOLD-CPP-FICM-X
        public BigDecimal holdCppFicm = BigDecimal.ZERO;    // L:1328 HOLD-CPP-FICM
    }

    public static class WsPerExmTab {                       // L:1330 WS-PER-EXM-TAB
        // No child fields
    }

    public static class WsPerExemptCnt {                    // L:1331 WS-PER-EXEMPT-CNT
        // No child fields
    }

    public static class WsPerExmTable {                     // L:1333 WS-PER-EXM-TABLE
        public BigDecimal wsPerExmFed = BigDecimal.ZERO;    // L:1334 WS-PER-EXM-FED
        public BigDecimal wsPerExmStt = BigDecimal.ZERO;    // L:1335 WS-PER-EXM-STT
        public BigDecimal wsPerExmLoc = BigDecimal.ZERO;    // L:1336 WS-PER-EXM-LOC
        public BigDecimal wsPerExmCit = BigDecimal.ZERO;    // L:1337 WS-PER-EXM-CIT
        public BigDecimal wsPerExmOth = BigDecimal.ZERO;    // L:1338 WS-PER-EXM-OTH
        public BigDecimal wsPerExmFica = BigDecimal.ZERO;   // L:1339 WS-PER-EXM-FICA
        public BigDecimal wsPerExmEic = BigDecimal.ZERO;    // L:1340 WS-PER-EXM-EIC
    }

    public static class TextLine {                          // L:1342 TEXT-LINE
        public String clientNoO = "";                       // L:1343 CLIENT-NO-O
        public String empNoO = "";                          // L:1345 EMP-NO-O
        public BigDecimal corpWrkO = BigDecimal.ZERO;       // L:1347 CORP-WRK-O
        public BigDecimal storeWrkO = BigDecimal.ZERO;      // L:1349 STORE-WRK-O
        public BigDecimal deptWrkO = BigDecimal.ZERO;       // L:1351 DEPT-WRK-O
        public String messageO = "";                        // L:1353 MESSAGE-O
    }

    public static class PayrollTransactionArea {            // L:1355 PAYROLL-TRANSACTION-AREA
        // No child fields
    }

    public static class TransactionWs {                     // L:1356 TRANSACTION-WS
        public BigDecimal[] corpWrkTrn = new BigDecimal[33];// L:1357 CORP-WRK-TRN
        public BigDecimal[] storeWrkTrn = new BigDecimal[33];// L:1358 STORE-WRK-TRN
        public BigDecimal[] deptWrkTrn = new BigDecimal[33];// L:1359 DEPT-WRK-TRN
        public String[] typeTrn = new String[33];           // L:1360 TYPE-TRN
        public String[] codeTrn = new String[33];           // L:1361 CODE-TRN
        public BigDecimal[] hoursTrn = new BigDecimal[33];  // L:1362 HOURS-TRN
        public BigDecimal[] rateTrn = new BigDecimal[33];   // L:1363 RATE-TRN
        public BigDecimal[] amountTrn = new BigDecimal[33]; // L:1364 AMOUNT-TRN
        public BigDecimal[] seqTrn = new BigDecimal[33];    // L:1365 SEQ-TRN
    }

    public static class PayrollDistributionArea {           // L:1368 PAYROLL-DISTRIBUTION-AREA
        // No child fields
    }

    public static class DistributionWs {                    // L:1369 DISTRIBUTION-WS
        public BigDecimal[] corpWrkDist = new BigDecimal[33];// L:1370 CORP-WRK-DIST
        public BigDecimal[] storeWrkDist = new BigDecimal[33];// L:1371 STORE-WRK-DIST
        public BigDecimal[] deptWrkDist = new BigDecimal[33];// L:1372 DEPT-WRK-DIST
        public BigDecimal[] hoursDist = new BigDecimal[33]; // L:1373 HOURS-DIST
        public BigDecimal[] amountDist = new BigDecimal[33];// L:1374 AMOUNT-DIST
        public BigDecimal[] ficaDist = new BigDecimal[33];  // L:1375 FICA-DIST
        public BigDecimal[] emprDist = new BigDecimal[33];  // L:1376 EMPR-DIST
    }

    public static class PayrollSummaryArea {                // L:1379 PAYROLL-SUMMARY-AREA
        public BigDecimal ernCppGrsLessTxSum = BigDecimal.ZERO;// L:1398 ERN-CPP-GRS-LESS-TX-SUM
        public BigDecimal lvSickAccRteSum = BigDecimal.ZERO;// L:1456 LV-SICK-ACC-RTE-SUM
        public BigDecimal lvAnnlAccRteSum = BigDecimal.ZERO;// L:1457 LV-ANNL-ACC-RTE-SUM
        public BigDecimal lvPersAccRteSum = BigDecimal.ZERO;// L:1458 LV-PERS-ACC-RTE-SUM
        public BigDecimal lvAccRteSum = BigDecimal.ZERO;    // L:1459 LV-ACC-RTE-SUM
        public BigDecimal annlTaxblFicaYtd = BigDecimal.ZERO;// L:1489 ANNL-TAXBL-FICA-YTD
    }

    public static class ErnCppTaxabilityTableSum {          // L:1380 ERN-CPP-TAXABILITY-TABLE-SUM
        // No child fields
    }

    public static class ErnCppTaxabilitySum {               // L:1381 ERN-CPP-TAXABILITY-SUM
        public String[] ernCppFedTaxability = new String[35];// L:1382 ERN-CPP-FED-TAXABILITY
        public String[] ernCppSttTaxability = new String[35];// L:1383 ERN-CPP-STT-TAXABILITY
        public String[] ernCppCitTaxability = new String[35];// L:1384 ERN-CPP-CIT-TAXABILITY
        public String[] ernCppLocTaxability = new String[35];// L:1385 ERN-CPP-LOC-TAXABILITY
        public String[] ernCppOthTaxability = new String[35];// L:1386 ERN-CPP-OTH-TAXABILITY
        public String[] ernCppFicaTaxability = new String[35];// L:1387 ERN-CPP-FICA-TAXABILITY
        public String[] ernCppFutaTaxability = new String[35];// L:1388 ERN-CPP-FUTA-TAXABILITY
        public String[] ernCppSucaTaxability = new String[35];// L:1389 ERN-CPP-SUCA-TAXABILITY
    }

    public static class ErnCppTableSum {                    // L:1390 ERN-CPP-TABLE-SUM
        // No child fields
    }

    public static class ErnCppSum {                         // L:1391 ERN-CPP-SUM
        // No child fields
    }

    public static class ErnCppTabSum {                      // L:1393 ERN-CPP-TAB-SUM
        public BigDecimal ernCppNetSum = BigDecimal.ZERO;   // L:1396 ERN-CPP-NET-SUM
        public BigDecimal ernCppGrossSum = BigDecimal.ZERO; // L:1397 ERN-CPP-GROSS-SUM
    }

    public static class ErnCppOthSum {                      // L:1394 ERN-CPP-OTH-SUM
        // No child fields
    }

    public static class HrsCppTableSum {                    // L:1399 HRS-CPP-TABLE-SUM
        // No child fields
    }

    public static class HrsCppSum {                         // L:1400 HRS-CPP-SUM
        // No child fields
    }

    public static class HrsCppTabSum {                      // L:1402 HRS-CPP-TAB-SUM
        public BigDecimal hrsCppGrossSum = BigDecimal.ZERO; // L:1405 HRS-CPP-GROSS-SUM
    }

    public static class HrsCppOthSum {                      // L:1403 HRS-CPP-OTH-SUM
        // No child fields
    }

    public static class TaxCppTableSum {                    // L:1406 TAX-CPP-TABLE-SUM
        // No child fields
    }

    public static class TaxCppSumX {                        // L:1407 TAX-CPP-SUM-X
        public BigDecimal[] taxCppSum = new BigDecimal[7];  // L:1408 TAX-CPP-SUM
    }

    public static class TaxCppTabSum {                      // L:1409 TAX-CPP-TAB-SUM
        public BigDecimal taxCppFedSum = BigDecimal.ZERO;   // L:1410 TAX-CPP-FED-SUM
        public BigDecimal taxCppSttSum = BigDecimal.ZERO;   // L:1411 TAX-CPP-STT-SUM
        public BigDecimal taxCppLocSum = BigDecimal.ZERO;   // L:1412 TAX-CPP-LOC-SUM
        public BigDecimal taxCppCitSum = BigDecimal.ZERO;   // L:1413 TAX-CPP-CIT-SUM
        public BigDecimal taxCppOthSum = BigDecimal.ZERO;   // L:1414 TAX-CPP-OTH-SUM
        public BigDecimal taxCppEicSum = BigDecimal.ZERO;   // L:1417 TAX-CPP-EIC-SUM
    }

    public static class TaxCppFicaSumX {                    // L:1415 TAX-CPP-FICA-SUM-X
        public BigDecimal taxCppFicaSum = BigDecimal.ZERO;  // L:1416 TAX-CPP-FICA-SUM
    }

    public static class TaxCppFicmSumX {                    // L:1418 TAX-CPP-FICM-SUM-X
        public BigDecimal taxCppFicmSum = BigDecimal.ZERO;  // L:1419 TAX-CPP-FICM-SUM
    }

    public static class DedCppTableSum {                    // L:1420 DED-CPP-TABLE-SUM
        // No child fields
    }

    public static class DeductionSum {                      // L:1422 DEDUCTION-SUM
        public String[] dedNoSum = new String[165];         // L:1423 DED-NO-SUM
        public BigDecimal[] dedOrderNo = new BigDecimal[165];// L:1424 DED-ORDER-NO
        public BigDecimal[] dedTblElementSum = new BigDecimal[165];// L:1425 DED-TBL-ELEMENT-SUM
        public BigDecimal[] dedSeqNoSum = new BigDecimal[165];// L:1426 DED-SEQ-NO-SUM
        public String[] dedParaSum = new String[165];       // L:1427 DED-PARA-SUM
        public BigDecimal[] dedNoToTakeSum = new BigDecimal[165];// L:1428 DED-NO-TO-TAKE-SUM
        public BigDecimal[] dedNoTakenSum = new BigDecimal[165];// L:1429 DED-NO-TAKEN-SUM
        public BigDecimal[] dedArrsCtrSum = new BigDecimal[165];// L:1430 DED-ARRS-CTR-SUM
        public String[] dedSetArrSum = new String[165];     // L:1431 DED-SET-ARR-SUM
        public BigDecimal[] dedAmtSum = new BigDecimal[165];// L:1432 DED-AMT-SUM
        public BigDecimal[] dedPctSum = new BigDecimal[165];// L:1433 DED-PCT-SUM
        public BigDecimal[] dedBalSum = new BigDecimal[165];// L:1434 DED-BAL-SUM
        public BigDecimal[] dedOptSum = new BigDecimal[165];// L:1435 DED-OPT-SUM
        public BigDecimal[] dedAccYtdSum = new BigDecimal[165];// L:1436 DED-ACC-YTD-SUM
        public String[] dedAssocDedNoSum = new String[165]; // L:1437 DED-ASSOC-DED-NO-SUM
        public String[] dedErrSum = new String[165];        // L:1438 DED-ERR-SUM
        public String[] dedYtdPrtSum = new String[165];     // L:1450 DED-YTD-PRT-SUM
        public BigDecimal[] dedOptNoSum = new BigDecimal[165];// L:1451 DED-OPT-NO-SUM
        public BigDecimal[] dedL1PctWs = new BigDecimal[165];// L:1452 DED-L1-PCT-WS
        public BigDecimal[] dedL1MatWs = new BigDecimal[165];// L:1453 DED-L1-MAT-WS
        public BigDecimal[] dedL2PctWs = new BigDecimal[165];// L:1454 DED-L2-PCT-WS
        public BigDecimal[] dedL2MatWs = new BigDecimal[165];// L:1455 DED-L2-MAT-WS
    }

    public static class DedTaxblTableSum {                  // L:1439 DED-TAXBL-TABLE-SUM
        // No child fields
    }

    public static class DedTaxbl {                          // L:1440 DED-TAXBL
        // No child fields
    }

    public static class DedTaxblTblSum {                    // L:1442 DED-TAXBL-TBL-SUM
        public String[] dedTaxblFed = new String[165];      // L:1443 DED-TAXBL-FED
        public String[] dedTaxblStt = new String[165];      // L:1444 DED-TAXBL-STT
        public String[] dedTaxblLoc = new String[165];      // L:1445 DED-TAXBL-LOC
        public String[] dedTaxblCit = new String[165];      // L:1446 DED-TAXBL-CIT
        public String[] dedTaxblOth = new String[165];      // L:1447 DED-TAXBL-OTH
        public String[] dedTaxblFica = new String[165];     // L:1448 DED-TAXBL-FICA
        public String[] dedTaxblEic = new String[165];      // L:1449 DED-TAXBL-EIC
    }

    public static class BankDeposit {                       // L:1460 BANK-DEPOSIT
        public BigDecimal[] bnkAbaNo = new BigDecimal[3];   // L:1461 BNK-ABA-NO
        public String[] bnkAcctType = new String[3];        // L:1462 BNK-ACCT-TYPE
        public String[] bnkPnFlag = new String[3];          // L:1463 BNK-PN-FLAG
        public String[] bnkAcct = new String[3];            // L:1464 BNK-ACCT
        public BigDecimal[] bnkDepAmt = new BigDecimal[3];  // L:1465 BNK-DEP-AMT
    }

    public static class AnnlTaxblTbl {                      // L:1481 ANNL-TAXBL-TBL
        public BigDecimal annlTaxblFed = BigDecimal.ZERO;   // L:1482 ANNL-TAXBL-FED
        public BigDecimal annlTaxblStt = BigDecimal.ZERO;   // L:1483 ANNL-TAXBL-STT
        public BigDecimal annlTaxblLoc = BigDecimal.ZERO;   // L:1484 ANNL-TAXBL-LOC
        public BigDecimal annlTaxblCit = BigDecimal.ZERO;   // L:1485 ANNL-TAXBL-CIT
        public BigDecimal annlTaxblOth = BigDecimal.ZERO;   // L:1486 ANNL-TAXBL-OTH
        public BigDecimal annlTaxblFica = BigDecimal.ZERO;  // L:1487 ANNL-TAXBL-FICA
        public BigDecimal annlTaxblEic = BigDecimal.ZERO;   // L:1488 ANNL-TAXBL-EIC
    }

    public static class WcTaxFields {                       // L:1501 WC-TAX-FIELDS
        public String wcDedNo = "";                         // L:1502 WC-DED-NO
        public BigDecimal wcDedSeq = BigDecimal.ZERO;       // L:1503 WC-DED-SEQ
        public BigDecimal wcDedAmt = BigDecimal.ZERO;       // L:1504 WC-DED-AMT
        public BigDecimal wsProdHrs = BigDecimal.ZERO;      // L:1505 WS-PROD-HRS
    }

    public static class TNum {                              // L:1516 T-NUM
        public BigDecimal wholeNumber = BigDecimal.ZERO;    // L:1517 WHOLE-NUMBER
        public BigDecimal decimal = BigDecimal.ZERO;        // L:1518 DECIMAL
    }

    public static class CalledParameters {                  // L:1635 CALLED-PARAMETERS
        public String cRetCode = "";                        // L:1636 C-RET-CODE
        public BigDecimal cClient = BigDecimal.ZERO;        // L:1637 C-CLIENT
        public short cComp = 0;                             // L:1638 C-COMP
        public BigDecimal cCorp = BigDecimal.ZERO;          // L:1639 C-CORP
        public BigDecimal cStore = BigDecimal.ZERO;         // L:1640 C-STORE
        public String cDed = "";                            // L:1641 C-DED
        public BigDecimal cRate = BigDecimal.ZERO;          // L:1642 C-RATE
        public BigDecimal cErnSeq = BigDecimal.ZERO;        // L:1643 C-ERN-SEQ
        public String cProdYn = "";                         // L:1644 C-PROD-YN
        public String cProfOpt = "";                        // L:1645 C-PROF-OPT
        public String cDataAreaName = "";                   // L:1646 C-DATA-AREA-NAME
        public String cPrelimProfile = "";                  // L:1647 C-PRELIM-PROFILE
    }

    public static class WsProfile {                         // L:1651 WS-PROFILE
        public String wsProf13 = "";                        // L:1652 WS-PROF-13
    }

    // === CONDITION ACCESSORS (88-level) ===
    public boolean isOk() {                                 // L:857 OK
        return "OK".equals(okFlag);
    }

    public boolean isNotOk() {                              // L:858 NOT-OK
        return "NO".equals(okFlag);
    }

    public boolean isTaxRoutineOk() {                       // L:860 TAX-ROUTINE-OK
        return "OK".equals(taxRoutineFlag);
    }

    public boolean isTaxRoutineError() {                    // L:861 TAX-ROUTINE-ERROR
        return "NO".equals(taxRoutineFlag);
    }

    public boolean isTaxKeyFound() {                        // L:863 TAX-KEY-FOUND
        return "OK".equals(taxKeyFlag);
    }

    public boolean isTaxKeyNotFound() {                     // L:864 TAX-KEY-NOT-FOUND
        return "NO".equals(taxKeyFlag);
    }

    public boolean isSetArrears() {                         // L:866 SET-ARREARS
        return "OK".equals(setArrFlag);
    }

    public boolean isDontSetArrears() {                     // L:867 DONT-SET-ARREARS
        return "NO".equals(setArrFlag);
    }

    public boolean isDedRoutineOk() {                       // L:869 DED-ROUTINE-OK
        return "OK".equals(dedRoutineFlag);
    }

    public boolean isDedRoutineError() {                    // L:870 DED-ROUTINE-ERROR
        return "NO".equals(dedRoutineFlag);
    }

    public boolean isPurgeOk() {                            // L:875 PURGE-OK
        return "OK".equals(purgeFlag);
    }

    public boolean isPurgeError() {                         // L:876 PURGE-ERROR
        return "NO".equals(purgeFlag);
    }

    public boolean isTakeWkDed() {                          // L:937 TAKE-WK-DED
        return "Y".equals(wkDedTaken);
    }

    public boolean isTakeBwDed() {                          // L:939 TAKE-BW-DED
        return "Y".equals(bwDedTaken);
    }

    public boolean isTakeSmDed() {                          // L:941 TAKE-SM-DED
        return "Y".equals(smDedTaken);
    }

    public boolean isTakeMtDed() {                          // L:943 TAKE-MT-DED
        return "Y".equals(mtDedTaken);
    }

    public boolean isRegTax() {                             // L:1063 REG-TAX
        return false;
    }

    public boolean isAddlTax() {                            // L:1064 ADDL-TAX
        return "A".equals(taxFlgWs);
    }

    public boolean isLessTax() {                            // L:1065 LESS-TAX
        return "L".equals(taxFlgWs);
    }

    public boolean isFixedTax() {                           // L:1066 FIXED-TAX
        return "F".equals(taxFlgWs);
    }

    public boolean isPctWageTax() {                         // L:1067 PCT-WAGE-TAX
        return "%".equals(taxFlgWs);
    }

    public boolean isPiggyBackTax() {                       // L:1068 PIGGY-BACK-TAX
        return "P".equals(taxFlgWs);
    }

    public boolean isTaxExempt() {                          // L:1069 TAX-EXEMPT
        return "E".equals(taxFlgWs);
    }

    public boolean isFedPctTax() {                          // L:1072 FED-PCT-TAX
        return "Z".equals(taxFlgWs);
    }

    public boolean isAdvEicMar() {                          // L:1074 ADV-EIC-MAR
        return "2".equals(taxFlgWs);
    }

    public boolean isAdvEicSng() {                          // L:1075 ADV-EIC-SNG
        return "1".equals(taxFlgWs);
    }

    public boolean isAdvEicMsp() {                          // L:1076 ADV-EIC-MSP
        return "3".equals(taxFlgWs);
    }

    // === ENTRY POINT ===
    /**
     * Main entry point - corresponds to PROCEDURE DIVISION USING.
     */
    public void run(String parmProfile, String parmSeq, String parmClient) {// L:1667 PROCEDURE DIVISION USING
        mainControl();
    }

    // === PARAGRAPH METHODS ===

    private void mainControl_000() {                        // L:1667 000-MAIN-CONTROL
        openFiles_010();                                    // L:1668 PERFORM 010-OPEN-FILES
        verification_100();                                 // L:1669 PERFORM 100-VERIFICATION THRU 100-EXIT
        if ("n".equals(gtnEnd)) {                           // L:1670 IF GTN-END = "N"
            okFlag = notOkLit;                              // L:1671 MOVE NOT-OK-LIT TO OK-FLAG
            grossToNet_200();                               // L:1672 PERFORM 200-GROSS-TO-NET THRU 200-EXIT
        }  // period ends IF scope
        closeFiles_800_200();                               // L:1673 PERFORM 800-200-CLOSE-FILES
        // GOBACK.                                          // L:1674 EXIT
    }

    private void openFiles_010() {                          // L:1677 010-OPEN-FILES
        // OPEN INPUT  PYSDREL0   PYS0REL1                  // L:1678 OPEN
        // payrollTimeRecord = default; // INITIALIZE PAYROLL-TIME-RECORD// L:1686 INITIALIZE PAYROLL-TIME-RECORD.
        // payrollPersonnelRecord = default; // INITIALIZE PAYROLL-PERSONNEL-RECORD// L:1687 INITIALIZE PAYROLL-PERSONNEL-RECORD.
    }

    private void exit_010() {                               // L:1689 010-EXIT
    }

    private void verification_100() {                       // L:1692 100-VERIFICATION
        gtnEnd = "N";                                       // L:1693 MOVE "N" TO GTN-END
        endOfYr = "N";                                      // L:1694 MOVE "N" TO END-OF-YR
        endOfQtr = "N";                                     // L:1695 MOVE "N" TO END-OF-QTR
        prmClient = parmClient;                             // L:1696 MOVE PARM-CLIENT TO PRM-CLIENT
        prmSeq = parmSeq;                                   // L:1698 MOVE PARM-SEQ TO PRM-SEQ
        cDataAreaName = "";                                 // L:1701 MOVE SPACES TO C-DATA-AREA-NAME
        cPrelimProfile = "";                                // L:1702 MOVE SPACES TO C-PRELIM-PROFILE
        cDataAreaName = "FMSPRLMPRF";                       // L:1703 MOVE "FMSPRLMPRF" TO C-DATA-AREA-NAME
        // CALL PYTDUPC                                     // L:1704 CALL "PYTDUPC" USING C-DATA-AREA-NAME,  ...
        callPytdupc();
        wsPrelimProfile = "";                               // L:1706 MOVE SPACES TO WS-PRELIM-PROFILE
        wsPrelimProfile = cPrelimProfile;                   // L:1707 MOVE C-PRELIM-PROFILE TO WS-PRELIM-PROFILE
        sdexco = parmProfile;                               // L:1709 MOVE PARM-PROFILE TO SDEXCO
        cClientEnv = "";                                    // L:1713 MOVE SPACES TO C-CLIENT-ENV
        // CALL FMHMUPK                                     // L:1714 CALL "FMHMUPK" USING C-CLIENT-ENV.      ...
        callFmhmupk();
        cRetCode = "";                                      // L:1717 MOVE SPACES TO C-RET-CODE
        cClient = prmClientNo;                              // L:1718 MOVE PRM-CLIENT-NO TO C-CLIENT
        expandDedArrearsSw = "N";                           // L:1719 MOVE "N" TO EXPAND-DED-ARREARS-SW
        // CALL PYDOXFK                                     // L:1720 CALL "PYDOXFK" USING C-RET-CODE,        ...
        callPydoxfk();
        sdmznu = prmSeqNo.toString();                       // L:1724 MOVE PRM-SEQ-NO TO SDMZNU
        sdbfnu = prmClientNo.toString();                    // L:1725 MOVE PRM-CLIENT-NO TO SDBFNU
        // READ PYSDREL0                                    // L:1726 READ
        messageO = "CLIENT CHECK RUN PROFILE NOT ON FILE."; // L:1728 MOVE "CLIENT CHECK RUN PROFILE NOT ON FILE." TO MESSAGE-O
        wsGtnErr = "AB";                                    // L:1730 MOVE "AB" TO WS-GTN-ERR
        wsDateEnd = BigDecimal.ZERO;                        // L:1731 MOVE 0 TO WS-DATE-END
        gtnError_800_700();                                 // L:1732 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // GO TO 100-EXIT - control flow                    // L:1733 GO TO 100-EXIT
        wsDateCheck = new BigDecimal(sdhhnu);               // L:1734 MOVE SDHHNU TO WS-DATE-CHECK
        wsDateEnd = new BigDecimal(sdhgnu);                 // L:1735 MOVE SDHGNU TO WS-DATE-END
        if (!"o".equals(sdixsa)) {                          // L:1736 IF SDIXSA NOT = "O"
            messageO = "NO OPEN PROFILE FOR G-T-N.";        // L:1737 MOVE "NO OPEN PROFILE FOR G-T-N." TO MESSAGE-O
            wsGtnErr = "AB";                                // L:1739 MOVE "AB" TO WS-GTN-ERR
            gtnError_800_700();                             // L:1740 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 100-EXIT - control flow                // L:1741 GO TO 100-EXIT
        }  // period ends IF scope
        if (parmProfile == wsPrelimProfile) {               // L:1744 IF PARM-PROFILE = WS-PRELIM-PROFILE     ...
            if (!"po".equals(sdiysa)) {                     // L:1745 IF SDIYSA NOT = "PO"                    ...
                messageO = "NOT ELIGIBLE FOR G-T-N.";       // L:1746 MOVE "NOT ELIGIBLE FOR G-T-N." TO MESSAGE-O
                wsGtnErr = "AB";                            // L:1748 MOVE "AB" TO WS-GTN-ERR
                gtnError_800_700();                         // L:1749 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                // GO TO 100-EXIT - control flow            // L:1750 GO TO 100-EXIT
            }                                               // L:1751 END-IF
        } else {                                            // L:1752 ELSE
            if (!"1O".equals(sdiysa)) {                     // L:1753 IF SDIYSA NOT = "1O"
                messageO = "NOT ELIGIBLE FOR G-T-N.";       // L:1754 MOVE "NOT ELIGIBLE FOR G-T-N." TO MESSAGE-O
                wsGtnErr = "AB";                            // L:1756 MOVE "AB" TO WS-GTN-ERR
                gtnError_800_700();                         // L:1757 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                // GO TO 100-EXIT - control flow            // L:1758 GO TO 100-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        clientOptions_110();                                // L:1759 PERFORM 110-CLIENT-OPTIONS THRU 110-EXIT
        verifyEoqEoy_150();                                 // L:1760 PERFORM 150-VERIFY-EOQ-EOY THRU 150-EXIT
        if (purgeError) {                                   // L:1761 IF PURGE-ERROR
            wsGtnErr = "AB";                                // L:1762 MOVE "AB" TO WS-GTN-ERR
            gtnError_800_700();                             // L:1763 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 100-EXIT - control flow                // L:1764 GO TO 100-EXIT
        }  // period ends IF scope
        housekeepingControl_1000_000();                     // L:1765 PERFORM 1000-000-HOUSEKEEPING-CONTROL
    }

    private void exit_100() {                               // L:1767 100-EXIT
    }

    private void clientOptions_110() {                      // L:1769 110-CLIENT-OPTIONS
        skipPurgeVerify = "N";                              // L:1770 MOVE "N" TO SKIP-PURGE-VERIFY
        skipDirDep = "N";                                   // L:1771 MOVE "N" TO SKIP-DIR-DEP
        wcTaxOptWs = "N";                                   // L:1772 MOVE "N" TO WC-TAX-OPT-WS
        ficaOnlyOptWs = "N";                                // L:1773 MOVE "N" TO FICA-ONLY-OPT-WS
        clnSetArrOptWs = "N";                               // L:1774 MOVE "N" TO CLN-SET-ARR-OPT-WS
        clnDirdepVoucherOptWs = "N";                        // L:1775 MOVE "N" TO CLN-DIRDEP-VOUCHER-OPT-WS
        clnDirdepWaitOptWs = "N";                           // L:1776 MOVE "N" TO CLN-DIRDEP-WAIT-OPT-WS
        clnDeptLaborFwwOptWs = "N";                         // L:1777 MOVE "N" TO CLN-DEPT-LABOR-FWW-OPT-WS
        clnGrossLimitOptWs = BigDecimal.valueOf(99999999);  // L:1778 MOVE 99999999 TO CLN-GROSS-LIMIT-OPT-WS
        clnHoursLimitOptWs = BigDecimal.valueOf(99999999);  // L:1779 MOVE 99999999 TO CLN-HOURS-LIMIT-OPT-WS
        clnShift1To2OptWs = "N";                            // L:1780 MOVE "N" TO CLN-SHIFT-1-TO-2-OPT-WS
        clnShift1To3OptWs = "N";                            // L:1781 MOVE "N" TO CLN-SHIFT-1-TO-3-OPT-WS
        clnShift1ToAllOptWs = "N";                          // L:1782 MOVE "N" TO CLN-SHIFT-1-TO-ALL-OPT-WS
        cln4K90RegOptWs = "N";                              // L:1783 MOVE "N" TO CLN-4K90-REG-OPT-WS
        clnOpt62Ws = "N";                                   // L:1784 MOVE "N" TO CLN-OPT62-WS
        wsCliOpt608Sw = "N";                                // L:1785 MOVE "N" TO WS-CLI-OPT-608-SW
        wsCliOpt630Sw = "N";                                // L:1786 MOVE "N" TO WS-CLI-OPT-630-SW
        wsClientDedOpt36Sw = "N";                           // L:1787 MOVE "N" TO WS-CLIENT-DED-OPT-36-SW
        wsClientDedOpt30Sw = "N";                           // L:1788 MOVE "N" TO WS-CLIENT-DED-OPT-30-SW
        clnBenDeductOptWs = BigDecimal.valueOf(26);         // L:1789 MOVE 26 TO CLN-BEN-DEDUCT-OPT-WS
        clnBaDeductOptWs = BigDecimal.valueOf(26);          // L:1790 MOVE 26 TO CLN-BA-DEDUCT-OPT-WS
        clnXsickSeq01 = BigDecimal.ZERO;                    // L:1791 MOVE 0 TO CLN-XSICK-SEQ01
        clnXsickSeq02 = BigDecimal.ZERO;                    // L:1792 MOVE 0 TO CLN-XSICK-SEQ02
        clnXsickSeq03 = BigDecimal.ZERO;                    // L:1793 MOVE 0 TO CLN-XSICK-SEQ03
        clnXsickSeq04 = BigDecimal.ZERO;                    // L:1794 MOVE 0 TO CLN-XSICK-SEQ04
        clnXsickSeq05 = BigDecimal.ZERO;                    // L:1795 MOVE 0 TO CLN-XSICK-SEQ05
        clnXsickSeq06 = BigDecimal.ZERO;                    // L:1796 MOVE 0 TO CLN-XSICK-SEQ06
        clnXsickSeq07 = BigDecimal.ZERO;                    // L:1797 MOVE 0 TO CLN-XSICK-SEQ07
        clnXsickSeq08 = BigDecimal.ZERO;                    // L:1798 MOVE 0 TO CLN-XSICK-SEQ08
        clnXsickSeq09 = BigDecimal.ZERO;                    // L:1799 MOVE 0 TO CLN-XSICK-SEQ09
        clnXsickSeq10 = BigDecimal.ZERO;                    // L:1800 MOVE 0 TO CLN-XSICK-SEQ10
        clnCtLeaveLimit = BigDecimal.ZERO;                  // L:1801 MOVE 0 TO CLN-CT-LEAVE-LIMIT
        // cl1Key = default; // INITIALIZE CL1-KEY          // L:1803 INITIALIZE CL1-KEY.
        cl1ClientNo = prmClientNo.toString();               // L:1804 MOVE PRM-CLIENT-NO TO CL1-CLIENT-NO
        // START PAYCLNPF01 KEY NOT < CL1-KEY               // L:1805 CODE
        // INVALID KEY                                      // L:1806 CODE
        clientNoO = prmClientNo.toString();                 // L:1807 MOVE PRM-CLIENT-NO TO CLIENT-NO-O
        wsGtnErr = "WR";                                    // L:1808 MOVE "WR" TO WS-GTN-ERR
        messageO = "CLIENT OPTIONS NOT ON FILE.";           // L:1809 MOVE "CLIENT OPTIONS NOT ON FILE." TO MESSAGE-O
        gtnError_800_700();                                 // L:1810 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // GO TO 110-EXIT - control flow                    // L:1811 GO TO 110-EXIT
    }

    private void readOptions_110() {                        // L:1813 110-READ-OPTIONS
        // READ PAYCLNPF01 NEXT                             // L:1814 READ
        // GO TO 110-EXIT - control flow                    // L:1816 GO TO 110-EXIT
        if (new BigDecimal(cl1ClientNo).compareTo(prmClientNo) != 0) {// L:1817 IF CL1-CLIENT-NO NOT = PRM-CLIENT-NO
            // GO TO 110-EXIT - control flow                // L:1818 GO TO 110-EXIT
        }  // period ends IF scope
        if (cl1OptNo == 1) {                                // L:1819 IF CL1-OPT-NO = 1
            skipPurgeVerify = "Y";                          // L:1820 MOVE "Y" TO SKIP-PURGE-VERIFY
        }  // period ends IF scope
        if (cl1OptNo == 2) {                                // L:1821 IF CL1-OPT-NO = 2
            skipDirDep = "Y";                               // L:1822 MOVE "Y" TO SKIP-DIR-DEP
        }  // period ends IF scope
        if (cl1OptNo == 3) {                                // L:1823 IF CL1-OPT-NO = 3
            ficaOnlyOptWs = "Y";                            // L:1824 MOVE "Y" TO FICA-ONLY-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 9) {                                // L:1825 IF CL1-OPT-NO = 9
            wcTaxOptWs = "Y";                               // L:1826 MOVE "Y" TO WC-TAX-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 10) {                               // L:1827 IF CL1-OPT-NO = 10
            clnSetArrOptWs = "Y";                           // L:1828 MOVE "Y" TO CLN-SET-ARR-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 37) {                               // L:1829 IF CL1-OPT-NO = 37
            clnDirdepVoucherOptWs = "Y";                    // L:1830 MOVE "Y" TO CLN-DIRDEP-VOUCHER-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 46) {                               // L:1831 IF CL1-OPT-NO = 46
            clnBenDeductOptWs = new BigDecimal(cl1OptValue);// L:1832 MOVE CL1-OPT-VALUE TO CLN-BEN-DEDUCT-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 47) {                               // L:1833 IF CL1-OPT-NO = 47
            clnDirdepWaitOptWs = "Y";                       // L:1834 MOVE "Y" TO CLN-DIRDEP-WAIT-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 53) {                               // L:1835 IF CL1-OPT-NO = 53
            clnDeptLaborFwwOptWs = "Y";                     // L:1836 MOVE "Y" TO CLN-DEPT-LABOR-FWW-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 54) {                               // L:1837 IF CL1-OPT-NO = 54
            clnGrossLimitOptWs = new BigDecimal(cl1OptValue);// L:1838 MOVE CL1-OPT-VALUE TO CLN-GROSS-LIMIT-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 57) {                               // L:1839 IF CL1-OPT-NO = 57
            clnHoursLimitOptWs = new BigDecimal(cl1OptValue);// L:1840 MOVE CL1-OPT-VALUE TO CLN-HOURS-LIMIT-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 60) {                               // L:1841 IF CL1-OPT-NO = 60
            clnShift1To2OptWs = "Y";                        // L:1842 MOVE "Y" TO CLN-SHIFT-1-TO-2-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 61) {                               // L:1843 IF CL1-OPT-NO = 61
            clnShift1To3OptWs = "Y";                        // L:1844 MOVE "Y" TO CLN-SHIFT-1-TO-3-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 62) {                               // L:1849 IF CL1-OPT-NO = 62                      ...
            clnOpt62Ws = "Y";                               // L:1850 MOVE "Y" TO CLN-OPT62-WS
            if (cl1OptNo == 63) {                           // L:1851 IF CL1-OPT-NO = 63
                cln4K90RegOptWs = "Y";                      // L:1852 MOVE "Y" TO CLN-4K90-REG-OPT-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if (cl1OptNo == 69) {                               // L:1853 IF CL1-OPT-NO = 69
            clnBaDeductOptWs = new BigDecimal(cl1OptValue); // L:1854 MOVE CL1-OPT-VALUE TO CLN-BA-DEDUCT-OPT-WS
        }  // period ends IF scope
        if (cl1OptNo == 850) {                              // L:1855 IF CL1-OPT-NO = 850                     ...
            clnXsickSeq01 = new BigDecimal(cl1OptValue);    // L:1856 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ01
            if (cl1OptNo == 851) {                          // L:1857 IF CL1-OPT-NO = 851                     ...
                clnXsickSeq02 = new BigDecimal(cl1OptValue);// L:1858 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ02
                if (cl1OptNo == 852) {                      // L:1859 IF CL1-OPT-NO = 852                     ...
                    clnXsickSeq03 = new BigDecimal(cl1OptValue);// L:1860 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ03
                    if (cl1OptNo == 853) {                  // L:1861 IF CL1-OPT-NO = 853                     ...
                        clnXsickSeq04 = new BigDecimal(cl1OptValue);// L:1862 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ04
                        if (cl1OptNo == 854) {              // L:1863 IF CL1-OPT-NO = 854                     ...
                            clnXsickSeq05 = new BigDecimal(cl1OptValue);// L:1864 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ05
                            if (cl1OptNo == 855) {          // L:1865 IF CL1-OPT-NO = 855                     ...
                                clnXsickSeq06 = new BigDecimal(cl1OptValue);// L:1866 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ06
                                if (cl1OptNo == 856) {      // L:1867 IF CL1-OPT-NO = 856                     ...
                                    clnXsickSeq07 = new BigDecimal(cl1OptValue);// L:1868 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ07
                                    if (cl1OptNo == 857) {  // L:1869 IF CL1-OPT-NO = 857                     ...
                                        clnXsickSeq08 = new BigDecimal(cl1OptValue);// L:1870 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ08
                                        if (cl1OptNo == 858) {// L:1871 IF CL1-OPT-NO = 858                     ...
                                            clnXsickSeq09 = new BigDecimal(cl1OptValue);// L:1872 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ09
                                            if (cl1OptNo == 859) {// L:1873 IF CL1-OPT-NO = 859                     ...
                                                clnXsickSeq10 = new BigDecimal(cl1OptValue);// L:1874 MOVE CL1-OPT-VALUE TO CLN-XSICK-SEQ10
                                                if (cl1OptNo == 608) {// L:1875 IF CL1-OPT-NO = 608                     ...
                                                    wsCliOpt608Sw = "Y";// L:1876 MOVE "Y" TO WS-CLI-OPT-608-SW
                                                    clnCtLeaveLimit = new BigDecimal(cl1OptValue);// L:1877 MOVE CL1-OPT-VALUE TO CLN-CT-LEAVE-LIMIT
                                                    if (cl1OptNo == 630) {// L:1878 IF CL1-OPT-NO = 630                     ...
                                                        wsCliOpt630Sw = "Y";// L:1879 MOVE "Y" TO WS-CLI-OPT-630-SW
                                                        // GO TO 110-READ-OPTIONS - control flow// L:1880 GO TO 110-READ-OPTIONS
                                                    }  // period ends IF scope
                                                }  // period ends IF scope
                                            }  // period ends IF scope
                                        }  // period ends IF scope
                                    }  // period ends IF scope
                                }  // period ends IF scope
                            }  // period ends IF scope
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
    }

    private void exit_110() {                               // L:1882 110-EXIT
    }

    private void verifyEoqEoy_150() {                       // L:1885 150-VERIFY-EOQ-EOY
        wsProfile = parmProfile;                            // L:1886 MOVE PARM-PROFILE TO WS-PROFILE
        cRetCode = "";                                      // L:1887 MOVE SPACES TO C-RET-CODE
        cProfOpt = "";                                      // L:1887 MOVE SPACES TO C-PROF-OPT
        // CALL PYXCXFK                                     // L:1888 CALL "PYXCXFK" USING C-RET-CODE, C-PROF-...
        callPyxcxfk();
        if ("glpost".equals(parmProfile) || wsProf13 == cProfOpt) {// L:1889 IF PARM-PROFILE = "GLPOST" OR
            // GO TO 150-EXIT - control flow                // L:1891 GO TO 150-EXIT
        }  // period ends IF scope
        s0bfnu = prmClientNo.toString();                    // L:1892 MOVE PRM-CLIENT-NO TO S0BFNU
        // READ PYS0REL1                                    // L:1893 READ
        messageO = "NO CLIENT PRIOR PERIOD.";               // L:1895 MOVE "NO CLIENT PRIOR PERIOD." TO MESSAGE-O
        wsGtnErr = "AB";                                    // L:1897 MOVE "AB" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:1898 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // GO TO 150-EXIT - control flow                    // L:1899 GO TO 150-EXIT
        calCdeCycle = s0cwte;                               // L:1900 MOVE S0CWTE TO CAL-CDE-CYCLE
        calNumber = Integer.parseInt(s0hdnu);               // L:1901 MOVE S0HDNU TO CAL-NUMBER
        calYear = Integer.parseInt(s0henu);                 // L:1902 MOVE S0HENU TO CAL-YEAR
        calPrdNo = Integer.parseInt(s0hfnu);                // L:1903 MOVE S0HFNU TO CAL-PRD-NO
        readPaycal_800_450();                               // L:1904 PERFORM 800-450-READ-PAYCAL
        if (calStat.compareTo(ioOk) != 0) {                 // L:1905 IF CAL-STAT NOT = IO-OK
            // GO TO 150-EXIT - control flow                // L:1906 GO TO 150-EXIT
        }  // period ends IF scope
        if ("y".equals(calClrQtd)) {                        // L:1907 IF CAL-CLR-QTD = "Y"
            endOfQtr = "Y";                                 // L:1908 MOVE "Y" TO END-OF-QTR
        }  // period ends IF scope
        if (("n".equals(s0l3sa) || "n".equals(s0l4sa)) && "y".equals(calClrQtd)) {// L:1909 IF (S0L3SA = "N" OR
            messageO = "EOQ EXTRACT AND/OR PURGE NOT COMPLETE.";// L:1912 MOVE "EOQ EXTRACT AND/OR PURGE NOT COMPLETE." TO MESSAGE-O
            wsGtnErr = "AB";                                // L:1914 MOVE "AB" TO WS-GTN-ERR
            wsDateEnd = BigDecimal.ZERO;                    // L:1915 MOVE 0 TO WS-DATE-END
            gtnError_800_700();                             // L:1916 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 150-EXIT - control flow                // L:1917 GO TO 150-EXIT
        }  // period ends IF scope
        if ("y".equals(skipPurgeVerify)) {                  // L:1918 IF SKIP-PURGE-VERIFY = "Y"
            messageO = "WARNING!! EOQ/EOY PURGES HAVE NOT BEEN VERIFIED.";// L:1919 MOVE "WARNING!! EOQ/EOY PURGES HAVE NOT BEEN VERIFIED." TO MESSAGE-O
            wsGtnErr = "WR";                                // L:1921 MOVE "WR" TO WS-GTN-ERR
            gtnError_800_700();                             // L:1922 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        } else {                                            // L:1923 ELSE
            verifyPurge_1000_600();                         // L:1924 PERFORM 1000-600-VERIFY-PURGE THRU 1000-699-EXIT
        }  // period ends IF scope
    }

    private void exit_150() {                               // L:1926 150-EXIT
        // /                                                // L:1927 COMMENT
    }

    private void grossToNet_200() {                         // L:1933 200-GROSS-TO-NET
        // Initialize BRK-KEY                               // L:1934 INITIALIZE BRK-KEY PAYROLL-SUMMARY-AREA
        brkClientNo = BigDecimal.ZERO;
        brkEmpNo = BigDecimal.ZERO;
        brkCorpWrk = BigDecimal.ZERO;
        brkStoreWrk = BigDecimal.ZERO;
        brkDeptWrk = BigDecimal.ZERO;
        brkCheckType = "";
        brkCheckNo = BigDecimal.ZERO;
        brkDateEnd = BigDecimal.ZERO;
        // Initialize PAYROLL-SUMMARY-AREA                  // L:1934 INITIALIZE BRK-KEY PAYROLL-SUMMARY-AREA
        ernCppGrsLessTxSum = BigDecimal.ZERO;
        lvSickAccRteSum = BigDecimal.ZERO;
        lvAnnlAccRteSum = BigDecimal.ZERO;
        lvPersAccRteSum = BigDecimal.ZERO;
        lvAccRteSum = BigDecimal.ZERO;
        annlTaxblFicaYtd = BigDecimal.ZERO;
        pctTotEarnWs = BigDecimal.ZERO;                     // L:1938 INITIALIZE PCT-TOT-EARN-WS.             ...
        // CALL PYD1XFK                                     // L:1941 CALL "PYD1XFK" USING C-RET-CODE, C-CLIEN...
        callPyd1Xfk();
        fdCount = BigDecimal.ZERO;                          // L:1942 MOVE ZEROS TO FD-COUNT
        savedTcpDirDepVoucher = "";                         // L:1945 INITIALIZE SAVED-TCP-DIR-DEP-VOUCHER    ...
        grossNetErrorCntWs = BigDecimal.ZERO;               // L:1948 MOVE ZERO TO GROSS-NET-ERROR-CNT-WS
        timClientNo = prmClientNo.shortValue();             // L:1949 MOVE PRM-CLIENT-NO TO TIM-CLIENT-NO
        startPaytim_800_330();                              // L:1950 PERFORM 800-330-START-PAYTIM
        if (timStat == ioAtEnd) {                           // L:1951 IF TIM-STAT = IO-AT-END
            // GO TO 200-EXIT - control flow                // L:1952 GO TO 200-EXIT
        }  // period ends IF scope
        readPaytim_800_335();                               // L:1953 PERFORM 800-335-READ-PAYTIM
        readClient_200_180();                               // L:1954 PERFORM 200-180-READ-CLIENT THRU 200-180-EXIT
        nextEmployee_200_125();                             // L:1955 PERFORM 200-125-NEXT-EMPLOYEE
        payrollCurrentTransRecord = "";                     // L:1956 INITIALIZE PAYROLL-CURRENT-TRANS-RECORD
        processControl_200_010();                           // L:1958 PERFORM 200-010-PROCESS-CONTROL THRU 200-010-EXIT
        employeeBreak_200_121();                            // L:1960 PERFORM 200-121-EMPLOYEE-BREAK
    }

    private void exit_200() {                               // L:1962 200-EXIT
    }

    private void processControl_200_010() {                 // L:1965 200-010-PROCESS-CONTROL
        breakControl_200_120();                             // L:1966 PERFORM 200-120-BREAK-CONTROL
        processDed_200_100();                               // L:1967 PERFORM 200-100-PROCESS-DED THRU 200-100-EXIT
        processErn_200_150();                               // L:1968 PERFORM 200-150-PROCESS-ERN THRU 200-150-EXIT
        timCheckTypeHold = timCheckType;                    // L:1969 MOVE TIM-CHECK-TYPE TO TIM-CHECK-TYPE-HOLD
        timCodeHold = timCode;                              // L:1970 MOVE TIM-CODE TO TIM-CODE-HOLD
        timDateEndHold = BigDecimal.valueOf(timDateEnd);    // L:1971 MOVE TIM-DATE-END TO TIM-DATE-END-HOLD
        timCdeCycleHold = timCdeCycle;                      // L:1972 MOVE TIM-CDE-CYCLE TO TIM-CDE-CYCLE-HOLD
        timCheckNoHold = BigDecimal.valueOf(timCheckNo);    // L:1973 MOVE TIM-CHECK-NO TO TIM-CHECK-NO-HOLD
        if ((timStat == ioOk && perStat == ioOk && ernStat == ioOk)) {// L:1974 IF (TIM-STAT = IO-OK AND PER-STAT = IO-O...
            computeEarn_300_270();                          // L:1977 PERFORM 300-270-COMPUTE-EARN
        }  // period ends IF scope
        readPaytim_800_335();                               // L:1978 PERFORM 800-335-READ-PAYTIM
    }

    private void exit_200_010() {                           // L:1980 200-010-EXIT
    }

    private void processDed_200_100() {                     // L:1988 200-100-PROCESS-DED
        if (perStat.compareTo(ioOk) != 0 || ernStat.compareTo(ioOk) != 0 || !"d".equals(timGroup)) {// L:1989 IF PER-STAT NOT = IO-OK
            // GO TO 200-100-EXIT - control flow            // L:1994 GO TO 200-100-EXIT
        }  // period ends IF scope
        findDedTbl_200_105();                               // L:1995 PERFORM 200-105-FIND-DED-TBL
        if (i.compareTo(BigDecimal.valueOf(165)) > 0) {     // L:2001 IF I > 165                              ...
            // STRING parse failed (no INTO): STRING "DED NOT IN TABLE ERROR - "...// L:2002 STRING "DED NOT IN TABLE ERROR - "
            wsGtnErr = "DE";                                // L:2006 MOVE "DE" TO WS-GTN-ERR
            gtnError_800_700();                             // L:2007 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 200-100-EXIT - control flow            // L:2008 GO TO 200-100-EXIT
        }  // period ends IF scope
        if ("2".equals(timCheckType)) {                     // L:2018 IF TIM-CHECK-TYPE = "2"
            dedAmtSum[i.intValue()] = dedAmtSum[i.intValue()].add(timAmount);// L:2019 ADD TIM-AMOUNT TO DED-AMT-SUM (I)
        } else {                                            // L:2020 ELSE
            dedAmtSum[i.intValue()] = timAmount;            // L:2021 MOVE TIM-AMOUNT TO DED-AMT-SUM(I)
        }  // period ends IF scope
        dedPctSum[i.intValue()] = BigDecimal.ZERO;          // L:2022 MOVE 0 TO DED-PCT-SUM(I)
        dedNoToTakeSum[i.intValue()] = BigDecimal.valueOf(timNoCycles);// L:2023 MOVE TIM-NO-CYCLES TO DED-NO-TO-TAKE-SUM(I)
        if ("r".equals(timCheckType)) {                     // L:2024 IF TIM-CHECK-TYPE = "R"
            dedBalSum[i.intValue()] = BigDecimal.valueOf(99999.99);// L:2025 MOVE 99999.99 TO DED-BAL-SUM(I)
            dedErrSum[i.intValue()] = "N";                  // L:2026 MOVE "N" TO DED-ERR-SUM(I)
        }  // period ends IF scope
        if ((("2".equals(timCheckType) || "3".equals(timCheckType))) && "fa".equals(dedParaSum[i.intValue()])) {// L:2034 IF (TIM-CHECK-TYPE = "2" OR "3")
            dedBalSum[i.intValue()] = BigDecimal.valueOf(99999.99);// L:2037 MOVE 99999.99 TO DED-BAL-SUM(I)
            dedErrSum[i.intValue()] = "N";                  // L:2038 MOVE "N" TO DED-ERR-SUM(I)
        }  // period ends IF scope
    }

    private void exit_200_100() {                           // L:2040 200-100-EXIT
    }

    private void findDedTbl_200_105() {                     // L:2043 200-105-FIND-DED-TBL
    }

    private void processErn_200_150() {                     // L:2052 200-150-PROCESS-ERN
        if (perStat.compareTo(ioOk) != 0 || ernStat.compareTo(ioOk) != 0) {// L:2053 IF PER-STAT NOT = IO-OK
            // GO TO 200-150-EXIT - control flow            // L:2056 GO TO 200-150-EXIT
        }  // period ends IF scope
        if (!"r".equals(timCheckType)) {                    // L:2057 IF TIM-CHECK-TYPE NOT = "R"
            if ("e".equals(timGroup) && !"3".equals(timCheckType)) {// L:2058 IF TIM-GROUP = "E" AND TIM-CHECK-TYPE NO...
                taxartn = "";                               // L:2059 INITIALIZE TAXARTN,                     ...
                // id520 = default; // INITIALIZE ID-520    // L:2059 INITIALIZE TAXARTN,                     ...
                taxacln = BigDecimal.valueOf(timClientNo);  // L:2071 MOVE TIM-CLIENT-NO TO TAXACLN
                taxaern = timCode;                          // L:2072 MOVE TIM-CODE TO TAXAERN
                taxaerr = "N";                              // L:2073 MOVE "N" TO TAXAERR
                // CALL PZE1XFK                             // L:2074 CALL "PZE1XFK" USING                    ...
                callPze1Xfk();
                ernCppFedTaxability[timTblElement] = taxafed;// L:2088 MOVE TAXAFED TO ERN-CPP-FED-TAXABILITY(TIM-TBL-ELEMENT)
                ernCppSttTaxability[timTblElement] = taxastt;// L:2089 MOVE TAXASTT TO ERN-CPP-STT-TAXABILITY(TIM-TBL-ELEMENT)
                ernCppCitTaxability[timTblElement] = taxacit;// L:2090 MOVE TAXACIT TO ERN-CPP-CIT-TAXABILITY(TIM-TBL-ELEMENT)
                ernCppLocTaxability[timTblElement] = taxaloc;// L:2091 MOVE TAXALOC TO ERN-CPP-LOC-TAXABILITY(TIM-TBL-ELEMENT)
                ernCppOthTaxability[timTblElement] = taxaoth;// L:2092 MOVE TAXAOTH TO ERN-CPP-OTH-TAXABILITY(TIM-TBL-ELEMENT)
                ernCppFicaTaxability[timTblElement] = taxafica;// L:2093 MOVE TAXAFICA TO ERN-CPP-FICA-TAXABILITY(TIM-TBL-ELEMENT)
                ernCppFutaTaxability[timTblElement] = taxafuta;// L:2094 MOVE TAXAFUTA TO ERN-CPP-FUTA-TAXABILITY(TIM-TBL-ELEMENT)
                ernCppSucaTaxability[timTblElement] = taxasuca;// L:2095 MOVE TAXASUCA TO ERN-CPP-SUCA-TAXABILITY(TIM-TBL-ELEMENT)
                ernCppSum[timTblElement] = ernCppSum[timTblElement].add(timAmount);// L:2097 ADD TIM-AMOUNT TO ERN-CPP-SUM (TIM-TBL-E...
                hrsCppSum[timTblElement] = hrsCppSum[timTblElement].add(timHours);// L:2098 ADD TIM-HOURS TO HRS-CPP-SUM (TIM-TBL-EL...
            } else if ("b".equals(timGroup)) {              // L:2099 ELSE IF TIM-GROUP = "B"
                bnkDepAmt[timTblElement] = bnkDepAmt[timTblElement].add(timAmount);// L:2100 ADD TIM-AMOUNT TO BNK-DEP-AMT (TIM-TBL-E...
            } else if ("ta".equals(timType)) {              // L:2101 ELSE IF TIM-TYPE = "TA"
                taxCppFicaSum = taxCppFicaSum.add(timAmount);// L:2102 ADD TIM-AMOUNT TO TAX-CPP-FICA-SUM
            } else if (("tf".equals(timType) && "fwt".equals(timCode))) {// L:2103 ELSE IF (TIM-TYPE = "TF" AND TIM-CODE = ...
                taxCppFedSum = taxCppFedSum.add(timAmount); // L:2104 ADD TIM-AMOUNT TO TAX-CPP-FED-SUM
            } else if (("tf".equals(timType) && "eic".equals(timCode))) {// L:2105 ELSE IF (TIM-TYPE = "TF" AND TIM-CODE = ...
                taxCppEicSum = taxCppEicSum.add(timAmount); // L:2106 ADD TIM-AMOUNT TO TAX-CPP-EIC-SUM
            } else if ("ts".equals(timType)) {              // L:2107 ELSE IF TIM-TYPE = "TS"
                taxCppSttSum = taxCppSttSum.add(timAmount); // L:2108 ADD TIM-AMOUNT TO TAX-CPP-STT-SUM
                cdeTaxWs = timCode;                         // L:2109 MOVE TIM-CODE TO CDE-TAX-WS
                sttLiteral = timCode;                       // L:2109 MOVE TIM-CODE TO STT-LITERAL
            } else if ("tl".equals(timType)) {              // L:2110 ELSE IF TIM-TYPE = "TL"
                taxCppLocSum = taxCppLocSum.add(timAmount); // L:2111 ADD TIM-AMOUNT TO TAX-CPP-LOC-SUM
                cdeTaxWs = timCode;                         // L:2112 MOVE TIM-CODE TO CDE-TAX-WS
                locLiteral = timCode;                       // L:2112 MOVE TIM-CODE TO LOC-LITERAL
            } else if ("tc".equals(timType)) {              // L:2113 ELSE IF TIM-TYPE = "TC"
                taxCppCitSum = taxCppCitSum.add(timAmount); // L:2114 ADD TIM-AMOUNT TO TAX-CPP-CIT-SUM
                cdeTaxWs = timCode;                         // L:2115 MOVE TIM-CODE TO CDE-TAX-WS
                citLiteral = timCode;                       // L:2115 MOVE TIM-CODE TO CIT-LITERAL
            } else if ("to".equals(timType)) {              // L:2116 ELSE IF TIM-TYPE = "TO"
                cdeTaxWs = timCode;                         // L:2117 MOVE TIM-CODE TO CDE-TAX-WS
                othLiteral = timCode;                       // L:2117 MOVE TIM-CODE TO OTH-LITERAL
                taxCppOthSum = taxCppOthSum.add(timAmount); // L:2118 ADD TIM-AMOUNT TO TAX-CPP-OTH-SUM.
            }  // period ends IF scope
        }  // period ends IF scope
        if ((("m".equals(timCheckType) || "2".equals(timCheckType) || "v".equals(timCheckType) || "x".equals(timCheckType))) && ("xa".equals(timType)) && ("ficm".equals(timCode))) {// L:2119 IF (TIM-CHECK-TYPE = "M" OR "2" OR "V" O...
            writeFicmTrans_500_600();                       // L:2121 PERFORM 500-600-WRITE-FICM-TRANS THRU 500-600-EXIT
        }  // auto-close unclosed IF
    }

    private void exit_200_150() {                           // L:2124 200-150-EXIT
    }

    private void breakControl_200_120() {                   // L:2132 200-120-BREAK-CONTROL
        employeeBreak_200_121();                            // L:2133 PERFORM 200-121-EMPLOYEE-BREAK
        nextEmployee_200_125();                             // L:2135 PERFORM 200-125-NEXT-EMPLOYEE
    }

    private void employeeBreak_200_121() {                  // L:2142 200-121-EMPLOYEE-BREAK
        if (brkClientNo.compareTo(BigDecimal.valueOf(timClientNo)) != 0) {// L:2143 IF BRK-CLIENT-NO NOT = TIM-CLIENT-NO
            timStat = ioAtEnd;                              // L:2144 MOVE IO-AT-END TO TIM-STAT
        }  // period ends IF scope
        if ((brkClientNo.compareTo(BigDecimal.valueOf(timClientNo)) != 0 || brkEmpNo.compareTo(BigDecimal.valueOf(timEmpNo)) != 0 || brkCheckType.compareTo(timCheckType) != 0 || brkCheckNo.compareTo(BigDecimal.valueOf(timCheckNo)) != 0 || brkDateEnd.compareTo(BigDecimal.valueOf(timDateEnd)) != 0 || timStat == ioAtEnd) && (perStat == ioOk && ernStat == ioOk)) {// L:2146 IF (BRK-CLIENT-NO NOT = TIM-CLIENT-NO
            wrapUp_200_190();                               // L:2159 PERFORM 200-190-WRAP-UP THRU 200-190-EXIT
        }  // period ends IF scope
        if ((brkClientNo.compareTo(BigDecimal.valueOf(timClientNo)) != 0 || brkEmpNo.compareTo(BigDecimal.valueOf(timEmpNo)) != 0)) {// L:2161 IF (BRK-CLIENT-NO NOT = TIM-CLIENT-NO   ...
            wsFicmYtd = BigDecimal.ZERO;                    // L:2164 MOVE ZEROS TO WS-FICM-YTD
        }  // auto-close unclosed IF
    }

    private void clientBreak_200_122() {                    // L:2170 200-122-CLIENT-BREAK
        if ((brkClientNo.compareTo(BigDecimal.valueOf(timClientNo)) != 0 && timStat.compareTo(ioAtEnd) != 0)) {// L:2171 IF (BRK-CLIENT-NO NOT = TIM-CLIENT-NO
            timStat = ioAtEnd;                              // L:2174 MOVE IO-AT-END TO TIM-STAT
        }  // period ends IF scope
    }

    private void nextEmployee_200_125() {                   // L:2182 200-125-NEXT-EMPLOYEE
        if ((brkClientNo.compareTo(BigDecimal.valueOf(timClientNo)) != 0 || brkEmpNo.compareTo(BigDecimal.valueOf(timEmpNo)) != 0 || brkCheckType.compareTo(timCheckType) != 0 || brkCheckNo.compareTo(BigDecimal.valueOf(timCheckNo)) != 0 || brkDateEnd.compareTo(BigDecimal.valueOf(timDateEnd)) != 0) && timStat.compareTo(ioAtEnd) != 0) {// L:2184 IF (BRK-CLIENT-NO NOT = TIM-CLIENT-NO
            nextEmployee_200_170();                         // L:2195 PERFORM 200-170-NEXT-EMPLOYEE
            brkClientNo = BigDecimal.valueOf(timClientNo);  // L:2197 MOVE TIM-CLIENT-NO TO BRK-CLIENT-NO
            brkEmpNo = BigDecimal.valueOf(timEmpNo);        // L:2198 MOVE TIM-EMP-NO TO BRK-EMP-NO
            brkCorpWrk = new BigDecimal(timCorpWrk);        // L:2199 MOVE TIM-CORP-WRK TO BRK-CORP-WRK
            brkStoreWrk = new BigDecimal(timStoreWrk);      // L:2200 MOVE TIM-STORE-WRK TO BRK-STORE-WRK
            brkCheckType = timCheckType;                    // L:2201 MOVE TIM-CHECK-TYPE TO BRK-CHECK-TYPE
            brkCheckNo = BigDecimal.valueOf(timCheckNo);    // L:2202 MOVE TIM-CHECK-NO TO BRK-CHECK-NO
            brkDateEnd = BigDecimal.valueOf(timDateEnd);    // L:2203 MOVE TIM-DATE-END TO BRK-DATE-END
            brkDeptWrk = new BigDecimal(timDeptWrk);        // L:2204 MOVE TIM-DEPT-WRK TO BRK-DEPT-WRK
        }  // period ends IF scope
    }

    private void nextEmployee_200_170() {                   // L:2206 200-170-NEXT-EMPLOYEE
        readEmployee_200_172();                             // L:2207 PERFORM 200-172-READ-EMPLOYEE THRU 200-172-EXIT
    }

    private void readEmployee_200_172() {                   // L:2209 200-172-READ-EMPLOYEE
        if (timClientNo == perClientNo && timEmpNo == perEmpNo) {// L:2210 IF TIM-CLIENT-NO = PER-CLIENT-NO AND
            loadCheckImage_200_173();                       // L:2212 PERFORM 200-173-LOAD-CHECK-IMAGE
            loadDeductions_200_174();                       // L:2213 PERFORM 200-174-LOAD-DEDUCTIONS
            // GO TO 200-172-EXIT - control flow            // L:2214 GO TO 200-172-EXIT
        }  // period ends IF scope
        perClientNo = timClientNo;                          // L:2215 MOVE TIM-CLIENT-NO TO PER-CLIENT-NO
        benClientNo = timClientNo;                          // L:2215 MOVE TIM-CLIENT-NO TO BEN-CLIENT-NO
        ernClientNo = timClientNo;                          // L:2215 MOVE TIM-CLIENT-NO TO ERN-CLIENT-NO
        perEmpNo = timEmpNo;                                // L:2217 MOVE TIM-EMP-NO TO PER-EMP-NO
        benEmpNo = timEmpNo;                                // L:2217 MOVE TIM-EMP-NO TO BEN-EMP-NO
        ernEmpNo = timEmpNo;                                // L:2217 MOVE TIM-EMP-NO TO ERN-EMP-NO
        errEmpNo = BigDecimal.valueOf(timEmpNo);            // L:2218 MOVE TIM-EMP-NO TO ERR-EMP-NO
        errDateEnd = BigDecimal.valueOf(timDateEnd);        // L:2219 MOVE TIM-DATE-END TO ERR-DATE-END
        readPayper_800_400();                               // L:2221 PERFORM 800-400-READ-PAYPER
        if (perStat.compareTo(ioOk) != 0) {                 // L:2222 IF PER-STAT NOT = IO-OK
            messageO = "EMPLOYEE NOT ON FILE-SKIPPED";      // L:2223 MOVE "EMPLOYEE NOT ON FILE-SKIPPED" TO MESSAGE-O
            wsGtnErr = "IO";                                // L:2224 MOVE "IO" TO WS-GTN-ERR
            gtnError_800_700();                             // L:2225 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 200-172-EXIT - control flow            // L:2226 GO TO 200-172-EXIT
        }  // period ends IF scope
        if ("i".equals(perActive)) {                        // L:2228 IF PER-ACTIVE = "I"                     ...
            messageO = "WARNING: EMPLOYEE IS INACTIVE.";    // L:2229 MOVE "WARNING: EMPLOYEE IS INACTIVE." TO MESSAGE-O
            wsGtnErr = "WR";                                // L:2231 MOVE "WR" TO WS-GTN-ERR
            gtnError_800_700();                             // L:2232 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }                                                   // L:2233 END-IF
        readPayern_800_410();                               // L:2235 PERFORM 800-410-READ-PAYERN
        if (ernStat.compareTo(ioOk) != 0) {                 // L:2236 IF ERN-STAT NOT = IO-OK
            messageO = "EARNINGS RECORD NOT FOUND-SKIPPED"; // L:2237 MOVE "EARNINGS RECORD NOT FOUND-SKIPPED" TO MESSAGE-O
            wsGtnErr = "IO";                                // L:2238 MOVE "IO" TO WS-GTN-ERR
            gtnError_800_700();                             // L:2239 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 200-172-EXIT - control flow            // L:2240 GO TO 200-172-EXIT
        }  // period ends IF scope
        readPayben_800_405();                               // L:2241 PERFORM 800-405-READ-PAYBEN
        loadCheckImage_200_173();                           // L:2242 PERFORM 200-173-LOAD-CHECK-IMAGE
        loadDeductions_200_174();                           // L:2243 PERFORM 200-174-LOAD-DEDUCTIONS
    }

    private void exit_200_172() {                           // L:2245 200-172-EXIT
    }

    private void loadCheckImage_200_173() {                 // L:2248 200-173-LOAD-CHECK-IMAGE
        holdMarStatFed = perMarStatFed;                     // L:2249 MOVE PER-MAR-STAT-FED TO HOLD-MAR-STAT-FED
        holdMarStatStt = perMarStatStt;                     // L:2250 MOVE PER-MAR-STAT-STT TO HOLD-MAR-STAT-STT
        holdMarStatLoc = perMarStatLoc;                     // L:2252 MOVE PER-MAR-STAT-LOC TO HOLD-MAR-STAT-LOC
        holdMarStatCit = perMarStatCit;                     // L:2253 MOVE PER-MAR-STAT-CIT TO HOLD-MAR-STAT-CIT
        holdMarStatOth = perMarStatOth;                     // L:2254 MOVE PER-MAR-STAT-OTH TO HOLD-MAR-STAT-OTH
        if (!"s".equals(holdMarStatFed) && !"h".equals(holdMarStatFed)) {// L:2259 IF HOLD-MAR-STAT-FED NOT = "S"
            holdMarStatFed = "M";                           // L:2261 MOVE "M" TO HOLD-MAR-STAT-FED
        }  // period ends IF scope
        if (!"s".equals(holdMarStatStt) && !"h".equals(holdMarStatStt) && !"1".equals(holdMarStatStt)) {// L:2262 IF HOLD-MAR-STAT-STT NOT = "S"
            holdMarStatStt = "M";                           // L:2266 MOVE "M" TO HOLD-MAR-STAT-STT
        }  // period ends IF scope
        if (!"s".equals(holdMarStatLoc) && !"h".equals(holdMarStatLoc)) {// L:2267 IF HOLD-MAR-STAT-LOC NOT = "S"          ...
            holdMarStatLoc = "M";                           // L:2269 MOVE "M" TO HOLD-MAR-STAT-LOC
            if (!"s".equals(holdMarStatCit) && !"h".equals(holdMarStatCit)) {// L:2270 IF HOLD-MAR-STAT-CIT NOT = "S"          ...
                holdMarStatCit = "M";                       // L:2272 MOVE "M" TO HOLD-MAR-STAT-CIT
                if (!"s".equals(holdMarStatOth) && !"h".equals(holdMarStatOth)) {// L:2273 IF HOLD-MAR-STAT-OTH NOT = "S"          ...
                    holdMarStatOth = "M";                   // L:2275 MOVE "M" TO HOLD-MAR-STAT-OTH
                    wsPerExmTable = perExmTable;            // L:2276 MOVE PER-EXM-TABLE TO WS-PER-EXM-TABLE
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        wsPerExmEic = BigDecimal.valueOf(perExmFed);        // L:2277 MOVE PER-EXM-FED TO WS-PER-EXM-EIC
        if (!"wk".equals(perCdeCycle)) {                    // L:2283 IF PER-CDE-CYCLE NOT = "WK"
            if (!"bw".equals(perCdeCycle)) {                // L:2284 IF PER-CDE-CYCLE NOT = "BW"
                if (!"sm".equals(perCdeCycle)) {            // L:2285 IF PER-CDE-CYCLE NOT = "SM"
                    if (!"mt".equals(perCdeCycle)) {        // L:2286 IF PER-CDE-CYCLE NOT = "MT"
                        if (!"qt".equals(perCdeCycle)) {    // L:2287 IF PER-CDE-CYCLE NOT = "QT"
                            if (!"sa".equals(perCdeCycle)) {// L:2288 IF PER-CDE-CYCLE NOT = "SA"
                                if (!"an".equals(perCdeCycle)) {// L:2289 IF PER-CDE-CYCLE NOT = "AN"
                                    perCdeCycle = wsCycleDefault;// L:2290 MOVE WS-CYCLE-DEFAULT TO PER-CDE-CYCLE
                                }  // period ends IF scope
                            }  // period ends IF scope
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if ("wk".equals(perCdeCycle)) {                     // L:2296 IF PER-CDE-CYCLE = "WK"
            fwwHrsWs = BigDecimal.valueOf(40);              // L:2297 MOVE 40 TO FWW-HRS-WS
            cdeCycleNumWs = BigDecimal.valueOf(52);         // L:2298 MOVE 52 TO CDE-CYCLE-NUM-WS
        }  // period ends IF scope
        if ("bw".equals(perCdeCycle)) {                     // L:2299 IF PER-CDE-CYCLE = "BW"
            fwwHrsWs = BigDecimal.valueOf(80);              // L:2300 MOVE 80 TO FWW-HRS-WS
            cdeCycleNumWs = BigDecimal.valueOf(26);         // L:2301 MOVE 26 TO CDE-CYCLE-NUM-WS
        }  // period ends IF scope
        if ("sm".equals(perCdeCycle)) {                     // L:2302 IF PER-CDE-CYCLE = "SM"
            fwwHrsWs = BigDecimal.valueOf(86.67);           // L:2303 MOVE 86.67 TO FWW-HRS-WS
            cdeCycleNumWs = BigDecimal.valueOf(24);         // L:2304 MOVE 24 TO CDE-CYCLE-NUM-WS
        }  // period ends IF scope
        if ("mt".equals(perCdeCycle)) {                     // L:2305 IF PER-CDE-CYCLE = "MT"
            fwwHrsWs = BigDecimal.valueOf(173.33);          // L:2306 MOVE 173.33 TO FWW-HRS-WS
            cdeCycleNumWs = BigDecimal.valueOf(12);         // L:2307 MOVE 12 TO CDE-CYCLE-NUM-WS
        }  // period ends IF scope
        if ("qt".equals(perCdeCycle)) {                     // L:2308 IF PER-CDE-CYCLE = "QT"
            fwwHrsWs = BigDecimal.valueOf(520);             // L:2309 MOVE 520 TO FWW-HRS-WS
            cdeCycleNumWs = BigDecimal.valueOf(4);          // L:2310 MOVE 4 TO CDE-CYCLE-NUM-WS
        }  // period ends IF scope
        if ("sa".equals(perCdeCycle)) {                     // L:2311 IF PER-CDE-CYCLE = "SA"
            fwwHrsWs = BigDecimal.valueOf(1040);            // L:2312 MOVE 1040 TO FWW-HRS-WS
            cdeCycleNumWs = BigDecimal.valueOf(2);          // L:2313 MOVE 2 TO CDE-CYCLE-NUM-WS
        }  // period ends IF scope
        if ("an".equals(perCdeCycle)) {                     // L:2314 IF PER-CDE-CYCLE = "AN"
            fwwHrsWs = BigDecimal.valueOf(2080);            // L:2315 MOVE 2080 TO FWW-HRS-WS
            cdeCycleNumWs = BigDecimal.valueOf(1);          // L:2316 MOVE 1 TO CDE-CYCLE-NUM-WS
        }  // period ends IF scope
        if (perCdeCycle.compareTo(clnCycle) != 0 && perStat == ioOk) {// L:2317 IF PER-CDE-CYCLE NOT = CLN-CYCLE
            messageO = "";                                  // L:2321 MOVE SPACES TO MESSAGE-O
            // STRING parse failed (no INTO): STRING "EMPLOYEE PAY FREQ. OF " PER-CDE-CYCLE...// L:2322 STRING "EMPLOYEE PAY FREQ. OF " PER-CDE-...
            wsGtnErr = "WR";                                // L:2324 MOVE "WR" TO WS-GTN-ERR
            gtnError_800_700();                             // L:2325 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        if ("3".equals(timCheckType)) {                     // L:2326 IF TIM-CHECK-TYPE = "3"
            if (timCdeCycle.compareTo(perCdeCycle) != 0) {  // L:2327 IF TIM-CDE-CYCLE NOT = PER-CDE-CYCLE
                if ("wk".equals(timCdeCycle)) {             // L:2328 IF TIM-CDE-CYCLE = "WK"
                    cdeCycleNumWs = BigDecimal.valueOf(52); // L:2329 MOVE 52 TO CDE-CYCLE-NUM-WS
                } else {                                    // L:2330 ELSE
                    if ("bw".equals(timCdeCycle)) {         // L:2331 IF TIM-CDE-CYCLE = "BW"
                        cdeCycleNumWs = BigDecimal.valueOf(26);// L:2332 MOVE 26 TO CDE-CYCLE-NUM-WS
                    } else {                                // L:2333 ELSE
                        if ("sm".equals(timCdeCycle)) {     // L:2334 IF TIM-CDE-CYCLE = "SM"
                            cdeCycleNumWs = BigDecimal.valueOf(24);// L:2335 MOVE 24 TO CDE-CYCLE-NUM-WS
                        } else {                            // L:2336 ELSE
                            if ("mt".equals(timCdeCycle)) { // L:2337 IF TIM-CDE-CYCLE = "MT"
                                cdeCycleNumWs = BigDecimal.valueOf(12);// L:2338 MOVE 12 TO CDE-CYCLE-NUM-WS
                            } else {                        // L:2339 ELSE
                                if ("qt".equals(timCdeCycle)) {// L:2340 IF TIM-CDE-CYCLE = "QT"
                                    cdeCycleNumWs = BigDecimal.valueOf(4);// L:2341 MOVE 04 TO CDE-CYCLE-NUM-WS
                                } else {                    // L:2342 ELSE
                                    if ("sa".equals(timCdeCycle)) {// L:2343 IF TIM-CDE-CYCLE = "SA"
                                        cdeCycleNumWs = BigDecimal.valueOf(2);// L:2344 MOVE 02 TO CDE-CYCLE-NUM-WS
                                    } else {                // L:2345 ELSE
                                        if ("an".equals(timCdeCycle)) {// L:2346 IF TIM-CDE-CYCLE = "AN"
                                            cdeCycleNumWs = BigDecimal.valueOf(1);// L:2347 MOVE 01 TO CDE-CYCLE-NUM-WS
                                        }  // period ends IF scope
                                    }  // period ends IF scope
                                }  // period ends IF scope
                            }  // period ends IF scope
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
    }

    private void loadDeductions_200_174() {                 // L:2349 200-174-LOAD-DEDUCTIONS
        control_200_174_0();                                // L:2350 PERFORM 200-174-0-CONTROL THRU 200-174-0-EXIT
    }

    private void exit_200_174() {                           // L:2353 200-174-EXIT
    }

    private void control_200_174_0() {                      // L:2359 200-174-0-CONTROL
        okFlag = okLit;                                     // L:2360 MOVE OK-LIT TO OK-FLAG
        dedRoutineFlag = okLit;                             // L:2360 MOVE OK-LIT TO DED-ROUTINE-FLAG
        if ((benDedNo[i.intValue()] == 0)) {                // L:2361 IF (BEN-DED-NO(I) = SPACES OR ZEROES)
            // GO TO 200-174-0-EXIT - control flow          // L:2362 GO TO 200-174-0-EXIT
        }  // period ends IF scope
        // 016740**********************************...      // L:2364 COMMENT
        // 016750* REGARDLESS OF WHETHER DEDUCTION ...      // L:2365 COMMENT
        // 016760* OFF, IF IT IS FICA NONTAXABLE, I...      // L:2366 COMMENT
        // 016770* NEEDS USED IN THE FICA CALCULATI...      // L:2367 COMMENT
        // 016780**********************************...      // L:2368 COMMENT
        // 016790*                                          // L:2369 COMMENT
        checkFicaTaxbl_200_174_8();                         // L:2370 PERFORM 200-174-8-CHECK-FICA-TAXBL
        if ("y".equals(ficaOnlyOptWs)) {                    // L:2371 IF FICA-ONLY-OPT-WS = "Y"
            // GO TO 200-174-0-EXIT - control flow          // L:2372 GO TO 200-174-0-EXIT
        }  // period ends IF scope
        wsDedTktn = BigDecimal.valueOf(benDedTktn[i.intValue()]);// L:2373 MOVE BEN-DED-TKTN(I) TO WS-DED-TKTN
        if ((("m".equals(timCheckType) || "2".equals(timCheckType) || "v".equals(timCheckType))) || wsNoToTake.compareTo(BigDecimal.ZERO) == 0) {// L:2374 IF (TIM-CHECK-TYPE = "M" OR "2" OR "V") ...
            loadSum_200_174_9();                            // L:2376 PERFORM 200-174-9-LOAD-SUM THRU 200-174-9-EXIT
            // GO TO 200-174-0-EXIT - control flow          // L:2377 GO TO 200-174-0-EXIT
        }  // period ends IF scope
        validateNo_200_174_1();                             // L:2378 PERFORM 200-174-1-VALIDATE-NO THRU 200-174-1-EXIT
        validatePara_200_174_2();                           // L:2379 PERFORM 200-174-2-VALIDATE-PARA THRU 200-174-2-EXIT
        validateDate_200_174_3();                           // L:2380 PERFORM 200-174-3-VALIDATE-DATE THRU 200-174-3-EXIT
        validateFreq_200_174_4();                           // L:2381 PERFORM 200-174-4-VALIDATE-FREQ THRU 200-174-4-EXIT
        checkArrs_200_174_5();                              // L:2382 PERFORM 200-174-5-CHECK-ARRS THRU 200-174-5-EXIT
        checkBalance_200_174_6();                           // L:2383 PERFORM 200-174-6-CHECK-BALANCE THRU 200-174-6-EXIT
        checkCombo_200_174_7();                             // L:2384 PERFORM 200-174-7-CHECK-COMBO THRU 200-174-7-EXIT
        if (ok) {                                           // L:2385 IF OK
            loadSum_200_174_9();                            // L:2386 PERFORM 200-174-9-LOAD-SUM THRU 200-174-9-EXIT
        }  // period ends IF scope
    }

    private void exit_200_174_0() {                         // L:2388 200-174-0-EXIT
    }

    private void validateNo_200_174_1() {                   // L:2397 200-174-1-VALIDATE-NO
        cnlParaYn = "N";                                    // L:2398 MOVE "N" TO CNL-PARA-YN
        cnlActYn = "Y";                                     // L:2399 MOVE "Y" TO CNL-ACT-YN
        cnlIdxWs = 1;                                       // L:2400 SET CNL-IDX-WS TO 1.
        // SEARCH DEDUCTION-CONTROL-ENTRY                   // L:2401 CODE
        // AT END                                           // L:2402 CODE
        error_200_174_11();                                 // L:2403 PERFORM 200-174-11-ERROR
        // GO TO 200-174-1-EXIT - control flow              // L:2404 GO TO 200-174-1-EXIT
        // WHEN CNL-NO-WS(CNL-IDX-WS) = BEN-DED-NO(...      // L:2405 WHEN
        k = BigDecimal.valueOf(cnlIdxWs);                   // L:2406 SET K TO CNL-IDX-WS.
        if ("i".equals(cnlActFlgWs[k.intValue()])) {        // L:2407 IF CNL-ACT-FLG-WS (K) = "I"
            cnlActYn = "N";                                 // L:2408 MOVE "N" TO CNL-ACT-YN
        }  // period ends IF scope
        para2aValidatePara_200_174();                       // L:2409 PERFORM 200-174-2A-VALIDATE-PARA THRU 200-174-2A-EXIT
        if ("n".equals(cnlParaYn)) {                        // L:2413 IF CNL-PARA-YN = "N"
            error_200_174_13();                             // L:2414 PERFORM 200-174-13-ERROR
        }  // period ends IF scope
    }

    private void exit_200_174_1() {                         // L:2420 200-174-1-EXIT
    }

    private void validatePara_200_174_2() {                 // L:2426 200-174-2-VALIDATE-PARA
        if ((!"ba".equals(benDedPara[i.intValue()]) && !"be".equals(benDedPara[i.intValue()]) && !"bo".equals(benDedPara[i.intValue()]) && !"ec".equals(benDedPara[i.intValue()]) && !"fa".equals(benDedPara[i.intValue()]) && !"fd".equals(benDedPara[i.intValue()]) && !"fn".equals(benDedPara[i.intValue()]) && !"te".equals(benDedPara[i.intValue()]) && !"ts".equals(benDedPara[i.intValue()]) && !"wc".equals(benDedPara[i.intValue()]) && !"eh".equals(benDedPara[i.intValue()]))) {// L:2427 IF (BEN-DED-PARA(I) NOT = "BA" AND "BE" ...
            error_200_174_12();                             // L:2432 PERFORM 200-174-12-ERROR
        }  // period ends IF scope
    }

    private void exit_200_174_2() {                         // L:2434 200-174-2-EXIT
    }

    private void para2aValidatePara_200_174() {             // L:2442 200-174-2A-VALIDATE-PARA
        if (benDedPara[i.intValue()] == cnlTypeWs[cnlIdxWs][cnlSub.intValue()]) {// L:2443 IF BEN-DED-PARA (I) = CNL-TYPE-WS (CNL-I...
            cnlParaYn = "Y";                                // L:2444 MOVE "Y" TO CNL-PARA-YN
        }  // period ends IF scope
    }

    private void para2aExit_200_174() {                     // L:2446 200-174-2A-EXIT
    }

    private void validateDate_200_174_3() {                 // L:2452 200-174-3-VALIDATE-DATE
        if (benBegDate[i.intValue()].compareTo(BigDecimal.ZERO) == 0 && benEndDate[i.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:2453 IF BEN-BEG-DATE (I) = 0 AND
            // GO TO 200-174-3-EXIT - control flow          // L:2455 GO TO 200-174-3-EXIT
        }  // period ends IF scope
        if (benEndDate[i.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:2456 IF BEN-END-DATE (I) = 0
            benEndDate[i.intValue()] = BigDecimal.valueOf(9999999);// L:2457 MOVE 9999999 TO BEN-END-DATE(I)
        }  // period ends IF scope
        if (benBegDate[i.intValue()].compareTo(wsDateEnd) <= 0 && benEndDate[i.intValue()].compareTo(wsDateEnd) > 0) {// L:2458 IF BEN-BEG-DATE (I) NOT > WS-DATE-END
            // GO TO 200-174-3-EXIT - control flow          // L:2461 GO TO 200-174-3-EXIT
        }  // period ends IF scope
        okFlag = notOkLit;                                  // L:2462 MOVE NOT-OK-LIT TO OK-FLAG
    }

    private void exit_200_174_3() {                         // L:2464 200-174-3-EXIT
    }

    private void validateFreq_200_174_4() {                 // L:2473 200-174-4-VALIDATE-FREQ
        if (("wk".equals(cnlFreqWs[cnlIdxWs]) && !takeWkDed)) {// L:2475 IF (CNL-FREQ-WS(CNL-IDX-WS) = "WK" AND N...
            wsNoToTake = BigDecimal.ZERO;                   // L:2476 MOVE 0 TO WS-NO-TO-TAKE
        }  // period ends IF scope
        if (("bw".equals(cnlFreqWs[cnlIdxWs]) && !takeBwDed)) {// L:2478 IF (CNL-FREQ-WS(CNL-IDX-WS) = "BW" AND N...
            wsNoToTake = BigDecimal.ZERO;                   // L:2479 MOVE 0 TO WS-NO-TO-TAKE
        }  // period ends IF scope
        if (("sm".equals(cnlFreqWs[cnlIdxWs]) && !takeSmDed)) {// L:2481 IF (CNL-FREQ-WS(CNL-IDX-WS) = "SM" AND N...
            wsNoToTake = BigDecimal.ZERO;                   // L:2482 MOVE 0 TO WS-NO-TO-TAKE
        }  // period ends IF scope
        if (("mt".equals(cnlFreqWs[cnlIdxWs]) && !takeMtDed)) {// L:2484 IF (CNL-FREQ-WS(CNL-IDX-WS) = "MT" AND N...
            wsNoToTake = BigDecimal.ZERO;                   // L:2485 MOVE 0 TO WS-NO-TO-TAKE
        }  // period ends IF scope
        if (benArrsCtr[i.intValue()].compareTo(BigDecimal.ZERO) > 0) {// L:2493 IF BEN-ARRS-CTR(I) > 0
            if (okFlag == notOkLit) {                       // L:2494 IF OK-FLAG = NOT-OK-LIT
                wsNoTaken = wsNoToTake;                     // L:2495 MOVE WS-NO-TO-TAKE TO WS-NO-TAKEN
            }  // period ends IF scope
        }  // period ends IF scope
        if (benArrsCtr[i.intValue()].compareTo(BigDecimal.ZERO) > 0) {// L:2496 IF BEN-ARRS-CTR(I) > ZERO MOVE OK-LIT TO...
        }  // auto-close unclosed IF
    }

    private void exit_200_174_4() {                         // L:2498 200-174-4-EXIT
    }

    private void checkArrs_200_174_5() {                    // L:2505 200-174-5-CHECK-ARRS
        setArrFlag = notOkLit;                              // L:2506 MOVE NOT-OK-LIT TO SET-ARR-FLAG
        wsCnlMaxArrears = BigDecimal.ZERO;                  // L:2514 MOVE 0 TO WS-CNL-MAX-ARREARS
        wsCnlMaxArrears = cnlMaxArrears[cnlIdxWs];          // L:2515 MOVE CNL-MAX-ARREARS(CNL-IDX-WS) TO WS-CNL-MAX-ARREARS
        if ("y".equals(clnSetArrOptWs)) {                   // L:2518 IF CLN-SET-ARR-OPT-WS = "Y"
            if ("y".equals(cnlSetArrWs[cnlIdxWs])) {        // L:2519 IF CNL-SET-ARR-WS(CNL-IDX-WS) = "Y"
                if (benDedPercent[i.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:2520 IF BEN-DED-PERCENT(I) = ZERO
                    setArrFlag = okLit;                     // L:2521 MOVE OK-LIT TO SET-ARR-FLAG
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
    }

    private void exit_200_174_5() {                         // L:2523 200-174-5-EXIT
    }

    private void checkBalance_200_174_6() {                 // L:2526 200-174-6-CHECK-BALANCE
        wsBalFlg = "N";                                     // L:2527 MOVE "N" TO WS-BAL-FLG
        if ((!"bo".equals(benDedPara[i.intValue()]) || !"ba".equals(benDedPara[i.intValue()]))) {// L:2528 IF (BEN-DED-PARA(I) NOT = "BO" OR "BA")
            if (benDedBal[i.intValue()].compareTo(BigDecimal.ZERO) <= 0) {// L:2529 IF BEN-DED-BAL(I) NOT > ZERO
                if ((benDedAmt[i.intValue()].compareTo(BigDecimal.ZERO) >= 0 && benDedPercent[i.intValue()].compareTo(BigDecimal.ZERO) >= 0)) {// L:2530 IF (BEN-DED-AMT(I) NOT < 0
                    wsBalFlg = "Y";                         // L:2533 MOVE "Y" TO WS-BAL-FLG
                    error_200_174_15();                     // L:2534 PERFORM 200-174-15-ERROR
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
    }

    private void exit_200_174_6() {                         // L:2536 200-174-6-EXIT
    }

    private void checkCombo_200_174_7() {                   // L:2539 200-174-7-CHECK-COMBO
        if (benDedAmt[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:2540 IF BEN-DED-AMT(I) NOT = ZERO
            if (benDedPercent[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:2541 IF BEN-DED-PERCENT(I) NOT = ZERO
                error_200_174_16();                         // L:2542 PERFORM 200-174-16-ERROR
            }  // period ends IF scope
        }  // period ends IF scope
    }

    private void exit_200_174_7() {                         // L:2544 200-174-7-EXIT
        // 017950**********************************...      // L:2546 COMMENT
        // 017960* IF DEDUCTION IS FICA NON-TAXABLE...      // L:2547 COMMENT
        // 017970* REGARDLESS OF WHETHER IT IS TURN...      // L:2548 COMMENT
        // 017980**********************************...      // L:2549 COMMENT
        // 017990*                                          // L:2550 COMMENT
    }

    private void checkFicaTaxbl_200_174_8() {               // L:2551 200-174-8-CHECK-FICA-TAXBL
        cnlIdxWs = 1;                                       // L:2552 018010     SET CNL-IDX-WS TO 1.         ...
        // 018020     SEARCH DEDUCTION-CONTROL-ENTR...      // L:2553 CODE
        cnlIdxWs = 201;                                     // L:2554 018030             SET CNL-IDX-WS TO 201...
        // 018040        WHEN CNL-NO-WS(CNL-IDX-WS)...      // L:2555 WHEN
        k = BigDecimal.valueOf(cnlIdxWs);                   // L:2556 018050             SET K TO CNL-IDX-WS. ...
        if ("n".equals(cnlTaxblFicaWs[cnlIdxWs])) {         // L:2557 018060     IF CNL-TAXBL-FICA-WS(CNL-IDX-...
            nontaxblFicaYtd = nontaxblFicaYtd.add(benAccYtd[i.intValue()]);// L:2558 018070        ADD BEN-ACC-YTD(I) TO NONT...
        }  // auto-close unclosed IF
    }

    private void exit_200_174_8() {                         // L:2560 200-174-8-EXIT
    }

    private void loadSum_200_174_9() {                      // L:2578 200-174-9-LOAD-SUM
        if ((("fd".equals(benDedPara[i.intValue()]) || "fn".equals(benDedPara[i.intValue()]))) && benDedTktn[i.intValue()] == 0) {// L:2579 IF (BEN-DED-PARA (I) = "FD" OR "FN")
            // GO TO 200-174-9-EXIT - control flow          // L:2582 GO TO 200-174-9-EXIT
        }  // period ends IF scope
        j = BigDecimal.valueOf(132).add(i);                 // L:2584 ADD 132, I GIVING J.                    ...
        if ("wc".equals(benDedPara[i.intValue()])) {        // L:2586 IF BEN-DED-PARA(I) = "WC"
            j = i;                                          // L:2587 MOVE I TO J
            if (dedNoSum[j.intValue()] != "") {             // L:2588 IF DED-NO-SUM(J) NOT = SPACES           ...
                j = j.add(BigDecimal.valueOf(1));           // L:2589 ADD 1 TO J                              ...
            }                                               // L:2590 END-IF
        }                                                   // L:2591 END-IF
        if ("be".equals(benDedPara[i.intValue()])) {        // L:2593 IF BEN-DED-PARA(I) = "BE"
            j = BigDecimal.valueOf(2).add(i);               // L:2594 ADD 2, I GIVING J.
        }  // period ends IF scope
        if ("ba".equals(benDedPara[i.intValue()])) {        // L:2596 IF BEN-DED-PARA(I) = "BA"
            j = BigDecimal.valueOf(30).add(i);              // L:2597 ADD 30, I GIVING J.
        }  // period ends IF scope
        if ("ts".equals(benDedPara[i.intValue()])) {        // L:2599 IF BEN-DED-PARA(I) = "TS"
            j = BigDecimal.valueOf(60).add(i);              // L:2600 ADD 60, I GIVING J.
        }  // period ends IF scope
        if ("te".equals(benDedPara[i.intValue()])) {        // L:2602 IF BEN-DED-PARA(I) = "TE"
            j = BigDecimal.valueOf(90).add(i);              // L:2603 ADD 90, I GIVING J.
        }  // period ends IF scope
        if ("fd".equals(benDedPara[i.intValue()])) {        // L:2605 IF BEN-DED-PARA(I) = "FD"
            fdCount = fdCount.add(BigDecimal.valueOf(1));   // L:2606 ADD 1 TO FD-COUNT                       ...
        }  // period ends IF scope
        j = BigDecimal.valueOf(121);                        // L:2611 MOVE 121 TO J
        if (benOrderNo[i.intValue()] == 0) {                // L:2612 IF BEN-ORDER-NO(I) = 0                  ...
            j = (j).add(fdCount);                           // L:2613 COMPUTE J = J + FD-COUNT                ...
        } else {                                            // L:2614 ELSE
            j = (j).add(BigDecimal.valueOf(benOrderNo[i.intValue()]));// L:2615 COMPUTE J = J + BEN-ORDER-NO(I)         ...
        }                                                   // L:2616 END-IF
        if ("fn".equals(benDedPara[i.intValue()])) {        // L:2621 IF BEN-DED-PARA(I) = "FN"
        }  // period ends IF scope
        j = BigDecimal.valueOf(165);                        // L:2623 MOVE 165 TO J
        if (("ec".equals(benDedPara[i.intValue()]) && benDedTktn[i.intValue()] != 0 && !dedRoutineError && cnlOptNoWs[cnlIdxWs].compareTo(BigDecimal.valueOf(2)) != 0 && (!"m".equals(timCheckType) && !"v".equals(timCheckType) && !"x".equals(timCheckType) && !"2".equals(timCheckType)))) {// L:2640 IF (BEN-DED-PARA(I) = "EC"
            findTsForEc_200_174_10();                       // L:2649 PERFORM 200-174-10-FIND-TS-FOR-EC
            if (k.compareTo(BigDecimal.valueOf(30)) > 0 || !"ts".equals(benDedPara[k.intValue()]) || !cnlAssocDedNoWs[cnlIdxWs].equals(String.valueOf(benDedNo[k.intValue()])) || "y".equals(dedErrSum[k.intValue()])) {// L:2653 IF K > 30
                para19aError_200_174();                     // L:2660 PERFORM 200-174-19A-ERROR
            }  // period ends IF scope
        }  // period ends IF scope
        if (("eh".equals(benDedPara[i.intValue()]) && benDedTktn[i.intValue()] != 0 && !dedRoutineError && cnlOptNoWs[cnlIdxWs].compareTo(BigDecimal.valueOf(2)) != 0 && (!"m".equals(timCheckType) && !"v".equals(timCheckType) && !"x".equals(timCheckType) && !"2".equals(timCheckType)) && benDedPercent[i.intValue()].compareTo(BigDecimal.ZERO) != 0)) {// L:2676 IF (BEN-DED-PARA(I) = "EH"              ...
            findTeFaForEh_200_174_10();                     // L:2686 PERFORM 200-174-10-FIND-TE-FA-FOR-EH
            if (k.compareTo(BigDecimal.valueOf(30)) > 0 || (!"te".equals(benDedPara[k.intValue()]) && !"fa".equals(benDedPara[k.intValue()])) || !cnlAssocDedNoWs[cnlIdxWs].equals(String.valueOf(benDedNo[k.intValue()])) || "y".equals(dedErrSum[k.intValue()])) {// L:2690 IF K > 30                               ...
                para19bError_200_174();                     // L:2698 PERFORM 200-174-19B-ERROR
                dedSeqNoSum[j.intValue()] = BigDecimal.valueOf(benSeqNo[i.intValue()]);// L:2701 MOVE BEN-SEQ-NO (I) TO DED-SEQ-NO-SUM(J)
            }  // period ends IF scope
        }  // period ends IF scope
        dedTblElementSum[j.intValue()] = i;                 // L:2702 MOVE I TO DED-TBL-ELEMENT-SUM(J)
        dedNoSum[j.intValue()] = String.valueOf(benDedNo[i.intValue()]);// L:2703 MOVE BEN-DED-NO(I) TO DED-NO-SUM(J)
        dedParaSum[j.intValue()] = benDedPara[i.intValue()];// L:2704 MOVE BEN-DED-PARA(I) TO DED-PARA-SUM(J)
        dedOrderNo[j.intValue()] = BigDecimal.valueOf(benOrderNo[i.intValue()]);// L:2705 MOVE BEN-ORDER-NO(I) TO DED-ORDER-NO(J)
        if ("n".equals(cnlActYn) || "y".equals(wsBalFlg)) { // L:2706 IF CNL-ACT-YN = "N" OR
            wsNoToTake = BigDecimal.ZERO;                   // L:2708 MOVE 0 TO WS-NO-TO-TAKE
        }  // period ends IF scope
        dedNoToTakeSum[j.intValue()] = wsNoToTake;          // L:2709 MOVE WS-NO-TO-TAKE TO DED-NO-TO-TAKE-SUM(J)
        dedNoTakenSum[j.intValue()] = wsNoTaken;            // L:2710 MOVE WS-NO-TAKEN TO DED-NO-TAKEN-SUM(J)
        dedArrsCtrSum[j.intValue()] = benArrsCtr[i.intValue()];// L:2711 MOVE BEN-ARRS-CTR(I) TO DED-ARRS-CTR-SUM(J)
        if ("y".equals(expandDedArrearsSw)) {               // L:2717 IF EXPAND-DED-ARREARS-SW = "Y"          ...
            wkBdeNewArrearsCounter = BigDecimal.ZERO;       // L:2718 MOVE ZEROS TO WK-BDE-NEW-ARREARS-COUNTER
            // CALL PYDMXFK                                 // L:2719 CALL "PYDMXFK" USING C-RET-CODE, TIM-CLI...
            callPydmxfk();
            dedArrsCtrSum[j.intValue()] = wkBdeNewArrearsCounter;// L:2722 MOVE WK-BDE-NEW-ARREARS-COUNTER TO DED-ARRS-CTR-SUM(J)
        }                                                   // L:2723 END-IF
        if (dedArrsCtrSum[j.intValue()].compareTo(BigDecimal.ZERO) > 0 && wsCnlMaxArrears.compareTo(BigDecimal.ZERO) > 0) {// L:2725 IF DED-ARRS-CTR-SUM(J) > 0 AND WS-CNL-MA...
            dedArrsCtrSum[j.intValue()] = wsCnlMaxArrears;  // L:2726 MOVE WS-CNL-MAX-ARREARS TO DED-ARRS-CTR-SUM(J)
            if (setArrears) {                               // L:2728 IF SET-ARREARS
                dedSetArrSum[j.intValue()] = "Y";           // L:2729 MOVE "Y" TO DED-SET-ARR-SUM(J)
            }  // period ends IF scope
        }  // period ends IF scope
        if (benDedAmt[i.intValue()].compareTo(BigDecimal.valueOf(99999.99)) == 0) {// L:2730 IF BEN-DED-AMT(I) = 99999.99
            dedAmtSum[j.intValue()] = BigDecimal.ZERO;      // L:2731 MOVE 0 TO DED-AMT-SUM(J)
        } else {                                            // L:2732 ELSE
            dedAmtSum[j.intValue()] = benDedAmt[i.intValue()];// L:2733 MOVE BEN-DED-AMT(I) TO DED-AMT-SUM(J)
        }  // period ends IF scope
        dedPctSum[j.intValue()] = benDedPercent[i.intValue()];// L:2734 MOVE BEN-DED-PERCENT(I) TO DED-PCT-SUM(J)
        dedBalSum[j.intValue()] = benDedBal[i.intValue()];  // L:2735 MOVE BEN-DED-BAL(I) TO DED-BAL-SUM(J)
        dedOptSum[j.intValue()] = benDedOpt[i.intValue()];  // L:2736 MOVE BEN-DED-OPT(I) TO DED-OPT-SUM(J)
        dedAccYtdSum[j.intValue()] = benAccYtd[i.intValue()];// L:2737 MOVE BEN-ACC-YTD(I) TO DED-ACC-YTD-SUM(J)
        if ((("m".equals(timCheckType) || "v".equals(timCheckType) || "x".equals(timCheckType) || "2".equals(timCheckType)))) {// L:2744 IF (TIM-CHECK-TYPE = "M" OR "V" OR "X" O...
            dedNoToTakeSum[j.intValue()] = BigDecimal.ZERO; // L:2745 MOVE 0 TO DED-NO-TO-TAKE-SUM(J)
            dedAmtSum[j.intValue()] = BigDecimal.ZERO;      // L:2746 MOVE 0 TO DED-AMT-SUM(J)
        }  // period ends IF scope
        if (dedRoutineError) {                              // L:2749 IF DED-ROUTINE-ERROR
            dedErrSum[j.intValue()] = "Y";                  // L:2750 MOVE "Y" TO DED-ERR-SUM(J)
            dedAssocDedNoSum[j.intValue()] = "";            // L:2751 MOVE SPACES TO DED-ASSOC-DED-NO-SUM(J)
            dedTaxblTableSum[j.intValue()] = "";            // L:2752 MOVE SPACES TO DED-TAXBL-TABLE-SUM(J)
            dedOptNoSum[j.intValue()] = BigDecimal.ZERO;    // L:2753 MOVE 0 TO DED-OPT-NO-SUM(J)
            // GO TO 200-174-9-EXIT - control flow          // L:2754 GO TO 200-174-9-EXIT
        }  // period ends IF scope
        dedAssocDedNoSum[j.intValue()] = cnlAssocDedNoWs[cnlIdxWs];// L:2755 MOVE CNL-ASSOC-DED-NO-WS(CNL-IDX-WS) TO DED-ASSOC-DED-NO-SUM(J)
        dedTaxblTableSum[j.intValue()] = cnlTaxblTableWs[cnlIdxWs];// L:2757 MOVE CNL-TAXBL-TABLE-WS(CNL-IDX-WS) TO DED-TAXBL-TABLE-SUM(J)
        dedYtdPrtSum[j.intValue()] = cnlYtdPrtWs[cnlIdxWs]; // L:2759 MOVE CNL-YTD-PRT-WS (CNL-IDX-WS) TO DED-YTD-PRT-SUM(J)
        dedOptNoSum[j.intValue()] = cnlOptNoWs[cnlIdxWs];   // L:2760 MOVE CNL-OPT-NO-WS (CNL-IDX-WS) TO DED-OPT-NO-SUM(J)
        if (cnlOptNoWs[cnlIdxWs].compareTo(BigDecimal.valueOf(3)) == 0) {// L:2761 IF CNL-OPT-NO-WS (CNL-IDX-WS) = 3
            dedL1PctWs[j.intValue()] = cnlL1PctWs[cnlIdxWs];// L:2762 MOVE CNL-L1-PCT-WS (CNL-IDX-WS) TO DED-L1-PCT-WS(J)
            dedL1MatWs[j.intValue()] = cnlL1MatWs[cnlIdxWs];// L:2763 MOVE CNL-L1-MAT-WS (CNL-IDX-WS) TO DED-L1-MAT-WS(J)
            dedL2PctWs[j.intValue()] = cnlL2PctWs[cnlIdxWs];// L:2764 MOVE CNL-L2-PCT-WS (CNL-IDX-WS) TO DED-L2-PCT-WS(J)
            dedL2MatWs[j.intValue()] = cnlL2MatWs[cnlIdxWs];// L:2765 MOVE CNL-L2-MAT-WS (CNL-IDX-WS) TO DED-L2-MAT-WS(J)
        }  // period ends IF scope
    }

    private void exit_200_174_9() {                         // L:2767 200-174-9-EXIT
    }

    private void findTsForEc_200_174_10() {                 // L:2770 200-174-10-FIND-TS-FOR-EC
    }

    private void findTeFaForEh_200_174_10() {               // L:2772 200-174-10-FIND-TE-FA-FOR-EH
    }

    private void error_200_174_11() {                       // L:2775 200-174-11-ERROR
        dedRoutineFlag = notOkLit;                          // L:2776 MOVE NOT-OK-LIT TO DED-ROUTINE-FLAG
        // STRING parse failed (no INTO): STRING "DED NOT IN DEDUCTION CONTROL-"...// L:2777 STRING "DED NOT IN DEDUCTION CONTROL-"
        wsGtnErr = "DE";                                    // L:2782 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:2783 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void error_200_174_12() {                       // L:2785 200-174-12-ERROR
        dedRoutineFlag = notOkLit;                          // L:2786 MOVE NOT-OK-LIT TO DED-ROUTINE-FLAG
        // STRING parse failed (no INTO): STRING "ILLEGAL DEDUCTION PARAMETER-"...// L:2787 STRING "ILLEGAL DEDUCTION PARAMETER-"
        wsGtnErr = "DE";                                    // L:2794 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:2795 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void error_200_174_13() {                       // L:2797 200-174-13-ERROR
        dedRoutineFlag = notOkLit;                          // L:2798 MOVE NOT-OK-LIT TO DED-ROUTINE-FLAG
        // STRING parse failed (no INTO): STRING BEN-DED-PARA (I),...// L:2799 STRING BEN-DED-PARA (I),
        wsGtnErr = "DE";                                    // L:2805 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:2806 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void error_200_174_15() {                       // L:2808 200-174-15-ERROR
        dedRoutineFlag = notOkLit;                          // L:2809 MOVE NOT-OK-LIT TO DED-ROUTINE-FLAG
        // STRING parse failed (no INTO): STRING "BALANCE NOT > ZERO AND DED IS ACTIVE-"...// L:2810 STRING "BALANCE NOT > ZERO AND DED IS AC...
        wsGtnErr = "DE";                                    // L:2815 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:2816 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void error_200_174_16() {                       // L:2818 200-174-16-ERROR
        dedRoutineFlag = notOkLit;                          // L:2819 MOVE NOT-OK-LIT TO DED-ROUTINE-FLAG
        // STRING parse failed (no INTO): STRING "AMT AND PCT ARE BOTH NON ZERO-"...// L:2820 STRING "AMT AND PCT ARE BOTH NON ZERO-"
        wsGtnErr = "DE";                                    // L:2825 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:2826 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void error_200_174_19() {                       // L:2828 200-174-19-ERROR
        dedRoutineFlag = notOkLit;                          // L:2829 MOVE NOT-OK-LIT TO DED-ROUTINE-FLAG
        // STRING parse failed (no INTO): STRING "DEDUCTS W/SAME PARAM-" DELIMITED BY SIZE...// L:2830 STRING "DEDUCTS W/SAME PARAM-" DELIMITED...
        wsGtnErr = "DE";                                    // L:2836 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:2837 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void para19aError_200_174() {                   // L:2839 200-174-19A-ERROR
        dedRoutineFlag = notOkLit;                          // L:2840 MOVE NOT-OK-LIT TO DED-ROUTINE-FLAG
        // STRING parse failed (no INTO): STRING "EC DED-" DELIMITED BY SIZE...// L:2841 STRING "EC DED-" DELIMITED BY SIZE
        wsGtnErr = "DE";                                    // L:2845 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:2846 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void para19bError_200_174() {                   // L:2848 200-174-19B-ERROR
        dedRoutineFlag = notOkLit;                          // L:2849 MOVE NOT-OK-LIT TO DED-ROUTINE-FLAG
        // STRING parse failed (no INTO): STRING "EH DED-" DELIMITED BY SIZE...// L:2850 STRING "EH DED-" DELIMITED BY SIZE      ...
        wsGtnErr = "DE";                                    // L:2854 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:2855 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void error_200_174_20() {                       // L:2857 200-174-20-ERROR
        // STRING parse failed (no INTO): STRING "INACTIVE DEDUCTION-" DELIMITED BY SIZE...// L:2859 STRING "INACTIVE DEDUCTION-" DELIMITED B...
        wsGtnErr = "DE";                                    // L:2863 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:2864 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void exit_200_174_20() {                        // L:2866 200-174-20-EXIT
        // /                                                // L:2867 COMMENT
    }

    private void readClient_200_180() {                     // L:2873 200-180-READ-CLIENT
        clnClientNo = prmClientNo.shortValue();             // L:2874 MOVE PRM-CLIENT-NO TO CLN-CLIENT-NO
        // READ PAYCLNFILE INVALID KEY                      // L:2875 READ
        clientNoO = prmClientNo.toString();                 // L:2876 MOVE PRM-CLIENT-NO TO CLIENT-NO-O
        empNoO = "0";                                       // L:2877 MOVE 0 TO EMP-NO-O
        corpWrkO = BigDecimal.ZERO;                         // L:2878 MOVE 0 TO CORP-WRK-O
        storeWrkO = BigDecimal.ZERO;                        // L:2879 MOVE 0 TO STORE-WRK-O
        deptWrkO = BigDecimal.ZERO;                         // L:2880 MOVE 0 TO DEPT-WRK-O
        messageO = "CLIENT RECORD NOT FOUND";               // L:2881 MOVE "CLIENT RECORD NOT FOUND" TO MESSAGE-O
        gtnError_800_700();                                 // L:2882 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        wsCurrentPeriod = BigDecimal.valueOf(clnCppNo);     // L:2883 MOVE CLN-CPP-NO TO WS-CURRENT-PERIOD
        calCdeCycle = clnCycle;                             // L:2884 MOVE CLN-CYCLE TO CAL-CDE-CYCLE
        calNumber = clnCalNo;                               // L:2885 MOVE CLN-CAL-NO TO CAL-NUMBER
        calYear = clnCalYr;                                 // L:2886 MOVE CLN-CAL-YR TO CAL-YEAR
        calPrdNo = clnCppNo;                                // L:2887 MOVE CLN-CPP-NO TO CAL-PRD-NO
        readPaycal_800_450();                               // L:2888 PERFORM 800-450-READ-PAYCAL
        if (calStat.compareTo(ioOk) != 0) {                 // L:2889 IF CAL-STAT NOT = IO-OK
            // GO TO 200-180-EXIT - control flow            // L:2890 GO TO 200-180-EXIT
        }  // period ends IF scope
        wsDedFlgs = calDedFlgs;                             // L:2891 MOVE CAL-DED-FLGS TO WS-DED-FLGS
        readPayclnpf03_200_181();                           // L:2892 PERFORM 200-181-READ-PAYCLNPF03 THRU 200-181-EXIT
        loadDed_1000_500();                                 // L:2893 PERFORM 1000-500-LOAD-DED THRU 1000-500-EXIT
    }

    private void exit_200_180() {                           // L:2895 200-180-EXIT
    }

    private void readPayclnpf03_200_181() {                 // L:2898 200-181-READ-PAYCLNPF03
        // payrollClientRateRecord = default; // INITIALIZE PAYROLL-CLIENT-RATE-RECORD// L:2899 INITIALIZE PAYROLL-CLIENT-RATE-RECORD.
        cl3ClientNo = clnClientNo;                          // L:2900 MOVE CLN-CLIENT-NO TO CL3-CLIENT-NO
        startCl3_200_181();                                 // L:2901 PERFORM 200-181-START-CL3
        if ("n".equals(cl3Ok)) {                            // L:2902 IF CL3-OK = "N"
            // GO TO 200-181-EXIT - control flow            // L:2903 GO TO 200-181-EXIT
        }  // period ends IF scope
    }

    private void readLoop_200_181() {                       // L:2905 200-181-READ-LOOP
        readCl3_200_181();                                  // L:2906 PERFORM 200-181-READ-CL3
        if ("n".equals(cl3Ok) || cl3ClientNo != clnClientNo) {// L:2907 IF CL3-OK = "N"
            // GO TO 200-181-EXIT - control flow            // L:2910 GO TO 200-181-EXIT
        }  // period ends IF scope
        clnErnCode[cl3ErnSeq] = cl3ErnCode;                 // L:2911 MOVE CL3-ERN-CODE TO CLN-ERN-CODE(CL3-ERN-SEQ)
        ernCode[cl3ErnSeq] = cl3ErnCode;                    // L:2912 MOVE CL3-ERN-CODE TO ERN-CODE(CL3-ERN-SEQ)
        clnMultiplier[cl3ErnSeq] = cl3Multiplier;           // L:2913 MOVE CL3-MULTIPLIER TO CLN-MULTIPLIER(CL3-ERN-SEQ)
        clnDiffFlg[cl3ErnSeq] = cl3DiffFlg;                 // L:2914 MOVE CL3-DIFF-FLG TO CLN-DIFF-FLG(CL3-ERN-SEQ)
        clnDiffAmt[cl3ErnSeq] = cl3DiffAmt;                 // L:2915 MOVE CL3-DIFF-AMT TO CLN-DIFF-AMT(CL3-ERN-SEQ)
        clnTaxblFed[cl3ErnSeq] = cl3TaxblFed;               // L:2916 MOVE CL3-TAXBL-FED TO CLN-TAXBL-FED(CL3-ERN-SEQ)
        clnTaxblStt[cl3ErnSeq] = cl3TaxblStt;               // L:2917 MOVE CL3-TAXBL-STT TO CLN-TAXBL-STT(CL3-ERN-SEQ)
        clnTaxblLoc[cl3ErnSeq] = cl3TaxblLoc;               // L:2918 MOVE CL3-TAXBL-LOC TO CLN-TAXBL-LOC(CL3-ERN-SEQ)
        clnTaxblCit[cl3ErnSeq] = cl3TaxblCit;               // L:2919 MOVE CL3-TAXBL-CIT TO CLN-TAXBL-CIT(CL3-ERN-SEQ)
        clnTaxblOth[cl3ErnSeq] = cl3TaxblOth;               // L:2920 MOVE CL3-TAXBL-OTH TO CLN-TAXBL-OTH(CL3-ERN-SEQ)
        clnTaxblFica[cl3ErnSeq] = cl3TaxblFica;             // L:2921 MOVE CL3-TAXBL-FICA TO CLN-TAXBL-FICA(CL3-ERN-SEQ)
        clnTaxblFuta[cl3ErnSeq] = cl3TaxblFuta;             // L:2922 MOVE CL3-TAXBL-FUTA TO CLN-TAXBL-FUTA(CL3-ERN-SEQ)
        clnTaxblSuca[cl3ErnSeq] = cl3TaxblSuca;             // L:2923 MOVE CL3-TAXBL-SUCA TO CLN-TAXBL-SUCA(CL3-ERN-SEQ)
        clnActFlg[cl3ErnSeq] = cl3ActFlg;                   // L:2924 MOVE CL3-ACT-FLG TO CLN-ACT-FLG(CL3-ERN-SEQ)
        // GO TO 200-181-READ-LOOP - control flow           // L:2925 GO TO 200-181-READ-LOOP
    }

    private void exit_200_181() {                           // L:2927 200-181-EXIT
    }

    private void startCl3_200_181() {                       // L:2930 200-181-START-CL3
        cl3Ok = "Y";                                        // L:2931 MOVE "Y" TO CL3-OK
        // START PAYCLNPF03 KEY NOT < CL3-KEY INVAL...      // L:2932 CODE
        cl3Ok = "N";                                        // L:2933 MOVE "N" TO CL3-OK
        if ("9D".equals(fsw)) {                             // L:2934 IF FSW = "9D" GO TO 200-181-START-CL3.
        }  // auto-close unclosed IF
    }

    private void readCl3_200_181() {                        // L:2937 200-181-READ-CL3
        cl3Ok = "Y";                                        // L:2938 MOVE "Y" TO CL3-OK
        // READ PAYCLNPF03 NEXT                             // L:2939 READ
        cl3Ok = "N";                                        // L:2941 MOVE "N" TO CL3-OK
        if ("9D".equals(fsw)) {                             // L:2942 IF FSW = "9D" GO TO 200-181-READ-CL3.
        }  // auto-close unclosed IF
    }

    private void scanErn_200_185() {                        // L:2945 200-185-SCAN-ERN
        if (ernCppSum[s.intValue()].compareTo(BigDecimal.ZERO) != 0 || hrsCppSum[s.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:2946 IF ERN-CPP-SUM(S) NOT = 0
            zeroYn = "N";                                   // L:2949 MOVE "N" TO ZERO-YN
        }  // period ends IF scope
    }

    private void exit_200_185() {                           // L:2951 200-185-EXIT
    }

    private void scanTax_200_186() {                        // L:2954 200-186-SCAN-TAX
        if (taxCppSum[s.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:2955 IF TAX-CPP-SUM(S) NOT = 0
            zeroYn = "N";                                   // L:2956 MOVE "N" TO ZERO-YN
        }  // period ends IF scope
    }

    private void exit_200_186() {                           // L:2958 200-186-EXIT
    }

    private void scanCode_200_187() {                       // L:2961 200-187-SCAN-CODE
        if (codeTrn[s.intValue()] != "") {                  // L:2962 IF CODE-TRN(S) NOT = SPACES
            zeroYn = "N";                                   // L:2963 MOVE "N" TO ZERO-YN
        }  // period ends IF scope
    }

    private void exit_200_187() {                           // L:2965 200-187-EXIT
    }

    private void scanDist_200_188() {                       // L:2968 200-188-SCAN-DIST
        if (amountDist[s.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:2969 IF AMOUNT-DIST(S) NOT = 0
            zeroYn = "N";                                   // L:2970 MOVE "N" TO ZERO-YN
        }  // period ends IF scope
    }

    private void exit_200_188() {                           // L:2972 200-188-EXIT
    }

    private void scanDed_200_189() {                        // L:2975 200-189-SCAN-DED
        if (dedNoToTakeSum[s.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:2976 IF DED-NO-TO-TAKE-SUM (S) NOT = 0
            zeroYn = "N";                                   // L:2977 MOVE "N" TO ZERO-YN
        }  // period ends IF scope
    }

    private void exit_200_189() {                           // L:2979 200-189-EXIT
        // /                                                // L:2980 COMMENT
    }

    private void wrapUp_200_190() {                         // L:2982 200-190-WRAP-UP
        errEmpNo = brkEmpNo;                                // L:2983 MOVE BRK-EMP-NO TO ERR-EMP-NO
        errDateEnd = brkDateEnd;                            // L:2984 MOVE BRK-DATE-END TO ERR-DATE-END
        zeroYn = "Y";                                       // L:2985 MOVE "Y" TO ZERO-YN
        scanErn_200_185();                                  // L:2986 PERFORM 200-185-SCAN-ERN THRU 200-185-EXIT
        scanTax_200_186();                                  // L:2990 PERFORM 200-186-SCAN-TAX THRU 200-186-EXIT
        scanCode_200_187();                                 // L:2994 PERFORM 200-187-SCAN-CODE THRU 200-187-EXIT
        scanDist_200_188();                                 // L:2998 PERFORM 200-188-SCAN-DIST THRU 200-188-EXIT
        scanDed_200_189();                                  // L:3002 PERFORM 200-189-SCAN-DED THRU 200-189-EXIT
        if ((ernCppGrsLessTxSum.compareTo(BigDecimal.ZERO) == 0 && "y".equals(zeroYn) && bnkDepAmt[0].compareTo(BigDecimal.ZERO) == 0 && bnkDepAmt[1].compareTo(BigDecimal.ZERO) == 0 && bnkDepAmt[2].compareTo(BigDecimal.ZERO) == 0)) {// L:3007 IF (ERN-CPP-GRS-LESS-TX-SUM = ZEROS AND
            messageO = "NOTHING FOUND TO COMPUTE NET AND/OR GROSS";// L:3012 MOVE "NOTHING FOUND TO COMPUTE NET AND/OR GROSS" TO MESSAGE-O
            wsGtnErr = "CD";                                // L:3014 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3015 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 200-190-CLEAR-WS - control flow        // L:3016 GO TO 200-190-CLEAR-WS
        }  // period ends IF scope
        if ((("3".equals(timCheckTypeHold) || "r".equals(timCheckTypeHold)) )) {// L:3017 IF (TIM-CHECK-TYPE-HOLD = "3" OR "R" )
            calculate_300_000();                            // L:3018 PERFORM 300-000-CALCULATE THRU 300-000-EXIT
        }  // period ends IF scope
        if ("c".equals(benAnnlClass)) {                     // L:3019 IF BEN-ANNL-CLASS = "C"
            if ((("v".equals(timCheckTypeHold) || "x".equals(timCheckTypeHold)))) {// L:3020 IF (TIM-CHECK-TYPE-HOLD = "V" OR "X")
                remAnnl_300_460();                          // L:3021 PERFORM 300-460-REM-ANNL THRU 300-460-EXIT
            } else {                                        // L:3022 ELSE
                annlLv_300_420();                           // L:3023 PERFORM 300-420-ANNL-LV THRU 300-420-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        if (ernCppGrossSum.compareTo(BigDecimal.ZERO) < 0 && (("r".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold)))) {// L:3025 IF ERN-CPP-GROSS-SUM < 0
            // Initialize PAYROLL-SUMMARY-AREA              // L:3028 INITIALIZE PAYROLL-SUMMARY-AREA
            ernCppGrsLessTxSum = BigDecimal.ZERO;
            lvSickAccRteSum = BigDecimal.ZERO;
            lvAnnlAccRteSum = BigDecimal.ZERO;
            lvPersAccRteSum = BigDecimal.ZERO;
            lvAccRteSum = BigDecimal.ZERO;
            annlTaxblFicaYtd = BigDecimal.ZERO;
            pctTotEarnWs = BigDecimal.ZERO;                 // L:3029 INITIALIZE PCT-TOT-EARN-WS              ...
            // payrollTransactionArea = default; // INITIALIZE PAYROLL-TRANSACTION-AREA// L:3030 INITIALIZE PAYROLL-TRANSACTION-AREA
            // payrollDistributionArea = default; // INITIALIZE PAYROLL-DISTRIBUTION-AREA// L:3031 INITIALIZE PAYROLL-DISTRIBUTION-AREA
            // CALL PYD1XFK                                 // L:3034 CALL "PYD1XFK" USING C-RET-CODE, C-CLIEN...
            callPyd1Xfk();
            fdCount = BigDecimal.ZERO;                      // L:3035 MOVE ZEROS TO FD-COUNT
            messageO = "EMPLOYEE SKIPPED; HAS NEGATIVE HOURS/EARNS.";// L:3037 MOVE "EMPLOYEE SKIPPED; HAS NEGATIVE HOURS/EARNS." TO MESSAGE-O
            wsGtnErr = "CD";                                // L:3039 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3040 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 200-190-CLEAR-WS - control flow        // L:3041 GO TO 200-190-CLEAR-WS
        }  // period ends IF scope
        if ((!"v".equals(timCheckTypeHold) && !"x".equals(timCheckTypeHold)) && ernCppNetSum.compareTo(BigDecimal.ZERO) < 0) {// L:3043 IF (TIM-CHECK-TYPE-HOLD NOT = "V" AND "X...
            messageO = "NET IS NEGATIVE. NO CHECK ISSUED."; // L:3046 MOVE "NET IS NEGATIVE. NO CHECK ISSUED." TO MESSAGE-O
            wsGtnErr = "CD";                                // L:3048 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3049 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 200-190-CLEAR-WS - control flow        // L:3050 GO TO 200-190-CLEAR-WS
        }  // period ends IF scope
        if ((!"v".equals(timCheckTypeHold) && !"x".equals(timCheckTypeHold)) && (bnkDepAmt[0].compareTo(BigDecimal.ZERO) < 0 || bnkDepAmt[1].compareTo(BigDecimal.ZERO) < 0 || bnkDepAmt[2].compareTo(BigDecimal.ZERO) < 0)) {// L:3051 IF (TIM-CHECK-TYPE-HOLD NOT = "V" AND "X...
            messageO = "BANK NET IS NEGATIVE. NO CHECK ISSUED.";// L:3056 MOVE "BANK NET IS NEGATIVE. NO CHECK ISSUED." TO MESSAGE-O
            wsGtnErr = "CD";                                // L:3058 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3059 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 200-190-CLEAR-WS - control flow        // L:3060 GO TO 200-190-CLEAR-WS
        }  // period ends IF scope
        if (ernCppGrossSum.compareTo(clnGrossLimitOptWs) > 0 && (!"v".equals(timCheckTypeHold) && !"x".equals(timCheckTypeHold) && !"m".equals(timCheckTypeHold))) {// L:3066 IF ERN-CPP-GROSS-SUM > CLN-GROSS-LIMIT-O...
            messageO = "";                                  // L:3069 MOVE SPACES TO MESSAGE-O
            editAmt = ernCppGrossSum.toString();            // L:3070 MOVE ERN-CPP-GROSS-SUM TO EDIT-AMT
            // STRING parse failed (no INTO): STRING "GROSS EARNINGS OF " EDIT-AMT " EXCEED GROS...// L:3071 STRING "GROSS EARNINGS OF " EDIT-AMT " E...
            wsGtnErr = "CD";                                // L:3074 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3075 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 200-190-CLEAR-WS - control flow        // L:3076 GO TO 200-190-CLEAR-WS
        }  // period ends IF scope
        if ((!"v".equals(timCheckTypeHold) && !"x".equals(timCheckTypeHold) && !"m".equals(timCheckTypeHold))) {// L:3082 IF (TIM-CHECK-TYPE-HOLD NOT = "V" AND "X...
            totalWs = BigDecimal.ZERO;                      // L:3083 MOVE 0 TO TOTAL-WS
            totalHrs_200_205();                             // L:3084 PERFORM 200-205-TOTAL-HRS
            if (totalWs.compareTo(clnHoursLimitOptWs) > 0) {// L:3086 IF TOTAL-WS > CLN-HOURS-LIMIT-OPT-WS
                messageO = "";                              // L:3087 MOVE SPACES TO MESSAGE-O
                editAmt = totalWs.toString();               // L:3088 MOVE TOTAL-WS TO EDIT-AMT
                // STRING parse failed (no INTO): STRING "TOTAL HOURS OF " EDIT-AMT " EXCEED HOURLY ...// L:3089 STRING "TOTAL HOURS OF " EDIT-AMT " EXCE...
                wsGtnErr = "CD";                            // L:3092 MOVE "CD" TO WS-GTN-ERR
                gtnError_800_700();                         // L:3093 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                // GO TO 200-190-CLEAR-WS - control flow    // L:3094 GO TO 200-190-CLEAR-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if (ernCppGrsLessTxSum.compareTo(BigDecimal.ZERO) == 0 && "y".equals(zeroYn) && bnkDepAmt[0].compareTo(BigDecimal.ZERO) == 0 && bnkDepAmt[1].compareTo(BigDecimal.ZERO) == 0 && bnkDepAmt[2].compareTo(BigDecimal.ZERO) == 0) {// L:3095 IF ERN-CPP-GRS-LESS-TX-SUM = ZEROS AND
        } else {                                            // L:3101 ELSE
            updateYtdTrn_500_000();                         // L:3102 PERFORM 500-000-UPDATE-YTD-TRN
        }  // period ends IF scope
        payrollCurrentTransRecord = "";                     // L:3108 INITIALIZE PAYROLL-CURRENT-TRANS-RECORD.
        tcpClientNo = perClientNo;                          // L:3109 MOVE PER-CLIENT-NO TO TCP-CLIENT-NO
        tcpDateEnd = wsDateEnd.intValue();                  // L:3110 MOVE WS-DATE-END TO TCP-DATE-END
        tcpEmpNo = perEmpNo;                                // L:3111 MOVE PER-EMP-NO TO TCP-EMP-NO
        tcpSeqNo = 0;                                       // L:3112 MOVE ZERO TO TCP-SEQ-NO
        tcpCompNo = clnCompNo;                              // L:3113 MOVE CLN-COMP-NO TO TCP-COMP-NO
        tcpCorpNo = perCorpNo;                              // L:3114 MOVE PER-CORP-NO TO TCP-CORP-NO
        tcpStoreNo = perStoreNo;                            // L:3115 MOVE PER-STORE-NO TO TCP-STORE-NO
        tcpDeptNo = perDeptNo;                              // L:3116 MOVE PER-DEPT-NO TO TCP-DEPT-NO
        if ((("m".equals(timCheckTypeHold) || "v".equals(timCheckTypeHold) || "x".equals(timCheckTypeHold)))) {// L:3117 IF (TIM-CHECK-TYPE-HOLD = "M" OR "V" OR ...
            tcpDocumentNo = timCheckNoHold.toString();      // L:3118 MOVE TIM-CHECK-NO-HOLD TO TCP-DOCUMENT-NO
            tcpDocumentDate = timDateEndHold.intValue();    // L:3119 MOVE TIM-DATE-END-HOLD TO TCP-DOCUMENT-DATE
        } else {                                            // L:3120 ELSE
            tcpDocumentNo = "0";                            // L:3121 MOVE 0 TO TCP-DOCUMENT-NO
            tcpDocumentDate = 0;                            // L:3121 MOVE 0 TO TCP-DOCUMENT-DATE
        }  // period ends IF scope
        tcpCheckNo = timCheckNoHold.intValue();             // L:3122 MOVE TIM-CHECK-NO-HOLD TO TCP-CHECK-NO
        tcpStoreGl = "0";                                   // L:3123 MOVE ZERO TO TCP-STORE-GL
        tcpAcctGl = "0";                                    // L:3123 MOVE ZERO TO TCP-ACCT-GL
        tcpDeptGl = "0";                                    // L:3123 MOVE ZERO TO TCP-DEPT-GL
        tcpCdeCycle = timCdeCycleHold;                      // L:3124 MOVE TIM-CDE-CYCLE-HOLD TO TCP-CDE-CYCLE
        tcpCheckType = timCheckTypeHold;                    // L:3125 MOVE TIM-CHECK-TYPE-HOLD TO TCP-CHECK-TYPE
        tcpEmpName = perEmpName;                            // L:3126 MOVE PER-EMP-NAME TO TCP-EMP-NAME
        if ("y".equals(clnDirdepVoucherOptWs) && ernCppNetSum.compareTo(BigDecimal.ZERO) == 0 && (bnkDepAmt[0].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[1].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[2].compareTo(BigDecimal.ZERO) != 0)) {// L:3127 IF CLN-DIRDEP-VOUCHER-OPT-WS = "Y"
            tcpDirDepVoucher = "Y";                         // L:3136 MOVE "Y" TO TCP-DIR-DEP-VOUCHER
            savedTcpDirDepVoucher = "Y";                    // L:3136 MOVE "Y" TO SAVED-TCP-DIR-DEP-VOUCHER
        } else {                                            // L:3138 ELSE
            tcpDirDepVoucher = "N";                         // L:3139 MOVE "N" TO TCP-DIR-DEP-VOUCHER
            savedTcpDirDepVoucher = "N";                    // L:3139 MOVE "N" TO SAVED-TCP-DIR-DEP-VOUCHER
        }                                                   // L:3141 END-IF
        ernTrn_200_191();                                   // L:3142 PERFORM 200-191-ERN-TRN THRU 200-191-EXIT
        tcpCorpWrk = String.valueOf(perCorpNo);             // L:3144 MOVE PER-CORP-NO TO TCP-CORP-WRK
        tcpStoreWrk = String.valueOf(perStoreNo);           // L:3145 MOVE PER-STORE-NO TO TCP-STORE-WRK
        tcpDeptWrk = String.valueOf(perDeptNo);             // L:3146 MOVE PER-DEPT-NO TO TCP-DEPT-WRK
        netTrn_200_192();                                   // L:3147 PERFORM 200-192-NET-TRN THRU 200-192-EXIT
        taxTrn_200_193();                                   // L:3148 PERFORM 200-193-TAX-TRN THRU 200-193-EXIT
        dedTrn_200_194();                                   // L:3150 PERFORM 200-194-DED-TRN THRU 200-194-EXIT
        dedUpdate_500_130();                                // L:3153 PERFORM 500-130-DED-UPDATE THRU 500-130-EXIT
        lvTrn_200_197();                                    // L:3156 PERFORM 200-197-LV-TRN THRU 200-197-EXIT
        ficaDistBalWs = taxCppFicmSum;                      // L:3157 MOVE TAX-CPP-FICM-SUM TO FICA-DIST-BAL-WS
        if (ficaDistBalWs.compareTo(BigDecimal.ZERO) != 0 && amountDist[0].compareTo(BigDecimal.ZERO) == 0) {// L:3158 IF FICA-DIST-BAL-WS NOT = 0 AND
            corpWrkDist[1] = BigDecimal.valueOf(perCorpNo); // L:3160 MOVE PER-CORP-NO TO CORP-WRK-DIST(1)
            storeWrkDist[1] = BigDecimal.valueOf(perStoreNo);// L:3161 MOVE PER-STORE-NO TO STORE-WRK-DIST(1)
            deptWrkDist[1] = BigDecimal.valueOf(perDeptNo); // L:3162 MOVE PER-DEPT-NO TO DEPT-WRK-DIST(1)
        }  // period ends IF scope
        expenseTrn_200_198();                               // L:3163 PERFORM 200-198-EXPENSE-TRN THRU 200-198-EXIT
        tcpCorpNo = perCorpNo;                              // L:3166 MOVE PER-CORP-NO TO TCP-CORP-NO
        tcpStoreNo = perStoreNo;                            // L:3167 MOVE PER-STORE-NO TO TCP-STORE-NO
        tcpDeptNo = perDeptNo;                              // L:3168 MOVE PER-DEPT-NO TO TCP-DEPT-NO
        depositTrn_200_199();                               // L:3169 PERFORM 200-199-DEPOSIT-TRN THRU 200-199-EXIT
        if (savedTcpSeqNo.compareTo(BigDecimal.ZERO) != 0) {// L:3172 IF SAVED-TCP-SEQ-NO NOT = ZEROS         ...
            rewritePaytrn_800_513();                        // L:3173 PERFORM 800-513-REWRITE-PAYTRN THRU 800-513-EXIT
        }                                                   // L:3174 END-IF
    }

    private void clearWs_200_190() {                        // L:3177 200-190-CLEAR-WS
        wsBnkSeq = BigDecimal.ZERO;                         // L:3178 MOVE 0 TO WS-BNK-SEQ
        // Initialize PAYROLL-SUMMARY-AREA                  // L:3179 INITIALIZE PAYROLL-SUMMARY-AREA
        ernCppGrsLessTxSum = BigDecimal.ZERO;
        lvSickAccRteSum = BigDecimal.ZERO;
        lvAnnlAccRteSum = BigDecimal.ZERO;
        lvPersAccRteSum = BigDecimal.ZERO;
        lvAccRteSum = BigDecimal.ZERO;
        annlTaxblFicaYtd = BigDecimal.ZERO;
        pctTotEarnWs = BigDecimal.ZERO;                     // L:3184 INITIALIZE PCT-TOT-EARN-WS.             ...
        // CALL PYD1XFK                                     // L:3187 CALL "PYD1XFK" USING C-RET-CODE, C-CLIEN...
        callPyd1Xfk();
        fdCount = BigDecimal.ZERO;                          // L:3188 MOVE ZEROS TO FD-COUNT
        savedTcpDirDepVoucher = "";                         // L:3191 INITIALIZE SAVED-TCP-DIR-DEP-VOUCHER    ...
    }

    private void exit_200_190() {                           // L:3195 200-190-EXIT
    }

    private void ernTrn_200_191() {                         // L:3201 200-191-ERN-TRN
        if ((amountTrn[i.intValue()].compareTo(BigDecimal.ZERO) != 0 || hoursTrn[i.intValue()].compareTo(BigDecimal.ZERO) != 0) && (!"gros".equals(codeTrn[i.intValue()]) && !"net".equals(codeTrn[i.intValue()]))) {// L:3202 IF (AMOUNT-TRN(I) NOT = ZERO OR
            tcpCorpWrk = corpWrkTrn[i.intValue()].toString();// L:3206 MOVE CORP-WRK-TRN(I) TO TCP-CORP-WRK
            tcpStoreWrk = storeWrkTrn[i.intValue()].toString();// L:3207 MOVE STORE-WRK-TRN(I) TO TCP-STORE-WRK
            tcpDeptWrk = deptWrkTrn[i.intValue()].toString();// L:3208 MOVE DEPT-WRK-TRN(I) TO TCP-DEPT-WRK
            tcpType = "EE";                                 // L:3209 MOVE "EE" TO TCP-TYPE
            tcpCode = codeTrn[i.intValue()];                // L:3210 MOVE CODE-TRN(I) TO TCP-CODE
            tcpHours = hoursTrn[i.intValue()];              // L:3211 MOVE HOURS-TRN(I) TO TCP-HOURS
            tcpRate = rateTrn[i.intValue()];                // L:3212 MOVE RATE-TRN(I) TO TCP-RATE
            tcpAmount = amountTrn[i.intValue()];            // L:3213 MOVE AMOUNT-TRN(I) TO TCP-AMOUNT
            tcpFileSeq = seqTrn[i.intValue()].intValue();   // L:3214 MOVE SEQ-TRN (I) TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3215 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
    }

    private void exit_200_191() {                           // L:3217 200-191-EXIT
    }

    private void netTrn_200_192() {                         // L:3224 200-192-NET-TRN
        if ((ernCppNetSum.compareTo(BigDecimal.ZERO) != 0 || ernCppGrossSum.compareTo(BigDecimal.ZERO) != 0)) {// L:3225 IF (ERN-CPP-NET-SUM NOT = 0 OR
            tcpType = "EN";                                 // L:3227 MOVE "EN" TO TCP-TYPE
            tcpCode = "NET";                                // L:3228 MOVE "NET" TO TCP-CODE
            tcpRate = BigDecimal.ZERO;                      // L:3229 MOVE ZERO TO TCP-RATE
            tcpHours = BigDecimal.ZERO;                     // L:3229 MOVE ZERO TO TCP-HOURS
            tcpAmount = ernCppNetSum;                       // L:3230 MOVE ERN-CPP-NET-SUM TO TCP-AMOUNT
            tcpFileSeq = 34;                                // L:3231 MOVE 34 TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3232 PERFORM 800-510-WRITE-PAYTRN
            tcpType = "EG";                                 // L:3233 MOVE "EG" TO TCP-TYPE
            tcpCode = "GROS";                               // L:3234 MOVE "GROS" TO TCP-CODE
            tcpRate = BigDecimal.ZERO;                      // L:3235 MOVE ZERO TO TCP-RATE
            tcpHours = hrsCppGrossSum;                      // L:3236 MOVE HRS-CPP-GROSS-SUM TO TCP-HOURS
            tcpAmount = ernCppGrossSum;                     // L:3237 MOVE ERN-CPP-GROSS-SUM TO TCP-AMOUNT
            tcpFileSeq = 35;                                // L:3238 MOVE 35 TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3239 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
    }

    private void exit_200_192() {                           // L:3241 200-192-EXIT
    }

    private void taxTrn_200_193() {                         // L:3247 200-193-TAX-TRN
        if (taxCppSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:3248 IF TAX-CPP-SUM(I) NOT = ZERO
            tcpGroup = "T";                                 // L:3249 MOVE "T" TO TCP-GROUP
            tcpSubGroup = taxSubGroup[i.intValue()];        // L:3250 MOVE TAX-SUB-GROUP(I) TO TCP-SUB-GROUP
            tcpCode = taxName[i.intValue()];                // L:3251 MOVE TAX-NAME(I) TO TCP-CODE
            tcpHours = BigDecimal.ZERO;                     // L:3252 MOVE ZERO TO TCP-HOURS
            tcpRate = BigDecimal.ZERO;                      // L:3252 MOVE ZERO TO TCP-RATE
            tcpAmount = taxCppSum[i.intValue()];            // L:3253 MOVE TAX-CPP-SUM(I) TO TCP-AMOUNT
            tcpFileSeq = i.intValue();                      // L:3254 MOVE I TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3263 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (("dopt".equals(taxName[i.intValue()]) || "gopt".equals(taxName[i.intValue()]))) {// L:3266 IF TAX-NAME(I) = "DOPT" OR "GOPT"       ...
            if (taxCppSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:3267 IF TAX-CPP-SUM(I) NOT = ZERO            ...
                tcpGroup = "X";                             // L:3268 MOVE "X" TO TCP-GROUP
                tcpCode = wkOprTaxCode;                     // L:3269 MOVE WK-OPR-TAX-CODE TO TCP-CODE
                tcpAmount = wkOprTrnAmount;                 // L:3270 MOVE WK-OPR-TRN-AMOUNT TO TCP-AMOUNT
                tcpFileSeq = 7;                             // L:3271 MOVE 7 TO TCP-FILE-SEQ
                writePaytrn_800_510();                      // L:3272 PERFORM 800-510-WRITE-PAYTRN
            }                                               // L:3273 END-IF
        }                                                   // L:3274 END-IF
    }

    private void exit_200_193() {                           // L:3277 200-193-EXIT
    }

    private void dedTrn_200_194() {                         // L:3283 200-194-DED-TRN
        if (dedNoSum[i.intValue()] == "" || dedNoToTakeSum[i.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:3284 IF DED-NO-SUM (I) = SPACES OR
            // GO TO 200-194-EXIT - control flow            // L:3286 GO TO 200-194-EXIT
        }  // period ends IF scope
        tcpCorpWrk = String.valueOf(perCorpNo);             // L:3288 MOVE PER-CORP-NO TO TCP-CORP-WRK
        tcpStoreWrk = String.valueOf(perStoreNo);           // L:3289 MOVE PER-STORE-NO TO TCP-STORE-WRK
        tcpDeptWrk = String.valueOf(perDeptNo);             // L:3290 MOVE PER-DEPT-NO TO TCP-DEPT-WRK
        if (("ec".equals(dedParaSum[i.intValue()]) || "eh".equals(dedParaSum[i.intValue()])) && dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:3295 IF (DED-PARA-SUM(I) = "EC" OR DED-PARA-S...
            tcpType = "DX";                                 // L:3297 MOVE "DX" TO TCP-TYPE
            emprDistBalWs = dedAmtSum[i.intValue()];        // L:3298 MOVE DED-AMT-SUM(I) TO EMPR-DIST-BAL-WS
        }  // period ends IF scope
        if ("y".equals(clnOpt62Ws)) {                       // L:3302 IF CLN-OPT62-WS = "Y"
            ehEmprExpenseTrn_200_196();                     // L:3303 PERFORM 200-196-EH-EMPR-EXPENSE-TRN THRU 200-196-EXIT
        } else {                                            // L:3304 ELSE
            emprExpenseTrn_200_195();                       // L:3305 PERFORM 200-195-EMPR-EXPENSE-TRN THRU 200-195-EXIT
        }                                                   // L:3308 END-IF
        // GO TO 200-194-EXIT - control flow                // L:3309 GO TO 200-194-EXIT
        tcpType = "D ";                                     // L:3310 MOVE "D " TO TCP-TYPE
        if (("ba".equals(dedParaSum[i.intValue()]) && dedNoTakenSum[i.intValue()].compareTo(BigDecimal.valueOf(1)) > 0)) {// L:3312 IF (DED-PARA-SUM (I) = "BA" AND
            tcpCode = dedNoSum[i.intValue()];               // L:3314 MOVE DED-NO-SUM(I) TO TCP-CODE
            tcpRate = BigDecimal.ZERO;                      // L:3315 MOVE ZERO TO TCP-RATE
            tcpHours = dedNoTakenSum[i.intValue()];         // L:3316 MOVE DED-NO-TAKEN-SUM(I) TO TCP-HOURS
            tcpAmount = BigDecimal.ZERO;                    // L:3317 MOVE ZERO TO TCP-AMOUNT
            tcpFileSeq = dedSeqNoSum[i.intValue()].intValue();// L:3318 MOVE DED-SEQ-NO-SUM (I) TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3319 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if ("ba".equals(dedParaSum[i.intValue()])) {        // L:3320 IF DED-PARA-SUM (I) = "BA"
            // GO TO 200-194-EXIT - control flow            // L:3321 GO TO 200-194-EXIT
        }  // period ends IF scope
        if ((ernCppGrossSum.compareTo(BigDecimal.ZERO) != 0 || ernCppNetSum.compareTo(BigDecimal.ZERO) != 0) && dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:3323 IF (ERN-CPP-GROSS-SUM NOT = 0 OR
            tcpCode = dedNoSum[i.intValue()];               // L:3326 MOVE DED-NO-SUM(I) TO TCP-CODE
            tcpRate = BigDecimal.ZERO;                      // L:3327 MOVE ZERO TO TCP-RATE
            tcpHours = dedNoTakenSum[i.intValue()];         // L:3328 MOVE DED-NO-TAKEN-SUM(I) TO TCP-HOURS
            tcpAmount = dedAmtSum[i.intValue()];            // L:3329 MOVE DED-AMT-SUM(I) TO TCP-AMOUNT
            tcpFileSeq = dedSeqNoSum[i.intValue()].intValue();// L:3330 MOVE DED-SEQ-NO-SUM (I) TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3331 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if ((ernCppGrossSum.compareTo(BigDecimal.ZERO) == 0 && ernCppNetSum.compareTo(BigDecimal.ZERO) == 0) && (bnkDepAmt[0].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[1].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[2].compareTo(BigDecimal.ZERO) != 0) && dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:3332 IF (ERN-CPP-GROSS-SUM = 0 AND
            tcpCode = dedNoSum[i.intValue()];               // L:3338 MOVE DED-NO-SUM(I) TO TCP-CODE
            tcpRate = BigDecimal.ZERO;                      // L:3339 MOVE ZERO TO TCP-RATE
            tcpHours = dedNoTakenSum[i.intValue()];         // L:3340 MOVE DED-NO-TAKEN-SUM(I) TO TCP-HOURS
            tcpAmount = dedAmtSum[i.intValue()];            // L:3341 MOVE DED-AMT-SUM(I) TO TCP-AMOUNT
            tcpFileSeq = dedSeqNoSum[i.intValue()].intValue();// L:3342 MOVE DED-SEQ-NO-SUM (I) TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3343 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if ("y".equals(dedSetArrSum[i.intValue()]) && dedArrsCtrSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0 && dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:3345 IF DED-SET-ARR-SUM(I) = "Y" AND
            tcpSubGroup = "A";                              // L:3348 MOVE "A" TO TCP-SUB-GROUP
            tcpCode = dedNoSum[i.intValue()];               // L:3349 MOVE DED-NO-SUM(I) TO TCP-CODE
            tcpRate = BigDecimal.ZERO;                      // L:3350 MOVE ZERO TO TCP-RATE
            tcpHours = dedArrsCtrSum[i.intValue()];         // L:3351 MOVE DED-ARRS-CTR-SUM(I) TO TCP-HOURS
            tcpAmount = BigDecimal.ZERO;                    // L:3352 MOVE ZERO TO TCP-AMOUNT
            tcpFileSeq = dedSeqNoSum[i.intValue()].intValue();// L:3353 MOVE DED-SEQ-NO-SUM (I) TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3354 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
    }

    private void exit_200_194() {                           // L:3356 200-194-EXIT
    }

    private void emprExpenseTrn_200_195() {                 // L:3363 200-195-EMPR-EXPENSE-TRN
        // DIVIDE parse failed: DIVIDE AMOUNT-DIST(IM) BY ERN-CPP-GROSS-SUM                  IBM-CT// L:3364 DIVIDE AMOUNT-DIST(IM) BY ERN-CPP-GROSS-...
        pctWs = BigDecimal.ZERO;                            // L:3367 MOVE ZERO TO PCT-WS
        pctWs = pctWs.multiply(dedAmtSum[i.intValue()]);    // L:3373 MULTIPLY DED-AMT-SUM (I) BY PCT-WS
        emprDistBalWs = emprDistBalWs.subtract(tcpAmount);  // L:3375 SUBTRACT TCP-AMOUNT FROM EMPR-DIST-BAL-W...
        jm = BigDecimal.valueOf(1).add(im);                 // L:3381 ADD 1 IM GIVING JM.
        if ((im.compareTo(BigDecimal.valueOf(33)) == 0 || (jm.compareTo(BigDecimal.valueOf(33)) <= 0 && storeWrkDist[jm.intValue()].compareTo(BigDecimal.ZERO) == 0))) {// L:3382 IF (IM = 33 OR
            tcpAmount = tcpAmount.add(emprDistBalWs);       // L:3390 ADD EMPR-DIST-BAL-WS TO TCP-AMOUNT.
        }  // period ends IF scope
        if (tcpAmount.compareTo(BigDecimal.ZERO) != 0) {    // L:3391 IF TCP-AMOUNT NOT = ZERO
            tcpCorpWrk = corpWrkDist[im.intValue()].toString();// L:3392 MOVE CORP-WRK-DIST(IM) TO TCP-CORP-WRK
            tcpStoreWrk = storeWrkDist[im.intValue()].toString();// L:3393 MOVE STORE-WRK-DIST(IM) TO TCP-STORE-WRK
            tcpDeptWrk = deptWrkDist[im.intValue()].toString();// L:3394 MOVE DEPT-WRK-DIST(IM) TO TCP-DEPT-WRK
            tcpGroup = "D";                                 // L:3395 MOVE "D" TO TCP-GROUP
            tcpSubGroup = "X";                              // L:3396 MOVE "X" TO TCP-SUB-GROUP
            tcpCode = dedNoSum[i.intValue()];               // L:3397 MOVE DED-NO-SUM(I) TO TCP-CODE
            tcpRate = BigDecimal.ZERO;                      // L:3398 MOVE ZERO TO TCP-RATE
            tcpHours = dedNoTakenSum[i.intValue()];         // L:3399 MOVE DED-NO-TAKEN-SUM(I) TO TCP-HOURS
            tcpFileSeq = dedSeqNoSum[i.intValue()].intValue();// L:3400 MOVE DED-SEQ-NO-SUM (I) TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3401 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
    }

    private void exit_200_195() {                           // L:3403 200-195-EXIT
    }

    private void ehEmprExpenseTrn_200_196() {               // L:3409 200-196-EH-EMPR-EXPENSE-TRN
        pctWs = BigDecimal.valueOf(1.0000);                 // L:3412 MOVE 1.0000 TO PCT-WS
        pctWs = pctWs.multiply(dedAmtSum[i.intValue()]);    // L:3418 MULTIPLY DED-AMT-SUM (I) BY PCT-WS      ...
        if (tcpAmount.compareTo(BigDecimal.ZERO) != 0) {    // L:3421 IF TCP-AMOUNT NOT = ZERO                ...
            tcpCorpWrk = String.valueOf(perCorpNo);         // L:3429 MOVE PER-CORP-NO TO TCP-CORP-WRK
            tcpStoreWrk = String.valueOf(perStoreNo);       // L:3430 MOVE PER-STORE-NO TO TCP-STORE-WRK
            tcpDeptWrk = String.valueOf(perDeptNo);         // L:3431 MOVE PER-DEPT-NO TO TCP-DEPT-WRK
            tcpGroup = "D";                                 // L:3432 MOVE "D" TO TCP-GROUP
            tcpSubGroup = "X";                              // L:3433 MOVE "X" TO TCP-SUB-GROUP
            tcpCode = dedNoSum[i.intValue()];               // L:3434 MOVE DED-NO-SUM(I) TO TCP-CODE
            tcpRate = BigDecimal.ZERO;                      // L:3435 MOVE ZERO TO TCP-RATE
            tcpHours = dedNoTakenSum[i.intValue()];         // L:3436 MOVE DED-NO-TAKEN-SUM(I) TO TCP-HOURS
            tcpFileSeq = dedSeqNoSum[i.intValue()].intValue();// L:3437 MOVE DED-SEQ-NO-SUM (I) TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3438 PERFORM 800-510-WRITE-PAYTRN
        }  // auto-close unclosed IF
    }

    private void exit_200_196() {                           // L:3440 200-196-EXIT
    }

    private void lvTrn_200_197() {                          // L:3446 200-197-LV-TRN
        if (lvSickAccRteSum.compareTo(BigDecimal.ZERO) != 0) {// L:3448 IF LV-SICK-ACC-RTE-SUM NOT = ZERO
            tcpType = "LV";                                 // L:3449 MOVE "LV" TO TCP-TYPE
            tcpCode = "SICK";                               // L:3450 MOVE "SICK" TO TCP-CODE
            xsickHoursWs = hrsCppSum[15];                   // L:3451 MOVE HRS-CPP-SUM (15) TO XSICK-HOURS-WS
            addXsickHours_1000_700();                       // L:3452 PERFORM 1000-700-ADD-XSICK-HOURS THRU 1000-700-EXIT
            tcpHours = xsickHoursWs;                        // L:3453 MOVE XSICK-HOURS-WS TO TCP-HOURS
            tcpAmount = BigDecimal.ZERO;                    // L:3454 MOVE ZERO TO TCP-AMOUNT
            tcpRate = lvSickAccRteSum;                      // L:3455 MOVE LV-SICK-ACC-RTE-SUM TO TCP-RATE
            tcpFileSeq = 1;                                 // L:3456 MOVE 1 TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3457 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (lvAnnlAccRteSum.compareTo(BigDecimal.ZERO) != 0) {// L:3458 IF LV-ANNL-ACC-RTE-SUM NOT = ZERO
            tcpType = "LV";                                 // L:3459 MOVE "LV" TO TCP-TYPE
            tcpCode = "ANNL";                               // L:3460 MOVE "ANNL" TO TCP-CODE
            tcpHours = hrsCppSum[17];                       // L:3461 MOVE HRS-CPP-SUM (17) TO TCP-HOURS
            tcpAmount = BigDecimal.ZERO;                    // L:3462 MOVE ZERO TO TCP-AMOUNT
            tcpRate = lvAnnlAccRteSum;                      // L:3463 MOVE LV-ANNL-ACC-RTE-SUM TO TCP-RATE
            tcpFileSeq = 2;                                 // L:3464 MOVE 2 TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3465 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (lvPersAccRteSum.compareTo(BigDecimal.ZERO) != 0) {// L:3466 IF LV-PERS-ACC-RTE-SUM NOT = ZERO
            tcpType = "LV";                                 // L:3467 MOVE "LV" TO TCP-TYPE
            tcpCode = "PERS";                               // L:3468 MOVE "PERS" TO TCP-CODE
            tcpHours = hrsCppSum[16];                       // L:3469 MOVE HRS-CPP-SUM (16) TO TCP-HOURS
            tcpAmount = BigDecimal.ZERO;                    // L:3470 MOVE ZERO TO TCP-AMOUNT
            tcpRate = lvPersAccRteSum;                      // L:3471 MOVE LV-PERS-ACC-RTE-SUM TO TCP-RATE
            tcpFileSeq = 3;                                 // L:3472 MOVE 3 TO TCP-FILE-SEQ
            writePaytrn_800_510();                          // L:3473 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
    }

    private void exit_200_197() {                           // L:3475 200-197-EXIT
    }

    private void expenseTrn_200_198() {                     // L:3482 200-198-EXPENSE-TRN
        // DIVIDE parse failed: DIVIDE AMOUNT-DIST(I) BY ERN-CPP-GROSS-SUM                   IBM-CT// L:3483 DIVIDE AMOUNT-DIST(I) BY ERN-CPP-GROSS-S...
        pctWs = BigDecimal.ZERO;                            // L:3486 MOVE ZERO TO PCT-WS
        if (amountDist[i.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:3487 IF AMOUNT-DIST (I) = 0
            pctWs = BigDecimal.valueOf(1.00);               // L:3488 MOVE 1.00 TO PCT-WS
        }  // period ends IF scope
        pctWs = pctWs.multiply(taxCppFicmSum);              // L:3494 MULTIPLY TAX-CPP-FICM-SUM BY PCT-WS     ...
        ficaDistBalWs = ficaDistBalWs.subtract(tcpAmount);  // L:3496 SUBTRACT TCP-AMOUNT FROM FICA-DIST-BAL-W...
        j = BigDecimal.valueOf(1).add(i);                   // L:3502 ADD 1 I GIVING J.
        if ((i.compareTo(BigDecimal.valueOf(33)) == 0 || (j.compareTo(BigDecimal.valueOf(33)) <= 0 && storeWrkDist[j.intValue()].compareTo(BigDecimal.ZERO) == 0))) {// L:3503 IF (I = 33 OR (J NOT > 33 AND STORE-WRK-...
            tcpAmount = tcpAmount.add(ficaDistBalWs);       // L:3504 ADD FICA-DIST-BAL-WS TO TCP-AMOUNT.
        }  // period ends IF scope
        if (tcpAmount.compareTo(BigDecimal.ZERO) != 0) {    // L:3506 IF TCP-AMOUNT NOT = ZERO
            tcpCorpWrk = corpWrkDist[i.intValue()].toString();// L:3507 MOVE CORP-WRK-DIST(I) TO TCP-CORP-WRK
            tcpStoreWrk = storeWrkDist[i.intValue()].toString();// L:3508 MOVE STORE-WRK-DIST(I) TO TCP-STORE-WRK
            tcpDeptWrk = deptWrkDist[i.intValue()].toString();// L:3509 MOVE DEPT-WRK-DIST(I) TO TCP-DEPT-WRK
            tcpGroup = "X";                                 // L:3510 MOVE "X" TO TCP-GROUP
            tcpSubGroup = "A";                              // L:3511 MOVE "A" TO TCP-SUB-GROUP
            tcpCode = taxName[6];                           // L:3512 MOVE TAX-NAME(6) TO TCP-CODE
            tcpHours = BigDecimal.ZERO;                     // L:3513 MOVE ZERO TO TCP-HOURS
            tcpRate = BigDecimal.ZERO;                      // L:3513 MOVE ZERO TO TCP-RATE
            writePaytrn_800_510();                          // L:3514 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
    }

    private void exit_200_198() {                           // L:3516 200-198-EXIT
        // /                                                // L:3518 COMMENT
    }

    private void depositTrn_200_199() {                     // L:3523 200-199-DEPOSIT-TRN
        if (i.compareTo(BigDecimal.valueOf(1)) == 0) {      // L:3524 IF I = 1
            tcpCode = "DEP1";                               // L:3525 MOVE "DEP1" TO TCP-CODE
            tcpCorpWrk = String.valueOf(perCorpNo);         // L:3526 MOVE PER-CORP-NO TO TCP-CORP-WRK
            tcpStoreWrk = String.valueOf(perStoreNo);       // L:3527 MOVE PER-STORE-NO TO TCP-STORE-WRK
            tcpDeptWrk = String.valueOf(perDeptNo);         // L:3528 MOVE PER-DEPT-NO TO TCP-DEPT-WRK
            if (i.compareTo(BigDecimal.valueOf(2)) == 0) {  // L:3529 IF I = 2
                tcpCode = "DEP2";                           // L:3530 MOVE "DEP2" TO TCP-CODE
                tcpCorpWrk = String.valueOf(perCorpNo);     // L:3531 MOVE PER-CORP-NO TO TCP-CORP-WRK
                tcpStoreWrk = String.valueOf(perStoreNo);   // L:3532 MOVE PER-STORE-NO TO TCP-STORE-WRK
                tcpDeptWrk = String.valueOf(perDeptNo);     // L:3533 MOVE PER-DEPT-NO TO TCP-DEPT-WRK
                if (i.compareTo(BigDecimal.valueOf(3)) == 0) {// L:3534 IF I = 3
                    tcpCode = "DEP3";                       // L:3535 MOVE "DEP3" TO TCP-CODE
                    tcpCorpWrk = String.valueOf(perCorpNo); // L:3536 MOVE PER-CORP-NO TO TCP-CORP-WRK
                    tcpStoreWrk = String.valueOf(perStoreNo);// L:3537 MOVE PER-STORE-NO TO TCP-STORE-WRK
                    tcpDeptWrk = String.valueOf(perDeptNo); // L:3538 MOVE PER-DEPT-NO TO TCP-DEPT-WRK
                    if ("p".equals(bnkAcctType[i.intValue()])) {// L:3542 IF BNK-ACCT-TYPE (I) = "P"              ...
                        tcpCode = "PCRD";                   // L:3543 MOVE "PCRD" TO TCP-CODE
                        tcpCorpWrk = String.valueOf(perCorpNo);// L:3544 MOVE PER-CORP-NO TO TCP-CORP-WRK
                        tcpStoreWrk = String.valueOf(perStoreNo);// L:3545 MOVE PER-STORE-NO TO TCP-STORE-WRK
                        tcpDeptWrk = String.valueOf(perDeptNo);// L:3546 MOVE PER-DEPT-NO TO TCP-DEPT-WRK
                    }                                       // L:3547 END-IF
                    if ((("s".equals(bnkPnFlag[i.intValue()]) || "w".equals(bnkPnFlag[i.intValue()]))) || bnkDepAmt[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:3549 IF (BNK-PN-FLAG(I) = "S" OR "W") OR
                        tcpType = "B ";                     // L:3551 MOVE "B " TO TCP-TYPE
                        tcpRate = BigDecimal.ZERO;          // L:3552 MOVE ZERO TO TCP-RATE
                        tcpHours = BigDecimal.ZERO;         // L:3552 MOVE ZERO TO TCP-HOURS
                        tcpAmount = bnkDepAmt[i.intValue()];// L:3553 MOVE BNK-DEP-AMT(I) TO TCP-AMOUNT
                        tcpFileSeq = i.intValue();          // L:3554 MOVE I TO TCP-FILE-SEQ
                        writePaytrn_800_510();              // L:3555 PERFORM 800-510-WRITE-PAYTRN
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if ((!"r".equals(timCheckTypeHold) && !"3".equals(timCheckTypeHold)) && ("s".equals(bnkPnFlag[i.intValue()]) || bnkDepAmt[i.intValue()].compareTo(BigDecimal.ZERO) != 0)) {// L:3562 IF (TIM-CHECK-TYPE-HOLD NOT = "R" AND NO...
            bnkAbaNo[i.intValue()] = BigDecimal.valueOf(perBankAbaNo[i.intValue()]);// L:3565 MOVE PER-BANK-ABA-NO (I) TO BNK-ABA-NO(I)
            bnkAcctType[i.intValue()] = perBankAcctType[i.intValue()];// L:3566 MOVE PER-BANK-ACCT-TYPE (I) TO BNK-ACCT-TYPE(I)
            bnkPnFlag[i.intValue()] = perBankPnFlag[i.intValue()];// L:3567 MOVE PER-BANK-PN-FLAG (I) TO BNK-PN-FLAG(I)
            bnkAcct[i.intValue()] = perBankAcct[i.intValue()];// L:3568 MOVE PER-BANK-ACCT (I) TO BNK-ACCT(I)
            if ("k".equals(bnkAcctType[i.intValue()])) {    // L:3569 IF BNK-ACCT-TYPE (I) = "K"
                bnkAcctType[i.intValue()] = "C";            // L:3570 MOVE "C" TO BNK-ACCT-TYPE(I)
            } else {                                        // L:3571 ELSE
                if ("v".equals(bnkAcctType[i.intValue()])) {// L:3572 IF BNK-ACCT-TYPE (I) = "V"
                    bnkAcctType[i.intValue()] = "S";        // L:3573 MOVE "S" TO BNK-ACCT-TYPE(I)
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (("s".equals(bnkPnFlag[i.intValue()]) || bnkDepAmt[i.intValue()].compareTo(BigDecimal.ZERO) != 0)) {// L:3574 IF (BNK-PN-FLAG(I) = "S" OR BNK-DEP-AMT(...
            if (("p".equals(bnkAcctType[i.intValue()]) && "s".equals(bnkPnFlag[i.intValue()]))) {// L:3577 IF (BNK-ACCT-TYPE(I) = "P" AND BNK-PN-FL...
                depTransCode = "23";                        // L:3578 MOVE "23" TO DEP-TRANS-CODE
            } else {                                        // L:3579 ELSE
                if (("p".equals(bnkAcctType[i.intValue()]) && !"s".equals(bnkPnFlag[i.intValue()]))) {// L:3580 IF (BNK-ACCT-TYPE(I) = "P" AND BNK-PN-FL...
                    depTransCode = "22";                    // L:3581 MOVE "22" TO DEP-TRANS-CODE
                } else {                                    // L:3582 ELSE
                    if (("c".equals(bnkAcctType[i.intValue()]) && "s".equals(bnkPnFlag[i.intValue()]))) {// L:3584 IF (BNK-ACCT-TYPE(I) = "C" AND BNK-PN-FL...
                        depTransCode = "23";                // L:3585 MOVE "23" TO DEP-TRANS-CODE
                    } else {                                // L:3586 ELSE
                        if (("c".equals(bnkAcctType[i.intValue()]) && !"s".equals(bnkPnFlag[i.intValue()]))) {// L:3587 IF (BNK-ACCT-TYPE(I) = "C" AND BNK-PN-FL...
                            depTransCode = "22";            // L:3588 MOVE "22" TO DEP-TRANS-CODE
                        } else {                            // L:3589 ELSE
                            if (("s".equals(bnkAcctType[i.intValue()]) && "s".equals(bnkPnFlag[i.intValue()]))) {// L:3590 IF (BNK-ACCT-TYPE(I) = "S" AND BNK-PN-FL...
                                depTransCode = "33";        // L:3591 MOVE "33" TO DEP-TRANS-CODE
                            } else {                        // L:3592 ELSE
                                if (("s".equals(bnkAcctType[i.intValue()]) && !"s".equals(bnkPnFlag[i.intValue()]))) {// L:3593 IF (BNK-ACCT-TYPE(I) = "S" AND BNK-PN-FL...
                                    depTransCode = "32";    // L:3594 MOVE "32" TO DEP-TRANS-CODE
                                }  // period ends IF scope
                            }  // period ends IF scope
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (("s".equals(bnkPnFlag[i.intValue()]) || bnkDepAmt[i.intValue()].compareTo(BigDecimal.ZERO) != 0)) {// L:3595 IF (BNK-PN-FLAG(I) = "S" OR BNK-DEP-AMT(...
            depClientNo = perClientNo;                      // L:3596 MOVE PER-CLIENT-NO TO DEP-CLIENT-NO
            depEmpNo = perEmpNo;                            // L:3597 MOVE PER-EMP-NO TO DEP-EMP-NO
            depBkAba = bnkAbaNo[i.intValue()].toString();   // L:3598 MOVE BNK-ABA-NO(I) TO DEP-BK-ABA
            depBkAccount = bnkAcct[i.intValue()];           // L:3599 MOVE BNK-ACCT(I) TO DEP-BK-ACCOUNT
            depAcctType = bnkAcctType[i.intValue()];        // L:3600 MOVE BNK-ACCT-TYPE(I) TO DEP-ACCT-TYPE
            wsBnkSeq = wsBnkSeq.add(BigDecimal.valueOf(1)); // L:3601 ADD 1 TO WS-BNK-SEQ
            depSeqNo = wsBnkSeq.intValue();                 // L:3602 MOVE WS-BNK-SEQ TO DEP-SEQ-NO
            depPnFlag = bnkPnFlag[i.intValue()];            // L:3603 MOVE BNK-PN-FLAG(I) TO DEP-PN-FLAG
            depTransAmt = bnkDepAmt[i.intValue()];          // L:3604 MOVE BNK-DEP-AMT(I) TO DEP-TRANS-AMT
            depCheckDate = wsDateCheck.intValue();          // L:3605 MOVE WS-DATE-CHECK TO DEP-CHECK-DATE
            depAllotAmt = BigDecimal.ZERO;                  // L:3606 MOVE 0 TO DEP-ALLOT-AMT
            depCheckNo = 0;                                 // L:3607 MOVE 0 TO DEP-CHECK-NO
            loadSign_200_200();                             // L:3608 PERFORM 200-200-LOAD-SIGN THRU 200-200-EXIT
            depDepositNo = i.intValue();                    // L:3609 MOVE I TO DEP-DEPOSIT-NO
            depEmpName = perEmpName;                        // L:3610 MOVE PER-EMP-NAME TO DEP-EMP-NAME
            if (parmProfile.compareTo(wsPrelimProfile) != 0) {// L:3613 IF PARM-PROFILE NOT = WS-PRELIM-PROFILE ...
                writePaydep_800_390();                      // L:3614 PERFORM 800-390-WRITE-PAYDEP
            }  // period ends IF scope
        }  // period ends IF scope
        // 200-199-EXIT. EXIT.                              // L:3616 CODE
    }

    private void loadSign_200_200() {                       // L:3623 200-200-LOAD-SIGN
        if (depTransAmt.compareTo(BigDecimal.ZERO) < 0) {   // L:3624 IF DEP-TRANS-AMT < 0
            depTransSign = "DB";                            // L:3625 MOVE "DB" TO DEP-TRANS-SIGN
        } else {                                            // L:3626 ELSE
            depTransSign = "CR";                            // L:3627 MOVE "CR" TO DEP-TRANS-SIGN
        }  // period ends IF scope
        // 200-200-EXIT. EXIT.                              // L:3628 CODE
    }

    private void totalHrs_200_205() {                       // L:3634 200-205-TOTAL-HRS
        totalWs = totalWs.add(hoursTrn[i.intValue()]);      // L:3635 ADD HOURS-TRN(I) TO TOTAL-WS.
        // 200-205-EXIT. EXIT.                              // L:3636 CODE
        // /                                                // L:3637 COMMENT
    }

    private void calculate_300_000() {                      // L:3639 300-000-CALCULATE
        if ("f".equals(perSchdl) && (("r".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold)))) {// L:3646 IF PER-SCHDL = "F"
            if ("y".equals(clnDeptLaborFwwOptWs)) {         // L:3649 IF CLN-DEPT-LABOR-FWW-OPT-WS = "Y"
                fwwDeptOfLabor_300_060();                   // L:3650 PERFORM 300-060-FWW-DEPT-OF-LABOR THRU 300-060-EXIT
            } else {                                        // L:3651 ELSE
                fwwPreprocess_300_050();                    // L:3652 PERFORM 300-050-FWW-PREPROCESS THRU 300-050-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        if ("n".equals(ficaOnlyOptWs)) {                    // L:3653 IF FICA-ONLY-OPT-WS = "N"
            grossWagesBeBa_300_203();                       // L:3655 PERFORM 300-203-GROSS-WAGES-BE-BA
            benAmountWs = BigDecimal.ZERO;                  // L:3656 MOVE 0 TO BEN-AMOUNT-WS
            benLookup_300_170();                            // L:3657 PERFORM 300-170-BEN-LOOKUP
            locateBenCode_300_180();                        // L:3660 PERFORM 300-180-LOCATE-BEN-CODE
            baAmountWs = BigDecimal.ZERO;                   // L:3663 MOVE 0 TO BA-AMOUNT-WS
            baLookup_300_140();                             // L:3664 PERFORM 300-140-BA-LOOKUP
            locateBaCode_300_150();                         // L:3667 PERFORM 300-150-LOCATE-BA-CODE
        }  // period ends IF scope
        grossWages_300_205();                               // L:3669 PERFORM 300-205-GROSS-WAGES
        ernCppGrossSum = totEarnWs;                         // L:3670 MOVE TOT-EARN-WS TO ERN-CPP-GROSS-SUM
        if (totEarnWs.compareTo(BigDecimal.ZERO) < 0 && (("r".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold)))) {// L:3672 IF TOT-EARN-WS < 0
            // GO TO 300-000-EXIT - control flow            // L:3675 GO TO 300-000-EXIT
        }  // period ends IF scope
        netWages_300_210();                                 // L:3677 PERFORM 300-210-NET-WAGES
        ernCppNetSum = totEarnWs;                           // L:3678 MOVE TOT-EARN-WS TO ERN-CPP-NET-SUM
        grossFicaWages_300_215();                           // L:3680 PERFORM 300-215-GROSS-FICA-WAGES
        tsaAmountWs = BigDecimal.ZERO;                      // L:3681 MOVE ZERO TO TSA-AMOUNT-WS
        // nontaxblTable = default; // INITIALIZE NONTAXBL-TABLE// L:3683 INITIALIZE NONTAXBL-TABLE, ANNL-TAXBL-TA...
        // annlTaxblTable = default; // INITIALIZE ANNL-TAXBL-TABLE// L:3683 INITIALIZE NONTAXBL-TABLE, ANNL-TAXBL-TA...
        nontaxblLookup_300_130();                           // L:3685 PERFORM 300-130-NONTAXBL-LOOKUP
        ficaTaxRoutine_300_100();                           // L:3688 PERFORM 300-100-FICA-TAX-ROUTINE
        ficaEmprRoutine_300_107();                          // L:3689 PERFORM 300-107-FICA-EMPR-ROUTINE
        if ("y".equals(ficaOnlyOptWs)) {                    // L:3690 IF FICA-ONLY-OPT-WS = "Y"
            if (("pauc".equals(perCdeCit) || "njuc".equals(perCdeCit) || "njud".equals(perCdeCit))) {// L:3691 IF PER-CDE-CIT = "PAUC" OR "NJUC" OR "NJ...
                cityTax_300_124();                          // L:3692 PERFORM 300-124-CITY-TAX
            }                                               // L:3693 END-IF
            if (("njuc".equals(perCdeOth) || "njud".equals(perCdeOth) || "pauc".equals(perCdeOth))) {// L:3694 IF PER-CDE-OTH = "NJUC" OR "NJUD" OR "PA...
                otherTax_300_126();                         // L:3695 PERFORM 300-126-OTHER-TAX
            }                                               // L:3696 END-IF
            // GO TO 300-000-NET-WAGES - control flow       // L:3697 GO TO 300-000-NET-WAGES
        }  // period ends IF scope
        federalTax_300_110();                               // L:3699 PERFORM 300-110-FEDERAL-TAX
        if ((("1".equals(perTaxFlgFed) || "2".equals(perTaxFlgFed) || "3".equals(perTaxFlgFed)))) {// L:3700 IF (PER-TAX-FLG-FED = "1" OR "2" OR "3")
            advancedEic_300_112();                          // L:3701 PERFORM 300-112-ADVANCED-EIC THRU 300-112-EXIT
        }  // period ends IF scope
        if (perCdeStt != "") {                              // L:3702 IF PER-CDE-STT NOT = SPACES
            stateTax_300_114();                             // L:3703 PERFORM 300-114-STATE-TAX
        }  // period ends IF scope
        if (perCdeLoc != "") {                              // L:3704 IF PER-CDE-LOC NOT = SPACES
            localTax_300_120();                             // L:3705 PERFORM 300-120-LOCAL-TAX
        }  // period ends IF scope
        if (perCdeCit != "") {                              // L:3706 IF PER-CDE-CIT NOT = SPACES
            cityTax_300_124();                              // L:3707 PERFORM 300-124-CITY-TAX
        }  // period ends IF scope
        if (perCdeOth != "") {                              // L:3708 IF PER-CDE-OTH NOT = SPACES
            otherTax_300_126();                             // L:3709 PERFORM 300-126-OTHER-TAX
        }  // period ends IF scope
    }

    private void netWages_300_000() {                       // L:3715 300-000-NET-WAGES
        ernCppGrsLessTxSum = ernCppNetSum;                  // L:3717 MOVE ERN-CPP-NET-SUM TO ERN-CPP-GRS-LESS-TX-SUM
        regularWages_300_245();                             // L:3718 PERFORM 300-245-REGULAR-WAGES
        wsStateMinWageHoursDiff = BigDecimal.ZERO;          // L:3721 MOVE ZEROS TO WS-STATE-MIN-WAGE-HOURS-DIFF
        wsGrossHoursMultByHrRate = BigDecimal.ZERO;         // L:3721 MOVE ZEROS TO WS-GROSS-HOURS-MULT-BY-HR-RATE
        wsGrossHoursMultByStMin = BigDecimal.ZERO;          // L:3721 MOVE ZEROS TO WS-GROSS-HOURS-MULT-BY-ST-MIN
        wsSalEmpNoHrsSw = "N";                              // L:3724 MOVE "N" TO WS-SAL-EMP-NO-HRS-SW
        if ("s".equals(perSchdl) && perRteHourly.compareTo(BigDecimal.ZERO) == 0) {// L:3727 IF PER-SCHDL = "S" AND PER-RTE-HOURLY = ...
            if (perSchdlHrs.compareTo(BigDecimal.ZERO) != 0) {// L:3728 IF PER-SCHDL-HRS NOT = ZEROS            ...
                // COMPUTE incomplete (multi-line): COMPUTE PER-RTE-HOURLY = PER-RTE-SALARY /// L:3729 COMPUTE PER-RTE-HOURLY = PER-RTE-SALARY ...
                perRteHourly = perRteHourly.multiply(hrsCppGrossSum);// L:3735 MULTIPLY HRS-CPP-GROSS-SUM BY PER-RTE-HO...
                // BUG01493                                 // L:3739 CODE
                // MULTIPLY parse failed: MULTIPLY HRS-CPP-GROSS-SUM BY// L:3744 MULTIPLY HRS-CPP-GROSS-SUM BY           ...
                // BUG01493                                 // L:3749 CODE
                // COMPUTE parse failed: COMPUTE WS-STATE-MIN-WAGE-HOURS-DIFF =// L:3751 COMPUTE WS-STATE-MIN-WAGE-HOURS-DIFF =  ...
            } else {                                        // L:3756 ELSE
                wsSalEmpNoHrsSw = "Y";                      // L:3757 MOVE "Y" TO WS-SAL-EMP-NO-HRS-SW
            }                                               // L:3758 END-IF
        } else {                                            // L:3759 ELSE
            perRteHourly = perRteHourly.multiply(hrsCppGrossSum);// L:3764 MULTIPLY HRS-CPP-GROSS-SUM BY PER-RTE-HO...
            // REQ01461                                     // L:3768 CODE
            wsStateMinWageRteHourly = wsStateMinWageRteHourly.multiply(hrsCppGrossSum);// L:3773 MULTIPLY HRS-CPP-GROSS-SUM BY WS-STATE-M...
            // REQ01461                                     // L:3777 CODE
            // COMPUTE parse failed: COMPUTE WS-STATE-MIN-WAGE-HOURS-DIFF =// L:3779 COMPUTE WS-STATE-MIN-WAGE-HOURS-DIFF =  ...
        }                                                   // L:3784 END-IF
        voluntaryDeductions_300_300();                      // L:3788 PERFORM 300-300-VOLUNTARY-DEDUCTIONS THRU 300-300-EXIT
        if ((("r".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold))) && ernCppNetSum.compareTo(BigDecimal.ZERO) < 0 && taxCppFedSum.compareTo(BigDecimal.ZERO) > 0) {// L:3801 IF (TIM-CHECK-TYPE-HOLD = "R" OR "3")
            taxCppFedSum = taxCppFedSum.add(ernCppNetSum);  // L:3806 ADD ERN-CPP-NET-SUM TO TAX-CPP-FED-SUM
            ernCppNetSum = BigDecimal.ZERO;                 // L:3807 MOVE 0 TO ERN-CPP-NET-SUM
            // STRING parse failed (no INTO): STRING "FEDL TAX GREATER THAN NET;  NET USED INSTE...// L:3808 STRING "FEDL TAX GREATER THAN NET;  NET ...
            wsGtnErr = "TX";                                // L:3810 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3811 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            if (taxCppFedSum.compareTo(BigDecimal.ZERO) < 0) {// L:3812 IF TAX-CPP-FED-SUM < 0
                ernCppNetSum = taxCppFedSum;                // L:3813 MOVE TAX-CPP-FED-SUM TO ERN-CPP-NET-SUM
                taxCppFedSum = BigDecimal.ZERO;             // L:3814 MOVE 0 TO TAX-CPP-FED-SUM
            }  // period ends IF scope
        }  // period ends IF scope
        if ((("r".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold))) && ernCppNetSum.compareTo(BigDecimal.ZERO) < 0 && taxCppOthSum.compareTo(BigDecimal.ZERO) > 0) {// L:3815 IF (TIM-CHECK-TYPE-HOLD = "R" OR "3")
            taxCppOthSum = taxCppOthSum.add(ernCppNetSum);  // L:3820 ADD ERN-CPP-NET-SUM TO TAX-CPP-OTH-SUM
            ernCppNetSum = BigDecimal.ZERO;                 // L:3821 MOVE 0 TO ERN-CPP-NET-SUM
            // STRING parse failed (no INTO): STRING "OTHER TAX > NET;  NET USED INSTEAD."...// L:3822 STRING "OTHER TAX > NET;  NET USED INSTE...
            wsGtnErr = "TX";                                // L:3824 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3825 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            if (taxCppOthSum.compareTo(BigDecimal.ZERO) < 0) {// L:3826 IF TAX-CPP-OTH-SUM < 0
                ernCppNetSum = taxCppOthSum;                // L:3827 MOVE TAX-CPP-OTH-SUM TO ERN-CPP-NET-SUM
                taxCppOthSum = BigDecimal.ZERO;             // L:3828 MOVE 0 TO TAX-CPP-OTH-SUM
            }  // period ends IF scope
        }  // period ends IF scope
        if ((("r".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold))) && ernCppNetSum.compareTo(BigDecimal.ZERO) < 0 && taxCppCitSum.compareTo(BigDecimal.ZERO) > 0) {// L:3829 IF (TIM-CHECK-TYPE-HOLD = "R" OR "3")
            taxCppCitSum = taxCppCitSum.add(ernCppNetSum);  // L:3834 ADD ERN-CPP-NET-SUM TO TAX-CPP-CIT-SUM
            ernCppNetSum = BigDecimal.ZERO;                 // L:3835 MOVE 0 TO ERN-CPP-NET-SUM
            // STRING parse failed (no INTO): STRING "CITY TAX GREATER THAN NET;  NET USED INSTE...// L:3836 STRING "CITY TAX GREATER THAN NET;  NET ...
            wsGtnErr = "TX";                                // L:3838 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3839 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            if (taxCppCitSum.compareTo(BigDecimal.ZERO) < 0) {// L:3840 IF TAX-CPP-CIT-SUM < 0
                ernCppNetSum = taxCppCitSum;                // L:3841 MOVE TAX-CPP-CIT-SUM TO ERN-CPP-NET-SUM
                taxCppCitSum = BigDecimal.ZERO;             // L:3842 MOVE 0 TO TAX-CPP-CIT-SUM
            }  // period ends IF scope
        }  // period ends IF scope
        if ((("r".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold))) && ernCppNetSum.compareTo(BigDecimal.ZERO) < 0 && taxCppLocSum.compareTo(BigDecimal.ZERO) > 0) {// L:3843 IF (TIM-CHECK-TYPE-HOLD = "R" OR "3")
            taxCppLocSum = taxCppLocSum.add(ernCppNetSum);  // L:3848 ADD ERN-CPP-NET-SUM TO TAX-CPP-LOC-SUM
            ernCppNetSum = BigDecimal.ZERO;                 // L:3849 MOVE 0 TO ERN-CPP-NET-SUM
            // STRING parse failed (no INTO): STRING "LOCAL TAX GREATER THAN NET; NET USED INSTE...// L:3850 STRING "LOCAL TAX GREATER THAN NET; NET ...
            wsGtnErr = "TX";                                // L:3852 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3853 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            if (taxCppLocSum.compareTo(BigDecimal.ZERO) < 0) {// L:3854 IF TAX-CPP-LOC-SUM < 0
                ernCppNetSum = taxCppLocSum;                // L:3855 MOVE TAX-CPP-LOC-SUM TO ERN-CPP-NET-SUM
                taxCppLocSum = BigDecimal.ZERO;             // L:3856 MOVE 0 TO TAX-CPP-LOC-SUM
            }  // period ends IF scope
        }  // period ends IF scope
        if ((("r".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold))) && ernCppNetSum.compareTo(BigDecimal.ZERO) < 0 && taxCppSttSum.compareTo(BigDecimal.ZERO) > 0) {// L:3857 IF (TIM-CHECK-TYPE-HOLD = "R" OR "3")
            taxCppSttSum = taxCppSttSum.add(ernCppNetSum);  // L:3862 ADD ERN-CPP-NET-SUM TO TAX-CPP-STT-SUM
            ernCppNetSum = BigDecimal.ZERO;                 // L:3863 MOVE 0 TO ERN-CPP-NET-SUM
            // STRING parse failed (no INTO): STRING "STATE TAX GREATER THAN NET; NET USED INSTE...// L:3864 STRING "STATE TAX GREATER THAN NET; NET ...
            wsGtnErr = "TX";                                // L:3866 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3867 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            if (taxCppSttSum.compareTo(BigDecimal.ZERO) < 0) {// L:3868 IF TAX-CPP-STT-SUM < 0
                ernCppNetSum = taxCppSttSum;                // L:3869 MOVE TAX-CPP-STT-SUM TO ERN-CPP-NET-SUM
                taxCppSttSum = BigDecimal.ZERO;             // L:3870 MOVE 0 TO TAX-CPP-STT-SUM
            }  // period ends IF scope
        }  // period ends IF scope
        if ((("r".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold))) && ernCppNetSum.compareTo(BigDecimal.ZERO) < 0 && taxCppFicaSum.compareTo(BigDecimal.ZERO) > 0) {// L:3871 IF (TIM-CHECK-TYPE-HOLD = "R" OR "3")
            taxCppFicaSum = taxCppFicaSum.add(ernCppNetSum);// L:3876 ADD ERN-CPP-NET-SUM TO TAX-CPP-FICA-SUM
            ernCppNetSum = BigDecimal.ZERO;                 // L:3877 MOVE 0 TO ERN-CPP-NET-SUM
            // STRING parse failed (no INTO): STRING "FICA TAX GREATER THAN NET; NET USED INSTEA...// L:3878 STRING "FICA TAX GREATER THAN NET; NET U...
            wsGtnErr = "TX";                                // L:3880 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3881 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            if (taxCppFicaSum.compareTo(BigDecimal.ZERO) < 0) {// L:3882 IF TAX-CPP-FICA-SUM < 0
                ernCppNetSum = taxCppFicaSum;               // L:3883 MOVE TAX-CPP-FICA-SUM TO ERN-CPP-NET-SUM
                taxCppFicaSum = BigDecimal.ZERO;            // L:3884 MOVE 0 TO TAX-CPP-FICA-SUM
            }  // period ends IF scope
        }  // period ends IF scope
        leaveAccrual_300_400();                             // L:3886 PERFORM 300-400-LEAVE-ACCRUAL THRU 300-400-EXIT
        directDeposit_300_600();                            // L:3887 PERFORM 300-600-DIRECT-DEPOSIT THRU 300-600-EXIT
        // 300-000-EXIT. EXIT.                              // L:3889 CODE
        // /                                                // L:3890 COMMENT
    }

    private void fwwPreprocess_300_050() {                  // L:3892 300-050-FWW-PREPROCESS
        totHoursWs = BigDecimal.ZERO;                       // L:3895 MOVE ZERO TO TOT-HOURS-WS
        addHours_300_057();                                 // L:3896 PERFORM 300-057-ADD-HOURS
        baseRteSalaryWs = perRteSalary;                     // L:3899 MOVE PER-RTE-SALARY TO BASE-RTE-SALARY-WS
        if (totHoursWs.compareTo(BigDecimal.ZERO) == 0) {   // L:3902 IF TOT-HOURS-WS = ZERO
            baseRteSalaryWs = BigDecimal.ZERO;              // L:3903 MOVE ZERO TO BASE-RTE-SALARY-WS
            wsGtnErr = "FW";                                // L:3904 MOVE "FW" TO WS-GTN-ERR
            messageO = "NO FWW HOURS ENTERED.  USING TIME ENTRY AMTS ONLY.";// L:3905 MOVE "NO FWW HOURS ENTERED.  USING TIME ENTRY AMTS ONLY." TO MESSAGE-O
            gtnError_800_700();                             // L:3907 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        // DIVIDE parse failed: DIVIDE BASE-RTE-SALARY-WS BY TOT-HOURS-WS                    IBM-CT// L:3908 DIVIDE BASE-RTE-SALARY-WS BY TOT-HOURS-W...
        baseRteHourlyWs = wsMinWageRteHourly;               // L:3911 MOVE WS-MIN-WAGE-RTE-HOURLY TO BASE-RTE-HOURLY-WS
        if (baseRteHourlyWs.compareTo(wsMinWageRteHourly) < 0) {// L:3913 IF BASE-RTE-HOURLY-WS < WS-MIN-WAGE-RTE-...
            baseRteHourlyWs = wsMinWageRteHourly;           // L:3914 MOVE WS-MIN-WAGE-RTE-HOURLY TO BASE-RTE-HOURLY-WS
            totHoursWs = totHoursWs.multiply(wsMinWageRteHourly);// L:3915 MULTIPLY WS-MIN-WAGE-RTE-HOURLY BY TOT-H...
            messageO = "FWW - HRLY RATE TOO LOW; MIN. WAGE RTE USED.";// L:3917 MOVE "FWW - HRLY RATE TOO LOW; MIN. WAGE RTE USED." TO MESSAGE-O
            wsGtnErr = "FW";                                // L:3919 MOVE "FW" TO WS-GTN-ERR
            gtnError_800_700();                             // L:3920 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        // DIVIDE parse failed: DIVIDE BASE-RTE-HOURLY-WS BY 2                               IBM-CT// L:3922 DIVIDE BASE-RTE-HOURLY-WS BY 2          ...
        totalWs = totHoursWs.subtract(fwwHrsWs);            // L:3925 SUBTRACT FWW-HRS-WS FROM TOT-HOURS-WS GI...
        totalWs = totalWs.multiply(baseRteOvrtmeWs);        // L:3926 MULTIPLY BASE-RTE-OVRTME-WS BY TOTAL-WS
        if (totOvtWagesWs.compareTo(BigDecimal.ZERO) < 0) { // L:3928 IF TOT-OVT-WAGES-WS < ZERO
            totOvtWagesWs = BigDecimal.ZERO;                // L:3929 MOVE ZERO TO TOT-OVT-WAGES-WS
        }  // period ends IF scope
        totalWs = baseRteSalaryWs.add(totOvtWagesWs);       // L:3930 ADD BASE-RTE-SALARY-WS TOT-OVT-WAGES-WS ...
        if (totalWs.compareTo(baseRteSalaryWs) > 0) {       // L:3933 IF TOTAL-WS > BASE-RTE-SALARY-WS
            baseRteSalaryWs = totalWs;                      // L:3934 MOVE TOTAL-WS TO BASE-RTE-SALARY-WS
        }  // period ends IF scope
        baseRteDistBalWs = baseRteSalaryWs;                 // L:3938 MOVE BASE-RTE-SALARY-WS TO BASE-RTE-DIST-BAL-WS
        j = BigDecimal.ZERO;                                // L:3939 MOVE ZERO TO J
        distributeTrn_300_054();                            // L:3940 PERFORM 300-054-DISTRIBUTE-TRN THRU 300-054-EXIT
        if (j.compareTo(BigDecimal.ZERO) != 0) {            // L:3944 IF J NOT = ZERO
            amountTrn[j.intValue()] = amountTrn[j.intValue()].add(baseRteDistBalWs);// L:3945 ADD BASE-RTE-DIST-BAL-WS TO AMOUNT-TRN(J...
        } else {                                            // L:3946 ELSE
            amountTrn[1] = amountTrn[1].add(baseRteDistBalWs);// L:3947 ADD BASE-RTE-DIST-BAL-WS TO AMOUNT-TRN(1...
        }  // period ends IF scope
        amountDist[1] = amountDist[1].add(baseRteDistBalWs);// L:3949 ADD BASE-RTE-DIST-BAL-WS TO AMOUNT-DIST(...
        if (m.compareTo(BigDecimal.ZERO) != 0) {            // L:3951 IF M NOT = ZERO
            ernCppSum[m.intValue()] = ernCppSum[m.intValue()].add(baseRteDistBalWs);// L:3952 ADD BASE-RTE-DIST-BAL-WS TO ERN-CPP-SUM(...
        } else {                                            // L:3953 ELSE
            ernCppSum[1] = ernCppSum[1].add(baseRteDistBalWs);// L:3954 ADD BASE-RTE-DIST-BAL-WS TO ERN-CPP-SUM(...
        }  // period ends IF scope
        // 300-050-EXIT. EXIT.                              // L:3956 CODE
    }

    private void distributeTrn_300_054() {                  // L:3959 300-054-DISTRIBUTE-TRN
        if (hoursTrn[i.intValue()].compareTo(BigDecimal.ZERO) == 0 || amountTrn[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:3961 IF HOURS-TRN(I) = ZERO
            pctWs = BigDecimal.ZERO;                        // L:3964 MOVE ZERO TO PCT-WS
        } else {                                            // L:3965 ELSE
            // DIVIDE parse failed: DIVIDE HOURS-TRN(I) BY TOT-HOURS-WS                       IBM-CT// L:3966 DIVIDE HOURS-TRN(I) BY TOT-HOURS-WS     ...
            pctWs = BigDecimal.ZERO;                        // L:3969 MOVE ZERO TO PCT-WS
        }  // period ends IF scope
        pctWs = pctWs.multiply(baseRteSalaryWs);            // L:3971 MULTIPLY BASE-RTE-SALARY-WS BY PCT-WS
        amountTrn[i.intValue()] = amountTrn[i.intValue()].add(totalWs);// L:3973 ADD TOTAL-WS TO AMOUNT-TRN(I).
        if (totalWs.compareTo(BigDecimal.ZERO) != 0) {      // L:3974 IF TOTAL-WS NOT = ZERO
            j = i;                                          // L:3976 MOVE I TO J
            distributeWrk_300_055();                        // L:3978 PERFORM 300-055-DISTRIBUTE-WRK
            if (totalWs.compareTo(BigDecimal.ZERO) != 0) {  // L:3982 IF TOTAL-WS NOT = ZERO
                m = BigDecimal.ZERO;                        // L:3983 MOVE ZERO TO M
                findIndex_300_058();                        // L:3984 PERFORM 300-058-FIND-INDEX
                if (totalWs.compareTo(BigDecimal.ZERO) != 0 && k.compareTo(BigDecimal.valueOf(35)) <= 0) {// L:3987 IF TOTAL-WS NOT = ZERO
                    l = k;                                  // L:3990 MOVE K TO L
                    ernCppSum[l.intValue()] = ernCppSum[l.intValue()].add(totalWs);// L:3991 ADD TOTAL-WS TO ERN-CPP-SUM(L)
                    m = l;                                  // L:3992 MOVE L TO M
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        baseRteDistBalWs = baseRteDistBalWs.subtract(totalWs);// L:3993 SUBTRACT TOTAL-WS FROM BASE-RTE-DIST-BAL...
        // 300-054-EXIT. EXIT.                              // L:3995 CODE
    }

    private void distributeWrk_300_055() {                  // L:3998 300-055-DISTRIBUTE-WRK
        if (storeWrkDist[k.intValue()].compareTo(storeWrkTrn[i.intValue()]) == 0) {// L:3999 IF STORE-WRK-DIST(K) = STORE-WRK-TRN(I)
            amountDist[k.intValue()] = amountDist[k.intValue()].add(totalWs);// L:4000 ADD TOTAL-WS TO AMOUNT-DIST(K).
        }  // period ends IF scope
        // 300-055-EXIT. EXIT.                              // L:4002 CODE
    }

    private void addHours_300_057() {                       // L:4005 300-057-ADD-HOURS
        if (amountTrn[j.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:4006 IF AMOUNT-TRN(J) = ZERO
            totHoursWs = totHoursWs.add(hoursTrn[j.intValue()]);// L:4007 ADD HOURS-TRN(J) TO TOT-HOURS-WS.
        }  // period ends IF scope
        // 300-057-EXIT. EXIT.                              // L:4009 CODE
    }

    private void findIndex_300_058() {                      // L:4012 300-058-FIND-INDEX
        // /                                                // L:4015 COMMENT
    }

    private void fwwDeptOfLabor_300_060() {                 // L:4021 300-060-FWW-DEPT-OF-LABOR
        totRegHoursWs = BigDecimal.ZERO;                    // L:4027 MOVE 0 TO TOT-REG-HOURS-WS
        totOvtHoursWs = BigDecimal.ZERO;                    // L:4027 MOVE 0 TO TOT-OVT-HOURS-WS
        totHoursWs = BigDecimal.ZERO;                       // L:4027 MOVE 0 TO TOT-HOURS-WS
        totDollarsWs = BigDecimal.ZERO;                     // L:4027 MOVE 0 TO TOT-DOLLARS-WS
        totalWs = BigDecimal.ZERO;                          // L:4027 MOVE 0 TO TOTAL-WS
        addHours_300_067();                                 // L:4029 PERFORM 300-067-ADD-HOURS THRU 300-067-EXIT
        if (totDollarsWs.compareTo(BigDecimal.ZERO) == 0 && totHoursWs.compareTo(BigDecimal.ZERO) == 0) {// L:4037 IF TOT-DOLLARS-WS = 0
            // GO TO 300-060-EXIT - control flow            // L:4040 GO TO 300-060-EXIT
        }  // period ends IF scope
        if (totOvtHoursWs.compareTo(BigDecimal.ZERO) == 0 && totRegHoursWs.compareTo(BigDecimal.ZERO) == 0) {// L:4047 IF TOT-OVT-HOURS-WS = 0
            messageO = "NO FWW HOURS ENTERED.  USING TIME ENTRY AMTS ONLY.";// L:4050 MOVE "NO FWW HOURS ENTERED.  USING TIME ENTRY AMTS ONLY." TO MESSAGE-O
            wsGtnErr = "FW";                                // L:4052 MOVE "FW" TO WS-GTN-ERR
            gtnError_800_700();                             // L:4053 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 300-060-EXIT - control flow            // L:4054 GO TO 300-060-EXIT
        }  // period ends IF scope
        totOvtWagesWs = BigDecimal.ZERO;                    // L:4060 MOVE 0 TO TOT-OVT-WAGES-WS
        if (totRegHoursWs.compareTo(BigDecimal.valueOf(40)) > 0) {// L:4061 IF TOT-REG-HOURS-WS > 40
            // COMPUTE incomplete (multi-line): COMPUTE TOT-OVT-WAGES-WS ROUNDED = (PER-RTE-SALARY /// L:4062 COMPUTE TOT-OVT-WAGES-WS ROUNDED = (PER-...
        }  // period ends IF scope
        // ADD parse failed: ADD PER-RTE-SALARY, TOT-OVT-WAGES-WS, TOT-DOLLARS-WS// L:4071 ADD PER-RTE-SALARY, TOT-OVT-WAGES-WS, TO...
        wsMinWageRteHourly = wsMinWageRteHourly.multiply(totHoursWs);// L:4078 MULTIPLY TOT-HOURS-WS BY WS-MIN-WAGE-RTE...
        if (baseRteSalaryWs.compareTo(totalWs) < 0) {       // L:4080 IF BASE-RTE-SALARY-WS < TOTAL-WS
            totalWs = totalWs.subtract(baseRteSalaryWs);    // L:4081 SUBTRACT BASE-RTE-SALARY-WS FROM TOTAL-W...
            totOvtWagesWs = totOvtWagesWs.add(totalWs);     // L:4082 ADD TOTAL-WS TO TOT-OVT-WAGES-WS
            editAmt = totalWs.toString();                   // L:4083 MOVE TOTAL-WS TO EDIT-AMT
            messageO = "";                                  // L:4084 MOVE SPACES TO MESSAGE-O
            // STRING parse failed (no INTO): STRING "FWW - HRLY RATE TOO LOW;  APPLIED MIN. WAG...// L:4085 STRING "FWW - HRLY RATE TOO LOW;  APPLIE...
            wsGtnErr = "FW";                                // L:4088 MOVE "FW" TO WS-GTN-ERR
            gtnError_800_700();                             // L:4089 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        totRegWagesWs = perRteSalary;                       // L:4097 MOVE PER-RTE-SALARY TO TOT-REG-WAGES-WS
        if (totOvtHoursWs.compareTo(BigDecimal.ZERO) == 0) {// L:4098 IF TOT-OVT-HOURS-WS = 0
            totRegWagesWs = totRegWagesWs.add(totOvtWagesWs);// L:4099 ADD TOT-OVT-WAGES-WS TO TOT-REG-WAGES-WS
            totOvtWagesWs = BigDecimal.ZERO;                // L:4100 MOVE 0 TO TOT-OVT-WAGES-WS
        }  // period ends IF scope
        if (totRegHoursWs.compareTo(BigDecimal.ZERO) == 0) {// L:4108 IF TOT-REG-HOURS-WS = 0
            totOvtWagesWs = totOvtWagesWs.add(totRegWagesWs);// L:4109 ADD TOT-REG-WAGES-WS TO TOT-OVT-WAGES-WS
            totRegWagesWs = BigDecimal.ZERO;                // L:4110 MOVE 0 TO TOT-REG-WAGES-WS
        }  // period ends IF scope
        if (totRegHoursWs.compareTo(BigDecimal.ZERO) != 0) {// L:4117 IF TOT-REG-HOURS-WS NOT = 0
            totRegHoursWs = totRegHoursWs.subtract(totOvtHoursWs);// L:4118 SUBTRACT TOT-OVT-HOURS-WS FROM TOT-REG-H...
            distributeReg_300_062();                        // L:4119 PERFORM 300-062-DISTRIBUTE-REG THRU 300-062-EXIT
        }  // period ends IF scope
        if (totRegHoursWs.compareTo(BigDecimal.ZERO) != 0 && totRegWagesWs.compareTo(BigDecimal.ZERO) != 0) {// L:4127 IF TOT-REG-HOURS-WS NOT = 0
            amountTrn[j.intValue()] = amountTrn[j.intValue()].add(totRegWagesWs);// L:4130 ADD TOT-REG-WAGES-WS TO AMOUNT-TRN(J)
            amountDist[l.intValue()] = amountDist[l.intValue()].add(totRegWagesWs);// L:4131 ADD TOT-REG-WAGES-WS TO AMOUNT-DIST(L)
            ernCppSum[m.intValue()] = ernCppSum[m.intValue()].add(totRegWagesWs);// L:4132 ADD TOT-REG-WAGES-WS TO ERN-CPP-SUM(M).
        }  // period ends IF scope
        if (totOvtHoursWs.compareTo(BigDecimal.ZERO) != 0) {// L:4139 IF TOT-OVT-HOURS-WS NOT = 0
            distributeOvt_300_064();                        // L:4140 PERFORM 300-064-DISTRIBUTE-OVT THRU 300-064-EXIT
        }  // period ends IF scope
        if (totOvtHoursWs.compareTo(BigDecimal.ZERO) != 0 && totOvtWagesWs.compareTo(BigDecimal.ZERO) != 0) {// L:4148 IF TOT-OVT-HOURS-WS NOT = 0
            amountTrn[j.intValue()] = amountTrn[j.intValue()].add(totOvtWagesWs);// L:4151 ADD TOT-OVT-WAGES-WS TO AMOUNT-TRN(J)
            amountDist[l.intValue()] = amountDist[l.intValue()].add(totOvtWagesWs);// L:4152 ADD TOT-OVT-WAGES-WS TO AMOUNT-DIST(L)
            ernCppSum[m.intValue()] = ernCppSum[m.intValue()].add(totOvtWagesWs);// L:4153 ADD TOT-OVT-WAGES-WS TO ERN-CPP-SUM(M).
        }  // period ends IF scope
        // 300-060-EXIT. EXIT.                              // L:4155 CODE
    }

    private void distributeReg_300_062() {                  // L:4157 300-062-DISTRIBUTE-REG
        if (("ovt1".equals(codeTrn[i.intValue()])) || hoursTrn[i.intValue()].compareTo(BigDecimal.ZERO) == 0 || amountTrn[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:4158 IF (CODE-TRN(I) = "OVT1")
            // GO TO 300-062-EXIT - control flow            // L:4163 GO TO 300-062-EXIT
        }  // period ends IF scope
        ibmCt = hoursTrn[i.intValue()].divide(totRegHoursWs, 10, RoundingMode.HALF_UP);// L:4164 DIVIDE TOT-REG-HOURS-WS INTO HOURS-TRN(I...
        pctWs = pctWs.multiply(totRegWagesWs);              // L:4166 MULTIPLY TOT-REG-WAGES-WS BY PCT-WS GIVI...
        totRegWagesWs = totRegWagesWs.subtract(amountTrn[i.intValue()]);// L:4168 SUBTRACT AMOUNT-TRN(I) FROM TOT-REG-WAGE...
        j = i;                                              // L:4169 MOVE I TO J
        distributeWrk_300_066();                            // L:4170 PERFORM 300-066-DISTRIBUTE-WRK
        ernCppSum[i.intValue()] = ernCppSum[i.intValue()].add(amountTrn[i.intValue()]);// L:4173 ADD AMOUNT-TRN(I) TO ERN-CPP-SUM(I).
        if (m.compareTo(BigDecimal.ZERO) == 0) {            // L:4174 IF M = 0
            m = i;                                          // L:4175 MOVE I TO M
        }  // period ends IF scope
        // 300-062-EXIT. EXIT.                              // L:4176 CODE
    }

    private void distributeOvt_300_064() {                  // L:4178 300-064-DISTRIBUTE-OVT
        if ((!"ovt1".equals(codeTrn[i.intValue()])) || hoursTrn[i.intValue()].compareTo(BigDecimal.ZERO) == 0 || amountTrn[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:4179 IF (CODE-TRN(I) NOT = "OVT1")
            // GO TO 300-064-EXIT - control flow            // L:4184 GO TO 300-064-EXIT
        }  // period ends IF scope
        ibmCt = hoursTrn[i.intValue()].divide(totOvtHoursWs, 10, RoundingMode.HALF_UP);// L:4185 DIVIDE TOT-OVT-HOURS-WS INTO HOURS-TRN(I...
        pctWs = pctWs.multiply(totOvtWagesWs);              // L:4187 MULTIPLY TOT-OVT-WAGES-WS BY PCT-WS GIVI...
        totOvtWagesWs = totOvtWagesWs.subtract(amountTrn[i.intValue()]);// L:4189 SUBTRACT AMOUNT-TRN(I) FROM TOT-OVT-WAGE...
        j = i;                                              // L:4190 MOVE I TO J
        distributeWrk_300_066();                            // L:4191 PERFORM 300-066-DISTRIBUTE-WRK
        ernCppSum[i.intValue()] = ernCppSum[i.intValue()].add(amountTrn[i.intValue()]);// L:4194 ADD AMOUNT-TRN(I) TO ERN-CPP-SUM(I).
        // 300-064-EXIT. EXIT.                              // L:4195 CODE
    }

    private void distributeWrk_300_066() {                  // L:4197 300-066-DISTRIBUTE-WRK
        if (corpWrkDist[k.intValue()].compareTo(corpWrkTrn[i.intValue()]) == 0 && storeWrkDist[k.intValue()].compareTo(storeWrkTrn[i.intValue()]) == 0 && deptWrkDist[k.intValue()].compareTo(deptWrkTrn[i.intValue()]) == 0) {// L:4198 IF CORP-WRK-DIST(K) = CORP-WRK-TRN(I) AN...
            amountDist[k.intValue()] = amountDist[k.intValue()].add(amountTrn[i.intValue()]);// L:4201 ADD AMOUNT-TRN(I) TO AMOUNT-DIST(K)
            l = k;                                          // L:4202 MOVE K TO L
        }  // period ends IF scope
        // 300-066-EXIT. EXIT.                              // L:4203 CODE
    }

    private void addHours_300_067() {                       // L:4205 300-067-ADD-HOURS
        if (("ovt1".equals(codeTrn[i.intValue()])) && amountTrn[i.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:4206 IF (CODE-TRN(I) = "OVT1")
            totOvtHoursWs = totOvtHoursWs.add(hoursTrn[i.intValue()]);// L:4209 ADD HOURS-TRN(I) TO TOT-OVT-HOURS-WS.
        }  // period ends IF scope
        if ((!"reg1".equals(codeTrn[i.intValue()]) || !"ovt1".equals(codeTrn[i.intValue()]) || !"vac".equals(codeTrn[i.intValue()])) && amountTrn[i.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:4210 IF (CODE-TRN(I) NOT = "REG1" OR "OVT1" O...
            totRegHoursWs = totRegHoursWs.add(hoursTrn[i.intValue()]);// L:4213 ADD HOURS-TRN(I) TO TOT-REG-HOURS-WS.
        }  // period ends IF scope
        totHoursWs = totHoursWs.add(hoursTrn[i.intValue()]);// L:4214 ADD HOURS-TRN(I) TO TOT-HOURS-WS.
        totDollarsWs = totDollarsWs.add(amountTrn[i.intValue()]);// L:4215 ADD AMOUNT-TRN(I) TO TOT-DOLLARS-WS.
        // 300-067-EXIT. EXIT.                              // L:4217 CODE
        // /                                                // L:4219 COMMENT
    }

    private void ficaTaxRoutine_300_100() {                 // L:4220 300-100-FICA-TAX-ROUTINE
        if (taxCppFicaSum.compareTo(BigDecimal.ZERO) != 0) {// L:4221 IF TAX-CPP-FICA-SUM NOT = 0
            holdCppFica = taxCppFicaSum;                    // L:4222 MOVE TAX-CPP-FICA-SUM TO HOLD-CPP-FICA
        } else {                                            // L:4223 ELSE
            // Initialize HOLD-CPP-FICA-X                   // L:4224 INITIALIZE HOLD-CPP-FICA-X.
            holdCppFica = BigDecimal.ZERO;
        }  // period ends IF scope
        taxCppFicaSum = BigDecimal.ZERO;                    // L:4225 MOVE ZERO TO TAX-CPP-FICA-SUM
        taxFlgWs = perTaxFlgFica;                           // L:4226 MOVE PER-TAX-FLG-FICA TO TAX-FLG-WS
        if ("y".equals(ws3TaxLevelsExist)) {                // L:4233 IF WS-3-TAX-LEVELS-EXIST = "Y"          ...
            if (ernTaxYtdFica.compareTo(wsFicaUprTaxLimitYtd1) > 0) {// L:4234 IF ERN-TAX-YTD-FICA > WS-FICA-UPR-TAX-LI...
                // SUBTRACT parse failed: SUBTRACT ERN-TAX-YTD-FICA FROM// L:4235 SUBTRACT ERN-TAX-YTD-FICA FROM          ...
            } else {                                        // L:4238 ELSE
                if (ernTaxYtdFica.compareTo(wsFicaUprTaxLimitYtd2) > 0) {// L:4239 IF ERN-TAX-YTD-FICA > WS-FICA-UPR-TAX-LI...
                    // SUBTRACT parse failed: SUBTRACT ERN-TAX-YTD-FICA FROM// L:4240 SUBTRACT ERN-TAX-YTD-FICA FROM          ...
                }                                           // L:4243 END-IF
            }                                               // L:4244 END-IF
            if (taxExempt) {                                // L:4252 IF NOT TAX-EXEMPT                       ...
                annualWageWs = totEarnWs.add(totEarnYtdWs); // L:4253 ADD TOT-EARN-WS TOT-EARN-YTD-WS GIVING A...
                annualWageWs = annualWageWs.subtract(nontaxblFica);// L:4254 SUBTRACT NONTAXBL-FICA FROM ANNUAL-WAGE-...
                annualWageWs = annualWageWs.subtract(nontaxblFicaYtd);// L:4255 SUBTRACT NONTAXBL-FICA-YTD FROM ANNUAL-W...
                if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd1) >= 0) {// L:4256 IF ANNUAL-WAGE-WS >= WS-FICA-LWR-WAGE-LI...
                    ficaCalculation_300_104_1();            // L:4257 PERFORM 300-104-FICA-CALCULATION-1
                } else {                                    // L:4258 ELSE
                    if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd2) >= 0) {// L:4259 IF ANNUAL-WAGE-WS >= WS-FICA-LWR-WAGE-LI...
                        ficaCalculation_300_104_2();        // L:4260 PERFORM 300-104-FICA-CALCULATION-2
                    } else {                                // L:4261 ELSE
                        ficaCalculation_300_104_3();        // L:4262 PERFORM 300-104-FICA-CALCULATION-3
                    }                                       // L:4263 END-IF
                }                                           // L:4264 END-IF
            }                                               // L:4265 END-IF
        } else {                                            // L:4266 ELSE
            if (ernTaxYtdFica.compareTo(wsFicaUprTaxLimitYtd) > 0) {// L:4272 IF ERN-TAX-YTD-FICA > WS-FICA-UPR-TAX-LI...
                wsFicaUprTaxLimitYtd = wsFicaUprTaxLimitYtd.subtract(ernTaxYtdFica);// L:4273 SUBTRACT ERN-TAX-YTD-FICA FROM WS-FICA-U...
            }                                               // L:4275 END-IF
        }  // period ends IF scope
        if ((!taxExempt && ernTaxYtdFica.compareTo(wsFicaUprTaxLimitYtd) < 0)) {// L:4283 IF (NOT TAX-EXEMPT
            ficaCalculation_300_104();                      // L:4286 PERFORM 300-104-FICA-CALCULATION
        }                                                   // L:4287 END-IF
        if (taxCppFicaSum.compareTo(ernCppNetSum) > 0) {    // L:4296 IF TAX-CPP-FICA-SUM > ERN-CPP-NET-SUM
            ficaError_300_106();                            // L:4297 PERFORM 300-106-FICA-ERROR
            taxCppFicaSum = ernCppNetSum;                   // L:4298 MOVE ERN-CPP-NET-SUM TO TAX-CPP-FICA-SUM
        }  // period ends IF scope
        ernCppNetSum = ernCppNetSum.subtract(taxCppFicaSum);// L:4300 SUBTRACT TAX-CPP-FICA-SUM FROM ERN-CPP-N...
        // 300-100-EXIT. EXIT.                              // L:4302 CODE
    }

    private void ficaCalculation_300_104() {                // L:4305 300-104-FICA-CALCULATION
        annualWageWs = totEarnWs.add(totEarnYtdWs);         // L:4316 ADD TOT-EARN-WS TOT-EARN-YTD-WS GIVING A...
        annualWageWs = annualWageWs.subtract(nontaxblFica); // L:4317 SUBTRACT NONTAXBL-FICA FROM ANNUAL-WAGE-...
        annualWageWs = annualWageWs.subtract(nontaxblFicaYtd);// L:4318 SUBTRACT NONTAXBL-FICA-YTD FROM ANNUAL-W...
        if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd) < 0) {// L:4319 IF ANNUAL-WAGE-WS < WS-FICA-LWR-WAGE-LIM...
            wsFicaLwrPercent = wsFicaLwrPercent.multiply(annualWageWs);// L:4320 MULTIPLY ANNUAL-WAGE-WS BY WS-FICA-LWR-P...
            if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd) >= 0) {// L:4323 IF ANNUAL-WAGE-WS NOT < WS-FICA-LWR-WAGE...
                taxYtdFicaWs = wsFicaLwrTaxLimitYtd;        // L:4324 MOVE WS-FICA-LWR-TAX-LIMIT-YTD TO TAX-YTD-FICA-WS
                annualWageWs = annualWageWs.subtract(wsFicaLwrWageLimitYtd);// L:4325 SUBTRACT WS-FICA-LWR-WAGE-LIMIT-YTD FROM...
                totalWs = (totalWs.multiply(wsFicaUprPercent)).setScale(2, RoundingMode.HALF_UP);// L:4327 MULTIPLY WS-FICA-UPR-PERCENT BY TOTAL-WS...
                taxYtdFicaWs = taxYtdFicaWs.add(totalWs);   // L:4328 ADD TOTAL-WS TO TAX-YTD-FICA-WS.
            }  // period ends IF scope
        }  // period ends IF scope
        if (annualWageWs.compareTo(wsFicaUprWageLimitYtd) >= 0) {// L:4330 IF ANNUAL-WAGE-WS NOT < WS-FICA-UPR-WAGE...
            taxYtdFicaWs = wsFicaUprTaxLimitYtd;            // L:4331 MOVE WS-FICA-UPR-TAX-LIMIT-YTD TO TAX-YTD-FICA-WS
        }  // period ends IF scope
        taxYtdFicaWs = taxYtdFicaWs.subtract(ernTaxYtdFica);// L:4338 SUBTRACT ERN-TAX-YTD-FICA FROM TAX-YTD-F...
        if (holdCppFica.compareTo(BigDecimal.ZERO) != 0) {  // L:4340 IF HOLD-CPP-FICA NOT = ZEROS
            taxCppFicaSum = holdCppFica;                    // L:4341 MOVE HOLD-CPP-FICA TO TAX-CPP-FICA-SUM
        }  // period ends IF scope
        if (taxYtdFicaWs.compareTo(wsFicaUprTaxLimitYtd) > 0) {// L:4347 IF TAX-YTD-FICA-WS > WS-FICA-UPR-TAX-LIM...
            wsFicaUprTaxLimitYtd = wsFicaUprTaxLimitYtd.subtract(ernTaxYtdFica);// L:4348 SUBTRACT ERN-TAX-YTD-FICA FROM WS-FICA-U...
            // 300-104-EXIT. EXIT.                          // L:4351 CODE
        }  // period ends IF scope
    }

    private void ficaCalculation_300_104_1() {              // L:4354 300-104-FICA-CALCULATION-1
        if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd1) < 0) {// L:4368 IF ANNUAL-WAGE-WS < WS-FICA-LWR-WAGE-LIM...
            wsFicaLwrPercent2 = wsFicaLwrPercent2.multiply(annualWageWs);// L:4369 MULTIPLY ANNUAL-WAGE-WS BY WS-FICA-LWR-P...
            if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd1) >= 0) {// L:4372 IF ANNUAL-WAGE-WS NOT < WS-FICA-LWR-WAGE...
                taxYtdFicaWs = wsFicaLwrTaxLimitYtd1;       // L:4373 MOVE WS-FICA-LWR-TAX-LIMIT-YTD-1 TO TAX-YTD-FICA-WS
                annualWageWs = annualWageWs.subtract(wsFicaLwrWageLimitYtd1);// L:4374 SUBTRACT WS-FICA-LWR-WAGE-LIMIT-YTD-1 FR...
                totalWs = (totalWs.multiply(wsFicaUprPercent1)).setScale(2, RoundingMode.HALF_UP);// L:4376 MULTIPLY WS-FICA-UPR-PERCENT-1 BY TOTAL-...
                taxYtdFicaWs = taxYtdFicaWs.add(totalWs);   // L:4377 ADD TOTAL-WS TO TAX-YTD-FICA-WS.        ...
                if (annualWageWs.compareTo(wsFicaUprWageLimitYtd1) >= 0) {// L:4379 IF ANNUAL-WAGE-WS NOT < WS-FICA-UPR-WAGE...
                    taxYtdFicaWs = wsFicaUprTaxLimitYtd1;   // L:4380 MOVE WS-FICA-UPR-TAX-LIMIT-YTD-1 TO TAX-YTD-FICA-WS
                    taxYtdFicaWs = taxYtdFicaWs.subtract(ernTaxYtdFica);// L:4387 SUBTRACT ERN-TAX-YTD-FICA FROM TAX-YTD-F...
                    if (holdCppFica.compareTo(BigDecimal.ZERO) != 0) {// L:4389 IF HOLD-CPP-FICA NOT = ZEROS            ...
                        taxCppFicaSum = holdCppFica;        // L:4390 MOVE HOLD-CPP-FICA TO TAX-CPP-FICA-SUM
                        if (taxYtdFicaWs.compareTo(wsFicaUprTaxLimitYtd1) > 0) {// L:4396 IF TAX-YTD-FICA-WS > WS-FICA-UPR-TAX-LIM...
                            wsFicaUprTaxLimitYtd1 = wsFicaUprTaxLimitYtd1.subtract(ernTaxYtdFica);// L:4397 SUBTRACT ERN-TAX-YTD-FICA FROM WS-FICA-U...
                            // 300-104-1-EXIT. EXIT.                   ...// L:4400 CODE
                        }  // auto-close unclosed IF
                    }  // auto-close unclosed IF
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void ficaCalculation_300_104_2() {              // L:4403 300-104-FICA-CALCULATION-2
        if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd2) < 0) {// L:4417 IF ANNUAL-WAGE-WS < WS-FICA-LWR-WAGE-LIM...
            wsFicaLwrPercent3 = wsFicaLwrPercent3.multiply(annualWageWs);// L:4418 MULTIPLY ANNUAL-WAGE-WS BY WS-FICA-LWR-P...
            if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd2) >= 0) {// L:4421 IF ANNUAL-WAGE-WS NOT < WS-FICA-LWR-WAGE...
                taxYtdFicaWs = wsFicaLwrTaxLimitYtd2;       // L:4422 MOVE WS-FICA-LWR-TAX-LIMIT-YTD-2 TO TAX-YTD-FICA-WS
                annualWageWs = annualWageWs.subtract(wsFicaLwrWageLimitYtd2);// L:4423 SUBTRACT WS-FICA-LWR-WAGE-LIMIT-YTD-2 FR...
                totalWs = (totalWs.multiply(wsFicaUprPercent2)).setScale(2, RoundingMode.HALF_UP);// L:4425 MULTIPLY WS-FICA-UPR-PERCENT-2 BY TOTAL-...
                taxYtdFicaWs = taxYtdFicaWs.add(totalWs);   // L:4426 ADD TOTAL-WS TO TAX-YTD-FICA-WS.        ...
                if (annualWageWs.compareTo(wsFicaUprWageLimitYtd2) >= 0) {// L:4428 IF ANNUAL-WAGE-WS NOT < WS-FICA-UPR-WAGE...
                    taxYtdFicaWs = wsFicaUprTaxLimitYtd2;   // L:4429 MOVE WS-FICA-UPR-TAX-LIMIT-YTD-2 TO TAX-YTD-FICA-WS
                    taxYtdFicaWs = taxYtdFicaWs.subtract(ernTaxYtdFica);// L:4436 SUBTRACT ERN-TAX-YTD-FICA FROM TAX-YTD-F...
                    if (holdCppFica.compareTo(BigDecimal.ZERO) != 0) {// L:4438 IF HOLD-CPP-FICA NOT = ZEROS            ...
                        taxCppFicaSum = holdCppFica;        // L:4439 MOVE HOLD-CPP-FICA TO TAX-CPP-FICA-SUM
                        if (taxYtdFicaWs.compareTo(wsFicaUprTaxLimitYtd2) > 0) {// L:4445 IF TAX-YTD-FICA-WS > WS-FICA-UPR-TAX-LIM...
                            wsFicaUprTaxLimitYtd2 = wsFicaUprTaxLimitYtd2.subtract(ernTaxYtdFica);// L:4446 SUBTRACT ERN-TAX-YTD-FICA FROM WS-FICA-U...
                            // 300-104-2-EXIT. EXIT.                   ...// L:4449 CODE
                        }  // auto-close unclosed IF
                    }  // auto-close unclosed IF
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void ficaCalculation_300_104_3() {              // L:4452 300-104-FICA-CALCULATION-3
        if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd3) < 0) {// L:4466 IF ANNUAL-WAGE-WS < WS-FICA-LWR-WAGE-LIM...
            // MULTIPLY invalid target (literal): MULTIPLY ANNUAL-WAGE-WS BY 0// L:4467 MULTIPLY ANNUAL-WAGE-WS BY 0            ...
            if (annualWageWs.compareTo(wsFicaLwrWageLimitYtd3) >= 0) {// L:4470 IF ANNUAL-WAGE-WS NOT < WS-FICA-LWR-WAGE...
                taxYtdFicaWs = wsFicaLwrTaxLimitYtd3;       // L:4471 MOVE WS-FICA-LWR-TAX-LIMIT-YTD-3 TO TAX-YTD-FICA-WS
                annualWageWs = annualWageWs.subtract(wsFicaLwrWageLimitYtd3);// L:4472 SUBTRACT WS-FICA-LWR-WAGE-LIMIT-YTD-3 FR...
                totalWs = (totalWs.multiply(wsFicaUprPercent3)).setScale(2, RoundingMode.HALF_UP);// L:4474 MULTIPLY WS-FICA-UPR-PERCENT-3 BY TOTAL-...
                taxYtdFicaWs = taxYtdFicaWs.add(totalWs);   // L:4475 ADD TOTAL-WS TO TAX-YTD-FICA-WS.        ...
                if (annualWageWs.compareTo(wsFicaUprWageLimitYtd3) >= 0) {// L:4477 IF ANNUAL-WAGE-WS NOT < WS-FICA-UPR-WAGE...
                    taxYtdFicaWs = wsFicaUprTaxLimitYtd3;   // L:4478 MOVE WS-FICA-UPR-TAX-LIMIT-YTD-3 TO TAX-YTD-FICA-WS
                    taxYtdFicaWs = taxYtdFicaWs.subtract(ernTaxYtdFica);// L:4485 SUBTRACT ERN-TAX-YTD-FICA FROM TAX-YTD-F...
                    if (holdCppFica.compareTo(BigDecimal.ZERO) != 0) {// L:4487 IF HOLD-CPP-FICA NOT = ZEROS            ...
                        taxCppFicaSum = holdCppFica;        // L:4488 MOVE HOLD-CPP-FICA TO TAX-CPP-FICA-SUM
                        if (taxYtdFicaWs.compareTo(wsFicaUprTaxLimitYtd3) > 0) {// L:4494 IF TAX-YTD-FICA-WS > WS-FICA-UPR-TAX-LIM...
                            wsFicaUprTaxLimitYtd3 = wsFicaUprTaxLimitYtd3.subtract(ernTaxYtdFica);// L:4495 SUBTRACT ERN-TAX-YTD-FICA FROM WS-FICA-U...
                            // 300-104-3-EXIT. EXIT.                   ...// L:4498 CODE
                        }  // auto-close unclosed IF
                    }  // auto-close unclosed IF
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void ficaError_300_106() {                      // L:4501 300-106-FICA-ERROR
        messageO = "FICA TAX > NET ** NET USED**";          // L:4502 MOVE "FICA TAX > NET ** NET USED**" TO MESSAGE-O
        wsGtnErr = "TX";                                    // L:4503 MOVE "TX" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:4504 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // /                                                // L:4505 COMMENT
    }

    private void ficaEmprRoutine_300_107() {                // L:4506 300-107-FICA-EMPR-ROUTINE
        getYtdFicm_1000_450();                              // L:4511 PERFORM 1000-450-GET-YTD-FICM
        if (taxCppFicmSum.compareTo(BigDecimal.ZERO) != 0) {// L:4513 IF TAX-CPP-FICM-SUM NOT = 0             ...
            holdCppFicm = taxCppFicmSum;                    // L:4514 MOVE TAX-CPP-FICM-SUM TO HOLD-CPP-FICM
        } else {                                            // L:4515 ELSE
            // Initialize HOLD-CPP-FICM-X                   // L:4516 INITIALIZE HOLD-CPP-FICM-X.             ...
            holdCppFicm = BigDecimal.ZERO;
            taxCppFicmSum = BigDecimal.ZERO;                // L:4517 MOVE ZERO TO TAX-CPP-FICM-SUM
            taxFlgWs = perTaxFlgFica;                       // L:4518 MOVE PER-TAX-FLG-FICA TO TAX-FLG-WS
            if (ernTaxYtdFicm.compareTo(wsFicmUprTaxLimitYtd) > 0) {// L:4524 IF ERN-TAX-YTD-FICM > WS-FICM-UPR-TAX-LI...
                wsFicmUprTaxLimitYtd = wsFicmUprTaxLimitYtd.subtract(ernTaxYtdFicm);// L:4525 SUBTRACT ERN-TAX-YTD-FICM FROM WS-FICM-U...
                if ((!taxExempt && ernTaxYtdFicm.compareTo(wsFicmUprTaxLimitYtd) < 0)) {// L:4533 IF (NOT TAX-EXEMPT                      ...
                    ficaEmprCalculation_300_108();          // L:4536 PERFORM 300-108-FICA-EMPR-CALCULATION
                    // 300-107-EXIT. EXIT.                     ...// L:4538 CODE
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void ficaEmprCalculation_300_108() {            // L:4541 300-108-FICA-EMPR-CALCULATION
        annualWageWs = totEarnWs.add(totEarnYtdWs);         // L:4552 ADD TOT-EARN-WS TOT-EARN-YTD-WS GIVING A...
        annualWageWs = annualWageWs.subtract(nontaxblFica); // L:4553 SUBTRACT NONTAXBL-FICA FROM ANNUAL-WAGE-...
        annualWageWs = annualWageWs.subtract(nontaxblFicaYtd);// L:4554 SUBTRACT NONTAXBL-FICA-YTD FROM ANNUAL-W...
        if (annualWageWs.compareTo(wsFicmLwrWageLimitYtd) < 0) {// L:4555 IF ANNUAL-WAGE-WS < WS-FICM-LWR-WAGE-LIM...
            wsFicmLwrPercent = wsFicmLwrPercent.multiply(annualWageWs);// L:4556 MULTIPLY ANNUAL-WAGE-WS BY WS-FICM-LWR-P...
            if (annualWageWs.compareTo(wsFicmLwrWageLimitYtd) >= 0) {// L:4559 IF ANNUAL-WAGE-WS NOT < WS-FICM-LWR-WAGE...
                taxYtdFicmWs = wsFicmLwrTaxLimitYtd;        // L:4560 MOVE WS-FICM-LWR-TAX-LIMIT-YTD TO TAX-YTD-FICM-WS
                annualWageWs = annualWageWs.subtract(wsFicmLwrWageLimitYtd);// L:4561 SUBTRACT WS-FICM-LWR-WAGE-LIMIT-YTD FROM...
                totalWs = (totalWs.multiply(wsFicmUprPercent)).setScale(2, RoundingMode.HALF_UP);// L:4563 MULTIPLY WS-FICM-UPR-PERCENT BY TOTAL-WS...
                taxYtdFicmWs = taxYtdFicmWs.add(totalWs);   // L:4564 ADD TOTAL-WS TO TAX-YTD-FICM-WS.        ...
                if (annualWageWs.compareTo(wsFicmUprWageLimitYtd) >= 0) {// L:4566 IF ANNUAL-WAGE-WS NOT < WS-FICM-UPR-WAGE...
                    taxYtdFicmWs = wsFicmUprTaxLimitYtd;    // L:4567 MOVE WS-FICM-UPR-TAX-LIMIT-YTD TO TAX-YTD-FICM-WS
                    taxYtdFicmWs = taxYtdFicmWs.subtract(ernTaxYtdFicm);// L:4574 SUBTRACT ERN-TAX-YTD-FICM FROM TAX-YTD-F...
                    if (holdCppFicm.compareTo(BigDecimal.ZERO) != 0) {// L:4576 IF HOLD-CPP-FICM NOT = ZEROS            ...
                        taxCppFicmSum = holdCppFicm;        // L:4577 MOVE HOLD-CPP-FICM TO TAX-CPP-FICM-SUM
                        if (taxYtdFicmWs.compareTo(wsFicmUprTaxLimitYtd) > 0) {// L:4583 IF TAX-YTD-FICM-WS > WS-FICM-UPR-TAX-LIM...
                            wsFicmUprTaxLimitYtd = wsFicmUprTaxLimitYtd.subtract(ernTaxYtdFicm);// L:4584 SUBTRACT ERN-TAX-YTD-FICM FROM WS-FICM-U...
                            wsFicmYtd = wsFicmYtd.add(taxCppFicmSum);// L:4587 ADD TAX-CPP-FICM-SUM TO WS-FICM-YTD.    ...
                            // 300-108-EXIT. EXIT.                     ...// L:4589 CODE
                        }  // auto-close unclosed IF
                    }  // auto-close unclosed IF
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void ficaEmprError_300_109() {                  // L:4592 300-109-FICA-EMPR-ERROR
        messageO = "FICA TAX > NET ** NET USED**";          // L:4593 MOVE "FICA TAX > NET ** NET USED**" TO MESSAGE-O
        wsGtnErr = "TX";                                    // L:4594 MOVE "TX" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:4595 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // /                                                // L:4596 COMMENT
    }

    private void federalTax_300_110() {                     // L:4598 300-110-FEDERAL-TAX
        grossFederalWages_300_220();                        // L:4600 PERFORM 300-220-GROSS-FEDERAL-WAGES
        tblWorkKey = "";                                    // L:4607 MOVE SPACES TO TBL-WORK-KEY
        cdeTaxWs = "FWT";                                   // L:4608 MOVE "FWT" TO CDE-TAX-WS
        cdeMarStatusWs = holdMarStatFed;                    // L:4609 MOVE HOLD-MAR-STAT-FED TO CDE-MAR-STATUS-WS
        taxEntity = BigDecimal.valueOf(1);                  // L:4610 MOVE 1 TO TAX-ENTITY
        taxParaYn = "N";                                    // L:4611 MOVE "N" TO TAX-PARA-YN
        holdTaxPara = BigDecimal.ZERO;                      // L:4612 INITIALIZE HOLD-TAX-PARA.
        if (taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:4613 IF TAX-CPP-SUM (TAX-ENTITY) NOT = ZEROS
            taxParaYn = "Y";                                // L:4614 MOVE "Y" TO TAX-PARA-YN
            holdPerTaxFlg = perTaxFlg[taxEntity.intValue()];// L:4615 MOVE PER-TAX-FLG (TAX-ENTITY) TO HOLD-PER-TAX-FLG
            holdTaxPara = perTaxPara[taxEntity.intValue()]; // L:4616 MOVE PER-TAX-PARA (TAX-ENTITY) TO HOLD-TAX-PARA
            perTaxPara[taxEntity.intValue()] = taxCppSum[taxEntity.intValue()];// L:4617 MOVE TAX-CPP-SUM (TAX-ENTITY) TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = "F";          // L:4618 MOVE "F" TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        taxFlgWs = perTaxFlgFed;                            // L:4619 MOVE PER-TAX-FLG-FED TO TAX-FLG-WS
        calculateTax_300_190();                             // L:4621 PERFORM 300-190-CALCULATE-TAX
        if ("y".equals(taxParaYn)) {                        // L:4622 IF TAX-PARA-YN = "Y"
            perTaxPara[taxEntity.intValue()] = holdTaxPara; // L:4623 MOVE HOLD-TAX-PARA TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = holdPerTaxFlg;// L:4624 MOVE HOLD-PER-TAX-FLG TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        // 300-110-EXIT. EXIT.                              // L:4626 CODE
    }

    private void advancedEic_300_112() {                    // L:4629 300-112-ADVANCED-EIC
        if ("c".equals(perTaxFlgFed)) {                     // L:4630 IF PER-TAX-FLG-FED = "C"
            taxEicError_300_198_2();                        // L:4631 PERFORM 300-198-2-TAX-EIC-ERROR
            // GO TO 300-112-EXIT - control flow            // L:4632 GO TO 300-112-EXIT
        }  // period ends IF scope
        grossFederalWages_300_220();                        // L:4633 PERFORM 300-220-GROSS-FEDERAL-WAGES
        if ((("1".equals(perTaxFlgFed) || "2".equals(perTaxFlgFed) || "3".equals(perTaxFlgFed)))) {// L:4634 IF (PER-TAX-FLG-FED = "1" OR "2" OR "3")
            advEicTax = "C";                                // L:4635 MOVE "C" TO ADV-EIC-TAX
        }  // period ends IF scope
        tblWorkKey = "";                                    // L:4636 MOVE SPACES TO TBL-WORK-KEY
        cdeTax13 = "EIC";                                   // L:4637 MOVE "EIC" TO CDE-TAX-13
        cdeTax4 = perTaxFlgFed;                             // L:4638 MOVE PER-TAX-FLG-FED TO CDE-TAX-4
        cdeMarStatusWs = "S";                               // L:4639 MOVE "S" TO CDE-MAR-STATUS-WS
        taxEntity = BigDecimal.valueOf(7);                  // L:4640 MOVE 7 TO TAX-ENTITY
        taxParaYn = "N";                                    // L:4641 MOVE "N" TO TAX-PARA-YN
        holdTaxPara = BigDecimal.ZERO;                      // L:4642 INITIALIZE HOLD-TAX-PARA.
        if (taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:4643 IF TAX-CPP-SUM (TAX-ENTITY) NOT = ZEROS
            taxParaYn = "Y";                                // L:4644 MOVE "Y" TO TAX-PARA-YN
            holdPerTaxFlg = perTaxFlg[1];                   // L:4645 MOVE PER-TAX-FLG (1) TO HOLD-PER-TAX-FLG
            holdTaxPara = perTaxPara[1];                    // L:4646 MOVE PER-TAX-PARA (1) TO HOLD-TAX-PARA
            perTaxPara[1] = taxCppSum[taxEntity.intValue()];// L:4647 MOVE TAX-CPP-SUM (TAX-ENTITY) TO PER-TAX-PARA(1)
            perTaxFlg[1] = "F";                             // L:4648 MOVE "F" TO PER-TAX-FLG(1)
        }  // period ends IF scope
        taxFlgWs = perTaxFlgFed;                            // L:4649 MOVE PER-TAX-FLG-FED TO TAX-FLG-WS
        calculateTax_300_190();                             // L:4650 PERFORM 300-190-CALCULATE-TAX
        if ("y".equals(taxParaYn)) {                        // L:4651 IF TAX-PARA-YN = "Y"
            perTaxPara[1] = holdTaxPara;                    // L:4652 MOVE HOLD-TAX-PARA TO PER-TAX-PARA(1)
            perTaxFlg[1] = holdPerTaxFlg;                   // L:4653 MOVE HOLD-PER-TAX-FLG TO PER-TAX-FLG(1)
        }  // period ends IF scope
        // 300-112-EXIT. EXIT.                              // L:4655 CODE
    }

    private void stateTax_300_114() {                       // L:4657 300-114-STATE-TAX
        grossStateWages_300_225();                          // L:4666 PERFORM 300-225-GROSS-STATE-WAGES
        if ("ma".equals(perCdeStt)) {                       // L:4668 IF PER-CDE-STT = "MA"                   ...
            cdeCycleNumWs = cdeCycleNumWs.multiply(totEarnWs);// L:4677 MULTIPLY TOT-EARN-WS BY CDE-CYCLE-NUM-WS...
            cdeCycleNumWs = cdeCycleNumWs.multiply(taxCppFicaSum);// L:4682 MULTIPLY TAX-CPP-FICA-SUM BY CDE-CYCLE-N...
        }                                                   // L:4686 END-IF
        tblWorkKey = "";                                    // L:4688 MOVE SPACES TO TBL-WORK-KEY
        tempCdeMarStatusWs = "";                            // L:4689 MOVE SPACES TO TEMP-CDE-MAR-STATUS-WS
        orMarStatusChangeSw = "N";                          // L:4690 MOVE "N" TO OR-MAR-STATUS-CHANGE-SW
        cdeTaxWs = perCdeStt;                               // L:4691 MOVE PER-CDE-STT TO CDE-TAX-WS
        sttLiteral = perCdeStt;                             // L:4691 MOVE PER-CDE-STT TO STT-LITERAL
        wsMwSttLiteral = perCdeStt;                         // L:4691 MOVE PER-CDE-STT TO WS-MW-STT-LITERAL
        cdeMarStatusWs = holdMarStatStt;                    // L:4693 MOVE HOLD-MAR-STAT-STT TO CDE-MAR-STATUS-WS
        ctStdDeductAmt = BigDecimal.ZERO;                   // L:4695 MOVE 0 TO CT-STD-DEDUCT-AMT
        if ("ct".equals(perCdeStt)) {                       // L:4696 IF PER-CDE-STT = "CT"
            if (perExmStt == 1) {                           // L:4697 IF PER-EXM-STT = 1
                cdeMarStatusWs = "A";                       // L:4698 MOVE "A" TO CDE-MAR-STATUS-WS
            }  // auto-close inner IF
        } else {                                            // L:4699 ELSE
            if (perExmStt == 2) {                           // L:4700 IF PER-EXM-STT = 2
                cdeMarStatusWs = "B";                       // L:4701 MOVE "B" TO CDE-MAR-STATUS-WS
                // ORPHAN ELSE (no matching IF)             // L:4702 ELSE
                if (perExmStt == 3) {                       // L:4703 IF PER-EXM-STT = 3
                    cdeMarStatusWs = "C";                   // L:4704 MOVE "C" TO CDE-MAR-STATUS-WS
                    // ORPHAN ELSE (no matching IF)         // L:4705 ELSE
                    if (perExmStt == 4) {                   // L:4706 IF PER-EXM-STT = 4
                        cdeMarStatusWs = "D";               // L:4707 MOVE "D" TO CDE-MAR-STATUS-WS
                        // ORPHAN ELSE (no matching IF)     // L:4708 ELSE
                        if (perExmStt == 6) {               // L:4709 IF PER-EXM-STT = 6
                            cdeMarStatusWs = "F";           // L:4710 MOVE "F" TO CDE-MAR-STATUS-WS
                            // ORPHAN ELSE (no matching IF) // L:4711 ELSE
                            cdeMarStatusWs = "A";           // L:4712 MOVE "A" TO CDE-MAR-STATUS-WS
                            if (!"e".equals(perTaxFlgStt)) {// L:4713 IF PER-TAX-FLG-STT NOT = "E"
                                messageO = "CT EMP MUST HAVE 1-4 OR 6 FOR STT EXEMPTIONS.";// L:4714 MOVE "CT EMP MUST HAVE 1-4 OR 6 FOR STT EXEMPTIONS." TO MESSAGE-O
                                wsGtnErr = "WR";            // L:4716 MOVE "WR" TO WS-GTN-ERR
                                gtnError_800_700();         // L:4717 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                            }  // period ends IF scope
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        taxEntity = BigDecimal.valueOf(2);                  // L:4718 MOVE 2 TO TAX-ENTITY
        taxParaYn = "N";                                    // L:4719 MOVE "N" TO TAX-PARA-YN
        holdTaxPara = BigDecimal.ZERO;                      // L:4720 INITIALIZE HOLD-TAX-PARA.
        if (taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:4721 IF TAX-CPP-SUM (TAX-ENTITY) NOT = ZEROS
            taxParaYn = "Y";                                // L:4722 MOVE "Y" TO TAX-PARA-YN
            holdPerTaxFlg = perTaxFlg[taxEntity.intValue()];// L:4723 MOVE PER-TAX-FLG (TAX-ENTITY) TO HOLD-PER-TAX-FLG
            holdTaxPara = perTaxPara[taxEntity.intValue()]; // L:4724 MOVE PER-TAX-PARA (TAX-ENTITY) TO HOLD-TAX-PARA
            perTaxPara[taxEntity.intValue()] = taxCppSum[taxEntity.intValue()];// L:4725 MOVE TAX-CPP-SUM (TAX-ENTITY) TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = "F";          // L:4726 MOVE "F" TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        taxFlgWs = perTaxFlgStt;                            // L:4727 MOVE PER-TAX-FLG-STT TO TAX-FLG-WS
        if ("ca".equals(perCdeStt)) {                       // L:4742 IF PER-CDE-STT = "CA"
            caTax_300_114_3();                              // L:4743 PERFORM 300-114-3-CA-TAX
        } else {                                            // L:4744 ELSE
            if ("nc".equals(perCdeStt)) {                   // L:4750 IF PER-CDE-STT = "NC"                   ...
                ncTax_300_114_20();                         // L:4751 PERFORM 300-114-20-NC-TAX
            } else {                                        // L:4752 ELSE
                calculateTax_300_190();                     // L:4753 PERFORM 300-190-CALCULATE-TAX
            }  // period ends IF scope
        }  // period ends IF scope
        if ("y".equals(taxParaYn)) {                        // L:4754 IF TAX-PARA-YN = "Y"
            perTaxPara[taxEntity.intValue()] = holdTaxPara; // L:4755 MOVE HOLD-TAX-PARA TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = holdPerTaxFlg;// L:4756 MOVE HOLD-PER-TAX-FLG TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        getStateMinWage_300_114_50();                       // L:4759 PERFORM 300-114-50-GET-STATE-MIN-WAGE
        // 300-114-EXIT. EXIT.                              // L:4761 CODE
        // /                                                // L:4763 COMMENT
    }

    private void laTax_300_114_1() {                        // L:4769 300-114-1-LA-TAX
        initialize_300_191();                               // L:4770 PERFORM 300-191-INITIALIZE
        // Initialize WS-LOUISIANA-STATE-TAX                // L:4771 INITIALIZE WS-LOUISIANA-STATE-TAX.
        w = BigDecimal.ZERO;
        w1 = BigDecimal.ZERO;
        w2 = BigDecimal.ZERO;
        w3 = BigDecimal.ZERO;
        sa = BigDecimal.ZERO;
        x = BigDecimal.ZERO;
        y = BigDecimal.ZERO;
        n = BigDecimal.ZERO;
        a = BigDecimal.ZERO;
        b = BigDecimal.ZERO;
        e = BigDecimal.ZERO;
        f = BigDecimal.ZERO;
        p1 = BigDecimal.ZERO;
        p2 = BigDecimal.ZERO;
        p3 = BigDecimal.ZERO;
        ll1 = BigDecimal.ZERO;
        ll2 = BigDecimal.ZERO;
        ll3 = BigDecimal.ZERO;
        taxableWageWs = annualWageWs;                       // L:4772 MOVE ANNUAL-WAGE-WS TO TAXABLE-WAGE-WS
        okFlag = notOkLit;                                  // L:4773 MOVE NOT-OK-LIT TO OK-FLAG
        taxKeyFlag = notOkLit;                              // L:4773 MOVE NOT-OK-LIT TO TAX-KEY-FLAG
        taxRoutineFlag = okLit;                             // L:4774 MOVE OK-LIT TO TAX-ROUTINE-FLAG
        lookup_300_114_9();                                 // L:4775 PERFORM 300-114-9-LOOKUP
        if ((BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0 || wsTblKey[tblIdx].compareTo(tblWorkKey) > 0)) {// L:4780 IF (TBL-IDX > WS-TBL-IDX-LIMIT
            taxKeyError_300_198_1();                        // L:4783 PERFORM 300-198-1-TAX-KEY-ERROR
        } else {                                            // L:4784 ELSE
            taxKeyFlag = okLit;                             // L:4785 MOVE OK-LIT TO TAX-KEY-FLAG
        }  // period ends IF scope
        if (annualWageWs.compareTo(BigDecimal.ZERO) <= 0) { // L:4786 IF ANNUAL-WAGE-WS NOT > ZERO
            taxRoutineFlag = notOkLit;                      // L:4787 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
        }  // period ends IF scope
        if ((taxKeyFound && taxRoutineOk)) {                // L:4788 IF (TAX-KEY-FOUND AND TAX-ROUTINE-OK)
            computeTax_300_114_2();                         // L:4789 PERFORM 300-114-2-COMPUTE-TAX
        }  // period ends IF scope
    }

    private void computeTax_300_114_2() {                   // L:4791 300-114-2-COMPUTE-TAX
        sa = annualWageWs;                                  // L:4798 MOVE ANNUAL-WAGE-WS TO SA
        x = BigDecimal.valueOf(wsPerExemptCnt[taxEntity.intValue()]);// L:4799 MOVE WS-PER-EXEMPT-CNT(TAX-ENTITY) TO X
        e = wsExemptAmt[tblIdx];                            // L:4800 MOVE WS-EXEMPT-AMT(TBL-IDX) TO E
        y = wsPerExmLoc;                                    // L:4801 MOVE WS-PER-EXM-LOC TO Y
        f = wsStdDedAmt[tblIdx];                            // L:4802 MOVE WS-STD-DED-AMT(TBL-IDX) TO F
        n = cdeCycleNumWs;                                  // L:4803 MOVE CDE-CYCLE-NUM-WS TO N
        p1 = wsPctExcessWage[tblIdx];                       // L:4804 MOVE WS-PCT-EXCESS-WAGE(TBL-IDX) TO P1
        ll1 = wsLowerWageLimit[tblIdx];                     // L:4805 MOVE WS-LOWER-WAGE-LIMIT(TBL-IDX) TO LL1
        tblIdx = tblIdx + 1;                                // L:4806 SET TBL-IDX UP BY 1.
        if (wsTblKey[tblIdx].compareTo(tblWorkKey) != 0) {  // L:4807 IF WS-TBL-KEY(TBL-IDX) NOT = TBL-WORK-KE...
            taxKeyError_300_198_1();                        // L:4808 PERFORM 300-198-1-TAX-KEY-ERROR
            taxRoutineFlag = notOkLit;                      // L:4809 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
        }  // period ends IF scope
        if (taxRoutineOk) {                                 // L:4810 IF TAX-ROUTINE-OK
            p2 = wsPctExcessWage[tblIdx];                   // L:4811 MOVE WS-PCT-EXCESS-WAGE(TBL-IDX) TO P2
            ll2 = wsLowerWageLimit[tblIdx];                 // L:4812 MOVE WS-LOWER-WAGE-LIMIT(TBL-IDX) TO LL2
        }  // period ends IF scope
        tblIdx = tblIdx + 1;                                // L:4813 SET TBL-IDX UP BY 1.
        if (wsTblKey[tblIdx].compareTo(tblWorkKey) != 0) {  // L:4814 IF WS-TBL-KEY(TBL-IDX) NOT = TBL-WORK-KE...
            taxKeyError_300_198_1();                        // L:4815 PERFORM 300-198-1-TAX-KEY-ERROR
            taxRoutineFlag = notOkLit;                      // L:4816 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
        }  // period ends IF scope
        if (taxRoutineOk) {                                 // L:4817 IF TAX-ROUTINE-OK
            p3 = wsPctExcessWage[tblIdx];                   // L:4818 MOVE WS-PCT-EXCESS-WAGE(TBL-IDX) TO P3
            ll3 = wsLowerWageLimit[tblIdx];                 // L:4819 MOVE WS-LOWER-WAGE-LIMIT(TBL-IDX) TO LL3
        }  // period ends IF scope
        if (taxRoutineOk) {                                 // L:4820 IF TAX-ROUTINE-OK
            computeTax_300_114_3();                         // L:4821 PERFORM 300-114-3-COMPUTE-TAX
        }  // period ends IF scope
    }

    private void computeTax_300_114_3() {                   // L:4823 300-114-3-COMPUTE-TAX
        w1 = ((p1).multiply(sa)).setScale(2, RoundingMode.HALF_UP);// L:4825 COMPUTE W1 ROUNDED = P1 * SA.
        if (w1.compareTo(BigDecimal.ZERO) < 0) {            // L:4826 IF W1 < 0
            w1 = BigDecimal.ZERO;                           // L:4827 MOVE 0 TO W1
        }  // period ends IF scope
        w2 = ((p2).multiply((sa).subtract(ll2))).setScale(2, RoundingMode.HALF_UP);// L:4828 COMPUTE W2 ROUNDED = P2 * (SA - LL2).
        if (w2.compareTo(BigDecimal.ZERO) < 0) {            // L:4829 IF W2 < 0
            w2 = BigDecimal.ZERO;                           // L:4830 MOVE 0 TO W2
        }  // period ends IF scope
        w3 = ((p3).multiply((sa).subtract(ll3))).setScale(2, RoundingMode.HALF_UP);// L:4831 COMPUTE W3 ROUNDED = P3 * (SA - LL3).
        if (w3.compareTo(BigDecimal.ZERO) < 0) {            // L:4832 IF W3 < 0
            w3 = BigDecimal.ZERO;                           // L:4833 MOVE 0 TO W3
        }  // period ends IF scope
        a = ((p1).multiply(((x).multiply(e)).add((y).multiply(f)))).setScale(2, RoundingMode.HALF_UP);// L:4834 COMPUTE A ROUNDED = P1 * ((X * E) + (Y *...
        if (a.compareTo(BigDecimal.ZERO) < 0) {             // L:4835 IF A < 0
            a = BigDecimal.ZERO;                            // L:4836 MOVE 0 TO A
        }  // period ends IF scope
        b = ((p2).multiply((((x).multiply(e)).add((y).multiply(f))).subtract(ll2))).setScale(2, RoundingMode.HALF_UP);// L:4837 COMPUTE B ROUNDED = P2 * ((X * E) + (Y *...
        if (b.compareTo(BigDecimal.ZERO) < 0) {             // L:4838 IF B < 0
            b = BigDecimal.ZERO;                            // L:4839 MOVE 0 TO B
        }  // period ends IF scope
        w = (((w1).add(w2)).add(w3)).subtract((a).add(b));  // L:4840 COMPUTE W = (W1 + W2 + W3) - (A + B).
        taxCppSum[taxEntity.intValue()] = w;                // L:4841 MOVE W TO TAX-CPP-SUM(TAX-ENTITY)
        if (taxRoutineOk) {                                 // L:4842 IF TAX-ROUTINE-OK
            reduceNet_300_198();                            // L:4843 PERFORM 300-198-REDUCE-NET
        }  // period ends IF scope
        // /                                                // L:4956 COMMENT
    }

    private void caTax_300_114_3() {                        // L:4957 300-114-3-CA-TAX
        holdTotEarnWs = totEarnWs;                          // L:4959 MOVE TOT-EARN-WS TO HOLD-TOT-EARN-WS
        initialize_300_191();                               // L:4960 PERFORM 300-191-INITIALIZE
        totEarnWs = totEarnWs.add(tsaAmountWs);             // L:4967 ADD TSA-AMOUNT-WS TO TOT-EARN-WS.
        totEarnWs = totEarnWs.subtract(annlTaxblStt);       // L:4968 SUBTRACT ANNL-TAXBL-STT FROM TOT-EARN-WS...
        cdeCycleNumWs = cdeCycleNumWs.multiply(totEarnWs);  // L:4969 MULTIPLY TOT-EARN-WS BY CDE-CYCLE-NUM-WS...
        annualWageWs = annualWageWs.add(annlTaxblStt);      // L:4971 ADD ANNL-TAXBL-STT TO ANNUAL-WAGE-WS.
        totEarnWs = totEarnWs.add(annlTaxblStt);            // L:4972 ADD ANNL-TAXBL-STT TO TOT-EARN-WS.
        taxableWageWs = annualWageWs;                       // L:4973 MOVE ANNUAL-WAGE-WS TO TAXABLE-WAGE-WS
        okFlag = notOkLit;                                  // L:4974 MOVE NOT-OK-LIT TO OK-FLAG
        taxKeyFlag = notOkLit;                              // L:4974 MOVE NOT-OK-LIT TO TAX-KEY-FLAG
        taxRoutineFlag = okLit;                             // L:4975 MOVE OK-LIT TO TAX-ROUTINE-FLAG
        savCdeTaxWs = cdeTaxWs;                             // L:4983 MOVE CDE-TAX-WS TO SAV-CDE-TAX-WS
        cdeTaxWs = "LOW$";                                  // L:4984 MOVE "LOW$" TO CDE-TAX-WS
        lookup_300_114_9();                                 // L:4985 PERFORM 300-114-9-LOOKUP
        if ((BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0 || wsTblKey[tblIdx].compareTo(tblWorkKey) > 0)) {// L:4990 IF (TBL-IDX > WS-TBL-IDX-LIMIT
            taxKeyError_300_198_1();                        // L:4993 PERFORM 300-198-1-TAX-KEY-ERROR
        } else {                                            // L:4994 ELSE
            taxKeyFlag = okLit;                             // L:4995 MOVE OK-LIT TO TAX-KEY-FLAG
        }  // period ends IF scope
        cdeTaxWs = savCdeTaxWs;                             // L:4996 MOVE SAV-CDE-TAX-WS TO CDE-TAX-WS
        if (annualWageWs.compareTo(BigDecimal.ZERO) <= 0) { // L:4997 IF ANNUAL-WAGE-WS NOT > ZERO
            taxRoutineFlag = notOkLit;                      // L:4998 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
        }  // period ends IF scope
        if ((taxKeyFound && taxRoutineOk)) {                // L:4999 IF (TAX-KEY-FOUND AND TAX-ROUTINE-OK)
            computeTax_300_114_4();                         // L:5000 PERFORM 300-114-4-COMPUTE-TAX
        }  // period ends IF scope
    }

    private void computeTax_300_114_4() {                   // L:5002 300-114-4-COMPUTE-TAX
        lowerWageLimitWs = wsLowerWageLimit[tblIdx];        // L:5009 MOVE WS-LOWER-WAGE-LIMIT (TBL-IDX) TO LOWER-WAGE-LIMIT-WS
        if ("m".equals(cdeMarStatusWs) || "h".equals(cdeMarStatusWs)) {// L:5016 IF CDE-MAR-STATUS-WS = "M"
            if (wsPerExmStt.compareTo(BigDecimal.valueOf(2)) < 0) {// L:5018 IF WS-PER-EXM-STT < 2
                // DIVIDE parse failed: DIVIDE LOWER-WAGE-LIMIT-WS BY 2                        IBM-CT// L:5019 DIVIDE LOWER-WAGE-LIMIT-WS BY 2         ...
                if (taxableWageWs.compareTo(lowerWageLimitWs) > 0) {// L:5029 IF TAXABLE-WAGE-WS > LOWER-WAGE-LIMIT-WS
                    totEarnWs = holdTotEarnWs;              // L:5031 MOVE HOLD-TOT-EARN-WS TO TOT-EARN-WS
                    calculateTax_300_190();                 // L:5033 PERFORM 300-190-CALCULATE-TAX
                } else {                                    // L:5034 ELSE
                    reduceNet_300_198();                    // L:5035 PERFORM 300-198-REDUCE-NET
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void lookup_300_114_9() {                       // L:5037 300-114-9-LOOKUP
        // /                                                // L:5039 COMMENT
    }

    private void ncTax_300_114_20() {                       // L:5040 300-114-20-NC-TAX
        initialize_300_191();                               // L:5041 PERFORM 300-191-INITIALIZE
        taxableWageWs = annualWageWs;                       // L:5042 MOVE ANNUAL-WAGE-WS TO TAXABLE-WAGE-WS
        okFlag = notOkLit;                                  // L:5043 MOVE NOT-OK-LIT TO OK-FLAG
        taxKeyFlag = notOkLit;                              // L:5043 MOVE NOT-OK-LIT TO TAX-KEY-FLAG
        taxRoutineFlag = okLit;                             // L:5044 MOVE OK-LIT TO TAX-ROUTINE-FLAG
        lookup_300_114_9();                                 // L:5045 PERFORM 300-114-9-LOOKUP
        if ((BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0 || wsTblKey[tblIdx].compareTo(tblWorkKey) > 0)) {// L:5052 IF (TBL-IDX > WS-TBL-IDX-LIMIT          ...
            taxKeyError_300_198_1();                        // L:5055 PERFORM 300-198-1-TAX-KEY-ERROR
        } else {                                            // L:5056 ELSE
            taxKeyFlag = okLit;                             // L:5057 MOVE OK-LIT TO TAX-KEY-FLAG
            if (annualWageWs.compareTo(BigDecimal.ZERO) <= 0) {// L:5058 IF ANNUAL-WAGE-WS NOT > ZERO            ...
                taxRoutineFlag = notOkLit;                  // L:5059 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
                if ((taxKeyFound && taxRoutineOk)) {        // L:5060 IF (TAX-KEY-FOUND AND TAX-ROUTINE-OK)   ...
                    computeTax_300_114_21();                // L:5061 PERFORM 300-114-21-COMPUTE-TAX
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void computeTax_300_114_21() {                  // L:5063 300-114-21-COMPUTE-TAX
        taxableWageWs = taxableWageWs.subtract(wsStdDedAmt[tblIdx]);// L:5075 SUBTRACT WS-STD-DED-AMT (TBL-IDX) FROM T...
        if (wsPerExemptCnt[taxEntity.intValue()] > 1) {     // L:5082 IF WS-PER-EXEMPT-CNT (TAX-ENTITY) > 1   ...
            if (wsPerExemptCnt[taxEntity.intValue()] < 3) { // L:5083 IF WS-PER-EXEMPT-CNT (TAX-ENTITY) < 3   ...
                cRetCode = "";                              // L:5085 MOVE SPACES TO C-RET-CODE
                wsPaytblpf01Level = BigDecimal.valueOf(1);  // L:5086 MOVE 01 TO WS-PAYTBLPF01-LEVEL
                wsPaytblpf01TaxOption = BigDecimal.valueOf(10);// L:5087 MOVE 010 TO WS-PAYTBLPF01-TAX-OPTION
                wsPaytblpf01TaxOptValue1 = BigDecimal.ZERO; // L:5088 INITIALIZE WS-PAYTBLPF01-TAX-OPT-VALUE1 ...
                // CALL PYOPXFK                             // L:5090 CALL "PYOPXFK" USING C-RET-CODE,        ...
                callPyopxfk();
                if (wsPaytblpf01TaxOptValue1.compareTo(BigDecimal.ZERO) != 0) {// L:5097 IF WS-PAYTBLPF01-TAX-OPT-VALUE1 NOT = ZE...
                    // MULTIPLY parse failed: MULTIPLY 1 BY // L:5098 MULTIPLY 1 BY                           ...
                    // COMPUTE parse failed: COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =// L:5101 COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =...
                    // MULTIPLY parse failed: MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 BY// L:5103 MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 ...
                    // COMPUTE parse failed: COMPUTE DEDUCT-EXEMPT-AMT-WS =// L:5107 COMPUTE DEDUCT-EXEMPT-AMT-WS =          ...
                } else {                                    // L:5110 ELSE
                    // MULTIPLY parse failed: MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) BY// L:5111 MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) ...
                }                                           // L:5114 END-IF
            } else {                                        // L:5115 ELSE
                if (wsPerExemptCnt[taxEntity.intValue()] >= 3) {// L:5117 IF WS-PER-EXEMPT-CNT (TAX-ENTITY) >= 3  ...
                    cRetCode = "";                          // L:5120 MOVE SPACES TO C-RET-CODE
                    wsPaytblpf01Level = BigDecimal.valueOf(1);// L:5121 MOVE 01 TO WS-PAYTBLPF01-LEVEL
                    wsPaytblpf01TaxOption = BigDecimal.valueOf(10);// L:5122 MOVE 010 TO WS-PAYTBLPF01-TAX-OPTION
                    wsPaytblpf01TaxOptValue1 = BigDecimal.ZERO;// L:5123 INITIALIZE WS-PAYTBLPF01-TAX-OPT-VALUE1 ...
                    // CALL PYOPXFK                         // L:5125 CALL "PYOPXFK" USING C-RET-CODE,        ...
                    callPyopxfk();
                    cRetCode = "";                          // L:5135 MOVE SPACES TO C-RET-CODE
                    wsPaytblpf01Level = BigDecimal.valueOf(1);// L:5136 MOVE 01 TO WS-PAYTBLPF01-LEVEL
                    wsPaytblpf01TaxOption = BigDecimal.valueOf(12);// L:5137 MOVE 012 TO WS-PAYTBLPF01-TAX-OPTION
                    wsPaytblpf01TaxOptValue2 = BigDecimal.ZERO;// L:5138 INITIALIZE WS-PAYTBLPF01-TAX-OPT-VALUE2 ...
                    // CALL PYOPXFK                         // L:5140 CALL "PYOPXFK" USING C-RET-CODE,        ...
                    callPyopxfk();
                    if (wsPaytblpf01TaxOptValue1.compareTo(BigDecimal.ZERO) != 0 && wsPaytblpf01TaxOptValue2.compareTo(BigDecimal.ZERO) != 0) {// L:5148 IF WS-PAYTBLPF01-TAX-OPT-VALUE1 NOT = ZE...
                        // MULTIPLY parse failed: MULTIPLY 1 BY// L:5151 MULTIPLY 1 BY                           ...
                        // MULTIPLY parse failed: MULTIPLY 1 BY// L:5154 MULTIPLY 1 BY                           ...
                        // COMPUTE parse failed: COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =// L:5158 COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =...
                        // MULTIPLY parse failed: MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 BY// L:5160 MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 ...
                        // COMPUTE parse failed: COMPUTE DEDUCT-EXEMPT-AMT-WS =// L:5164 COMPUTE DEDUCT-EXEMPT-AMT-WS =          ...
                    } else {                                // L:5168 ELSE
                        if (wsPaytblpf01TaxOptValue1.compareTo(BigDecimal.ZERO) != 0) {// L:5169 IF WS-PAYTBLPF01-TAX-OPT-VALUE1 NOT = ZE...
                            // MULTIPLY parse failed: MULTIPLY 1 BY// L:5170 MULTIPLY 1 BY                           ...
                            // COMPUTE parse failed: COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =// L:5173 COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =...
                            // MULTIPLY parse failed: MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 BY// L:5175 MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 ...
                            // COMPUTE parse failed: COMPUTE DEDUCT-EXEMPT-AMT-WS =// L:5179 COMPUTE DEDUCT-EXEMPT-AMT-WS =          ...
                        } else {                            // L:5182 ELSE
                            if (wsPaytblpf01TaxOptValue2.compareTo(BigDecimal.ZERO) != 0) {// L:5183 IF WS-PAYTBLPF01-TAX-OPT-VALUE2 NOT = ZE...
                                // MULTIPLY parse failed: MULTIPLY 2 BY// L:5184 MULTIPLY 2 BY                           ...
                                // COMPUTE parse failed: COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT2 =// L:5187 COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT2 =...
                                // MULTIPLY parse failed: MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT2 BY// L:5189 MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT2 ...
                                // COMPUTE parse failed: COMPUTE DEDUCT-EXEMPT-AMT-WS =// L:5193 COMPUTE DEDUCT-EXEMPT-AMT-WS =          ...
                            } else {                        // L:5196 ELSE
                                // MULTIPLY parse failed: MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) BY// L:5197 MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) ...
                            }                               // L:5200 END-IF
                        }                                   // L:5201 END-IF
                    }                                       // L:5202 END-IF
                }                                           // L:5204 END-IF
            }                                               // L:5205 END-IF
        } else {                                            // L:5206 ELSE
            inc = inc.multiply(BigDecimal.valueOf(wsPerExemptCnt[taxEntity.intValue()]));// L:5207 MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) ...
        }                                                   // L:5210 END-IF
        taxableWageWs = taxableWageWs.subtract(deductExemptAmtWs);// L:5217 SUBTRACT DEDUCT-EXEMPT-AMT-WS FROM TAXAB...
        if (taxableWageWs.compareTo(BigDecimal.ZERO) < 0) { // L:5218 IF TAXABLE-WAGE-WS < 0
            taxableWageWs = BigDecimal.ZERO;                // L:5219 MOVE 0 TO TAXABLE-WAGE-WS
        }  // period ends IF scope
        taxKeyFlag = notOkLit;                              // L:5225 MOVE NOT-OK-LIT TO TAX-KEY-FLAG
        lookup_300_114_9();                                 // L:5226 PERFORM 300-114-9-LOOKUP
        if ((BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0 || wsTblKey[tblIdx].compareTo(tblWorkKey) > 0)) {// L:5233 IF (TBL-IDX > WS-TBL-IDX-LIMIT          ...
            taxKeyError_300_198_1();                        // L:5236 PERFORM 300-198-1-TAX-KEY-ERROR
        } else {                                            // L:5237 ELSE
            taxKeyFlag = okLit;                             // L:5238 MOVE OK-LIT TO TAX-KEY-FLAG
            // SUBTRACT parse failed: SUBTRACT WS-LOWER-WAGE-LIMIT (TBL-IDX)                       INC#780// L:5244 SUBTRACT WS-LOWER-WAGE-LIMIT (TBL-IDX)  ...
            inc = inc.multiply(wsPctExcessWage[tblIdx]);    // L:5246 MULTIPLY WS-PCT-EXCESS-WAGE (TBL-IDX) BY...
            if (excessTaxWs.compareTo(BigDecimal.ZERO) < 0) {// L:5248 IF EXCESS-TAX-WS < ZERO                 ...
                excessTaxWs = BigDecimal.ZERO;              // L:5249 MOVE ZERO TO EXCESS-TAX-WS
                if (taxRoutineOk) {                         // L:5250 IF TAX-ROUTINE-OK                       ...
                    // ADD parse failed: ADD EXCESS-TAX-WS WS-FLAT-TAX-AMT (TBL-IDX)              INC#780// L:5251 ADD EXCESS-TAX-WS WS-FLAT-TAX-AMT (TBL-I...
                    reduceNet_300_198();                    // L:5253 PERFORM 300-198-REDUCE-NET
                    // /                                    // L:5254 COMMENT
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void getStateMinWage_300_114_50() {             // L:5256 300-114-50-GET-STATE-MIN-WAGE
        p0rtn = "";                                         // L:5259 MOVE SPACES TO P0RTN
        wp0001 = BigDecimal.valueOf(perClientNo);           // L:5260 MOVE PER-CLIENT-NO TO WP0001
        wp0002 = BigDecimal.valueOf(perCompNo);             // L:5261 MOVE PER-COMP-NO TO WP0002
        wp0003 = BigDecimal.valueOf(perCorpNo);             // L:5262 MOVE PER-CORP-NO TO WP0003
        wp0004 = BigDecimal.valueOf(perStoreNo);            // L:5263 MOVE PER-STORE-NO TO WP0004
        wp0005 = "";                                        // L:5264 MOVE SPACES TO WP0005
        // CALL PYIZXFK                                     // L:5265 CALL "PYIZXFK" USING P0RTN,             ...
        callPyizxfk();
        // Initialize WS-MW-TBL-CDE-ST-KEY                  // L:5272 INITIALIZE WS-MW-TBL-CDE-ST-KEY.        ...
        wsMwTblCdeTax = "";
        wsMwTblMarStatus = "";
        // REQ01461                                         // L:5273 CODE
        // STRING parse failed (no INTO): STRING WP0005 DELIMITED BY SIZE,...// L:5274 STRING WP0005 DELIMITED BY SIZE,        ...
        // REQ01461                                         // L:5277 CODE
        wsMwTblMarStatus = "S";                             // L:5278 MOVE "S" TO WS-MW-TBL-MAR-STATUS
        // REQ01461                                         // L:5279 CODE
        // SET WS-SAVED-TBL-IDX TO TBL-IDX.        ...      // L:5280 SET
        // REQ01461                                         // L:5281 CODE
        lookup_300_114_9();                                 // L:5282 PERFORM 300-114-9-LOOKUP
        if ((BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0 || wsTblKey[tblIdx].compareTo(wsMwTblCdeStKey) > 0)) {// L:5287 IF (TBL-IDX > WS-TBL-IDX-LIMIT          ...
            wsStateMinWageRteHourly = BigDecimal.ZERO;      // L:5296 MOVE ZEROS TO WS-STATE-MIN-WAGE-RTE-HOURLY
        } else {                                            // L:5297 ELSE
            wsStateMinWageRteHourly = wsLowerWageLimit[tblIdx];// L:5298 MOVE WS-LOWER-WAGE-LIMIT(TBL-IDX) TO WS-STATE-MIN-WAGE-RTE-HOURLY
        }                                                   // L:5300 END-IF
        // REQ01461                                         // L:5301 CODE
        // SET TBL-IDX TO WS-SAVED-TBL-IDX.        ...      // L:5302 SET
        // /                                                // L:5304 COMMENT
    }

    private void localTax_300_120() {                       // L:5305 300-120-LOCAL-TAX
        grossLocalWages_300_230();                          // L:5306 PERFORM 300-230-GROSS-LOCAL-WAGES
        tblWorkKey = "";                                    // L:5307 MOVE SPACES TO TBL-WORK-KEY
        cdeTaxWs = perCdeLoc;                               // L:5308 MOVE PER-CDE-LOC TO CDE-TAX-WS
        locLiteral = perCdeLoc;                             // L:5308 MOVE PER-CDE-LOC TO LOC-LITERAL
        cdeMarStatusWs = holdMarStatLoc;                    // L:5310 MOVE HOLD-MAR-STAT-LOC TO CDE-MAR-STATUS-WS
        taxEntity = BigDecimal.valueOf(3);                  // L:5311 MOVE 3 TO TAX-ENTITY
        taxParaYn = "N";                                    // L:5312 MOVE "N" TO TAX-PARA-YN
        holdTaxPara = BigDecimal.ZERO;                      // L:5313 INITIALIZE HOLD-TAX-PARA.
        if (taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:5314 IF TAX-CPP-SUM (TAX-ENTITY) NOT = ZEROS
            taxParaYn = "Y";                                // L:5315 MOVE "Y" TO TAX-PARA-YN
            holdPerTaxFlg = perTaxFlg[taxEntity.intValue()];// L:5316 MOVE PER-TAX-FLG (TAX-ENTITY) TO HOLD-PER-TAX-FLG
            holdTaxPara = perTaxPara[taxEntity.intValue()]; // L:5317 MOVE PER-TAX-PARA (TAX-ENTITY) TO HOLD-TAX-PARA
            perTaxPara[taxEntity.intValue()] = taxCppSum[taxEntity.intValue()];// L:5318 MOVE TAX-CPP-SUM (TAX-ENTITY) TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = "F";          // L:5319 MOVE "F" TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        taxFlgWs = perTaxFlgLoc;                            // L:5320 MOVE PER-TAX-FLG-LOC TO TAX-FLG-WS
        calculateTax_300_190();                             // L:5321 PERFORM 300-190-CALCULATE-TAX
        if ("y".equals(taxParaYn)) {                        // L:5322 IF TAX-PARA-YN = "Y"
            perTaxPara[taxEntity.intValue()] = holdTaxPara; // L:5323 MOVE HOLD-TAX-PARA TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = holdPerTaxFlg;// L:5324 MOVE HOLD-PER-TAX-FLG TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        // 300-120-EXIT. EXIT.                              // L:5326 CODE
    }

    private void cityTax_300_124() {                        // L:5332 300-124-CITY-TAX
        grossCityWages_300_235();                           // L:5333 PERFORM 300-235-GROSS-CITY-WAGES
        tblWorkKey = "";                                    // L:5334 MOVE SPACES TO TBL-WORK-KEY
        cdeTaxWs = perCdeCit;                               // L:5335 MOVE PER-CDE-CIT TO CDE-TAX-WS
        citLiteral = perCdeCit;                             // L:5335 MOVE PER-CDE-CIT TO CIT-LITERAL
        cdeMarStatusWs = holdMarStatCit;                    // L:5337 MOVE HOLD-MAR-STAT-CIT TO CDE-MAR-STATUS-WS
        taxEntity = BigDecimal.valueOf(4);                  // L:5338 MOVE 4 TO TAX-ENTITY
        taxParaYn = "N";                                    // L:5339 MOVE "N" TO TAX-PARA-YN
        holdTaxPara = BigDecimal.ZERO;                      // L:5340 INITIALIZE HOLD-TAX-PARA.
        if (taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:5341 IF TAX-CPP-SUM (TAX-ENTITY) NOT = ZEROS
            taxParaYn = "Y";                                // L:5342 MOVE "Y" TO TAX-PARA-YN
            holdPerTaxFlg = perTaxFlg[taxEntity.intValue()];// L:5343 MOVE PER-TAX-FLG (TAX-ENTITY) TO HOLD-PER-TAX-FLG
            holdTaxPara = perTaxPara[taxEntity.intValue()]; // L:5344 MOVE PER-TAX-PARA (TAX-ENTITY) TO HOLD-TAX-PARA
            perTaxPara[taxEntity.intValue()] = taxCppSum[taxEntity.intValue()];// L:5345 MOVE TAX-CPP-SUM (TAX-ENTITY) TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = "F";          // L:5346 MOVE "F" TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        taxFlgWs = perTaxFlgCit;                            // L:5347 MOVE PER-TAX-FLG-CIT TO TAX-FLG-WS
        calculateTax_300_190();                             // L:5348 PERFORM 300-190-CALCULATE-TAX
        if ("y".equals(taxParaYn)) {                        // L:5349 IF TAX-PARA-YN = "Y"
            perTaxPara[taxEntity.intValue()] = holdTaxPara; // L:5350 MOVE HOLD-TAX-PARA TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = holdPerTaxFlg;// L:5351 MOVE HOLD-PER-TAX-FLG TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        // 300-124-EXIT. EXIT.                              // L:5353 CODE
    }

    private void otherTax_300_126() {                       // L:5355 300-126-OTHER-TAX
        grossOtherWages_300_240();                          // L:5356 PERFORM 300-240-GROSS-OTHER-WAGES
        tblWorkKey = "";                                    // L:5357 MOVE SPACES TO TBL-WORK-KEY
        cdeTaxWs = perCdeOth;                               // L:5358 MOVE PER-CDE-OTH TO CDE-TAX-WS
        othLiteral = perCdeOth;                             // L:5358 MOVE PER-CDE-OTH TO OTH-LITERAL
        cdeMarStatusWs = holdMarStatOth;                    // L:5360 MOVE HOLD-MAR-STAT-OTH TO CDE-MAR-STATUS-WS
        taxEntity = BigDecimal.valueOf(5);                  // L:5361 MOVE 5 TO TAX-ENTITY
        taxParaYn = "N";                                    // L:5362 MOVE "N" TO TAX-PARA-YN
        holdTaxPara = BigDecimal.ZERO;                      // L:5363 INITIALIZE HOLD-TAX-PARA.
        if (taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:5364 IF TAX-CPP-SUM (TAX-ENTITY) NOT = ZEROS
            taxParaYn = "Y";                                // L:5365 MOVE "Y" TO TAX-PARA-YN
            holdPerTaxFlg = perTaxFlg[taxEntity.intValue()];// L:5366 MOVE PER-TAX-FLG (TAX-ENTITY) TO HOLD-PER-TAX-FLG
            holdTaxPara = perTaxPara[taxEntity.intValue()]; // L:5367 MOVE PER-TAX-PARA (TAX-ENTITY) TO HOLD-TAX-PARA
            perTaxPara[taxEntity.intValue()] = taxCppSum[taxEntity.intValue()];// L:5368 MOVE TAX-CPP-SUM (TAX-ENTITY) TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = "F";          // L:5369 MOVE "F" TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        taxFlgWs = perTaxFlgOth;                            // L:5370 MOVE PER-TAX-FLG-OTH TO TAX-FLG-WS
        calculateTax_300_190();                             // L:5371 PERFORM 300-190-CALCULATE-TAX
        if ("y".equals(taxParaYn)) {                        // L:5372 IF TAX-PARA-YN = "Y"
            perTaxPara[taxEntity.intValue()] = holdTaxPara; // L:5373 MOVE HOLD-TAX-PARA TO PER-TAX-PARA(TAX-ENTITY)
            perTaxFlg[taxEntity.intValue()] = holdPerTaxFlg;// L:5374 MOVE HOLD-PER-TAX-FLG TO PER-TAX-FLG(TAX-ENTITY)
        }  // period ends IF scope
        // 300-126-EXIT. EXIT.                              // L:5376 CODE
        // /                                                // L:5379 COMMENT
        // 037290* ADD UP DEDUCTION AMOUNTS WHICH A...      // L:5381 COMMENT
        // 037300* LOC, CIT, OTH, FICA.  IGNORE FN ...      // L:5382 COMMENT
        // 037310* CANNOT BE PRE-CALCULATED.  IGNOR...      // L:5383 COMMENT
        // 037320* EFFECT GROSS, NET, OR TAXES.             // L:5384 COMMENT
        // 037330**********************************...      // L:5386 COMMENT
        // 037340*                                          // L:5387 COMMENT
    }

    private void nontaxblLookup_300_130() {                 // L:5388 300-130-NONTAXBL-LOOKUP
        // 037350*    DISPLAY "IN 300-130-NONTAXBL-...      // L:5389 COMMENT
        if ((dedNoSum[i.intValue()] != "") && (dedNoToTakeSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) && (!"y".equals(dedErrSum[i.intValue()])) && (!"fd".equals(dedParaSum[i.intValue()]) && !"fn".equals(dedParaSum[i.intValue()]) && !"ec".equals(dedParaSum[i.intValue()]) && !"eh".equals(dedParaSum[i.intValue()])) && ((("n".equals(dedTaxblFed[i.intValue()]) || "a".equals(dedTaxblFed[i.intValue()]))) || (("n".equals(dedTaxblStt[i.intValue()]) || "a".equals(dedTaxblStt[i.intValue()]))) || (("n".equals(dedTaxblLoc[i.intValue()]) || "a".equals(dedTaxblLoc[i.intValue()]))) || (("n".equals(dedTaxblCit[i.intValue()]) || "a".equals(dedTaxblCit[i.intValue()]))) || (("n".equals(dedTaxblOth[i.intValue()]) || "a".equals(dedTaxblOth[i.intValue()]))) || (("n".equals(dedTaxblFica[i.intValue()]) || "a".equals(dedTaxblFica[i.intValue()]))) || (("n".equals(dedTaxblEic[i.intValue()]) || "a".equals(dedTaxblEic[i.intValue()]))))) {// L:5390 037360     IF (DED-NO-SUM(I) NOT = SPACE...
            calculateNontaxbl_300_134();                    // L:5412 PERFORM 300-134-CALCULATE-NONTAXBL
            // 037560*                                      // L:5413 COMMENT
            // 037570*                                      // L:5414 COMMENT
        }  // auto-close unclosed IF
    }

    private void calculateNontaxbl_300_134() {              // L:5415 300-134-CALCULATE-NONTAXBL
        if ("y".equals(cln4K90RegOptWs) && (("4K90".equals(dedNoSum[i.intValue()]) || "4KPA".equals(dedNoSum[i.intValue()]))) && "ts".equals(dedParaSum[i.intValue()])) {// L:5416 037590     IF CLN-4K90-REG-OPT-WS = "Y" ...
            // ADD parse failed: ADD ERN-CPP-SUM(1), ERN-CPP-SUM(2),// L:5421 037640        ADD ERN-CPP-SUM(1), ERN-CP...
        } else {                                            // L:5423 ELSE
            ernDedGrossWs = ernCppGrossSum;                 // L:5424 MOVE ERN-CPP-GROSS-SUM TO ERN-DED-GROSS-WS
            okFlag = okLit;                                 // L:5425 MOVE OK-LIT TO OK-FLAG
            dedAmtWs = BigDecimal.ZERO;                     // L:5426 MOVE ZERO TO DED-AMT-WS
            if (dedPctSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:5427 037700     IF DED-PCT-SUM(I) NOT = ZERO ...
                // DIVIDE parse failed: DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING DED-PCT-WS// L:5428 037710        DIVIDE DED-PCT-SUM(I) BY 1...
                // 037720*¢¢¢¢   MULTIPLY DED-PCT-WS BY ERN...// L:5429 COMMENT
                pctTotEarnWs = pctTotEarnWs.multiply(dedPctWs);// L:5431 037720        MULTIPLY DED-PCT-WS BY PCT...
                dedAmtWs = BigDecimal.ZERO;                 // L:5434 MOVE ZERO TO DED-AMT-WS
                if (dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:5435 037760     IF DED-AMT-SUM(I) NOT = ZERO ...
                    dedAmtWs = dedAmtSum[i.intValue()];     // L:5436 MOVE DED-AMT-SUM(I) TO DED-AMT-WS
                    if ("te".equals(dedParaSum[i.intValue()])) {// L:5438 IF DED-PARA-SUM(I) = "TE"               ...
                        if ((dedOptSum[i.intValue()].compareTo(BigDecimal.ZERO) > 0 && dedOptSum[i.intValue()].compareTo(BigDecimal.valueOf(100)) <= 0)) {// L:5439 IF (DED-OPT-SUM(I) > ZERO AND DED-OPT-SU...
                            dedMaxWs = BigDecimal.valueOf(99999.99);// L:5440 MOVE 99999.99 TO DED-MAX-WS
                            // DIVIDE parse failed: DIVIDE DED-OPT-SUM(I) BY 100.00 GIVING TE-OPT-PCT-WS// L:5441 DIVIDE DED-OPT-SUM(I) BY 100.00 GIVING T...
                            pctTotEarnWs = pctTotEarnWs.multiply(teOptPctWs);// L:5442 MULTIPLY TE-OPT-PCT-WS BY PCT-TOT-EARN-W...
                            dedMaxWs = BigDecimal.ZERO;     // L:5445 MOVE ZERO TO DED-MAX-WS
                            endMultiply = BigDecimal.ZERO;  // L:5445 MOVE ZERO TO END-MULTIPLY
                            if (dedMaxWs.compareTo(dedAmtWs) < 0) {// L:5451 IF DED-MAX-WS < DED-AMT-WS              ...
                                dedAmtWs = dedMaxWs;        // L:5457 MOVE DED-MAX-WS TO DED-AMT-WS
                                dedAmtSum[i.intValue()] = dedAmtWs;// L:5458 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                            }                               // L:5460 END-IF
                        }                                   // L:5461 END-IF
                    }                                       // L:5462 END-IF
                    // ADD parse failed: ADD DED-NO-TO-TAKE-SUM(I) DED-ARRS-CTR-SUM(I)// L:5464 037780     ADD DED-NO-TO-TAKE-SUM(I) DED...
                    noToTakeWs = noToTakeWs.subtract(dedNoTakenSum[i.intValue()]);// L:5466 037800     SUBTRACT DED-NO-TAKEN-SUM(I) ...
                    if (noToTakeWs.compareTo(BigDecimal.ZERO) < 0) {// L:5467 037810     IF NO-TO-TAKE-WS < ZERO MOVE ...
                        dedAmtWs = dedAmtWs.multiply(noToTakeWs);// L:5468 037820     MULTIPLY NO-TO-TAKE-WS BY DED...
                        dedAmtWs = BigDecimal.ZERO;         // L:5471 MOVE ZERO TO DED-AMT-WS
                        if (dedBalSum[i.intValue()].compareTo(BigDecimal.valueOf(99999.99)) != 0) {// L:5481 037860     IF DED-BAL-SUM(I) NOT = 99999...
                            if (dedAmtWs.compareTo(dedBalSum[i.intValue()]) > 0) {// L:5482 037870        IF DED-AMT-WS > DED-BAL-SU...
                                dedAmtWs = dedBalSum[i.intValue()];// L:5483 MOVE DED-BAL-SUM(I) TO DED-AMT-WS
                                if ("ts".equals(dedParaSum[i.intValue()])) {// L:5484 IF DED-PARA-SUM(I) = "TS"
                                    tsaAmountWs = tsaAmountWs.add(dedAmtWs);// L:5485 037890        ADD DED-AMT-WS TO TSA-AMOU...
                                    if ("n".equals(dedTaxblFed[i.intValue()])) {// L:5486 037900     IF DED-TAXBL-FED(I) = "N"    ...
                                        nontaxblFed = nontaxblFed.add(dedAmtWs);// L:5487 037910        ADD DED-AMT-WS TO NONTAXBL...
                                        if ("n".equals(dedTaxblStt[i.intValue()])) {// L:5488 037920     IF DED-TAXBL-STT(I) = "N"    ...
                                            nontaxblStt = nontaxblStt.add(dedAmtWs);// L:5489 037930        ADD DED-AMT-WS TO NONTAXBL...
                                            if ("n".equals(dedTaxblLoc[i.intValue()])) {// L:5490 037940     IF DED-TAXBL-LOC(I) = "N"    ...
                                                nontaxblLoc = nontaxblLoc.add(dedAmtWs);// L:5491 037950        ADD DED-AMT-WS TO NONTAXBL...
                                                if ("n".equals(dedTaxblCit[i.intValue()])) {// L:5492 037960     IF DED-TAXBL-CIT(I) = "N"    ...
                                                    nontaxblCit = nontaxblCit.add(dedAmtWs);// L:5493 037970        ADD DED-AMT-WS TO NONTAXBL...
                                                    if ("n".equals(dedTaxblOth[i.intValue()])) {// L:5494 037980     IF DED-TAXBL-OTH(I) = "N"    ...
                                                        nontaxblOth = nontaxblOth.add(dedAmtWs);// L:5495 037990        ADD DED-AMT-WS TO NONTAXBL...
                                                        if ("n".equals(dedTaxblFica[i.intValue()])) {// L:5496 038000     IF DED-TAXBL-FICA(I) = "N"   ...
                                                            nontaxblFica = nontaxblFica.add(dedAmtWs);// L:5497 038010        ADD DED-AMT-WS TO NONTAXBL...
                                                            if ("n".equals(dedTaxblEic[i.intValue()])) {// L:5498 038000     IF DED-TAXBL-EIC(I) = "N"    ...
                                                                nontaxblEic = nontaxblEic.add(dedAmtWs);// L:5499 038010        ADD DED-AMT-WS TO NONTAXBL...
                                                                if ("a".equals(dedTaxblFed[i.intValue()])) {// L:5500 037900     IF DED-TAXBL-FED(I) = "A"    ...
                                                                    annlTaxblFed = annlTaxblFed.add(dedAmtWs);// L:5501 037910        ADD DED-AMT-WS TO ANNL-TAX...
                                                                    if ("a".equals(dedTaxblStt[i.intValue()])) {// L:5502 037920     IF DED-TAXBL-STT(I) = "A"    ...
                                                                        annlTaxblStt = annlTaxblStt.add(dedAmtWs);// L:5503 037930        ADD DED-AMT-WS TO ANNL-TAX...
                                                                        if ("a".equals(dedTaxblLoc[i.intValue()])) {// L:5504 037940     IF DED-TAXBL-LOC(I) = "A"    ...
                                                                            annlTaxblLoc = annlTaxblLoc.add(dedAmtWs);// L:5505 037950        ADD DED-AMT-WS TO ANNL-TAX...
                                                                            if ("a".equals(dedTaxblCit[i.intValue()])) {// L:5506 037960     IF DED-TAXBL-CIT(I) = "A"    ...
                                                                                annlTaxblCit = annlTaxblCit.add(dedAmtWs);// L:5507 037970        ADD DED-AMT-WS TO ANNL-TAX...
                                                                                if ("a".equals(dedTaxblOth[i.intValue()])) {// L:5508 037980     IF DED-TAXBL-OTH(I) = "A"    ...
                                                                                    annlTaxblOth = annlTaxblOth.add(dedAmtWs);// L:5509 037990        ADD DED-AMT-WS TO ANNL-TAX...
                                                                                    if ("a".equals(dedTaxblFica[i.intValue()])) {// L:5510 038000     IF DED-TAXBL-FICA(I) = "A"   ...
                                                                                        annlTaxblFica = annlTaxblFica.add(dedAmtWs);// L:5511 038010        ADD DED-AMT-WS TO ANNL-TAX...
                                                                                        if ("a".equals(dedTaxblEic[i.intValue()])) {// L:5512 038000     IF DED-TAXBL-EIC(I) = "A"    ...
                                                                                            annlTaxblEic = annlTaxblEic.add(dedAmtWs);// L:5513 038010        ADD DED-AMT-WS TO ANNL-TAX...
                                                                                            // 038020*// L:5514 COMMENT
                                                                                        }  // auto-close unclosed IF
                                                                                    }  // auto-close unclosed IF
                                                                                }  // auto-close unclosed IF
                                                                            }  // auto-close unclosed IF
                                                                        }  // auto-close unclosed IF
                                                                    }  // auto-close unclosed IF
                                                                }  // auto-close unclosed IF
                                                            }  // auto-close unclosed IF
                                                        }  // auto-close unclosed IF
                                                    }  // auto-close unclosed IF
                                                }  // auto-close unclosed IF
                                            }  // auto-close unclosed IF
                                        }  // auto-close unclosed IF
                                    }  // auto-close unclosed IF
                                }  // auto-close unclosed IF
                            }  // auto-close unclosed IF
                        }  // auto-close unclosed IF
                    }  // auto-close unclosed IF
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void error_300_138() {                          // L:5515 300-138-ERROR
        okFlag = notOkLit;                                  // L:5516 MOVE NOT-OK-LIT TO OK-FLAG
        // STRING parse failed (no INTO): STRING "TSA AMOUNT IS > 99999.99 - "...// L:5517 038050     STRING "TSA AMOUNT IS > 99999...
        wsGtnErr = "DE";                                    // L:5521 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:5522 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void error_300_139() {                          // L:5524 300-139-ERROR
        okFlag = notOkLit;                                  // L:5525 MOVE NOT-OK-LIT TO OK-FLAG
        // STRING parse failed (no INTO): STRING "TE OPT AMOUNT IS > 99999.99 - "           ...// L:5526 STRING "TE OPT AMOUNT IS > 99999.99 - " ...
        wsGtnErr = "DE";                                    // L:5530 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:5531 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // /                                                // L:5533 COMMENT
    }

    private void baLookup_300_140() {                       // L:5543 300-140-BA-LOOKUP
        if ((dedNoSum[i.intValue()] != "") && (dedNoToTakeSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) && (!"y".equals(dedErrSum[i.intValue()])) && ("ba".equals(dedParaSum[i.intValue()]))) {// L:5544 IF (DED-NO-SUM(I) NOT = SPACES)
            calculateBa_300_142();                          // L:5551 PERFORM 300-142-CALCULATE-BA THRU 300-142-EXIT
        }  // period ends IF scope
    }

    private void calculateBa_300_142() {                    // L:5553 300-142-CALCULATE-BA
        okFlag = okLit;                                     // L:5554 MOVE OK-LIT TO OK-FLAG
        // DIVIDE parse failed: DIVIDE DED-OPT-SUM(I) BY 100.00 GIVING BA-PCT-WS.            IBM-CT// L:5555 DIVIDE DED-OPT-SUM(I) BY 100.00 GIVING B...
        dedAmtWs = BigDecimal.ZERO;                         // L:5556 MOVE ZERO TO DED-AMT-WS
        dedPctWs = BigDecimal.ZERO;                         // L:5556 MOVE ZERO TO DED-PCT-WS
        if (dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:5557 IF DED-AMT-SUM(I) NOT = ZERO
            dedAmtWs = dedAmtSum[i.intValue()];             // L:5558 MOVE DED-AMT-SUM(I) TO DED-AMT-WS
        }  // period ends IF scope
        if (dedPctSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:5559 IF DED-PCT-SUM(I) NOT = ZERO
            // DIVIDE parse failed: DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING DED-PCT-WS         IBM-CT// L:5560 DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING D...
            pctTotEarnWs = pctTotEarnWs.multiply(dedPctWs); // L:5562 MULTIPLY DED-PCT-WS BY PCT-TOT-EARN-WS  ...
            dedAmtWs = BigDecimal.ZERO;                     // L:5565 MOVE ZERO TO DED-AMT-WS
        }  // period ends IF scope
        // ADD parse failed: ADD DED-NO-TO-TAKE-SUM(I) DED-ARRS-CTR-SUM(I)// L:5566 ADD DED-NO-TO-TAKE-SUM(I) DED-ARRS-CTR-S...
        noToTakeWs = noToTakeWs.subtract(dedNoTakenSum[i.intValue()]);// L:5568 SUBTRACT DED-NO-TAKEN-SUM(I) FROM NO-TO-...
        if (noToTakeWs.compareTo(BigDecimal.ZERO) < 0) {    // L:5569 IF NO-TO-TAKE-WS < ZERO MOVE ZERO TO NO-...
            dedAmtWs = dedAmtWs.multiply(noToTakeWs);       // L:5570 MULTIPLY NO-TO-TAKE-WS BY DED-AMT-WS
            dedAmtWs = BigDecimal.ZERO;                     // L:5573 MOVE ZERO TO DED-AMT-WS
        }  // period ends IF scope
        if (dedBalSum[i.intValue()].compareTo(BigDecimal.valueOf(99999.99)) != 0) {// L:5574 IF DED-BAL-SUM(I) NOT = 99999.99
            if (dedAmtWs.compareTo(dedBalSum[i.intValue()]) > 0) {// L:5575 IF DED-AMT-WS > DED-BAL-SUM(I)
                dedAmtWs = dedBalSum[i.intValue()];         // L:5576 MOVE DED-BAL-SUM(I) TO DED-AMT-WS
            }  // period ends IF scope
        }  // period ends IF scope
        baAmountWs = dedAmtWs;                              // L:5577 MOVE DED-AMT-WS TO BA-AMOUNT-WS
        dedNoTakenSum[i.intValue()] = noToTakeWs;           // L:5578 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
        dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;      // L:5579 MOVE 0 TO DED-ARRS-CTR-SUM(I)
        // 300-142-EXIT. EXIT.                              // L:5581 CODE
    }

    private void error_300_148() {                          // L:5584 300-148-ERROR
        okFlag = notOkLit;                                  // L:5585 MOVE NOT-OK-LIT TO OK-FLAG
        // STRING parse failed (no INTO): STRING "BEN AMOUNT IS > 99999.99 - "...// L:5586 STRING "BEN AMOUNT IS > 99999.99 - "
        wsGtnErr = "DE";                                    // L:5590 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:5591 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // 300-148-EXIT. EXIT.                              // L:5592 CODE
    }

    private void locateBaCode_300_150() {                   // L:5603 300-150-LOCATE-BA-CODE
        zeroYn = "Y";                                       // L:5604 MOVE "Y" TO ZERO-YN
        scanCode_200_187();                                 // L:5605 PERFORM 200-187-SCAN-CODE THRU 200-187-EXIT
        if ("n".equals(zeroYn)) {                           // L:5609 IF ZERO-YN = "N"
            if (baAmountWs.compareTo(BigDecimal.ZERO) != 0) {// L:5610 IF BA-AMOUNT-WS NOT = 0
                findCode_300_155();                         // L:5611 PERFORM 300-155-FIND-CODE THRU 300-155-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
    }

    private void findCode_300_155() {                       // L:5613 300-155-FIND-CODE
        if ((clnBaDeductOptWs.compareTo(BigDecimal.valueOf(1)) < 0 || clnBaDeductOptWs.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:5614 IF (CLN-BA-DEDUCT-OPT-WS < 1 OR > 33)
            clnBaDeductOptWs = BigDecimal.valueOf(26);      // L:5615 MOVE 26 TO CLN-BA-DEDUCT-OPT-WS
        }  // period ends IF scope
        findIndex_300_158();                                // L:5616 PERFORM 300-158-FIND-INDEX
        if ((l.compareTo(BigDecimal.valueOf(1)) < 0 || l.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:5625 IF (L < 1 OR L > 33)
            messageO = "DISTRIBUTION TABLE OVERFLOW-BA DED.";// L:5626 MOVE "DISTRIBUTION TABLE OVERFLOW-BA DED." TO MESSAGE-O
            wsGtnErr = "CD";                                // L:5627 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:5628 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        } else {                                            // L:5629 ELSE
            corpWrkDist[l.intValue()] = BigDecimal.valueOf(perCorpNo);// L:5630 MOVE PER-CORP-NO TO CORP-WRK-DIST(L)
            storeWrkDist[l.intValue()] = BigDecimal.valueOf(perStoreNo);// L:5631 MOVE PER-STORE-NO TO STORE-WRK-DIST(L)
            deptWrkDist[l.intValue()] = BigDecimal.valueOf(perDeptNo);// L:5632 MOVE PER-DEPT-NO TO DEPT-WRK-DIST(L)
            amountDist[l.intValue()] = amountDist[l.intValue()].add(baAmountWs);// L:5633 ADD BA-AMOUNT-WS TO AMOUNT-DIST(L).
        }  // period ends IF scope
        m = clnBaDeductOptWs;                               // L:5634 MOVE CLN-BA-DEDUCT-OPT-WS TO M
        ernCppSum[m.intValue()] = ernCppSum[m.intValue()].add(baAmountWs);// L:5635 ADD BA-AMOUNT-WS TO ERN-CPP-SUM(M).
        findIndex_300_188();                                // L:5636 PERFORM 300-188-FIND-INDEX
        if ((k.compareTo(BigDecimal.valueOf(1)) < 0 || k.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:5647 IF (K < 1 OR K > 33)
            messageO = "EARNINGS TABLE OVERFLOW-BA DED.";   // L:5648 MOVE "EARNINGS TABLE OVERFLOW-BA DED." TO MESSAGE-O
            wsGtnErr = "CD";                                // L:5649 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:5650 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        } else {                                            // L:5651 ELSE
            corpWrkTrn[k.intValue()] = BigDecimal.valueOf(perCorpNo);// L:5652 MOVE PER-CORP-NO TO CORP-WRK-TRN(K)
            storeWrkTrn[k.intValue()] = BigDecimal.valueOf(perStoreNo);// L:5653 MOVE PER-STORE-NO TO STORE-WRK-TRN(K)
            deptWrkTrn[k.intValue()] = BigDecimal.valueOf(perDeptNo);// L:5654 MOVE PER-DEPT-NO TO DEPT-WRK-TRN(K)
            typeTrn[k.intValue()] = "EE";                   // L:5655 MOVE "EE" TO TYPE-TRN(K)
            codeTrn[k.intValue()] = ernCode[clnBaDeductOptWs.intValue()];// L:5656 MOVE ERN-CODE(CLN-BA-DEDUCT-OPT-WS) TO CODE-TRN(K)
            seqTrn[k.intValue()] = clnBaDeductOptWs;        // L:5657 MOVE CLN-BA-DEDUCT-OPT-WS TO SEQ-TRN(K)
            amountTrn[k.intValue()] = amountTrn[k.intValue()].add(baAmountWs);// L:5658 ADD BA-AMOUNT-WS TO AMOUNT-TRN(K).
        }  // period ends IF scope
        // 300-155-EXIT. EXIT.                              // L:5659 CODE
    }

    private void findIndex_300_158() {                      // L:5661 300-158-FIND-INDEX
        // /                                                // L:5662 COMMENT
    }

    private void benLookup_300_170() {                      // L:5671 300-170-BEN-LOOKUP
        if ((dedNoSum[i.intValue()] != "") && (dedNoToTakeSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) && (!"y".equals(dedErrSum[i.intValue()])) && ("be".equals(dedParaSum[i.intValue()]))) {// L:5672 IF (DED-NO-SUM(I) NOT = SPACES)
            calculateBen_300_171();                         // L:5679 PERFORM 300-171-CALCULATE-BEN THRU 300-171-EXIT
        }  // period ends IF scope
    }

    private void calculateBen_300_171() {                   // L:5681 300-171-CALCULATE-BEN
        okFlag = okLit;                                     // L:5682 MOVE OK-LIT TO OK-FLAG
        dedAmtWs = BigDecimal.ZERO;                         // L:5683 MOVE ZERO TO DED-AMT-WS
        if (dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:5684 IF DED-AMT-SUM(I) NOT = ZERO
            dedAmtWs = dedAmtSum[i.intValue()];             // L:5685 MOVE DED-AMT-SUM(I) TO DED-AMT-WS
        }  // period ends IF scope
        if (dedPctSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:5686 IF DED-PCT-SUM(I) NOT = ZERO
            // DIVIDE parse failed: DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING DED-PCT-WS         IBM-CT// L:5687 DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING D...
            pctTotEarnWs = pctTotEarnWs.multiply(dedPctWs); // L:5689 MULTIPLY DED-PCT-WS BY PCT-TOT-EARN-WS  ...
            dedAmtWs = BigDecimal.ZERO;                     // L:5692 MOVE ZERO TO DED-AMT-WS
        }  // period ends IF scope
        // ADD parse failed: ADD DED-NO-TO-TAKE-SUM(I) DED-ARRS-CTR-SUM(I)// L:5693 ADD DED-NO-TO-TAKE-SUM(I) DED-ARRS-CTR-S...
        noToTakeWs = noToTakeWs.subtract(dedNoTakenSum[i.intValue()]);// L:5695 SUBTRACT DED-NO-TAKEN-SUM(I) FROM NO-TO-...
        if (noToTakeWs.compareTo(BigDecimal.ZERO) < 0) {    // L:5696 IF NO-TO-TAKE-WS < ZERO MOVE ZERO TO NO-...
            dedAmtWs = dedAmtWs.multiply(noToTakeWs);       // L:5697 MULTIPLY NO-TO-TAKE-WS BY DED-AMT-WS
            dedAmtWs = BigDecimal.ZERO;                     // L:5700 MOVE ZERO TO DED-AMT-WS
        }  // period ends IF scope
        if (dedBalSum[i.intValue()].compareTo(BigDecimal.valueOf(99999.99)) != 0) {// L:5701 IF DED-BAL-SUM(I) NOT = 99999.99
            if (dedAmtWs.compareTo(dedBalSum[i.intValue()]) > 0) {// L:5702 IF DED-AMT-WS > DED-BAL-SUM(I)
                dedAmtWs = dedBalSum[i.intValue()];         // L:5703 MOVE DED-BAL-SUM(I) TO DED-AMT-WS
            }  // period ends IF scope
        }  // period ends IF scope
        benAmountWs = benAmountWs.add(dedAmtWs);            // L:5704 ADD DED-AMT-WS TO BEN-AMOUNT-WS.
        // 300-171-EXIT. EXIT.                              // L:5705 CODE
    }

    private void error_300_178() {                          // L:5707 300-178-ERROR
        okFlag = notOkLit;                                  // L:5708 MOVE NOT-OK-LIT TO OK-FLAG
        // STRING parse failed (no INTO): STRING "BEN AMOUNT IS > 99999.99 - "...// L:5709 STRING "BEN AMOUNT IS > 99999.99 - "
        wsGtnErr = "DE";                                    // L:5713 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:5714 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // 300-178-EXIT. EXIT.                              // L:5715 CODE
    }

    private void locateBenCode_300_180() {                  // L:5726 300-180-LOCATE-BEN-CODE
        zeroYn = "Y";                                       // L:5727 MOVE "Y" TO ZERO-YN
        scanCode_200_187();                                 // L:5728 PERFORM 200-187-SCAN-CODE THRU 200-187-EXIT
        if ("n".equals(zeroYn)) {                           // L:5732 IF ZERO-YN = "N"
            if (benAmountWs.compareTo(BigDecimal.ZERO) != 0) {// L:5733 IF BEN-AMOUNT-WS NOT = 0
                findCode_300_185();                         // L:5734 PERFORM 300-185-FIND-CODE THRU 300-185-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
    }

    private void findCode_300_185() {                       // L:5736 300-185-FIND-CODE
        if ((clnBenDeductOptWs.compareTo(BigDecimal.valueOf(1)) < 0 || clnBenDeductOptWs.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:5737 IF (CLN-BEN-DEDUCT-OPT-WS < 1 OR > 33)
            clnBenDeductOptWs = BigDecimal.valueOf(26);     // L:5738 MOVE 26 TO CLN-BEN-DEDUCT-OPT-WS
        }  // period ends IF scope
        findIndex_300_188();                                // L:5739 PERFORM 300-188-FIND-INDEX
        if ((l.compareTo(BigDecimal.valueOf(1)) < 0 || l.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:5748 IF (L < 1 OR L > 33)
            messageO = "DISTRIBUTION TABLE OVERFLOW-BE DED.";// L:5749 MOVE "DISTRIBUTION TABLE OVERFLOW-BE DED." TO MESSAGE-O
            wsGtnErr = "CD";                                // L:5750 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:5751 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        } else {                                            // L:5752 ELSE
            corpWrkDist[l.intValue()] = BigDecimal.valueOf(perCorpNo);// L:5753 MOVE PER-CORP-NO TO CORP-WRK-DIST(L)
            storeWrkDist[l.intValue()] = BigDecimal.valueOf(perStoreNo);// L:5754 MOVE PER-STORE-NO TO STORE-WRK-DIST(L)
            deptWrkDist[l.intValue()] = BigDecimal.valueOf(perDeptNo);// L:5755 MOVE PER-DEPT-NO TO DEPT-WRK-DIST(L)
            amountDist[l.intValue()] = amountDist[l.intValue()].add(benAmountWs);// L:5756 ADD BEN-AMOUNT-WS TO AMOUNT-DIST(L).
        }  // period ends IF scope
        m = clnBenDeductOptWs;                              // L:5757 MOVE CLN-BEN-DEDUCT-OPT-WS TO M
        ernCppSum[m.intValue()] = ernCppSum[m.intValue()].add(benAmountWs);// L:5758 ADD BEN-AMOUNT-WS TO ERN-CPP-SUM(M).
        findIndex_300_188();                                // L:5759 PERFORM 300-188-FIND-INDEX
        if ((k.compareTo(BigDecimal.valueOf(1)) < 0 || k.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:5770 IF (K < 1 OR K > 33)
            messageO = "EARNINGS TABLE OVERFLOW-BE DED.";   // L:5771 MOVE "EARNINGS TABLE OVERFLOW-BE DED." TO MESSAGE-O
            wsGtnErr = "CD";                                // L:5772 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:5773 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        } else {                                            // L:5774 ELSE
            corpWrkTrn[k.intValue()] = BigDecimal.valueOf(perCorpNo);// L:5775 MOVE PER-CORP-NO TO CORP-WRK-TRN(K)
            storeWrkTrn[k.intValue()] = BigDecimal.valueOf(perStoreNo);// L:5776 MOVE PER-STORE-NO TO STORE-WRK-TRN(K)
            deptWrkTrn[k.intValue()] = BigDecimal.valueOf(perDeptNo);// L:5777 MOVE PER-DEPT-NO TO DEPT-WRK-TRN(K)
            typeTrn[k.intValue()] = "EE";                   // L:5778 MOVE "EE" TO TYPE-TRN(K)
            codeTrn[k.intValue()] = ernCode[clnBenDeductOptWs.intValue()];// L:5779 MOVE ERN-CODE(CLN-BEN-DEDUCT-OPT-WS) TO CODE-TRN(K)
            seqTrn[k.intValue()] = clnBenDeductOptWs;       // L:5780 MOVE CLN-BEN-DEDUCT-OPT-WS TO SEQ-TRN(K)
            amountTrn[k.intValue()] = amountTrn[k.intValue()].add(benAmountWs);// L:5781 ADD BEN-AMOUNT-WS TO AMOUNT-TRN(K).
        }  // period ends IF scope
        // 300-185-EXIT. EXIT.                              // L:5782 CODE
    }

    private void findIndex_300_188() {                      // L:5784 300-188-FIND-INDEX
        // /                                                // L:5785 COMMENT
    }

    private void calculateTax_300_190() {                   // L:5786 300-190-CALCULATE-TAX
        initialize_300_191();                               // L:5796 PERFORM 300-191-INITIALIZE
        if (taxEntity.compareTo(BigDecimal.valueOf(1)) == 0 && "n".equals(perTaxFlgFed)) {// L:5797 IF TAX-ENTITY = 1                       ...
            annualWageWs = annualWageWs.add(BigDecimal.valueOf(2650));// L:5799 ADD 2650 TO ANNUAL-WAGE-WS.             ...
            if (taxEntity.compareTo(BigDecimal.valueOf(1)) == 0) {// L:5802 IF TAX-ENTITY = 1                       ...
                getTfw4Info_666();                          // L:5804 PERFORM 666-GET-TFW4-INFO
                if ("y".equals(w40004)) {                   // L:5805 IF W40004 = "Y"                         ...
                    taxableWageWs = annualWageWs;           // L:5807 MOVE ANNUAL-WAGE-WS TO TAXABLE-WAGE-WS
                    if ("y".equals(w40005)) {               // L:5809 IF W40005 = "Y"                         ...
                        taxFlgWs = "E";                     // L:5810 MOVE "E" TO TAX-FLG-WS
                    } else {                                // L:5811 ELSE
                        taxFlgWs = perTaxFlgFed;            // L:5812 MOVE PER-TAX-FLG-FED TO TAX-FLG-WS
                    }                                       // L:5813 END-IF
                    if ("y".equals(w40007)) {               // L:5814 IF W40007 = "Y"                         ...
                        cdeTaxWs = "FWT2";                  // L:5816 MOVE "FWT2" TO CDE-TAX-WS
                    } else {                                // L:5817 ELSE
                        cdeTaxWs = "FWT";                   // L:5819 MOVE "FWT" TO CDE-TAX-WS
                    }                                       // L:5820 END-IF
                    holdMarStatFed = w40006;                // L:5823 MOVE W40006 TO HOLD-MAR-STAT-FED
                    cdeMarStatusWs = holdMarStatFed;        // L:5824 MOVE HOLD-MAR-STAT-FED TO CDE-MAR-STATUS-WS
                }                                           // L:5827 END-IF
            }                                               // L:5828 END-IF
            if (taxEntity.compareTo(BigDecimal.valueOf(3)) == 0) {// L:5831 IF TAX-ENTITY = 3                       ...
                if (!"s".equals(cdeMarStatusWs)) {          // L:5832 IF CDE-MAR-STATUS-WS NOT = "S"          ...
                    martn = "";                             // L:5833 MOVE SPACES TO MARTN
                    ma0001 = cdeTaxWs;                      // L:5834 MOVE CDE-TAX-WS TO MA0001
                    ma0002 = cdeMarStatusWs;                // L:5835 MOVE CDE-MAR-STATUS-WS TO MA0002
                    ma0003 = "TL";                          // L:5836 MOVE "TL" TO MA0003
                    ma0004 = "N";                           // L:5837 MOVE "N" TO MA0004
                    // CALL PYFWXFK                         // L:5838 CALL "PYFWXFK" USING                    ...
                    callPyfwxfk();
                    if ("y".equals(ma0004)) {               // L:5845 IF MA0004 = "Y"                         ...
                        cdeMarStatusWs = "S";               // L:5846 MOVE "S" TO CDE-MAR-STATUS-WS
                    }                                       // L:5847 END-IF
                }                                           // L:5848 END-IF
            }                                               // L:5849 END-IF
            if (taxEntity.compareTo(BigDecimal.valueOf(4)) == 0) {// L:5850 IF TAX-ENTITY = 4                       ...
                if (!"s".equals(cdeMarStatusWs)) {          // L:5851 IF CDE-MAR-STATUS-WS NOT = "S"          ...
                    martn = "";                             // L:5852 MOVE SPACES TO MARTN
                    ma0001 = cdeTaxWs;                      // L:5853 MOVE CDE-TAX-WS TO MA0001
                    ma0002 = cdeMarStatusWs;                // L:5854 MOVE CDE-MAR-STATUS-WS TO MA0002
                    ma0003 = "TC";                          // L:5855 MOVE "TC" TO MA0003
                    ma0004 = "N";                           // L:5856 MOVE "N" TO MA0004
                    // CALL PYFWXFK                         // L:5857 CALL "PYFWXFK" USING                    ...
                    callPyfwxfk();
                    if ("y".equals(ma0004)) {               // L:5864 IF MA0004 = "Y"                         ...
                        cdeMarStatusWs = "S";               // L:5865 MOVE "S" TO CDE-MAR-STATUS-WS
                    }                                       // L:5866 END-IF
                }                                           // L:5867 END-IF
            }                                               // L:5868 END-IF
            if (taxEntity.compareTo(BigDecimal.valueOf(5)) == 0) {// L:5869 IF TAX-ENTITY = 5                       ...
                if (!"s".equals(cdeMarStatusWs)) {          // L:5870 IF CDE-MAR-STATUS-WS NOT = "S"          ...
                    martn = "";                             // L:5871 MOVE SPACES TO MARTN
                    ma0001 = cdeTaxWs;                      // L:5872 MOVE CDE-TAX-WS TO MA0001
                    ma0002 = cdeMarStatusWs;                // L:5873 MOVE CDE-MAR-STATUS-WS TO MA0002
                    ma0003 = "TO";                          // L:5874 MOVE "TO" TO MA0003
                    ma0004 = "N";                           // L:5875 MOVE "N" TO MA0004
                    // CALL PYFWXFK                         // L:5876 CALL "PYFWXFK" USING                    ...
                    callPyfwxfk();
                    if ("y".equals(ma0004)) {               // L:5883 IF MA0004 = "Y"                         ...
                        cdeMarStatusWs = "S";               // L:5884 MOVE "S" TO CDE-MAR-STATUS-WS
                    }                                       // L:5885 END-IF
                }                                           // L:5886 END-IF
            }                                               // L:5887 END-IF
        }  // period ends IF scope
        taxTableSearch_300_192();                           // L:5896 PERFORM 300-192-TAX-TABLE-SEARCH
        if (taxEntity.compareTo(BigDecimal.valueOf(1)) == 0 && "n".equals(perTaxFlgFed)) {// L:5897 IF TAX-ENTITY = 1                       ...
            annualWageWs = annualWageWs.subtract(BigDecimal.valueOf(2650));// L:5899 SUBTRACT 2650 FROM ANNUAL-WAGE-WS.      ...
            if ((taxRoutineOk && !taxExempt)) {             // L:5900 IF (TAX-ROUTINE-OK
                computeTax_300_198();                       // L:5914 PERFORM 300-198-COMPUTE-TAX
            }  // period ends IF scope
        }  // period ends IF scope
        reduceNet_300_198();                                // L:5927 PERFORM 300-198-REDUCE-NET
    }

    private void initialize_300_191() {                     // L:5929 300-191-INITIALIZE
        taxCppSum[taxEntity.intValue()] = BigDecimal.ZERO;  // L:5931 MOVE ZERO TO TAX-CPP-SUM(TAX-ENTITY)
        lowerWageLimitWs = BigDecimal.ZERO;                 // L:5931 MOVE ZERO TO LOWER-WAGE-LIMIT-WS
        pctExcessWageWs = BigDecimal.ZERO;                  // L:5931 MOVE ZERO TO PCT-EXCESS-WAGE-WS
        flatTaxAmtWs = BigDecimal.ZERO;                     // L:5931 MOVE ZERO TO FLAT-TAX-AMT-WS
        taxLimitYtdWs = BigDecimal.valueOf(99999999.99);    // L:5935 MOVE 99999999.99 TO TAX-LIMIT-YTD-WS
        wageLimitYtdWs = BigDecimal.valueOf(99999999.99);   // L:5935 MOVE 99999999.99 TO WAGE-LIMIT-YTD-WS
        taxLimitCppWs = BigDecimal.valueOf(99999999.99);    // L:5935 MOVE 99999999.99 TO TAX-LIMIT-CPP-WS
        totEarnWs = totEarnWs.subtract(nontaxbl[taxEntity.intValue()]);// L:5943 SUBTRACT NONTAXBL(TAX-ENTITY) FROM TOT-E...
        // DIVIDE invalid target (literal): DIVIDE CDE-CYCLE-NUM-WS INTO 60.00// L:5951 DIVIDE CDE-CYCLE-NUM-WS INTO 60.00
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "mo".equals(cdeTaxWs))) {// L:5960 IF (TAX-ENTITY = 2 AND
            if ("s".equals(cdeMarStatusWs)) {               // L:5962 IF CDE-MAR-STATUS-WS = "S"
                moFedWithLimitS = moFedWithLimitS.divide(cdeCycleNumWs, 10, RoundingMode.HALF_UP);// L:5963 DIVIDE CDE-CYCLE-NUM-WS INTO MO-FED-WITH...
            } else {                                        // L:5965 ELSE
                moFedWithLimitM = moFedWithLimitM.divide(cdeCycleNumWs, 10, RoundingMode.HALF_UP);// L:5966 DIVIDE CDE-CYCLE-NUM-WS INTO MO-FED-WITH...
                if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs))) {// L:5969 IF (TAX-ENTITY = 2 AND
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        tempCdeMarStatusWs = cdeMarStatusWs;                // L:5976 MOVE CDE-MAR-STATUS-WS TO TEMP-CDE-MAR-STATUS-WS
        if ("s".equals(cdeMarStatusWs) && wsPerExemptCnt[taxEntity.intValue()] >= 3) {// L:5980 IF CDE-MAR-STATUS-WS = "S" AND          ...
            tempCdeMarStatusWs = "M";                       // L:5982 MOVE "M" TO TEMP-CDE-MAR-STATUS-WS
            orMarStatusChangeSw = "Y";                      // L:5983 MOVE "Y" TO OR-MAR-STATUS-CHANGE-SW
        }                                                   // L:6016 END-IF
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "mo".equals(cdeTaxWs) && !taxExempt)) {// L:6018 IF (TAX-ENTITY = 2 AND
            taxCppSttSum = taxCppFedSum;                    // L:6021 MOVE TAX-CPP-FED-SUM TO TAX-CPP-STT-SUM
            if (taxCppFedSum.compareTo(moFedLimit) > 0) {   // L:6022 IF TAX-CPP-FED-SUM > MO-FED-LIMIT
                taxCppSttSum = moFedLimit;                  // L:6023 MOVE MO-FED-LIMIT TO TAX-CPP-STT-SUM
            }  // period ends IF scope
        }  // period ends IF scope
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && ("mo".equals(cdeTaxWs)) && !taxExempt)) {// L:6034 IF (TAX-ENTITY = 2 AND
            totEarnWs = totEarnWs.subtract(taxCppEicSum);   // L:6039 SUBTRACT TAX-CPP-EIC-SUM FROM TOT-EARN-W...
            totEarnWs = totEarnWs.subtract(taxCppSttSum);   // L:6040 SUBTRACT TAX-CPP-STT-SUM FROM TOT-EARN-W...
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && ("ia".equals(cdeTaxWs))) {// L:6041 IF TAX-ENTITY = 2
            totEarnWs = totEarnWs.subtract(taxCppEicSum);   // L:6045 SUBTRACT TAX-CPP-EIC-SUM FROM TOT-EARN-W...
            totEarnWs = totEarnWs.subtract(taxCppFedSum);   // L:6046 SUBTRACT TAX-CPP-FED-SUM FROM TOT-EARN-W...
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(5)) == 0 && "pa".equals(perCdeStt) && "mopt".equals(perCdeOth)) {// L:6053 IF TAX-ENTITY = 5
            annualWageWs = totEarnWs.add(totEarnYtdWs);     // L:6058 ADD TOT-EARN-WS TOT-EARN-YTD-WS GIVING A...
            if (annualWageWs.compareTo(paMoptLowWageLimit) <= 0) {// L:6059 IF ANNUAL-WAGE-WS NOT > PA-MOPT-LOW-WAGE...
                totEarnWs = BigDecimal.ZERO;                // L:6060 MOVE 0 TO TOT-EARN-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(5)) == 0 && "pa".equals(perCdeStt) && "sopt".equals(perCdeOth)) {// L:6062 IF TAX-ENTITY = 5
            annualWageWs = totEarnWs.add(totEarnYtdWs);     // L:6067 ADD TOT-EARN-WS TOT-EARN-YTD-WS GIVING A...
            if (annualWageWs.compareTo(paSoptLowWageLimit) <= 0) {// L:6068 IF ANNUAL-WAGE-WS NOT > PA-SOPT-LOW-WAGE...
                totEarnWs = BigDecimal.ZERO;                // L:6069 MOVE 0 TO TOT-EARN-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(5)) == 0 && "pa".equals(perCdeStt) && "sopu".equals(perCdeOth)) {// L:6071 IF TAX-ENTITY = 5
            annualWageWs = totEarnWs.add(totEarnYtdWs);     // L:6076 ADD TOT-EARN-WS TOT-EARN-YTD-WS GIVING A...
            if (annualWageWs.compareTo(paSopuLowWageLimit) <= 0) {// L:6077 IF ANNUAL-WAGE-WS NOT > PA-SOPU-LOW-WAGE...
                totEarnWs = BigDecimal.ZERO;                // L:6078 MOVE 0 TO TOT-EARN-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(5)) == 0 && "pa".equals(perCdeStt) && "copt".equals(perCdeOth)) {// L:6085 IF TAX-ENTITY = 5
            annualWageWs = totEarnWs.add(totEarnYtdWs);     // L:6090 ADD TOT-EARN-WS TOT-EARN-YTD-WS GIVING A...
            if (annualWageWs.compareTo(paCoptLowWageLimit) <= 0) {// L:6091 IF ANNUAL-WAGE-WS NOT > PA-COPT-LOW-WAGE...
                totEarnWs = BigDecimal.ZERO;                // L:6092 MOVE 0 TO TOT-EARN-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(5)) == 0 && "pa".equals(perCdeStt) && "eopt".equals(perCdeOth)) {// L:6094 IF TAX-ENTITY = 5
            annualWageWs = totEarnWs.add(totEarnYtdWs);     // L:6099 ADD TOT-EARN-WS TOT-EARN-YTD-WS GIVING A...
            if (annualWageWs.compareTo(paEoptLowWageLimit) <= 0) {// L:6100 IF ANNUAL-WAGE-WS NOT > PA-EOPT-LOW-WAGE...
                totEarnWs = BigDecimal.ZERO;                // L:6101 MOVE 0 TO TOT-EARN-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(5)) == 0 && "pa".equals(perCdeStt) && "copt".equals(perCdeOth)) {// L:6108 IF TAX-ENTITY = 5
            annualWageWs = totEarnWs.add(totEarnYtdWs);     // L:6113 ADD TOT-EARN-WS TOT-EARN-YTD-WS GIVING A...
            if (annualWageWs.compareTo(paLoptLowWageLimit) <= 0) {// L:6114 IF ANNUAL-WAGE-WS NOT > PA-LOPT-LOW-WAGE...
                totEarnWs = BigDecimal.ZERO;                // L:6115 MOVE 0 TO TOT-EARN-WS
            }  // period ends IF scope
        }  // period ends IF scope
        totEarnWs = totEarnWs.subtract(annlTaxbl[taxEntity.intValue()]);// L:6119 SUBTRACT ANNL-TAXBL(TAX-ENTITY) FROM TOT...
        cdeCycleNumWs = cdeCycleNumWs.multiply(totEarnWs);  // L:6120 MULTIPLY TOT-EARN-WS BY CDE-CYCLE-NUM-WS
        annualWageWs = annualWageWs.add(annlTaxbl[taxEntity.intValue()]);// L:6122 ADD ANNL-TAXBL(TAX-ENTITY) TO ANNUAL-WAG...
        totEarnWs = totEarnWs.add(annlTaxbl[taxEntity.intValue()]);// L:6123 ADD ANNL-TAXBL(TAX-ENTITY) TO TOT-EARN-W...
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ma".equals(perCdeStt)) {// L:6125 IF TAX-ENTITY = 2 AND                   ...
            masttrtn = "";                                  // L:6127 MOVE SPACES TO MASTTRTN
            mast01 = maAnnualTaxCppFicaSum;                 // L:6134 MOVE MA-ANNUAL-TAX-CPP-FICA-SUM TO MAST01
            mast02 = taxYtdFicaWs;                          // L:6135 MOVE TAX-YTD-FICA-WS TO MAST02
            mast03 = wsPerExmStt;                           // L:6136 MOVE WS-PER-EXM-STT TO MAST03
            mast04 = maGrossEarnWs;                         // L:6137 MOVE MA-GROSS-EARN-WS TO MAST04
            mast05 = annualWageWs;                          // L:6138 MOVE ANNUAL-WAGE-WS TO MAST05
            mast06 = "N";                                   // L:6139 MOVE "N" TO MAST06
            // CALL PZALXFK                                 // L:6140 CALL "PZALXFK" USING                    ...
            callPzalxfk();
            annualWageWs = mast05;                          // L:6149 MOVE MAST05 TO ANNUAL-WAGE-WS
            maZeroTaxYn = mast06;                           // L:6151 MOVE MAST06 TO MA-ZERO-TAX-YN
        }                                                   // L:6153 END-IF
        // /                                                // L:6155 COMMENT
    }

    private void taxTableSearch_300_192() {                 // L:6156 300-192-TAX-TABLE-SEARCH
        taxableWageWs = annualWageWs;                       // L:6157 MOVE ANNUAL-WAGE-WS TO TAXABLE-WAGE-WS
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs))) {// L:6158 IF (TAX-ENTITY = 2 AND                  ...
            orrtn = "";                                     // L:6161 MOVE SPACES TO ORRTN
            or0001 = cdeMarStatusWs;                        // L:6162 MOVE CDE-MAR-STATUS-WS TO OR0001
            or0002 = taxableWageWs;                         // L:6164 MOVE TAXABLE-WAGE-WS TO OR0002
            or0003 = "N";                                   // L:6165 MOVE "N" TO OR0003
            or0004 = "N";                                   // L:6167 MOVE "N" TO OR0004
            // CALL PYN4XFK                                 // L:6170 CALL "PYN4XFK" USING                    ...
            callPyn4Xfk();
        }                                                   // L:6179 END-IF
        okFlag = notOkLit;                                  // L:6185 MOVE NOT-OK-LIT TO OK-FLAG
        taxKeyFlag = notOkLit;                              // L:6185 MOVE NOT-OK-LIT TO TAX-KEY-FLAG
        taxRoutineFlag = okLit;                             // L:6186 MOVE OK-LIT TO TAX-ROUTINE-FLAG
        tblIdx = 1;                                         // L:6187 SET TBL-IDX TO 1.
        control_300_194();                                  // L:6189 PERFORM 300-194-CONTROL
        if (taxKeyNotFound) {                               // L:6191 IF TAX-KEY-NOT-FOUND
            taxKeyError_300_198_1();                        // L:6195 PERFORM 300-198-1-TAX-KEY-ERROR
        }  // period ends IF scope
    }

    private void control_300_194() {                        // L:6198 300-194-CONTROL
        if (annualWageWs.compareTo(BigDecimal.valueOf(.1)) < 0) {// L:6199 IF ANNUAL-WAGE-WS < .01
            taxRoutineFlag = notOkLit;                      // L:6200 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            taxKeyFlag = okLit;                             // L:6201 MOVE OK-LIT TO TAX-KEY-FLAG
        } else {                                            // L:6202 ELSE
            if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs))) {// L:6204 IF (TAX-ENTITY = 2 AND                  ...
                lookup_300_114_9();                         // L:6210 PERFORM 300-114-9-LOOKUP
                if ((BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0 || wsTblKey[tblIdx].compareTo(tblWorkKey) > 0)) {// L:6217 IF (TBL-IDX > WS-TBL-IDX-LIMIT          ...
                    taxRoutineFlag = notOkLit;              // L:6220 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
                } else {                                    // L:6222 ELSE
                    taxKeyFlag = okLit;                     // L:6223 MOVE OK-LIT TO TAX-KEY-FLAG
                }                                           // L:6225 END-IF
                if ((taxKeyFound && taxRoutineOk)) {        // L:6226 IF (TAX-KEY-FOUND AND TAX-ROUTINE-OK)   ...
                    cRetCode = "";                          // L:6228 MOVE SPACES TO C-RET-CODE
                    wsOrPaytblpf01Level = wsLevel[tblIdx];  // L:6229 MOVE WS-LEVEL (TBL-IDX) TO WS-OR-PAYTBLPF01-LEVEL
                    wsOrPaytblpf01TaxOption = BigDecimal.valueOf(9);// L:6230 MOVE 009 TO WS-OR-PAYTBLPF01-TAX-OPTION
                    wsOrPaytblpf01TaxOptVal1 = BigDecimal.ZERO;// L:6231 INITIALIZE WS-OR-PAYTBLPF01-TAX-OPT-VAL1...
                    // id145 = default; // INITIALIZE ID-145// L:6231 INITIALIZE WS-OR-PAYTBLPF01-TAX-OPT-VAL1...
                    // CALL PYOPXFK                         // L:6241 CALL "PYOPXFK" USING C-RET-CODE,        ...
                    callPyopxfk();
                    tempOrFedWithLimit = BigDecimal.ZERO;   // L:6250 MOVE ZEROS TO TEMP-OR-FED-WITH-LIMIT
                    if (wsOrPaytblpf01TaxOptVal1.compareTo(BigDecimal.ZERO) != 0) {// L:6251 IF WS-OR-PAYTBLPF01-TAX-OPT-VAL1 NOT = Z...
                        tempOrFedWithLimit = wsOrPaytblpf01TaxOptVal1;// L:6252 MOVE WS-OR-PAYTBLPF01-TAX-OPT-VAL1 TO TEMP-OR-FED-WITH-LIMIT
                    }                                       // L:6257 END-IF
                    orFedLimit = BigDecimal.ZERO;           // L:6258 INITIALIZE OR-FED-LIMIT                 ...
                    // id145 = default; // INITIALIZE ID-145// L:6258 INITIALIZE OR-FED-LIMIT                 ...
                    if (tempOrFedWithLimit.compareTo(BigDecimal.ZERO) != 0) {// L:6259 IF TEMP-OR-FED-WITH-LIMIT NOT = ZEROS   ...
                        orFedLimit = tempOrFedWithLimit;    // L:6264 MOVE TEMP-OR-FED-WITH-LIMIT TO OR-FED-LIMIT
                    } else {                                // L:6265 ELSE
                        orFedWithLimit = orFedWithLimit.divide(cdeCycleNumWs, 10, RoundingMode.HALF_UP);// L:6267 DIVIDE CDE-CYCLE-NUM-WS INTO OR-FED-WITH...
                    }                                       // L:6269 END-IF
                    // COMPUTE parse failed: COMPUTE OR-FED-DEDUCTION-AMT =// L:6275 COMPUTE OR-FED-DEDUCTION-AMT =          ...
                    if (orFedDeductionAmt.compareTo(orFedLimit) > 0) {// L:6280 IF OR-FED-DEDUCTION-AMT > OR-FED-LIMIT  ...
                        orFedDeductionAmt = orFedLimit;     // L:6282 MOVE OR-FED-LIMIT TO OR-FED-DEDUCTION-AMT
                    }                                       // L:6283 END-IF
                    taxableWageWs = taxableWageWs.subtract(orFedDeductionAmt);// L:6285 SUBTRACT OR-FED-DEDUCTION-AMT FROM TAXAB...
                    if ("y".equals(orMarStatusChangeSw)) {  // L:6288 IF OR-MAR-STATUS-CHANGE-SW = "Y"        ...
                        cdeMarStatusWs = tempCdeMarStatusWs;// L:6289 MOVE TEMP-CDE-MAR-STATUS-WS TO CDE-MAR-STATUS-WS
                        lookup_300_114_9();                 // L:6290 PERFORM 300-114-9-LOOKUP
                        if ((BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0 || wsTblKey[tblIdx].compareTo(tblWorkKey) > 0)) {// L:6297 IF (TBL-IDX > WS-TBL-IDX-LIMIT          ...
                            // GO TO OR-CONTINUE - control flow// L:6301 GO TO OR-CONTINUE
                        }                                   // L:6302 END-IF
                    }                                       // L:6303 END-IF
                    // SUBTRACT parse failed: SUBTRACT WS-STD-DED-AMT (TBL-IDX)// L:6307 SUBTRACT WS-STD-DED-AMT (TBL-IDX)       ...
                    wsOrSavedExemptAmt = wsExemptAmt[tblIdx];// L:6315 MOVE WS-EXEMPT-AMT (TBL-IDX) TO WS-OR-SAVED-EXEMPT-AMT
                    cdeMarStatusWs = tempCdeMarStatusWs;    // L:6323 MOVE TEMP-CDE-MAR-STATUS-WS TO CDE-MAR-STATUS-WS
                    lookup_300_196();                       // L:6325 PERFORM 300-196-LOOKUP
                }                                           // L:6332 END-IF
            } else {                                        // L:6333 ELSE
                if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6336 IF (TAX-ENTITY = 2 AND                  ...
                    lookup_300_114_9();                     // L:6343 PERFORM 300-114-9-LOOKUP
                    if ((BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0 || wsTblKey[tblIdx].compareTo(tblWorkKey) > 0)) {// L:6350 IF (TBL-IDX > WS-TBL-IDX-LIMIT          ...
                        taxRoutineFlag = notOkLit;          // L:6353 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
                    } else {                                // L:6356 ELSE
                        taxKeyFlag = okLit;                 // L:6357 MOVE OK-LIT TO TAX-KEY-FLAG
                    }                                       // L:6360 END-IF
                    if ((taxKeyFound && taxRoutineOk)) {    // L:6361 IF (TAX-KEY-FOUND AND TAX-ROUTINE-OK)   ...
                        // SUBTRACT parse failed: SUBTRACT WS-STD-DED-AMT (TBL-IDX)// L:6366 SUBTRACT WS-STD-DED-AMT (TBL-IDX)       ...
                        if (wsPerExemptCnt[taxEntity.intValue()] > 0) {// L:6370 IF WS-PER-EXEMPT-CNT (TAX-ENTITY) > 0   ...
                            // SUBTRACT parse failed: SUBTRACT WS-EXEMPT-AMT (TBL-IDX)// L:6374 SUBTRACT WS-EXEMPT-AMT (TBL-IDX)        ...
                        }                                   // L:6377 END-IF
                        if (wsPerExemptCnt[taxEntity.intValue()] >= 2) {// L:6380 IF WS-PER-EXEMPT-CNT (TAX-ENTITY) >= 2  ...
                            cRetCode = "";                  // L:6383 MOVE SPACES TO C-RET-CODE
                            wsAlPaytblpf01Level = wsLevel[tblIdx];// L:6384 MOVE WS-LEVEL (TBL-IDX) TO WS-AL-PAYTBLPF01-LEVEL
                            wsAlPaytblpf01TaxOption = BigDecimal.valueOf(10);// L:6385 MOVE 010 TO WS-AL-PAYTBLPF01-TAX-OPTION
                            wsAlPaytblpf01TaxOptVal1 = BigDecimal.ZERO;// L:6386 INITIALIZE WS-AL-PAYTBLPF01-TAX-OPT-VAL1...
                            // id502 = default; // INITIALIZE ID-502// L:6386 INITIALIZE WS-AL-PAYTBLPF01-TAX-OPT-VAL1...
                            // CALL PYOPXFK                 // L:6388 CALL "PYOPXFK" USING C-RET-CODE,        ...
                            callPyopxfk();
                            if (wsAlPaytblpf01TaxOptVal1.compareTo(BigDecimal.ZERO) != 0) {// L:6395 IF WS-AL-PAYTBLPF01-TAX-OPT-VAL1 NOT = Z...
                                // COMPUTE parse failed: COMPUTE WS-AL-EXEMPT-AMT =// L:6396 COMPUTE WS-AL-EXEMPT-AMT =              ...
                                // SUBTRACT parse failed: SUBTRACT WS-AL-EXEMPT-AMT// L:6402 SUBTRACT WS-AL-EXEMPT-AMT               ...
                            }                               // L:6405 END-IF
                        }                                   // L:6406 END-IF
                        // COMPUTE incomplete (multi-line): COMPUTE TAXABLE-WAGE-WS = TAXABLE-WAGE-WS -// L:6411 COMPUTE TAXABLE-WAGE-WS = TAXABLE-WAGE-W...
                        lookup_300_196();                   // L:6416 PERFORM 300-196-LOOKUP
                    }                                       // L:6424 END-IF
                } else {                                    // L:6426 ELSE
                    lookup_300_196();                       // L:6427 PERFORM 300-196-LOOKUP
                    // OR-CONTINUE.                            ...// L:6434 CODE
                    if (BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0) {// L:6435 IF TBL-IDX > WS-TBL-IDX-LIMIT
                        taxRoutineFlag = notOkLit;          // L:6436 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        // ID-145                                           // L:6437 CODE
    }

    private void lookup_300_196() {                         // L:6439 300-196-LOOKUP
        if (tblWorkKey == wsTblKey[tblIdx]) {               // L:6440 IF TBL-WORK-KEY = WS-TBL-KEY (TBL-IDX)
            if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs)) {// L:6441 IF TAX-ENTITY = 2 AND CDE-TAX-WS = "OR" ...
                wsOr2NdLevel = wsLevel[tblIdx];             // L:6444 MOVE WS-LEVEL (TBL-IDX) TO WS-OR-2ND-LEVEL
            }                                               // L:6445 END-IF
            if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs)) {// L:6446 IF TAX-ENTITY = 2 AND CDE-TAX-WS = "AL" ...
                if (taxableWageWs.compareTo(BigDecimal.ZERO) < 0) {// L:6448 IF TAXABLE-WAGE-WS < ZERO               ...
                    taxableWageWs = BigDecimal.ZERO;        // L:6450 MOVE ZERO TO TAXABLE-WAGE-WS
                }                                           // L:6451 END-IF
            }                                               // L:6452 END-IF
            taxKeyFlag = okLit;                             // L:6453 MOVE OK-LIT TO TAX-KEY-FLAG
            if (taxableWageWs.compareTo(wsLowerWageLimit[tblIdx]) >= 0) {// L:6454 IF TAXABLE-WAGE-WS NOT < WS-LOWER-WAGE-L...
                exemption_300_197();                        // L:6458 PERFORM 300-197-EXEMPTION
            }  // period ends IF scope
        }  // period ends IF scope
        if (wsTblKey[tblIdx].compareTo(tblWorkKey) > 0) {   // L:6459 IF WS-TBL-KEY (TBL-IDX) > TBL-WORK-KEY
            taxRoutineFlag = notOkLit;                      // L:6461 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
        }  // period ends IF scope
    }

    private void exemption_300_197() {                      // L:6463 300-197-EXEMPTION
        taxCreditYn = wsTaxCreditYn[tblIdx];                // L:6464 MOVE WS-TAX-CREDIT-YN (TBL-IDX) TO TAX-CREDIT-YN
        if (wsPerExemptCnt[taxEntity.intValue()] > 1 && !(taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs)) && !(taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6465 IF WS-PER-EXEMPT-CNT (TAX-ENTITY) > 1   ...
            if (wsPerExemptCnt[taxEntity.intValue()] < 3) { // L:6468 IF WS-PER-EXEMPT-CNT (TAX-ENTITY) < 3   ...
                cRetCode = "";                              // L:6470 MOVE SPACES TO C-RET-CODE
                wsPaytblpf01Level = BigDecimal.valueOf(1);  // L:6471 MOVE 01 TO WS-PAYTBLPF01-LEVEL
                wsPaytblpf01TaxOption = BigDecimal.valueOf(10);// L:6472 MOVE 010 TO WS-PAYTBLPF01-TAX-OPTION
                wsPaytblpf01TaxOptValue1 = BigDecimal.ZERO; // L:6473 INITIALIZE WS-PAYTBLPF01-TAX-OPT-VALUE1 ...
                // CALL PYOPXFK                             // L:6475 CALL "PYOPXFK" USING C-RET-CODE,        ...
                callPyopxfk();
                if (wsPaytblpf01TaxOptValue1.compareTo(BigDecimal.ZERO) != 0) {// L:6482 IF WS-PAYTBLPF01-TAX-OPT-VALUE1 NOT = ZE...
                    // MULTIPLY parse failed: MULTIPLY 1 BY // L:6483 MULTIPLY 1 BY                           ...
                    // COMPUTE parse failed: COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =// L:6486 COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =...
                    // MULTIPLY parse failed: MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 BY// L:6488 MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 ...
                    // COMPUTE parse failed: COMPUTE DEDUCT-EXEMPT-AMT-WS =// L:6492 COMPUTE DEDUCT-EXEMPT-AMT-WS =          ...
                } else {                                    // L:6495 ELSE
                    // MULTIPLY parse failed: MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) BY// L:6496 MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) ...
                }                                           // L:6499 END-IF
            } else {                                        // L:6500 ELSE
                if (wsPerExemptCnt[taxEntity.intValue()] >= 3) {// L:6502 IF WS-PER-EXEMPT-CNT (TAX-ENTITY) >= 3  ...
                    cRetCode = "";                          // L:6505 MOVE SPACES TO C-RET-CODE
                    wsPaytblpf01Level = BigDecimal.valueOf(1);// L:6506 MOVE 01 TO WS-PAYTBLPF01-LEVEL
                    wsPaytblpf01TaxOption = BigDecimal.valueOf(10);// L:6507 MOVE 010 TO WS-PAYTBLPF01-TAX-OPTION
                    wsPaytblpf01TaxOptValue1 = BigDecimal.ZERO;// L:6508 INITIALIZE WS-PAYTBLPF01-TAX-OPT-VALUE1 ...
                    // CALL PYOPXFK                         // L:6510 CALL "PYOPXFK" USING C-RET-CODE,        ...
                    callPyopxfk();
                    cRetCode = "";                          // L:6520 MOVE SPACES TO C-RET-CODE
                    wsPaytblpf01Level = BigDecimal.valueOf(1);// L:6521 MOVE 01 TO WS-PAYTBLPF01-LEVEL
                    wsPaytblpf01TaxOption = BigDecimal.valueOf(12);// L:6522 MOVE 012 TO WS-PAYTBLPF01-TAX-OPTION
                    wsPaytblpf01TaxOptValue2 = BigDecimal.ZERO;// L:6523 INITIALIZE WS-PAYTBLPF01-TAX-OPT-VALUE2 ...
                    // CALL PYOPXFK                         // L:6525 CALL "PYOPXFK" USING C-RET-CODE,        ...
                    callPyopxfk();
                    if (wsPaytblpf01TaxOptValue1.compareTo(BigDecimal.ZERO) != 0 && wsPaytblpf01TaxOptValue2.compareTo(BigDecimal.ZERO) != 0) {// L:6533 IF WS-PAYTBLPF01-TAX-OPT-VALUE1 NOT = ZE...
                        // MULTIPLY parse failed: MULTIPLY 1 BY// L:6536 MULTIPLY 1 BY                           ...
                        // MULTIPLY parse failed: MULTIPLY 1 BY// L:6539 MULTIPLY 1 BY                           ...
                        // COMPUTE parse failed: COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =// L:6543 COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =...
                        // MULTIPLY parse failed: MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 BY// L:6545 MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 ...
                        // COMPUTE parse failed: COMPUTE DEDUCT-EXEMPT-AMT-WS =// L:6549 COMPUTE DEDUCT-EXEMPT-AMT-WS =          ...
                    } else {                                // L:6553 ELSE
                        if (wsPaytblpf01TaxOptValue1.compareTo(BigDecimal.ZERO) != 0) {// L:6554 IF WS-PAYTBLPF01-TAX-OPT-VALUE1 NOT = ZE...
                            // MULTIPLY parse failed: MULTIPLY 1 BY// L:6555 MULTIPLY 1 BY                           ...
                            // COMPUTE parse failed: COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =// L:6558 COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 =...
                            // MULTIPLY parse failed: MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 BY// L:6560 MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT1 ...
                            // COMPUTE parse failed: COMPUTE DEDUCT-EXEMPT-AMT-WS =// L:6564 COMPUTE DEDUCT-EXEMPT-AMT-WS =          ...
                        } else {                            // L:6567 ELSE
                            if (wsPaytblpf01TaxOptValue2.compareTo(BigDecimal.ZERO) != 0) {// L:6568 IF WS-PAYTBLPF01-TAX-OPT-VALUE2 NOT = ZE...
                                // MULTIPLY parse failed: MULTIPLY 2 BY// L:6569 MULTIPLY 2 BY                           ...
                                // COMPUTE parse failed: COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT2 =// L:6572 COMPUTE WS-PAYTBLPF01-XTRA-EXEMPT-CNT2 =...
                                // MULTIPLY parse failed: MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT2 BY// L:6574 MULTIPLY WS-PAYTBLPF01-XTRA-EXEMPT-CNT2 ...
                                // COMPUTE parse failed: COMPUTE DEDUCT-EXEMPT-AMT-WS =// L:6578 COMPUTE DEDUCT-EXEMPT-AMT-WS =          ...
                            } else {                        // L:6581 ELSE
                                // MULTIPLY parse failed: MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) BY// L:6582 MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) ...
                            }                               // L:6585 END-IF
                        }                                   // L:6586 END-IF
                    }                                       // L:6587 END-IF
                }                                           // L:6589 END-IF
            }                                               // L:6590 END-IF
        } else {                                            // L:6591 ELSE
            if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs)) {// L:6592 IF TAX-ENTITY = 2 AND CDE-TAX-WS = "OR" ...
                // MULTIPLY parse failed: MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) BY// L:6600 MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) ...
            } else {                                        // L:6605 ELSE
                if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6606 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                    inc = inc.multiply(BigDecimal.valueOf(wsPerExemptCnt[taxEntity.intValue()]));// L:6607 MULTIPLY WS-PER-EXEMPT-CNT (TAX-ENTITY) ...
                }                                           // L:6610 END-IF
            }                                               // L:6611 END-IF
        }                                                   // L:6612 END-IF
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6634 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
            if (((deductExemptAmtWs.compareTo(BigDecimal.ZERO) > 0) )) {// L:6635 IF ((DEDUCT-EXEMPT-AMT-WS > ZERO)
                deductExemptAddlAmtWs = wsExemptAddlAmt[tblIdx];// L:6639 MOVE WS-EXEMPT-ADDL-AMT (TBL-IDX) TO DEDUCT-EXEMPT-ADDL-AMT-WS
            } else {                                        // L:6641 ELSE
                deductExemptAddlAmtWs = BigDecimal.ZERO;    // L:6642 MOVE ZERO TO DEDUCT-EXEMPT-ADDL-AMT-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ia".equals(cdeTaxWs)) || (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ca".equals(cdeTaxWs))) {// L:6651 IF (TAX-ENTITY = 2
            deductExemptAddlAmtWs = BigDecimal.valueOf(wsPerExemptCnt[2]);// L:6658 MOVE WS-PER-EXEMPT-CNT(2) TO DEDUCT-EXEMPT-ADDL-AMT-WS
            if (deductExemptAddlAmtWs.compareTo(BigDecimal.valueOf(2)) > 0) {// L:6661 IF DEDUCT-EXEMPT-ADDL-AMT-WS > 2
                deductExemptAddlAmtWs = BigDecimal.valueOf(2);// L:6662 MOVE 2 TO DEDUCT-EXEMPT-ADDL-AMT-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ia".equals(cdeTaxWs)) || (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ca".equals(cdeTaxWs))) {// L:6663 IF (TAX-ENTITY = 2
            // MULTIPLY parse failed: MULTIPLY WS-EXEMPT-ADDL-AMT(TBL-IDX) BY// L:6670 MULTIPLY WS-EXEMPT-ADDL-AMT(TBL-IDX) BY
            deductExemptAmtWs = deductExemptAmtWs.add(deductExemptAddlAmtWs);// L:6672 ADD DEDUCT-EXEMPT-ADDL-AMT-WS TO DEDUCT-...
            deductExemptAddlAmtWs = BigDecimal.ZERO;        // L:6673 MOVE 0 TO DEDUCT-EXEMPT-ADDL-AMT-WS
        }  // period ends IF scope
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6716 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
            wsStdDedPct[tblIdx] = wsStdDedPct[tblIdx].multiply(annualWageWs);// L:6717 MULTIPLY ANNUAL-WAGE-WS BY WS-STD-DED-PC...
            if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6719 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                if (deductStdAmtWs.compareTo(wsStdDedAmt[tblIdx]) > 0) {// L:6720 IF DEDUCT-STD-AMT-WS > WS-STD-DED-AMT (T...
                    deductStdAmtWs = wsStdDedAmt[tblIdx];   // L:6721 MOVE WS-STD-DED-AMT (TBL-IDX) TO DEDUCT-STD-AMT-WS
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ia".equals(cdeTaxWs)) {// L:6729 IF TAX-ENTITY = 2
            if (wsPerExmStt.compareTo(BigDecimal.valueOf(2)) < 0) {// L:6732 IF WS-PER-EXM-STT < 2
                deductStdAmtWs = wsStdDedAmt[tblIdx];       // L:6733 MOVE WS-STD-DED-AMT(TBL-IDX) TO DEDUCT-STD-AMT-WS
            } else {                                        // L:6734 ELSE
                // ADD parse failed: ADD WS-STD-DED-AMT(TBL-IDX), IA-STD-DED-TIER GIVING// L:6735 ADD WS-STD-DED-AMT(TBL-IDX), IA-STD-DED-...
                if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ca".equals(cdeTaxWs)) {// L:6737 IF TAX-ENTITY = 2                       ...
                    deductStdAmtWs = wsStdDedAmt[tblIdx];   // L:6741 MOVE WS-STD-DED-AMT(TBL-IDX) TO DEDUCT-STD-AMT-WS
                    if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "sc".equals(cdeTaxWs)) {// L:6749 IF TAX-ENTITY = 2                       ...
                        if (wsPerExmStt.compareTo(BigDecimal.ZERO) == 0) {// L:6752 IF WS-PER-EXM-STT = 0                   ...
                            deductStdAmtWs = BigDecimal.ZERO;// L:6753 MOVE ZEROS TO DEDUCT-STD-AMT-WS
                        }                                   // L:6754 END-IF
                    }                                       // L:6755 END-IF
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ct".equals(cdeTaxWs) && ctStdDeductAmt.compareTo(BigDecimal.ZERO) == 0) {// L:6764 IF TAX-ENTITY = 2                       ...
            ctStdDeductAmt = wsStdDedAmt[tblIdx];           // L:6769 MOVE WS-STD-DED-AMT(TBL-IDX) TO CT-STD-DEDUCT-AMT
            if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ct".equals(cdeTaxWs)) {// L:6770 IF TAX-ENTITY = 2
                deductStdAmtWs = ctStdDeductAmt;            // L:6773 MOVE CT-STD-DEDUCT-AMT TO DEDUCT-STD-AMT-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && deductStdAmtWs.compareTo(mdMinStdDed) < 0 && (("md".equals(cdeTaxWs) || "m1".equals(cdeTaxWs) || "m2".equals(cdeTaxWs) || "m3".equals(cdeTaxWs) || "m4".equals(cdeTaxWs) || "m5".equals(cdeTaxWs) || "m6".equals(cdeTaxWs) || "m7".equals(cdeTaxWs) || "m8".equals(cdeTaxWs) || "m9".equals(cdeTaxWs) || "mb".equals(cdeTaxWs) || "mc".equals(cdeTaxWs) || "mg".equals(cdeTaxWs) || "mh".equals(cdeTaxWs)))) {// L:6781 IF TAX-ENTITY = 2
            deductStdAmtWs = mdMinStdDed;                   // L:6789 MOVE MD-MIN-STD-DED TO DEDUCT-STD-AMT-WS
        }  // period ends IF scope
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ca".equals(cdeTaxWs))) {// L:6796 IF (TAX-ENTITY = 2 AND CDE-TAX-WS = "CA"...
            if ((("m".equals(cdeMarStatusWs) || "h".equals(cdeMarStatusWs)) && wsPerExmStt.compareTo(BigDecimal.valueOf(2)) < 0)) {// L:6798 IF ((CDE-MAR-STATUS-WS = "M" OR CDE-MAR-...
                // DIVIDE parse failed: DIVIDE DEDUCT-STD-AMT-WS BY 2                          IBM-CT// L:6800 DIVIDE DEDUCT-STD-AMT-WS BY 2           ...
                if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs))) {// L:6803 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                    if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6804 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                        taxableWageWs = annualWageWs;       // L:6805 MOVE ANNUAL-WAGE-WS TO TAXABLE-WAGE-WS
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "y".equals(taxCreditYn))) {// L:6812 IF NOT (TAX-ENTITY = 2 AND TAX-CREDIT-YN...
            if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ia".equals(cdeTaxWs))) {// L:6813 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs))) {// L:6814 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                    if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6815 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ca".equals(cdeTaxWs))) {// L:6816 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                            taxableWageWs = taxableWageWs.subtract(deductExemptAmtWs);// L:6819 SUBTRACT DEDUCT-EXEMPT-AMT-WS FROM TAXAB...
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "y".equals(taxCreditYn))) {// L:6828 IF NOT (TAX-ENTITY = 2 AND TAX-CREDIT-YN...
            if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ca".equals(cdeTaxWs))) {// L:6829 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ia".equals(cdeTaxWs))) {// L:6830 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                    if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ky".equals(cdeTaxWs))) {// L:6831 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs))) {// L:6832 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                            if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6833 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                                // SUBTRACT parse failed: SUBTRACT DEDUCT-EXEMPT-ADDL-AMT-WS// L:6834 SUBTRACT DEDUCT-EXEMPT-ADDL-AMT-WS
                                if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs))) {// L:6837 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                                    if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "al".equals(cdeTaxWs))) {// L:6838 IF NOT (TAX-ENTITY = 2 AND CDE-TAX-WS = ...
                                        taxableWageWs = taxableWageWs.subtract(deductStdAmtWs);// L:6839 SUBTRACT DEDUCT-STD-AMT-WS FROM TAXABLE-...
                                    }  // period ends IF scope
                                }  // period ends IF scope
                            }  // period ends IF scope
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ar".equals(cdeTaxWs)) {// L:6841 IF TAX-ENTITY = 2 AND CDE-TAX-WS = "AR" ...
            if (taxableWageWs.compareTo(BigDecimal.valueOf(91801)) < 0) {// L:6846 IF TAXABLE-WAGE-WS < 91801              ...
                theNumber = taxableWageWs;                  // L:6847 MOVE TAXABLE-WAGE-WS TO THE-NUMBER
                wholeNumberDiv100 = (wholeNumber).divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP);// L:6848 COMPUTE WHOLE-NUMBER-DIV-100 = WHOLE-NUM...
                lowNumber = (wholeNumberDiv100).multiply(BigDecimal.valueOf(100));// L:6849 COMPUTE LOW-NUMBER = WHOLE-NUMBER-DIV-10...
                midRange50 = (lowNumber).add(BigDecimal.valueOf(50));// L:6850 COMPUTE MID-RANGE-50 = LOW-NUMBER + 50  ...
                taxableWageWs = midRange50;                 // L:6851 MOVE MID-RANGE-50 TO TAXABLE-WAGE-WS
            }                                               // L:6852 END-IF
        }                                                   // L:6853 END-IF
        if (taxableWageWs.compareTo(BigDecimal.ZERO) < 0) { // L:6865 IF TAXABLE-WAGE-WS < ZERO
            taxableWageWs = BigDecimal.ZERO;                // L:6866 MOVE ZERO TO TAXABLE-WAGE-WS
        }  // period ends IF scope
        if (taxableWageWs.compareTo(wsLowerWageLimit[tblIdx]) >= 0) {// L:6873 IF TAXABLE-WAGE-WS NOT < WS-LOWER-WAGE-L...
            lowerWageLimitWs = wsLowerWageLimit[tblIdx];    // L:6882 MOVE WS-LOWER-WAGE-LIMIT(TBL-IDX) TO LOWER-WAGE-LIMIT-WS
            pctExcessWageWs = wsPctExcessWage[tblIdx];      // L:6890 MOVE WS-PCT-EXCESS-WAGE(TBL-IDX) TO PCT-EXCESS-WAGE-WS
            flatTaxAmtWs = wsFlatTaxAmt[tblIdx];            // L:6897 MOVE WS-FLAT-TAX-AMT(TBL-IDX) TO FLAT-TAX-AMT-WS
            taxLimitYtdWs = wsTaxLimitYtd[tblIdx];          // L:6904 MOVE WS-TAX-LIMIT-YTD(TBL-IDX) TO TAX-LIMIT-YTD-WS
            wageLimitYtdWs = wsWageLimitYtd[tblIdx];        // L:6911 MOVE WS-WAGE-LIMIT-YTD(TBL-IDX) TO WAGE-LIMIT-YTD-WS
            // MULTIPLY invalid target (literal): MULTIPLY WS-TAX-LIMIT-CPP(TBL-IDX) BY 52 GIVING// L:6920 MULTIPLY WS-TAX-LIMIT-CPP(TBL-IDX) BY 52...
            // DIVIDE parse failed: DIVIDE TAX-LIMIT-CPP-WS BY CDE-CYCLE-NUM-WS GIVING// L:6922 DIVIDE TAX-LIMIT-CPP-WS BY CDE-CYCLE-NUM...
            okFlag = okLit;                                 // L:6930 MOVE OK-LIT TO OK-FLAG
            taxKeyFlag = okLit;                             // L:6930 MOVE OK-LIT TO TAX-KEY-FLAG
        }  // period ends IF scope
    }

    private void computeTax_300_198() {                     // L:6945 300-198-COMPUTE-TAX
        taxableWageWs = taxableWageWs.subtract(lowerWageLimitWs);// L:6950 SUBTRACT LOWER-WAGE-LIMIT-WS FROM TAXABL...
        excessWageWs = excessWageWs.multiply(pctExcessWageWs);// L:6959 MULTIPLY PCT-EXCESS-WAGE-WS BY EXCESS-WA...
        // ADD parse failed: ADD EXCESS-TAX-WS FLAT-TAX-AMT-WS// L:6968 ADD EXCESS-TAX-WS FLAT-TAX-AMT-WS
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs) && "y".equals(or0003)) {// L:6970 IF TAX-ENTITY = 2 AND CDE-TAX-WS = "OR" ...
            cRetCode = "";                                  // L:6972 MOVE SPACES TO C-RET-CODE
            wsOrPaytblpf01Level = wsOr2NdLevel;             // L:6973 MOVE WS-OR-2ND-LEVEL TO WS-OR-PAYTBLPF01-LEVEL
            wsOrPaytblpf01TaxOption = BigDecimal.valueOf(13);// L:6974 MOVE 013 TO WS-OR-PAYTBLPF01-TAX-OPTION
            wsOrFlatTaxAdjAmt = BigDecimal.ZERO;            // L:6975 INITIALIZE WS-OR-FLAT-TAX-ADJ-AMT       ...
            // id145 = default; // INITIALIZE ID-145        // L:6975 INITIALIZE WS-OR-FLAT-TAX-ADJ-AMT       ...
            // CALL PYOPXFK                                 // L:6985 CALL "PYOPXFK" USING C-RET-CODE,        ...
            callPyopxfk();
            // COMPUTE parse failed: COMPUTE TAX-CPP-SUM(TAX-ENTITY) =// L:6996 COMPUTE TAX-CPP-SUM(TAX-ENTITY) =       ...
        }                                                   // L:7000 END-IF
        if (((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "y".equals(taxCreditYn)) || (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && ("ia".equals(cdeTaxWs) || "||".equals(cdeTaxWs))))) {// L:7010 IF ((TAX-ENTITY = 2 AND TAX-CREDIT-YN = ...
            if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "||".equals(cdeTaxWs) && "y".equals(or0004)) {// L:7015 IF TAX-ENTITY = 2 AND CDE-TAX-WS = "OR" ...
                deductExemptAmtWs = BigDecimal.ZERO;        // L:7018 MOVE ZEROS TO DEDUCT-EXEMPT-AMT-WS
            }                                               // L:7019 END-IF
            if (deductExemptAmtWs.compareTo(taxCppSum[1]) > 0) {// L:7020 IF DEDUCT-EXEMPT-AMT-WS > TAX-CPP-SUM(2)
                taxCppSum[2] = BigDecimal.ZERO;             // L:7021 MOVE ZERO TO TAX-CPP-SUM(2)
            } else {                                        // L:7022 ELSE
                // SUBTRACT parse failed: SUBTRACT DEDUCT-EXEMPT-AMT-WS// L:7025 SUBTRACT DEDUCT-EXEMPT-AMT-WS
            }                                               // L:7030 END-IF
        }                                                   // L:7031 END-IF
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && (("ca".equals(cdeTaxWs) || "ar".equals(cdeTaxWs) || "ky".equals(cdeTaxWs))))) {// L:7038 IF (TAX-ENTITY = 2 AND
            wsPerExmStt = wsPerExmStt.multiply(deductExemptAddlAmtWs);// L:7041 MULTIPLY DEDUCT-EXEMPT-ADDL-AMT-WS BY WS...
            if (deductExemptAddlAmtWs.compareTo(taxCppSum[1]) > 0) {// L:7043 IF DEDUCT-EXEMPT-ADDL-AMT-WS > TAX-CPP-S...
                taxCppSum[2] = BigDecimal.ZERO;             // L:7044 MOVE ZERO TO TAX-CPP-SUM(2)
            } else {                                        // L:7045 ELSE
                // SUBTRACT parse failed: SUBTRACT DEDUCT-EXEMPT-ADDL-AMT-WS// L:7046 SUBTRACT DEDUCT-EXEMPT-ADDL-AMT-WS
            }                                               // L:7048 END-IF
        }                                                   // L:7050 END-IF
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ct".equals(cdeTaxWs)) {// L:7074 IF TAX-ENTITY = 2
            ctTaxCredit_300_500();                          // L:7077 PERFORM 300-500-CT-TAX-CREDIT THRU 300-500-EXIT
        }                                                   // L:7078 END-IF
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && (("md".equals(cdeTaxWs) || "m1".equals(cdeTaxWs) || "m2".equals(cdeTaxWs) || "m3".equals(cdeTaxWs) || "m4".equals(cdeTaxWs) || "m5".equals(cdeTaxWs) || "m6".equals(cdeTaxWs) || "m7".equals(cdeTaxWs) || "m8".equals(cdeTaxWs) || "m9".equals(cdeTaxWs) || "mb".equals(cdeTaxWs) || "mc".equals(cdeTaxWs) || "mg".equals(cdeTaxWs) || "mh".equals(cdeTaxWs)))) {// L:7080 IF TAX-ENTITY = 2 AND                   ...
            cdeCycleNumWs = cdeCycleNumWs.multiply(totEarnWs);// L:7088 MULTIPLY TOT-EARN-WS BY CDE-CYCLE-NUM-WS...
            if (mdGrossEarnWs.compareTo(BigDecimal.valueOf(5000)) < 0) {// L:7090 IF MD-GROSS-EARN-WS < 5000              ...
                taxCppSum[2] = BigDecimal.ZERO;             // L:7091 MOVE ZERO TO TAX-CPP-SUM(2)
            }                                               // L:7092 END-IF
        }                                                   // L:7093 END-IF
        if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ma".equals(cdeTaxWs) && "y".equals(maZeroTaxYn)) {// L:7101 IF TAX-ENTITY = 2 AND                   ...
            taxCppSum[2] = BigDecimal.ZERO;                 // L:7105 MOVE ZERO TO TAX-CPP-SUM(2)
        }                                                   // L:7106 END-IF
    }

    private void reduceNet_300_198() {                      // L:7108 300-198-REDUCE-NET
        if (pctWageTax && taxEntity.compareTo(BigDecimal.valueOf(7)) != 0) {// L:7114 IF PCT-WAGE-TAX
            if (!"az".equals(cdeTaxWs)) {                   // L:7117 IF CDE-TAX-WS NOT = "AZ"                ...
                perTaxPara[taxEntity.intValue()] = perTaxPara[taxEntity.intValue()].multiply(annualWageWs);// L:7118 MULTIPLY ANNUAL-WAGE-WS BY PER-TAX-PARA(...
            } else {                                        // L:7120 ELSE
                // DIVIDE parse failed: DIVIDE PER-TAX-PARA(TAX-ENTITY) BY 100// L:7121 DIVIDE PER-TAX-PARA(TAX-ENTITY) BY 100  ...
                azPctWs = azPctWs.multiply(annualWageWs);   // L:7123 MULTIPLY ANNUAL-WAGE-WS BY AZ-PCT-WS    ...
            }  // period ends IF scope
        }  // period ends IF scope
        // DIVIDE parse failed: DIVIDE TAX-CPP-SUM(TAX-ENTITY) BY CDE-CYCLE-NUM-WS// L:7159 DIVIDE TAX-CPP-SUM(TAX-ENTITY) BY CDE-CY...
        if ("y".equals(w40004) && taxEntity.compareTo(BigDecimal.valueOf(1)) == 0) {// L:7166 IF W40004 = "Y"                         ...
            // COMPUTE parse failed: COMPUTE DEPEND-PAYPPD-AMT-WS =// L:7172 COMPUTE DEPEND-PAYPPD-AMT-WS =          ...
            // SUBTRACT parse failed: SUBTRACT DEPEND-PAYPPD-AMT-WS// L:7174 SUBTRACT DEPEND-PAYPPD-AMT-WS           ...
            if (taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) < 0) {// L:7177 IF TAX-CPP-SUM(TAX-ENTITY) < ZERO       ...
                taxCppSum[taxEntity.intValue()] = BigDecimal.ZERO;// L:7178 MOVE 0 TO TAX-CPP-SUM(TAX-ENTITY)
            }                                               // L:7179 END-IF
        }                                                   // L:7180 END-IF
        if (addlTax && taxEntity.compareTo(BigDecimal.valueOf(7)) != 0) {// L:7182 IF ADDL-TAX
            taxCppSum[taxEntity.intValue()] = taxCppSum[taxEntity.intValue()].add(perTaxPara[taxEntity.intValue()]);// L:7186 ADD PER-TAX-PARA(TAX-ENTITY) TO TAX-CPP-...
        }  // period ends IF scope
        if (piggyBackTax && taxEntity.compareTo(BigDecimal.valueOf(7)) != 0) {// L:7187 IF PIGGY-BACK-TAX
            perTaxPara[taxEntity.intValue()] = perTaxPara[taxEntity.intValue()].add(BigDecimal.valueOf(1.0));// L:7190 ADD 1.0 TO PER-TAX-PARA(TAX-ENTITY)
            // MULTIPLY parse failed: MULTIPLY PER-TAX-PARA(TAX-ENTITY)// L:7191 MULTIPLY PER-TAX-PARA(TAX-ENTITY)
            perTaxPara[taxEntity.intValue()] = perTaxPara[taxEntity.intValue()].subtract(BigDecimal.valueOf(1.0));// L:7193 SUBTRACT 1.0 FROM PER-TAX-PARA(TAX-ENTIT...
        }  // period ends IF scope
        if (lessTax && taxEntity.compareTo(BigDecimal.valueOf(7)) != 0) {// L:7194 IF LESS-TAX
            // SUBTRACT parse failed: SUBTRACT PER-TAX-PARA(TAX-ENTITY) FROM// L:7197 SUBTRACT PER-TAX-PARA(TAX-ENTITY) FROM
            if (fixedTax && taxEntity.compareTo(BigDecimal.valueOf(7)) != 0) {// L:7199 IF FIXED-TAX
                taxCppSum[taxEntity.intValue()] = perTaxPara[taxEntity.intValue()];// L:7202 MOVE PER-TAX-PARA(TAX-ENTITY) TO TAX-CPP-SUM(TAX-ENTITY)
            }  // period ends IF scope
        }  // period ends IF scope
        if (fixedTax && taxEntity.compareTo(BigDecimal.valueOf(7)) == 0) {// L:7203 IF FIXED-TAX
            taxCppSum[taxEntity.intValue()] = perTaxPara[1];// L:7206 MOVE PER-TAX-PARA(1) TO TAX-CPP-SUM(TAX-ENTITY)
        }  // period ends IF scope
        if ((fedPctTax && taxEntity.compareTo(BigDecimal.valueOf(2)) == 0)) {// L:7207 IF (FED-PCT-TAX
            if (!"az".equals(cdeTaxWs)) {                   // L:7210 IF CDE-TAX-WS NOT = "AZ"
                perTaxPara[taxEntity.intValue()] = perTaxPara[taxEntity.intValue()].multiply(taxCppSum[1]);// L:7211 MULTIPLY TAX-CPP-SUM (1) BY PER-TAX-PARA...
            } else {                                        // L:7213 ELSE
                // DIVIDE parse failed: DIVIDE PER-TAX-PARA(TAX-ENTITY) BY 100// L:7214 DIVIDE PER-TAX-PARA(TAX-ENTITY) BY 100
                azPctWs = azPctWs.multiply(taxCppSum[1]);   // L:7216 MULTIPLY TAX-CPP-SUM (1) BY AZ-PCT-WS
                if (taxCppSum[taxEntity.intValue()].compareTo(azTaxMin) < 0) {// L:7218 IF TAX-CPP-SUM(TAX-ENTITY) < AZ-TAX-MIN
                    taxCppSum[taxEntity.intValue()] = azTaxMin;// L:7219 MOVE AZ-TAX-MIN TO TAX-CPP-SUM(TAX-ENTITY)
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if ((taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && (("ms".equals(cdeTaxWs) || "mf".equals(cdeTaxWs))))) {// L:7221 IF (TAX-ENTITY = 2 AND                  ...
            // MULTIPLY invalid target (literal): MULTIPLY TAX-CPP-SUM(TAX-ENTITY) BY 1// L:7223 MULTIPLY TAX-CPP-SUM(TAX-ENTITY) BY 1   ...
            taxCppSum[taxEntity.intValue()] = msStateTaxWhole;// L:7225 MOVE MS-STATE-TAX-WHOLE TO TAX-CPP-SUM(TAX-ENTITY)
            if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ok".equals(cdeTaxWs) && !fixedTax) {// L:7227 IF TAX-ENTITY = 2 AND                   ...
                // MULTIPLY invalid target (literal): MULTIPLY TAX-CPP-SUM(TAX-ENTITY) BY 1// L:7230 MULTIPLY TAX-CPP-SUM(TAX-ENTITY) BY 1   ...
                taxCppSum[taxEntity.intValue()] = okStateTaxWhole;// L:7232 MOVE OK-STATE-TAX-WHOLE TO TAX-CPP-SUM(TAX-ENTITY)
                if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "la".equals(cdeTaxWs) && taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) < 0 && ("2".equals(timCheckTypeHold) || "3".equals(timCheckTypeHold))) {// L:7234 IF TAX-ENTITY = 2                       ...
                    taxCppSum[taxEntity.intValue()] = BigDecimal.ZERO;// L:7241 MOVE 0 TO TAX-CPP-SUM(TAX-ENTITY)
                    if (taxEntity.compareTo(BigDecimal.valueOf(7)) == 0 && !advEicTax.isEmpty() && ernCppGrossSum.compareTo(BigDecimal.ZERO) > 0 && taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) > 0) {// L:7244 IF TAX-ENTITY = 7
                        taxCppSum[taxEntity.intValue()] = BigDecimal.ZERO;// L:7251 MOVE 0 TO TAX-CPP-SUM(TAX-ENTITY)
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (totEarnYtdWs.compareTo(wageLimitYtdWs) > 0) {   // L:7259 IF TOT-EARN-YTD-WS > WAGE-LIMIT-YTD-WS
            taxCppSum[taxEntity.intValue()] = BigDecimal.ZERO;// L:7263 MOVE ZERO TO TAX-CPP-SUM(TAX-ENTITY)
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(7)) != 0) {// L:7264 IF TAX-ENTITY NOT = 7
            // ADD parse failed: ADD ERN-TAX-YTD(TAX-ENTITY) TAX-CPP-SUM(TAX-ENTITY)// L:7265 ADD ERN-TAX-YTD(TAX-ENTITY) TAX-CPP-SUM(...
            if (taxEntity.compareTo(BigDecimal.valueOf(7)) != 0 && totTaxYtdWs.compareTo(taxLimitYtdWs) > 0) {// L:7267 IF TAX-ENTITY NOT = 7
                taxLimitYtdWs = taxLimitYtdWs.subtract(ernTaxYtd[taxEntity.intValue()]);// L:7274 SUBTRACT ERN-TAX-YTD(TAX-ENTITY) FROM TA...
                if (taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) < 0) {// L:7279 IF TAX-CPP-SUM(TAX-ENTITY) < ZERO
                    taxCppSum[taxEntity.intValue()] = BigDecimal.ZERO;// L:7280 MOVE ZERO TO TAX-CPP-SUM(TAX-ENTITY)
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        wkOptTrnAmount = BigDecimal.ZERO;                   // L:7282 MOVE ZEROS TO WK-OPT-TRN-AMOUNT
        wkOprTrnAmount = BigDecimal.ZERO;                   // L:7282 MOVE ZEROS TO WK-OPR-TRN-AMOUNT
        wkOptTaxCode = "";                                  // L:7284 MOVE SPACES TO WK-OPT-TAX-CODE
        wkOprTaxCode = "";                                  // L:7284 MOVE SPACES TO WK-OPR-TAX-CODE
        if (taxEntity.compareTo(BigDecimal.valueOf(5)) == 0) {// L:7286 IF TAX-ENTITY = 5                       ...
            if (("dopt".equals(taxName[taxEntity.intValue()]) || "gopt".equals(taxName[taxEntity.intValue()]))) {// L:7287 IF TAX-NAME(TAX-ENTITY) = "DOPT" OR "GOP...
                wsDateCheckPacked = wsDateCheck;            // L:7288 MOVE WS-DATE-CHECK TO WS-DATE-CHECK-PACKED
                wkOptTaxCode = taxName[taxEntity.intValue()];// L:7289 MOVE TAX-NAME(TAX-ENTITY) TO WK-OPT-TAX-CODE
                // CALL PYA8XFK                             // L:7290 CALL "PYA8XFK" USING C-RET-CODE, PER-CLI...
                callPya8Xfk();
                if (wkOptTrnAmount.compareTo(BigDecimal.ZERO) != 0) {// L:7295 IF WK-OPT-TRN-AMOUNT NOT = ZEROS        ...
                    taxCppSum[taxEntity.intValue()] = wkOptTrnAmount;// L:7296 MOVE WK-OPT-TRN-AMOUNT TO TAX-CPP-SUM(TAX-ENTITY)
                } else {                                    // L:7297 ELSE
                    taxCppSum[taxEntity.intValue()] = BigDecimal.ZERO;// L:7298 MOVE ZEROS TO TAX-CPP-SUM(TAX-ENTITY)
                }                                           // L:7299 END-IF
            }                                               // L:7300 END-IF
        }                                                   // L:7301 END-IF
        if (taxEntity.compareTo(BigDecimal.valueOf(7)) == 0) {// L:7303 IF TAX-ENTITY = 7
            // ADD parse failed: ADD ERN-YTD-ADVEIC TAX-CPP-SUM(TAX-ENTITY) GIVING// L:7304 ADD ERN-YTD-ADVEIC TAX-CPP-SUM(TAX-ENTIT...
            if (totTaxYtdWs.compareTo(taxLimitYtdWs) < 0) { // L:7306 IF TOT-TAX-YTD-WS < TAX-LIMIT-YTD-WS
                taxLimitYtdWs = taxLimitYtdWs.subtract(ernYtdAdveic);// L:7307 SUBTRACT ERN-YTD-ADVEIC FROM TAX-LIMIT-Y...
                if (taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) > 0) {// L:7309 IF TAX-CPP-SUM(TAX-ENTITY) > 0
                    taxCppSum[taxEntity.intValue()] = BigDecimal.ZERO;// L:7310 MOVE 0 TO TAX-CPP-SUM(TAX-ENTITY)
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(7)) != 0 && taxCppSum[taxEntity.intValue()].compareTo(taxLimitCppWs) > 0) {// L:7317 IF TAX-ENTITY NOT = 7
            if (taxLimitCppWs.compareTo(BigDecimal.ZERO) > 0) {// L:7320 IF TAX-LIMIT-CPP-WS > ZERO
                taxCppSum[taxEntity.intValue()] = taxLimitCppWs;// L:7321 MOVE TAX-LIMIT-CPP-WS TO TAX-CPP-SUM(TAX-ENTITY)
            }  // period ends IF scope
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(7)) != 0 && !"3".equals(timCheckTypeHold) && taxCppSum[taxEntity.intValue()].compareTo(BigDecimal.ZERO) < 0) {// L:7326 IF TAX-ENTITY NOT = 7
            // STRING parse failed (no INTO): STRING TAX-ENTITY-NAME(TAX-ENTITY)...// L:7331 STRING TAX-ENTITY-NAME(TAX-ENTITY)
            wsGtnErr = "TX";                                // L:7336 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:7337 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            taxCppSum[taxEntity.intValue()] = BigDecimal.ZERO;// L:7338 MOVE ZERO TO TAX-CPP-SUM(TAX-ENTITY)
        }  // period ends IF scope
        if (taxEntity.compareTo(BigDecimal.valueOf(7)) != 0 && taxCppSum[taxEntity.intValue()].compareTo(ernCppNetSum) > 0) {// L:7340 IF TAX-ENTITY NOT = 7
            // STRING parse failed (no INTO): STRING TAX-ENTITY-NAME(TAX-ENTITY)...// L:7346 STRING TAX-ENTITY-NAME(TAX-ENTITY)
            wsGtnErr = "TX";                                // L:7351 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:7352 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            taxCppSum[taxEntity.intValue()] = ernCppNetSum; // L:7353 MOVE ERN-CPP-NET-SUM TO TAX-CPP-SUM(TAX-ENTITY)
        }  // period ends IF scope
        cRetCode = "";                                      // L:7359 MOVE SPACES TO C-RET-CODE
        wsPaytblpf01Level = BigDecimal.valueOf(1);          // L:7360 MOVE 01 TO WS-PAYTBLPF01-LEVEL
        wsPaytblpf01TaxOption = BigDecimal.valueOf(11);     // L:7361 MOVE 011 TO WS-PAYTBLPF01-TAX-OPTION
        wsRoundTaxAmountSw = "N";                           // L:7362 MOVE "N" TO WS-ROUND-TAX-AMOUNT-SW
        // CALL PYOOXFK                                     // L:7363 CALL "PYOOXFK" USING C-RET-CODE,        ...
        callPyooxfk();
        if ("y".equals(wsRoundTaxAmountSw)) {               // L:7369 IF WS-ROUND-TAX-AMOUNT-SW = "Y"         ...
            // MULTIPLY invalid target (literal): MULTIPLY TAX-CPP-SUM(TAX-ENTITY) BY 1// L:7370 MULTIPLY TAX-CPP-SUM(TAX-ENTITY) BY 1   ...
            taxCppSum[taxEntity.intValue()] = genericTaxWhole;// L:7372 MOVE GENERIC-TAX-WHOLE TO TAX-CPP-SUM(TAX-ENTITY)
            if (taxEntity.compareTo(BigDecimal.valueOf(2)) == 0 && "ar".equals(cdeTaxWs)) {// L:7375 IF TAX-ENTITY = 2 AND CDE-TAX-WS = "AR" ...
                // MULTIPLY invalid target (literal): MULTIPLY TAX-CPP-SUM(TAX-ENTITY) BY 1// L:7376 MULTIPLY TAX-CPP-SUM(TAX-ENTITY) BY 1   ...
                taxCppSum[taxEntity.intValue()] = genericTaxWhole;// L:7378 MOVE GENERIC-TAX-WHOLE TO TAX-CPP-SUM(TAX-ENTITY)
            }                                               // L:7379 END-IF
        }  // period ends IF scope
        ernCppNetSum = ernCppNetSum.subtract(taxCppSum[taxEntity.intValue()]);// L:7387 SUBTRACT TAX-CPP-SUM(TAX-ENTITY) FROM ER...
    }

    private void taxKeyError_300_198_1() {                  // L:7393 300-198-1-TAX-KEY-ERROR
        messageO = "";                                      // L:7394 MOVE SPACES TO MESSAGE-O
        // STRING parse failed (no INTO): STRING "TAX TABLE NOT FOUND -" DELIMITED BY SIZE...// L:7395 STRING "TAX TABLE NOT FOUND -" DELIMITED...
        wsGtnErr = "TX";                                    // L:7401 MOVE "TX" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:7402 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void taxEicError_300_198_2() {                  // L:7405 300-198-2-TAX-EIC-ERROR
        messageO = "";                                      // L:7406 MOVE SPACES TO MESSAGE-O
        // STRING parse failed (no INTO): STRING "INVALID EIC CODE - " DELIMITED BY SIZE...// L:7407 STRING "INVALID EIC CODE - " DELIMITED B...
        wsGtnErr = "TX";                                    // L:7410 MOVE "TX" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:7411 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // 300-199-EXIT. EXIT.                              // L:7413 CODE
        // /                                                // L:7414 COMMENT
    }

    private void grossWagesBeBa_300_203() {                 // L:7417 300-203-GROSS-WAGES-BE-BA
        addWagesBeBa_300_203_1();                           // L:7418 PERFORM 300-203-1-ADD-WAGES-BE-BA
    }

    private void addWagesBeBa_300_203_1() {                 // L:7420 300-203-1-ADD-WAGES-BE-BA
        pctTotEarnWs = BigDecimal.ZERO;                     // L:7421 MOVE ZERO TO PCT-TOT-EARN-WS
        addWagesBeBa_300_203_2();                           // L:7422 PERFORM 300-203-2-ADD-WAGES-BE-BA
    }

    private void addWagesBeBa_300_203_2() {                 // L:7425 300-203-2-ADD-WAGES-BE-BA
        pctTotEarnWs = pctTotEarnWs.add(ernCppSum[pctNdx.intValue()]);// L:7426 ADD ERN-CPP-SUM(PCT-NDX) TO PCT-TOT-EARN...
        // /                                                // L:7427 COMMENT
    }

    private void grossWages_300_205() {                     // L:7430 300-205-GROSS-WAGES
        addWages_300_250();                                 // L:7431 PERFORM 300-250-ADD-WAGES
    }

    private void grossHours_300_206() {                     // L:7433 300-206-GROSS-HOURS
        addHours_300_260();                                 // L:7434 PERFORM 300-260-ADD-HOURS
    }

    private void netWages_300_210() {                       // L:7436 300-210-NET-WAGES
        addWages_300_250();                                 // L:7437 PERFORM 300-250-ADD-WAGES
    }

    private void grossFicaWages_300_215() {                 // L:7439 300-215-GROSS-FICA-WAGES
        wsCaller = "FICA";                                  // L:7440 MOVE "FICA" TO WS-CALLER
        addWages_300_250();                                 // L:7441 PERFORM 300-250-ADD-WAGES
    }

    private void grossFederalWages_300_220() {              // L:7443 300-220-GROSS-FEDERAL-WAGES
        wsCaller = "FED ";                                  // L:7444 MOVE "FED " TO WS-CALLER
        addWages_300_250();                                 // L:7445 PERFORM 300-250-ADD-WAGES
    }

    private void grossStateWages_300_225() {                // L:7447 300-225-GROSS-STATE-WAGES
        wsCaller = "STT ";                                  // L:7448 MOVE "STT " TO WS-CALLER
        addWages_300_250();                                 // L:7449 PERFORM 300-250-ADD-WAGES
    }

    private void grossLocalWages_300_230() {                // L:7451 300-230-GROSS-LOCAL-WAGES
        wsCaller = "LOC ";                                  // L:7452 MOVE "LOC " TO WS-CALLER
        addWages_300_250();                                 // L:7453 PERFORM 300-250-ADD-WAGES
    }

    private void grossCityWages_300_235() {                 // L:7455 300-235-GROSS-CITY-WAGES
        wsCaller = "CIT ";                                  // L:7456 MOVE "CIT " TO WS-CALLER
        addWages_300_250();                                 // L:7457 PERFORM 300-250-ADD-WAGES
    }

    private void grossOtherWages_300_240() {                // L:7459 300-240-GROSS-OTHER-WAGES
        wsCaller = "OTH ";                                  // L:7460 MOVE "OTH " TO WS-CALLER
        addWages_300_250();                                 // L:7461 PERFORM 300-250-ADD-WAGES
    }

    private void regularWages_300_245() {                   // L:7463 300-245-REGULAR-WAGES
        totEarnWs = BigDecimal.ZERO;                        // L:7464 MOVE ZERO TO TOT-EARN-WS
        totEarnYtdWs = BigDecimal.ZERO;                     // L:7464 MOVE ZERO TO TOT-EARN-YTD-WS
        addWages_300_251();                                 // L:7465 PERFORM 300-251-ADD-WAGES
        totRegWagesWs = totEarnWs;                          // L:7467 MOVE TOT-EARN-WS TO TOT-REG-WAGES-WS
    }

    private void addWages_300_250() {                       // L:7469 300-250-ADD-WAGES
        totEarnWs = BigDecimal.ZERO;                        // L:7470 MOVE ZERO TO TOT-EARN-WS
        totEarnYtdWs = BigDecimal.ZERO;                     // L:7470 MOVE ZERO TO TOT-EARN-YTD-WS
        addWages_300_251();                                 // L:7471 PERFORM 300-251-ADD-WAGES
    }

    private void addWages_300_251() {                       // L:7474 300-251-ADD-WAGES
        totEarnWs = totEarnWs.add(ernCppSum[j.intValue()]); // L:7475 ADD ERN-CPP-SUM(J) TO TOT-EARN-WS.
        totEarnYtdWs = totEarnYtdWs.add(ernEarnYtd[j.intValue()]);// L:7476 ADD ERN-EARN-YTD(J) TO TOT-EARN-YTD-WS.
        if ("fed ".equals(wsCaller) && "n".equals(ernCppFedTaxability[j.intValue()])) {// L:7478 IF WS-CALLER = "FED " AND               ...
            totEarnWs = totEarnWs.subtract(ernCppSum[j.intValue()]);// L:7480 SUBTRACT ERN-CPP-SUM(J) FROM TOT-EARN-WS...
            totEarnYtdWs = totEarnYtdWs.subtract(ernEarnYtd[j.intValue()]);// L:7481 SUBTRACT ERN-EARN-YTD(J) FROM TOT-EARN-Y...
        }                                                   // L:7482 END-IF
        if ("stt ".equals(wsCaller) && "n".equals(ernCppSttTaxability[j.intValue()])) {// L:7483 IF WS-CALLER = "STT " AND               ...
            totEarnWs = totEarnWs.subtract(ernCppSum[j.intValue()]);// L:7485 SUBTRACT ERN-CPP-SUM(J) FROM TOT-EARN-WS...
            totEarnYtdWs = totEarnYtdWs.subtract(ernEarnYtd[j.intValue()]);// L:7486 SUBTRACT ERN-EARN-YTD(J) FROM TOT-EARN-Y...
        }                                                   // L:7487 END-IF
        if ("cit ".equals(wsCaller) && "n".equals(ernCppCitTaxability[j.intValue()])) {// L:7488 IF WS-CALLER = "CIT " AND               ...
            totEarnWs = totEarnWs.subtract(ernCppSum[j.intValue()]);// L:7490 SUBTRACT ERN-CPP-SUM(J) FROM TOT-EARN-WS...
            totEarnYtdWs = totEarnYtdWs.subtract(ernEarnYtd[j.intValue()]);// L:7491 SUBTRACT ERN-EARN-YTD(J) FROM TOT-EARN-Y...
        }                                                   // L:7492 END-IF
        if ("loc ".equals(wsCaller) && "n".equals(ernCppLocTaxability[j.intValue()])) {// L:7493 IF WS-CALLER = "LOC " AND               ...
            totEarnWs = totEarnWs.subtract(ernCppSum[j.intValue()]);// L:7495 SUBTRACT ERN-CPP-SUM(J) FROM TOT-EARN-WS...
            totEarnYtdWs = totEarnYtdWs.subtract(ernEarnYtd[j.intValue()]);// L:7496 SUBTRACT ERN-EARN-YTD(J) FROM TOT-EARN-Y...
        }                                                   // L:7497 END-IF
        if ("oth ".equals(wsCaller) && "n".equals(ernCppOthTaxability[j.intValue()])) {// L:7498 IF WS-CALLER = "OTH " AND               ...
            totEarnWs = totEarnWs.subtract(ernCppSum[j.intValue()]);// L:7500 SUBTRACT ERN-CPP-SUM(J) FROM TOT-EARN-WS...
            totEarnYtdWs = totEarnYtdWs.subtract(ernEarnYtd[j.intValue()]);// L:7501 SUBTRACT ERN-EARN-YTD(J) FROM TOT-EARN-Y...
        }                                                   // L:7502 END-IF
        if ("fica".equals(wsCaller) && "n".equals(ernCppFicaTaxability[j.intValue()])) {// L:7503 IF WS-CALLER = "FICA" AND               ...
            totEarnWs = totEarnWs.subtract(ernCppSum[j.intValue()]);// L:7505 SUBTRACT ERN-CPP-SUM(J) FROM TOT-EARN-WS...
            totEarnYtdWs = totEarnYtdWs.subtract(ernEarnYtd[j.intValue()]);// L:7506 SUBTRACT ERN-EARN-YTD(J) FROM TOT-EARN-Y...
        }                                                   // L:7507 END-IF
        if ("futa".equals(wsCaller) && "n".equals(ernCppFutaTaxability[j.intValue()])) {// L:7508 IF WS-CALLER = "FUTA" AND               ...
            totEarnWs = totEarnWs.subtract(ernCppSum[j.intValue()]);// L:7510 SUBTRACT ERN-CPP-SUM(J) FROM TOT-EARN-WS...
            totEarnYtdWs = totEarnYtdWs.subtract(ernEarnYtd[j.intValue()]);// L:7511 SUBTRACT ERN-EARN-YTD(J) FROM TOT-EARN-Y...
        }                                                   // L:7512 END-IF
        if ("suca".equals(wsCaller) && "n".equals(ernCppSucaTaxability[j.intValue()])) {// L:7513 IF WS-CALLER = "SUCA" AND               ...
            totEarnWs = totEarnWs.subtract(ernCppSum[j.intValue()]);// L:7515 SUBTRACT ERN-CPP-SUM(J) FROM TOT-EARN-WS...
            totEarnYtdWs = totEarnYtdWs.subtract(ernEarnYtd[j.intValue()]);// L:7516 SUBTRACT ERN-EARN-YTD(J) FROM TOT-EARN-Y...
        }                                                   // L:7517 END-IF
    }

    private void addHours_300_260() {                       // L:7521 300-260-ADD-HOURS
        totHoursWs = BigDecimal.ZERO;                       // L:7522 MOVE ZERO TO TOT-HOURS-WS
        addHours_300_261();                                 // L:7523 PERFORM 300-261-ADD-HOURS
    }

    private void addHours_300_261() {                       // L:7526 300-261-ADD-HOURS
        totHoursWs = totHoursWs.add(hrsCppSum[j.intValue()]);// L:7527 ADD HRS-CPP-SUM(J) TO TOT-HOURS-WS.
        // /                                                // L:7528 COMMENT
    }

    private void computeEarn_300_270() {                    // L:7531 300-270-COMPUTE-EARN
        if ("f".equals(perSchdl)) {                         // L:7537 IF PER-SCHDL = "F"
            fww_300_272();                                  // L:7538 PERFORM 300-272-FWW THRU 300-272-EXIT
        } else {                                            // L:7539 ELSE
            findCode_300_271();                             // L:7540 PERFORM 300-271-FIND-CODE THRU 300-271-EXIT
        }  // period ends IF scope
    }

    private void findCode_300_271() {                       // L:7542 300-271-FIND-CODE
        if ((("2".equals(timCheckType) || "m".equals(timCheckType) || "v".equals(timCheckType) || "x".equals(timCheckType)) )) {// L:7549 IF (TIM-CHECK-TYPE = "2" OR "M" OR "V" O...
            if ("ee".equals(timType)) {                     // L:7550 IF TIM-TYPE = "EE"
                findIndex_300_278();                        // L:7551 PERFORM 300-278-FIND-INDEX
                findIndex_300_278();                        // L:7560 PERFORM 300-278-FIND-INDEX
                if ((k.compareTo(BigDecimal.valueOf(1)) < 0 || k.compareTo(BigDecimal.valueOf(33)) > 0 || l.compareTo(BigDecimal.valueOf(1)) < 0 || l.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:7566 IF (K < 1 OR K > 33 OR L < 1 OR L > 33)
                    messageO = "EARNINGS/DISTRIBUTION TABLE OVERFLOW-ABORT";// L:7567 MOVE "EARNINGS/DISTRIBUTION TABLE OVERFLOW-ABORT" TO MESSAGE-O
                    gtnError_800_700();                     // L:7569 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                    wsGtnErr = "AB";                        // L:7570 MOVE "AB" TO WS-GTN-ERR
                    // GO TO 300-271-EXIT - control flow    // L:7571 GO TO 300-271-EXIT
                } else {                                    // L:7572 ELSE
                    corpWrkTrn[k.intValue()] = new BigDecimal(timCorpWrk);// L:7573 MOVE TIM-CORP-WRK TO CORP-WRK-TRN(K)
                    storeWrkTrn[k.intValue()] = new BigDecimal(timStoreWrk);// L:7574 MOVE TIM-STORE-WRK TO STORE-WRK-TRN(K)
                    deptWrkTrn[k.intValue()] = new BigDecimal(timDeptWrk);// L:7575 MOVE TIM-DEPT-WRK TO DEPT-WRK-TRN(K)
                    typeTrn[k.intValue()] = timType;        // L:7576 MOVE TIM-TYPE TO TYPE-TRN(K)
                    codeTrn[k.intValue()] = timCode;        // L:7577 MOVE TIM-CODE TO CODE-TRN(K)
                    seqTrn[k.intValue()] = BigDecimal.valueOf(timTblElement);// L:7578 MOVE TIM-TBL-ELEMENT TO SEQ-TRN(K)
                    hoursTrn[k.intValue()] = hoursTrn[k.intValue()].add(timHours);// L:7579 ADD TIM-HOURS TO HOURS-TRN(K)
                    amountTrn[k.intValue()] = amountTrn[k.intValue()].add(timAmount);// L:7580 ADD TIM-AMOUNT TO AMOUNT-TRN(K)
                    rateTrn[k.intValue()] = timRate;        // L:7581 MOVE TIM-RATE TO RATE-TRN(K)
                    corpWrkDist[l.intValue()] = new BigDecimal(timCorpWrk);// L:7582 MOVE TIM-CORP-WRK TO CORP-WRK-DIST(L)
                    storeWrkDist[l.intValue()] = new BigDecimal(timStoreWrk);// L:7583 MOVE TIM-STORE-WRK TO STORE-WRK-DIST(L)
                    deptWrkDist[l.intValue()] = new BigDecimal(timDeptWrk);// L:7584 MOVE TIM-DEPT-WRK TO DEPT-WRK-DIST(L)
                    hoursDist[l.intValue()] = hoursDist[l.intValue()].add(timHours);// L:7585 ADD TIM-HOURS TO HOURS-DIST(L)
                    amountDist[l.intValue()] = amountDist[l.intValue()].add(timAmount);// L:7586 ADD TIM-AMOUNT TO AMOUNT-DIST(L)
                    // GO TO 300-271-EXIT - control flow    // L:7587 GO TO 300-271-EXIT
                }  // auto-close inner IF
            } else {                                        // L:7588 ELSE
                // GO TO 300-271-EXIT - control flow        // L:7589 GO TO 300-271-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        if ("s".equals(timGroup)) {                         // L:7595 IF TIM-GROUP = "S"
            timGroup = "E";                                 // L:7596 MOVE "E" TO TIM-GROUP
        }  // period ends IF scope
        if (!"e".equals(timGroup)) {                        // L:7597 IF TIM-GROUP NOT = "E" GO TO 300-271-EXI...
            premRateWs = BigDecimal.ZERO;                   // L:7598 MOVE ZERO TO PREM-RATE-WS
            rateWs = BigDecimal.ZERO;                       // L:7598 MOVE ZERO TO RATE-WS
            totalWs = BigDecimal.ZERO;                      // L:7598 MOVE ZERO TO TOTAL-WS
        }  // period ends IF scope
        factorWs = BigDecimal.valueOf(1.00);                // L:7599 MOVE 1.00 TO FACTOR-WS
        findIndex_300_278();                                // L:7600 PERFORM 300-278-FIND-INDEX
        if (j.compareTo(BigDecimal.valueOf(35)) > 0) {      // L:7603 IF J > 35
            messageO = "ILLEGAL TIME ENTRY CODE-SKIPPED";   // L:7604 MOVE "ILLEGAL TIME ENTRY CODE-SKIPPED" TO MESSAGE-O
            wsGtnErr = "CD";                                // L:7605 MOVE "CD" TO WS-GTN-ERR
            gtnError_800_700();                             // L:7606 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 300-271-EXIT - control flow            // L:7607 GO TO 300-271-EXIT
        }  // period ends IF scope
        workTimCode = timCode;                              // L:7614 MOVE TIM-CODE TO WORK-TIM-CODE
        pe3ClientNo = perClientNo;                          // L:7615 MOVE PER-CLIENT-NO TO PE3-CLIENT-NO
        pe3EmpNo = perEmpNo;                                // L:7616 MOVE PER-EMP-NO TO PE3-EMP-NO
        pe3SeqNo = j.intValue();                            // L:7617 MOVE J TO PE3-SEQ-NO
        readPaype3_800_403();                               // L:7618 PERFORM 800-403-READ-PAYPE3 THRU 800-403-EXIT
        if ("n".equals(recOk)) {                            // L:7619 IF REC-OK = "N"
            holdDiffFlg = clnDiffFlg[j.intValue()];         // L:7620 MOVE CLN-DIFF-FLG(J) TO HOLD-DIFF-FLG
            holdDiffAmt = clnDiffAmt[j.intValue()];         // L:7621 MOVE CLN-DIFF-AMT(J) TO HOLD-DIFF-AMT
            holdMultiplier = clnMultiplier[j.intValue()];   // L:7622 MOVE CLN-MULTIPLIER(J) TO HOLD-MULTIPLIER
        } else {                                            // L:7623 ELSE
            holdDiffFlg = pe3DiffFlg;                       // L:7624 MOVE PE3-DIFF-FLG TO HOLD-DIFF-FLG
            holdDiffAmt = pe3DiffAmt;                       // L:7625 MOVE PE3-DIFF-AMT TO HOLD-DIFF-AMT
            holdMultiplier = pe3Multiplier;                 // L:7626 MOVE PE3-MULTIPLIER TO HOLD-MULTIPLIER
        }  // period ends IF scope
        if (perRteHourly.compareTo(BigDecimal.ZERO) != 0) { // L:7637 IF PER-RTE-HOURLY NOT = ZERO
            rateWs = perRteHourly;                          // L:7638 MOVE PER-RTE-HOURLY TO RATE-WS
            if ("+".equals(holdDiffFlg)) {                  // L:7639 IF HOLD-DIFF-FLG = "+"
                rateWs = holdDiffAmt.add(perRteHourly);     // L:7640 ADD HOLD-DIFF-AMT PER-RTE-HOURLY GIVING ...
            }  // period ends IF scope
        }  // period ends IF scope
        if (perRteHourly.compareTo(BigDecimal.ZERO) != 0) { // L:7641 IF PER-RTE-HOURLY NOT = ZERO
            rateWs = rateWs.multiply(holdMultiplier);       // L:7642 MULTIPLY HOLD-MULTIPLIER BY RATE-WS
        } else {                                            // L:7644 ELSE
            rateWs = perRteSalary;                          // L:7645 MOVE PER-RTE-SALARY TO RATE-WS
        }  // period ends IF scope
        if (perRteHourly.compareTo(BigDecimal.ZERO) != 0) { // L:7646 IF PER-RTE-HOURLY NOT = ZERO
            if (timHours.compareTo(BigDecimal.ZERO) == 0) { // L:7647 IF TIM-HOURS = ZERO
                rateWs = perRteSalary;                      // L:7648 MOVE PER-RTE-SALARY TO RATE-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if ((timHours.compareTo(BigDecimal.ZERO) != 0 && "$".equals(holdDiffFlg))) {// L:7654 IF (TIM-HOURS NOT = ZERO AND HOLD-DIFF-F...
            rateWs = rateWs.add(holdDiffAmt);               // L:7655 ADD HOLD-DIFF-AMT TO RATE-WS.
        }  // period ends IF scope
        if ((timHours.compareTo(BigDecimal.ZERO) != 0 && "%".equals(holdDiffFlg))) {// L:7661 IF (TIM-HOURS NOT = ZERO AND HOLD-DIFF-F...
            rateWs = rateWs.multiply(holdDiffAmt);          // L:7662 MULTIPLY HOLD-DIFF-AMT BY RATE-WS
            if (timRate.compareTo(BigDecimal.ZERO) != 0) {  // L:7669 IF TIM-RATE NOT = ZERO MOVE TIM-RATE TO ...
                if (timRate.compareTo(BigDecimal.ZERO) == 0 && timAmount.compareTo(BigDecimal.ZERO) == 0 && "s".equals(perSchdl) && perRteSalary.compareTo(BigDecimal.ZERO) != 0) {// L:7672 IF TIM-RATE = ZERO AND                  ...
                    rateWs = perRteSalary;                  // L:7676 MOVE PER-RTE-SALARY TO RATE-WS
                    if ("y".equals(wsCliOpt630Sw) && "s".equals(perSchdl)) {// L:7683 IF WS-CLI-OPT-630-SW = "Y" AND          ...
                        if ("697".equals(cClientEnv)) {     // L:7687 IF C-CLIENT-ENV = "697"                 ...
                            if (timHours.compareTo(perSchdlHrs) != 0 && perSchdlHrs.compareTo(BigDecimal.ZERO) != 0) {// L:7688 IF TIM-HOURS NOT = PER-SCHDL-HRS AND    ...
                                // COMPUTE incomplete (multi-line): COMPUTE PER-RTE-HOURLY = PER-RTE-SALARY /// L:7690 COMPUTE PER-RTE-HOURLY = PER-RTE-SALARY ...
                            }                               // L:7692 END-IF
                        }                                   // L:7693 END-IF
                        if ((timRate.compareTo(BigDecimal.ZERO) == 0 || timAmount.compareTo(BigDecimal.ZERO) == 0) && perRteHourly.compareTo(BigDecimal.ZERO) != 0 && timHours.compareTo(BigDecimal.ZERO) != 0) {// L:7694 IF (TIM-RATE = ZERO OR                  ...
                            rateWs = perRteHourly;          // L:7698 MOVE PER-RTE-HOURLY TO RATE-WS
                            findIndex_300_278();            // L:7705 PERFORM 300-278-FIND-INDEX
                            findIndex_300_278();            // L:7725 PERFORM 300-278-FIND-INDEX
                            if (( k.compareTo(BigDecimal.valueOf(1)) < 0 || k.compareTo(BigDecimal.valueOf(33)) > 0 || l.compareTo(BigDecimal.valueOf(1)) < 0 || l.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:7739 IF ( K < 1 OR K > 33 OR L < 1 OR L > 33)
                                messageO = "EARNINGS/DISTRIBUTION TABLE OVERFLOW";// L:7740 MOVE "EARNINGS/DISTRIBUTION TABLE OVERFLOW" TO MESSAGE-O
                                wsGtnErr = "AB";            // L:7742 MOVE "AB" TO WS-GTN-ERR
                                gtnError_800_700();         // L:7743 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                                // GO TO 300-271-EXIT - control flow// L:7744 GO TO 300-271-EXIT
                            }  // period ends IF scope
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        corpWrkTrn[k.intValue()] = new BigDecimal(timCorpWrk);// L:7745 MOVE TIM-CORP-WRK TO CORP-WRK-TRN(K)
        corpWrkDist[l.intValue()] = new BigDecimal(timCorpWrk);// L:7745 MOVE TIM-CORP-WRK TO CORP-WRK-DIST(L)
        storeWrkTrn[k.intValue()] = new BigDecimal(timStoreWrk);// L:7746 MOVE TIM-STORE-WRK TO STORE-WRK-TRN(K)
        storeWrkDist[l.intValue()] = new BigDecimal(timStoreWrk);// L:7746 MOVE TIM-STORE-WRK TO STORE-WRK-DIST(L)
        deptWrkTrn[k.intValue()] = new BigDecimal(timDeptWrk);// L:7747 MOVE TIM-DEPT-WRK TO DEPT-WRK-TRN(K)
        deptWrkDist[l.intValue()] = new BigDecimal(timDeptWrk);// L:7747 MOVE TIM-DEPT-WRK TO DEPT-WRK-DIST(L)
        if (j.compareTo(BigDecimal.valueOf(35)) <= 0) {     // L:7751 IF J NOT > 35
            if ((timAmount.compareTo(BigDecimal.ZERO) == 0 && timHours.compareTo(BigDecimal.ZERO) != 0 && perRteHourly.compareTo(BigDecimal.ZERO) != 0)) {// L:7752 IF (TIM-AMOUNT = ZERO AND TIM-HOURS NOT ...
                rateWs = rateWs.multiply(timHours);         // L:7755 MULTIPLY TIM-HOURS BY RATE-WS
                if ("n".equals(wsCliOpt630Sw)) {            // L:7761 IF WS-CLI-OPT-630-SW = "N"              ...
                    if (j.compareTo(BigDecimal.valueOf(35)) <= 0 && timAmount.compareTo(BigDecimal.ZERO) == 0 && "s".equals(perSchdl) && perRteSalary.compareTo(BigDecimal.ZERO) != 0) {// L:7762 IF J NOT > 35
                        totalWs = perRteSalary;             // L:7769 MOVE PER-RTE-SALARY TO TOTAL-WS
                        if ("reg1".equals(timCode) && timHours.compareTo(BigDecimal.ZERO) == 0) {// L:7770 IF TIM-CODE = "REG1"
                            timHours = perSchdlHrs;         // L:7773 MOVE PER-SCHDL-HRS TO TIM-HOURS
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (timAmount.compareTo(BigDecimal.ZERO) != 0) {    // L:7777 IF TIM-AMOUNT NOT = ZERO MOVE TIM-AMOUNT...
        }  // period ends IF scope
        if (j.compareTo(BigDecimal.valueOf(35)) <= 0 && "reg1".equals(timCode) && timHours.compareTo(BigDecimal.ZERO) == 0 && "r".equals(timCheckType) && "s".equals(perSchdl) && perRteSalary.compareTo(totalWs) == 0 && perRteSalary.compareTo(BigDecimal.ZERO) != 0) {// L:7783 IF J NOT > 35
            timHours = perSchdlHrs;                         // L:7796 MOVE PER-SCHDL-HRS TO TIM-HOURS
        }  // period ends IF scope
        if (j.compareTo(BigDecimal.valueOf(35)) <= 0) {     // L:7800 IF J NOT > 35
            ernCppSum[j.intValue()] = ernCppSum[j.intValue()].add(totalWs);// L:7801 ADD TOTAL-WS TO ERN-CPP-SUM(J)
            hrsCppSum[35] = hrsCppSum[35].add(timHours);    // L:7802 ADD TIM-HOURS TO HRS-CPP-SUM(35)
            hrsCppSum[j.intValue()] = hrsCppSum[j.intValue()].add(timHours);// L:7803 ADD TIM-HOURS TO HRS-CPP-SUM(J).
        }  // period ends IF scope
        typeTrn[k.intValue()] = timType;                    // L:7804 MOVE TIM-TYPE TO TYPE-TRN(K)
        codeTrn[k.intValue()] = timCode;                    // L:7805 MOVE TIM-CODE TO CODE-TRN(K)
        seqTrn[k.intValue()] = BigDecimal.valueOf(timTblElement);// L:7806 MOVE TIM-TBL-ELEMENT TO SEQ-TRN(K)
        hoursTrn[k.intValue()] = hoursTrn[k.intValue()].add(timHours);// L:7807 ADD TIM-HOURS TO HOURS-TRN(K).
        rateTrn[k.intValue()] = rateWs;                     // L:7808 MOVE RATE-WS TO RATE-TRN(K)
        amountTrn[k.intValue()] = amountTrn[k.intValue()].add(totalWs);// L:7809 ADD TOTAL-WS TO AMOUNT-TRN(K).
        hoursDist[l.intValue()] = hoursDist[l.intValue()].add(timHours);// L:7810 ADD TIM-HOURS TO HOURS-DIST(L).
        amountDist[l.intValue()] = amountDist[l.intValue()].add(totalWs);// L:7811 ADD TOTAL-WS TO AMOUNT-DIST(L).
        // 300-271-EXIT. EXIT.                              // L:7813 CODE
        // /                                                // L:7815 COMMENT
    }

    private void fww_300_272() {                            // L:7824 300-272-FWW
        if ((("2".equals(timCheckType) || "m".equals(timCheckType) || "v".equals(timCheckType) || "x".equals(timCheckType)) )) {// L:7825 IF (TIM-CHECK-TYPE = "2" OR "M" OR "V" O...
            if ("ee".equals(timType)) {                     // L:7826 IF TIM-TYPE = "EE"
                findIndex_300_278();                        // L:7827 PERFORM 300-278-FIND-INDEX
                findIndex_300_278();                        // L:7836 PERFORM 300-278-FIND-INDEX
                if ((k.compareTo(BigDecimal.valueOf(1)) < 0 || k.compareTo(BigDecimal.valueOf(33)) > 0 || l.compareTo(BigDecimal.valueOf(1)) < 0 || l.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:7842 IF (K < 1 OR K > 33 OR L < 1 OR L > 33)
                    messageO = "EARNINGS/DISTRIBUTION TABLE OVERFLOW.";// L:7843 MOVE "EARNINGS/DISTRIBUTION TABLE OVERFLOW." TO MESSAGE-O
                    wsGtnErr = "AB";                        // L:7845 MOVE "AB" TO WS-GTN-ERR
                    gtnError_800_700();                     // L:7846 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                    // GO TO 300-272-EXIT - control flow    // L:7847 GO TO 300-272-EXIT
                } else {                                    // L:7848 ELSE
                    corpWrkTrn[k.intValue()] = new BigDecimal(timCorpWrk);// L:7849 MOVE TIM-CORP-WRK TO CORP-WRK-TRN(K)
                    storeWrkTrn[k.intValue()] = new BigDecimal(timStoreWrk);// L:7850 MOVE TIM-STORE-WRK TO STORE-WRK-TRN(K)
                    deptWrkTrn[k.intValue()] = new BigDecimal(timDeptWrk);// L:7851 MOVE TIM-DEPT-WRK TO DEPT-WRK-TRN(K)
                    typeTrn[k.intValue()] = timType;        // L:7852 MOVE TIM-TYPE TO TYPE-TRN(K)
                    codeTrn[k.intValue()] = timCode;        // L:7853 MOVE TIM-CODE TO CODE-TRN(K)
                    hoursTrn[k.intValue()] = hoursTrn[k.intValue()].add(timHours);// L:7854 ADD TIM-HOURS TO HOURS-TRN(K)
                    seqTrn[k.intValue()] = BigDecimal.valueOf(timTblElement);// L:7855 MOVE TIM-TBL-ELEMENT TO SEQ-TRN(K)
                    amountTrn[k.intValue()] = amountTrn[k.intValue()].add(timAmount);// L:7856 ADD TIM-AMOUNT TO AMOUNT-TRN(K)
                    rateTrn[k.intValue()] = timRate;        // L:7857 MOVE TIM-RATE TO RATE-TRN(K)
                    corpWrkDist[l.intValue()] = new BigDecimal(timCorpWrk);// L:7858 MOVE TIM-CORP-WRK TO CORP-WRK-DIST(L)
                    storeWrkDist[l.intValue()] = new BigDecimal(timStoreWrk);// L:7859 MOVE TIM-STORE-WRK TO STORE-WRK-DIST(L)
                    deptWrkDist[l.intValue()] = new BigDecimal(timDeptWrk);// L:7860 MOVE TIM-DEPT-WRK TO DEPT-WRK-DIST(L)
                    hoursDist[l.intValue()] = hoursDist[l.intValue()].add(timHours);// L:7861 ADD TIM-HOURS TO HOURS-DIST(L)
                    amountDist[l.intValue()] = amountDist[l.intValue()].add(timAmount);// L:7862 ADD TIM-AMOUNT TO AMOUNT-DIST(L)
                    // GO TO 300-272-EXIT - control flow    // L:7863 GO TO 300-272-EXIT
                }  // auto-close inner IF
            } else {                                        // L:7864 ELSE
                // GO TO 300-272-EXIT - control flow        // L:7865 GO TO 300-272-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        if ("s".equals(timGroup)) {                         // L:7871 IF TIM-GROUP = "S"
            timGroup = "E";                                 // L:7872 MOVE "E" TO TIM-GROUP
        }  // period ends IF scope
        if (!"e".equals(timGroup)) {                        // L:7873 IF TIM-GROUP NOT = "E" GO TO 300-272-EXI...
            premRateWs = BigDecimal.ZERO;                   // L:7874 MOVE ZERO TO PREM-RATE-WS
            rateWs = BigDecimal.ZERO;                       // L:7874 MOVE ZERO TO RATE-WS
            totalWs = BigDecimal.ZERO;                      // L:7874 MOVE ZERO TO TOTAL-WS
        }  // period ends IF scope
        findIndex_300_278();                                // L:7875 PERFORM 300-278-FIND-INDEX
        if (j.compareTo(BigDecimal.valueOf(35)) > 0) {      // L:7878 IF J > 35
            messageO = "ILLEGAL TIME ENTRY CODE-SKIPPED";   // L:7879 MOVE "ILLEGAL TIME ENTRY CODE-SKIPPED" TO MESSAGE-O
            wsGtnErr = "IO";                                // L:7880 MOVE "IO" TO WS-GTN-ERR
            gtnError_800_700();                             // L:7881 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 300-272-EXIT - control flow            // L:7882 GO TO 300-272-EXIT
        }  // period ends IF scope
        rateWs = timRate;                                   // L:7883 MOVE TIM-RATE TO RATE-WS
        if (timRate.compareTo(BigDecimal.ZERO) == 0) {      // L:7884 IF TIM-RATE = ZERO
            rateWs = perRteSalary;                          // L:7885 MOVE PER-RTE-SALARY TO RATE-WS
        }  // period ends IF scope
        findIndex_300_278();                                // L:7891 PERFORM 300-278-FIND-INDEX
        findIndex_300_278();                                // L:7915 PERFORM 300-278-FIND-INDEX
        if (( k.compareTo(BigDecimal.valueOf(1)) < 0 || k.compareTo(BigDecimal.valueOf(33)) > 0 || l.compareTo(BigDecimal.valueOf(1)) < 0 || l.compareTo(BigDecimal.valueOf(33)) > 0)) {// L:7933 IF ( K < 1 OR K > 33 OR L < 1 OR L > 33)
            messageO = "EARNINGS/DISTRIBUTION TABLE OVERFLOW.";// L:7934 MOVE "EARNINGS/DISTRIBUTION TABLE OVERFLOW." TO MESSAGE-O
            gtnError_800_700();                             // L:7936 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        corpWrkTrn[k.intValue()] = new BigDecimal(timCorpWrk);// L:7937 MOVE TIM-CORP-WRK TO CORP-WRK-TRN(K)
        corpWrkDist[l.intValue()] = new BigDecimal(timCorpWrk);// L:7937 MOVE TIM-CORP-WRK TO CORP-WRK-DIST(L)
        storeWrkTrn[k.intValue()] = new BigDecimal(timStoreWrk);// L:7938 MOVE TIM-STORE-WRK TO STORE-WRK-TRN(K)
        storeWrkDist[l.intValue()] = new BigDecimal(timStoreWrk);// L:7938 MOVE TIM-STORE-WRK TO STORE-WRK-DIST(L)
        deptWrkTrn[k.intValue()] = new BigDecimal(timDeptWrk);// L:7939 MOVE TIM-DEPT-WRK TO DEPT-WRK-TRN(K)
        deptWrkDist[l.intValue()] = new BigDecimal(timDeptWrk);// L:7939 MOVE TIM-DEPT-WRK TO DEPT-WRK-DIST(L)
        if (timAmount.compareTo(BigDecimal.ZERO) != 0) {    // L:7945 IF TIM-AMOUNT NOT = ZERO MOVE TIM-AMOUNT...
            if (j.compareTo(BigDecimal.valueOf(35)) <= 0) { // L:7951 IF J NOT > 35
                ernCppSum[j.intValue()] = ernCppSum[j.intValue()].add(totalWs);// L:7952 ADD TOTAL-WS TO ERN-CPP-SUM(J)
                hrsCppSum[35] = hrsCppSum[35].add(timHours);// L:7953 ADD TIM-HOURS TO HRS-CPP-SUM(35)
                hrsCppSum[j.intValue()] = hrsCppSum[j.intValue()].add(timHours);// L:7954 ADD TIM-HOURS TO HRS-CPP-SUM(J).
            }  // period ends IF scope
        }  // period ends IF scope
        typeTrn[k.intValue()] = timType;                    // L:7955 MOVE TIM-TYPE TO TYPE-TRN(K)
        codeTrn[k.intValue()] = timCode;                    // L:7956 MOVE TIM-CODE TO CODE-TRN(K)
        hoursTrn[k.intValue()] = hoursTrn[k.intValue()].add(timHours);// L:7957 ADD TIM-HOURS TO HOURS-TRN(K).
        seqTrn[k.intValue()] = BigDecimal.valueOf(timTblElement);// L:7958 MOVE TIM-TBL-ELEMENT TO SEQ-TRN(K)
        rateTrn[k.intValue()] = rateWs;                     // L:7959 MOVE RATE-WS TO RATE-TRN(K)
        amountTrn[k.intValue()] = amountTrn[k.intValue()].add(totalWs);// L:7960 ADD TOTAL-WS TO AMOUNT-TRN(K).
        hoursDist[l.intValue()] = hoursDist[l.intValue()].add(timHours);// L:7961 ADD TIM-HOURS TO HOURS-DIST(L).
        amountDist[l.intValue()] = amountDist[l.intValue()].add(totalWs);// L:7962 ADD TOTAL-WS TO AMOUNT-DIST(L).
        // 300-272-EXIT. EXIT.                              // L:7963 CODE
    }

    private void findIndex_300_278() {                      // L:7965 300-278-FIND-INDEX
        // /                                                // L:7966 COMMENT
    }

    private void voluntaryDeductions_300_300() {            // L:7967 300-300-VOLUNTARY-DEDUCTIONS
        if ("y".equals(cln4K90RegOptWs) && (("4K90".equals(dedNoSum[i.intValue()]) || "4KPA".equals(dedNoSum[i.intValue()]))) && "ts".equals(dedParaSum[i.intValue()])) {// L:7968 IF CLN-4K90-REG-OPT-WS = "Y" AND
            // ADD parse failed: ADD ERN-CPP-SUM (1),       // L:7971 ADD ERN-CPP-SUM (1),
        } else {                                            // L:7975 ELSE
        }  // period ends IF scope
        if ("ba".equals(dedParaSum[i.intValue()])) {        // L:7977 IF DED-PARA-SUM(I) = "BA"               ...
            ernDedGrossWs = pctTotEarnWs;                   // L:7978 MOVE PCT-TOT-EARN-WS TO ERN-DED-GROSS-WS
        } else {                                            // L:7979 ELSE
            if ("be".equals(dedParaSum[i.intValue()])) {    // L:7980 IF DED-PARA-SUM(I) = "BE"               ...
                ernDedGrossWs = pctTotEarnWs;               // L:7981 MOVE PCT-TOT-EARN-WS TO ERN-DED-GROSS-WS
            } else {                                        // L:7982 ELSE
                ernDedGrossWs = ernCppGrossSum;             // L:7983 MOVE ERN-CPP-GROSS-SUM TO ERN-DED-GROSS-WS
                if (dedNoSum[i.intValue()] != "" && (!"ba".equals(dedParaSum[i.intValue()]) && !"wc".equals(dedParaSum[i.intValue()])) && dedNoToTakeSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:7984 IF DED-NO-SUM(I) NOT = SPACES
                    calculateDeduction_300_310();           // L:7989 PERFORM 300-310-CALCULATE-DEDUCTION
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (dedNoSum[i.intValue()] != "" && "wc".equals(dedParaSum[i.intValue()]) && dedNoToTakeSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:7990 IF DED-NO-SUM(I) NOT = SPACES
            calcWcTax_300_330();                            // L:7995 PERFORM 300-330-CALC-WC-TAX THRU 300-330-EXIT
        }  // period ends IF scope
        // 300-300-EXIT. EXIT.                              // L:7997 CODE
    }

    private void calculateDeduction_300_310() {             // L:8000 300-310-CALCULATE-DEDUCTION
        okFlag = okLit;                                     // L:8001 MOVE OK-LIT TO OK-FLAG
        dedAmtWs = BigDecimal.ZERO;                         // L:8002 MOVE ZERO TO DED-AMT-WS
        if ((("fa".equals(dedParaSum[i.intValue()]) || "bo".equals(dedParaSum[i.intValue()]) || "ts".equals(dedParaSum[i.intValue()]) || "be".equals(dedParaSum[i.intValue()]))) || ("ec".equals(dedParaSum[i.intValue()]) && dedOptNoSum[i.intValue()].compareTo(BigDecimal.valueOf(2)) == 0)) {// L:8004 IF (DED-PARA-SUM(I) = "FA" OR "BO" OR "T...
            normalDeduction_300_311();                      // L:8010 PERFORM 300-311-NORMAL-DEDUCTION
        } else {                                            // L:8011 ELSE
            if ("fd".equals(dedParaSum[i.intValue()])) {    // L:8012 IF DED-PARA-SUM(I) = "FD"
                fixedDisposable_300_312();                  // L:8013 PERFORM 300-312-FIXED-DISPOSABLE
            } else {                                        // L:8014 ELSE
                if ("fn".equals(dedParaSum[i.intValue()])) {// L:8015 IF DED-PARA-SUM(I) = "FN"
                    fixedNet_300_313();                     // L:8016 PERFORM 300-313-FIXED-NET
                } else {                                    // L:8017 ELSE
                    if (("ec".equals(dedParaSum[i.intValue()]) || "eh".equals(dedParaSum[i.intValue()])) && (dedOptNoSum[i.intValue()].compareTo(BigDecimal.valueOf(2)) != 0 && dedOptNoSum[i.intValue()].compareTo(BigDecimal.valueOf(3)) != 0)) {// L:8022 IF (DED-PARA-SUM(I) = "EC" OR           ...
                        emprContribution_300_314();         // L:8026 PERFORM 300-314-EMPR-CONTRIBUTION
                    } else {                                // L:8027 ELSE
                        if ("ec".equals(dedParaSum[i.intValue()]) && (dedOptNoSum[i.intValue()].compareTo(BigDecimal.valueOf(3)) == 0)) {// L:8028 IF DED-PARA-SUM(I) = "EC"               ...
                            multiLvlEc_300_316();           // L:8034 PERFORM 300-316-MULTI-LVL-EC
                        } else {                            // L:8035 ELSE
                            if ("te".equals(dedParaSum[i.intValue()])) {// L:8036 IF DED-PARA-SUM(I) = "TE"               ...
                                te_300_317();               // L:8037 PERFORM 300-317-TE
                                // ORPHAN ELSE (no matching IF)// L:8040 ELSE
                                if ("y".equals(dedErrSum[i.intValue()])) {// L:8041 IF DED-ERR-SUM(I) = "Y"
                                    dedAmtWs = BigDecimal.ZERO;// L:8042 MOVE ZERO TO DED-AMT-WS
                                    noToTakeWs = BigDecimal.ZERO;// L:8042 MOVE ZERO TO NO-TO-TAKE-WS
                                } else {                    // L:8043 ELSE
                                    dedRoutineError_300_321();// L:8044 PERFORM 300-321-DED-ROUTINE-ERROR
                                }  // period ends IF scope
                            }  // period ends IF scope
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (ok) {                                           // L:8045 IF NOT OK
            dedErrSum[i.intValue()] = "Y";                  // L:8046 MOVE "Y" TO DED-ERR-SUM(I)
        }  // period ends IF scope
        takeDeduction_300_319();                            // L:8047 PERFORM 300-319-TAKE-DEDUCTION THRU 300-319-EXIT
        dedAmtWsFd = dedAmtWs;                              // L:8054 MOVE DED-AMT-WS TO DED-AMT-WS-FD
        // CALL PYDXXFK                                     // L:8055 CALL "PYDXXFK" USING C-RET-CODE,        ...
        callPydxxfk();
    }

    private void normalDeduction_300_311() {                // L:8061 300-311-NORMAL-DEDUCTION
        if (dedPctSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8062 IF DED-PCT-SUM(I) NOT = ZERO
            // DIVIDE parse failed: DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING DED-PCT-WS         IBM-CT// L:8063 DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING D...
            pctTotEarnWs = pctTotEarnWs.multiply(dedPctWs); // L:8066 MULTIPLY DED-PCT-WS BY PCT-TOT-EARN-WS  ...
            dedAmtWs = BigDecimal.ZERO;                     // L:8069 MOVE ZERO TO DED-AMT-WS
        }  // period ends IF scope
        if (dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8070 IF DED-AMT-SUM(I) NOT = ZERO
            dedAmtWs = dedAmtSum[i.intValue()];             // L:8071 MOVE DED-AMT-SUM(I) TO DED-AMT-WS
        }  // period ends IF scope
    }

    private void fixedDisposable_300_312() {                // L:8073 300-312-FIXED-DISPOSABLE
        cRetCode = "";                                      // L:8077 MOVE SPACES TO C-RET-CODE
        wsDateEndPacked = wsDateEnd;                        // L:8078 MOVE WS-DATE-END TO WS-DATE-END-PACKED
        fdErnCppGrsLessTxSum = ernCppGrsLessTxSum;          // L:8079 MOVE ERN-CPP-GRS-LESS-TX-SUM TO FD-ERN-CPP-GRS-LESS-TX-SUM
        // CALL PYJKXFK                                     // L:8087 CALL "PYJKXFK" USING C-RET-CODE, PER-CLI...
        callPyjkxfk();
        if (dedPctSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8093 IF DED-PCT-SUM(I) NOT = ZERO
            // DIVIDE parse failed: DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING DED-PCT-WS         IBM-CT// L:8094 DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING D...
            fdErnCppGrsLessTxSum = fdErnCppGrsLessTxSum.multiply(dedPctWs);// L:8096 MULTIPLY DED-PCT-WS BY FD-ERN-CPP-GRS-LE...
            dedAmtWs = BigDecimal.ZERO;                     // L:8099 MOVE ZERO TO DED-AMT-WS
        }  // period ends IF scope
        if (dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8100 IF DED-AMT-SUM(I) NOT = ZERO
            dedAmtWs = dedAmtSum[i.intValue()];             // L:8101 MOVE DED-AMT-SUM(I) TO DED-AMT-WS
        }  // period ends IF scope
    }

    private void fixedNet_300_313() {                       // L:8103 300-313-FIXED-NET
        if (dedPctSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8104 IF DED-PCT-SUM(I) NOT = ZERO
            // DIVIDE parse failed: DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING DED-PCT-WS         IBM-CT// L:8105 DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING D...
            pctTotEarnWs = pctTotEarnWs.multiply(dedPctWs); // L:8108 MULTIPLY DED-PCT-WS BY PCT-TOT-EARN-WS  ...
            dedAmtWs = BigDecimal.ZERO;                     // L:8111 MOVE ZERO TO DED-AMT-WS
        }  // period ends IF scope
        if (dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8112 IF DED-AMT-SUM(I) NOT = ZERO
            dedAmtWs = dedAmtSum[i.intValue()];             // L:8113 MOVE DED-AMT-SUM(I) TO DED-AMT-WS
        }  // period ends IF scope
    }

    private void emprContribution_300_314() {               // L:8118 300-314-EMPR-CONTRIBUTION
        findTsTeFa_300_315();                               // L:8122 PERFORM 300-315-FIND-TS-TE-FA
        if (k.compareTo(BigDecimal.valueOf(165)) > 0 || dedAssocDedNoSum[i.intValue()].compareTo(dedNoSum[k.intValue()]) != 0) {// L:8127 IF K > 165                              ...
            dedAmtWs = BigDecimal.ZERO;                     // L:8130 MOVE 0 TO DED-AMT-WS
        } else {                                            // L:8131 ELSE
            dedAmtWs = dedAmtSum[k.intValue()];             // L:8132 MOVE DED-AMT-SUM(K) TO DED-AMT-WS
        }  // period ends IF scope
        if (dedPctSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8138 IF DED-PCT-SUM(I) NOT = ZERO
            // DIVIDE parse failed: DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING DED-PCT-WS         IBM-CT// L:8139 DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING D...
            dedAmtWs = dedAmtWs.multiply(dedPctWs);         // L:8140 MULTIPLY DED-PCT-WS BY DED-AMT-WS
            dedAmtWs = BigDecimal.ZERO;                     // L:8143 MOVE ZERO TO DED-AMT-WS
        }  // period ends IF scope
        if (dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8144 IF DED-AMT-SUM(I) NOT = ZERO
            dedAmtWs = dedAmtSum[i.intValue()];             // L:8145 MOVE DED-AMT-SUM(I) TO DED-AMT-WS
        }  // period ends IF scope
        dedMaxWs = BigDecimal.valueOf(99999.99);            // L:8151 MOVE 99999.99 TO DED-MAX-WS
        if ((dedOptSum[i.intValue()].compareTo(BigDecimal.ZERO) > 0 && dedOptSum[i.intValue()].compareTo(BigDecimal.valueOf(100)) <= 0)) {// L:8152 IF (DED-OPT-SUM(I) > ZERO AND DED-OPT-SU...
            // DIVIDE parse failed: DIVIDE DED-OPT-SUM(I) BY 100.00 GIVING DED-PCT-WS         IBM-CT// L:8153 DIVIDE DED-OPT-SUM(I) BY 100.00 GIVING D...
            pctTotEarnWs = pctTotEarnWs.multiply(dedPctWs); // L:8155 MULTIPLY DED-PCT-WS BY PCT-TOT-EARN-WS  ...
            dedMaxWs = BigDecimal.ZERO;                     // L:8158 MOVE ZERO TO DED-MAX-WS
        }  // period ends IF scope
        if (dedAmtWs.compareTo(dedMaxWs) > 0) {             // L:8164 IF DED-AMT-WS > DED-MAX-WS
            dedAmtWs = dedMaxWs;                            // L:8165 MOVE DED-MAX-WS TO DED-AMT-WS
        }  // period ends IF scope
    }

    private void findTsTeFa_300_315() {                     // L:8170 300-315-FIND-TS-TE-FA
        // /                                                // L:8172 COMMENT
    }

    private void multiLvlEc_300_316() {                     // L:8173 300-316-MULTI-LVL-EC
        findTsTeFa_300_315();                               // L:8177 PERFORM 300-315-FIND-TS-TE-FA
        if (k.compareTo(BigDecimal.valueOf(125)) > 0 || dedAssocDedNoSum[i.intValue()].compareTo(dedNoSum[k.intValue()]) != 0) {// L:8180 IF K > 125                              ...
            dedPctWs = BigDecimal.ZERO;                     // L:8183 MOVE 0 TO DED-PCT-WS
        } else {                                            // L:8184 ELSE
            // DIVIDE parse failed: DIVIDE DED-PCT-SUM(K) BY 100.00 GIVING DED-PCT-WS.// L:8185 DIVIDE DED-PCT-SUM(K) BY 100.00 GIVING D...
        }  // period ends IF scope
        dedAmtLvl1Ws = BigDecimal.ZERO;                     // L:8191 MOVE 0 TO DED-AMT-LVL1-WS
        dedMaxLvl1Ws = BigDecimal.ZERO;                     // L:8191 MOVE 0 TO DED-MAX-LVL1-WS
        dedAmtLvl2Ws = BigDecimal.ZERO;                     // L:8191 MOVE 0 TO DED-AMT-LVL2-WS
        dedMaxLvl2Ws = BigDecimal.ZERO;                     // L:8191 MOVE 0 TO DED-MAX-LVL2-WS
        dedPctLvl1Ws = BigDecimal.ZERO;                     // L:8191 MOVE 0 TO DED-PCT-LVL1-WS
        dedPctLvl2Ws = BigDecimal.ZERO;                     // L:8191 MOVE 0 TO DED-PCT-LVL2-WS
        dedPctLvl1Ws = dedL1PctWs[i.intValue()];            // L:8201 MOVE DED-L1-PCT-WS (I) TO DED-PCT-LVL1-WS
        dedMatLvl1Ws = dedL1MatWs[i.intValue()];            // L:8202 MOVE DED-L1-MAT-WS (I) TO DED-MAT-LVL1-WS
        dedMatLvl1Ws = dedMatLvl1Ws.multiply(pctTotEarnWs); // L:8204 MULTIPLY PCT-TOT-EARN-WS BY DED-MAT-LVL1...
        if (dedPctWs.compareTo(dedPctLvl1Ws) < 0) {         // L:8207 IF DED-PCT-WS < DED-PCT-LVL1-WS         ...
            dedPctLvl1Ws = dedPctWs;                        // L:8208 MOVE DED-PCT-WS TO DED-PCT-LVL1-WS
            dedAmtLvl1Ws = dedAmtLvl1Ws.multiply(dedPctLvl1Ws);// L:8209 MULTIPLY DED-PCT-LVL1-WS BY DED-AMT-LVL1...
        }  // period ends IF scope
        dedPctLvl2Ws = dedL2PctWs[i.intValue()];            // L:8219 MOVE DED-L2-PCT-WS (I) TO DED-PCT-LVL2-WS
        dedMatLvl2Ws = dedL2MatWs[i.intValue()];            // L:8220 MOVE DED-L2-MAT-WS (I) TO DED-MAT-LVL2-WS
        dedMatLvl2Ws = dedMatLvl2Ws.multiply(pctTotEarnWs); // L:8222 MULTIPLY PCT-TOT-EARN-WS BY DED-MAT-LVL2...
        dedPctWs = dedPctWs.subtract(dedPctLvl1Ws);         // L:8224 SUBTRACT DED-PCT-LVL1-WS FROM DED-PCT-WS...
        if (dedPctWs.compareTo(BigDecimal.ZERO) < 0) {      // L:8225 IF DED-PCT-WS < 0                       ...
            dedPctWs = BigDecimal.valueOf(.00);             // L:8226 MOVE 0.00 TO DED-PCT-WS
            if (dedPctWs.compareTo(dedPctLvl2Ws) < 0) {     // L:8228 IF DED-PCT-WS < DED-PCT-LVL2-WS         ...
                dedPctLvl2Ws = dedPctWs;                    // L:8229 MOVE DED-PCT-WS TO DED-PCT-LVL2-WS
                dedAmtLvl2Ws = dedAmtLvl2Ws.multiply(dedPctLvl2Ws);// L:8230 MULTIPLY DED-PCT-LVL2-WS BY DED-AMT-LVL2...
                dedAmtWs = dedAmtLvl1Ws.add(dedAmtLvl2Ws);  // L:8232 ADD DED-AMT-LVL1-WS, DED-AMT-LVL2-WS GIV...
                // 300-316-EXIT. EXIT.                      // L:8234 CODE
            }  // period ends IF scope
        }  // period ends IF scope
    }

    private void te_300_317() {                             // L:8236 300-317-TE
        if (dedPctSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8251 IF DED-PCT-SUM(I) NOT = ZERO            ...
            // DIVIDE parse failed: DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING DED-PCT-WS// L:8252 DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING D...
            pctTotEarnWs = pctTotEarnWs.multiply(dedPctWs); // L:8254 MULTIPLY DED-PCT-WS BY PCT-TOT-EARN-WS  ...
            dedAmtWs = BigDecimal.ZERO;                     // L:8257 MOVE ZERO TO DED-AMT-WS
            endMultiply = BigDecimal.ZERO;                  // L:8257 MOVE ZERO TO END-MULTIPLY
        }                                                   // L:8259 END-IF
        if (dedAmtSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8261 IF DED-AMT-SUM(I) NOT = ZERO            ...
            dedAmtWs = dedAmtSum[i.intValue()];             // L:8262 MOVE DED-AMT-SUM(I) TO DED-AMT-WS
            // /                                            // L:8267 COMMENT
        }  // auto-close unclosed IF
    }

    private void takeDeduction_300_319() {                  // L:8269 300-319-TAKE-DEDUCTION
        // ADD parse failed: ADD DED-NO-TO-TAKE-SUM(I) DED-ARRS-CTR-SUM(I)// L:8270 ADD DED-NO-TO-TAKE-SUM(I) DED-ARRS-CTR-S...
        noToTakeWs = noToTakeWs.subtract(dedNoTakenSum[i.intValue()]);// L:8272 SUBTRACT DED-NO-TAKEN-SUM(I) FROM NO-TO-...
        if ("y".equals(dedErrSum[i.intValue()])) {          // L:8278 IF DED-ERR-SUM(I) = "Y"
            noToTakeWs = BigDecimal.ZERO;                   // L:8279 MOVE ZERO TO NO-TO-TAKE-WS
        }  // period ends IF scope
        if (noToTakeWs.compareTo(BigDecimal.ZERO) < 0) {    // L:8280 IF NO-TO-TAKE-WS < ZERO MOVE ZERO TO NO-...
            dedAmtWs = dedAmtWs.multiply(noToTakeWs);       // L:8281 MULTIPLY NO-TO-TAKE-WS BY DED-AMT-WS
            dedAmtWs = BigDecimal.ZERO;                     // L:8284 MOVE ZERO TO DED-AMT-WS
        }  // period ends IF scope
        if ("y".equals(wsClientDedOpt36Sw)) {               // L:8292 IF WS-CLIENT-DED-OPT-36-SW = "Y"        ...
            if (wsStateMinWageRteHourly.compareTo(BigDecimal.ZERO) != 0) {// L:8293 IF WS-STATE-MIN-WAGE-RTE-HOURLY NOT = ZE...
                para319aFindDedOpt_300_36();                // L:8297 PERFORM 300-319A-FIND-DED-OPT-36 THRU 300-319A-EXIT
                if ("y".equals(wsDedWithOpt36FoundSw)) {    // L:8298 IF WS-DED-WITH-OPT-36-FOUND-SW = "Y"    ...
                    if (!"bo".equals(dedParaSum[i.intValue()])) {// L:8300 IF DED-PARA-SUM(I) NOT = "BO"           ...
                        if (dedBalSum[i.intValue()].compareTo(BigDecimal.valueOf(99999.99)) != 0) {// L:8301 IF DED-BAL-SUM(I) NOT = 99999.99        ...
                            if (dedAmtWs.compareTo(dedBalSum[i.intValue()]) > 0) {// L:8302 IF DED-AMT-WS > DED-BAL-SUM(I)          ...
                                dedAmtWs = dedBalSum[i.intValue()];// L:8303 MOVE DED-BAL-SUM(I) TO DED-AMT-WS
                            }                               // L:8304 END-IF
                        }                                   // L:8305 END-IF
                    }                                       // L:8306 END-IF
                    if (wsStateMinWageHoursDiff.compareTo(dedAmtWs) >= 0 || (wsStateMinWageHoursDiff.compareTo(BigDecimal.ZERO) == 0 && "y".equals(wsSalEmpNoHrsSw))) {// L:8311 IF WS-STATE-MIN-WAGE-HOURS-DIFF >= DED-A...
                        dedAmtSum[i.intValue()] = dedAmtWs; // L:8317 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                        ernCppNetSum = ernCppNetSum.subtract(dedAmtWs);// L:8318 SUBTRACT DED-AMT-WS FROM ERN-CPP-NET-SUM...
                        dedNoTakenSum[i.intValue()] = noToTakeWs;// L:8319 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
                        dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;// L:8320 MOVE ZERO TO DED-ARRS-CTR-SUM(I)
                        // COMPUTE parse failed: COMPUTE WS-STATE-MIN-WAGE-HOURS-DIFF =// L:8322 COMPUTE WS-STATE-MIN-WAGE-HOURS-DIFF =  ...
                    } else {                                // L:8326 ELSE
                        // STRING parse failed (no INTO): STRING "DEDUCTION "   DELIMITED BY SIZE...// L:8329 STRING "DEDUCTION "   DELIMITED BY SIZE ...
                        wsGtnErr = "DE";                    // L:8336 MOVE "DE" TO WS-GTN-ERR
                        gtnError_800_700();                 // L:8337 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                        dedNoTakenSum[i.intValue()] = BigDecimal.ZERO;// L:8339 MOVE ZERO TO DED-NO-TAKEN-SUM(I)
                        dedAmtWs = BigDecimal.ZERO;         // L:8339 MOVE ZERO TO DED-AMT-WS
                        dedAmtSum[i.intValue()] = dedAmtWs; // L:8341 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                        dedArrsCtrSum[i.intValue()] = BigDecimal.valueOf(1);// L:8344 MOVE 1 TO DED-ARRS-CTR-SUM(I)
                    }                                       // L:8346 END-IF
                    // GO TO 300-319-EXIT - control flow    // L:8348 GO TO 300-319-EXIT
                } else {                                    // L:8349 ELSE
                    // CONTINUE                                ...// L:8351 CONTINUE
                }                                           // L:8352 END-IF
            } else {                                        // L:8353 ELSE
                // STRING parse failed (no INTO): STRING "DEDUCTION "   DELIMITED BY SIZE...// L:8356 STRING "DEDUCTION "   DELIMITED BY SIZE ...
                wsGtnErr = "DE";                            // L:8363 MOVE "DE" TO WS-GTN-ERR
                gtnError_800_700();                         // L:8364 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                dedNoTakenSum[i.intValue()] = BigDecimal.ZERO;// L:8366 MOVE ZERO TO DED-NO-TAKEN-SUM(I)
                dedAmtWs = BigDecimal.ZERO;                 // L:8366 MOVE ZERO TO DED-AMT-WS
                dedAmtSum[i.intValue()] = dedAmtWs;         // L:8368 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                dedArrsCtrSum[i.intValue()] = BigDecimal.valueOf(1);// L:8371 MOVE 1 TO DED-ARRS-CTR-SUM(I)
            }                                               // L:8373 END-IF
        } else {                                            // L:8374 ELSE
            // CONTINUE                                ...  // L:8376 CONTINUE
        }                                                   // L:8377 END-IF
        if ("fd".equals(dedParaSum[i.intValue()]) && (dedOptSum[i.intValue()].compareTo(BigDecimal.valueOf(0.0)) > 0 && dedOptSum[i.intValue()].compareTo(BigDecimal.valueOf(1.0)) < 0)) {// L:8385 IF DED-PARA-SUM(I) = "FD"
            fdErnCppGrsLessTxSum = fdErnCppGrsLessTxSum.multiply(dedOptSum[i.intValue()]);// L:8389 MULTIPLY DED-OPT-SUM(I) BY FD-ERN-CPP-GR...
            if ("fd".equals(dedParaSum[i.intValue()])) {    // L:8392 IF DED-PARA-SUM(I) = "FD"
                totalWs = dedAmtWs.add(dedOptSum[i.intValue()]);// L:8393 ADD DED-AMT-WS DED-OPT-SUM(I) GIVING TOT...
                if (fdErnCppGrsLessTxSum.compareTo(totalWs) < 0) {// L:8396 IF FD-ERN-CPP-GRS-LESS-TX-SUM < TOTAL-WS...
                    if (fdErnCppGrsLessTxSum.compareTo(dedOptSum[i.intValue()]) > 0) {// L:8398 IF FD-ERN-CPP-GRS-LESS-TX-SUM > DED-OPT-...
                        // SUBTRACT parse failed: SUBTRACT DED-OPT-SUM(I)// L:8400 SUBTRACT DED-OPT-SUM(I)                 ...
                    } else {                                // L:8408 ELSE
                        dedAmtWs = BigDecimal.ZERO;         // L:8409 MOVE ZERO TO DED-AMT-WS
                        if ("fd".equals(dedParaSum[i.intValue()])) {// L:8415 IF DED-PARA-SUM(I) = "FD"               ...
                            para319bFindDedOpt_300_35();    // L:8418 PERFORM 300-319B-FIND-DED-OPT-35 THRU 300-319B-EXIT
                            if ("y".equals(wsDedWithOpt35FoundSw)) {// L:8419 IF WS-DED-WITH-OPT-35-FOUND-SW = "Y"    ...
                                if (wsStateMinWageRteHourly.compareTo(BigDecimal.ZERO) != 0) {// L:8422 IF WS-STATE-MIN-WAGE-RTE-HOURLY NOT = ZE...
                                    // COMPUTE parse failed: COMPUTE WS-FD-ADJUSTED-AMT =// L:8432 COMPUTE WS-FD-ADJUSTED-AMT =            ...
                                    // COMPUTE parse failed: COMPUTE WS-FD-DED-AMT-TO-TAKE =// L:8468 COMPUTE WS-FD-DED-AMT-TO-TAKE =         ...
                                    if (wsFdDedAmtToTake.compareTo(BigDecimal.ZERO) <= 0) {// L:8471 IF WS-FD-DED-AMT-TO-TAKE <= 0           ...
                                        // STRING parse failed (no INTO): STRING "DEDUCTION "   DELIMITED BY SIZE...// L:8473 STRING "DEDUCTION "   DELIMITED BY SIZE ...
                                        wsGtnErr = "DE";    // L:8480 MOVE "DE" TO WS-GTN-ERR
                                        gtnError_800_700(); // L:8481 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                                        dedNoTakenSum[i.intValue()] = BigDecimal.ZERO;// L:8482 MOVE ZERO TO DED-NO-TAKEN-SUM(I)
                                        dedAmtWs = BigDecimal.ZERO;// L:8482 MOVE ZERO TO DED-AMT-WS
                                        dedAmtSum[i.intValue()] = dedAmtWs;// L:8484 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                                    } else {                // L:8486 ELSE
                                        if (wsFdDedAmtToTake.compareTo(dedAmtWs) >= 0) {// L:8487 IF WS-FD-DED-AMT-TO-TAKE >= DED-AMT-WS  ...
                                            dedAmtSum[i.intValue()] = dedAmtWs;// L:8490 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                                            ernCppNetSum = ernCppNetSum.subtract(dedAmtWs);// L:8491 SUBTRACT DED-AMT-WS FROM ERN-CPP-NET-SUM...
                                            dedNoTakenSum[i.intValue()] = noToTakeWs;// L:8492 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
                                            dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;// L:8493 MOVE ZERO TO DED-ARRS-CTR-SUM(I)
                                        } else {            // L:8494 ELSE
                                            if (wsFdDedAmtToTake.compareTo(dedAmtWs) < 0) {// L:8495 IF WS-FD-DED-AMT-TO-TAKE < DED-AMT-WS   ...
                                                dedAmtSum[i.intValue()] = wsFdDedAmtToTake;// L:8498 MOVE WS-FD-DED-AMT-TO-TAKE TO DED-AMT-SUM(I)
                                                // SUBTRACT parse failed: SUBTRACT WS-FD-DED-AMT-TO-TAKE FROM// L:8500 SUBTRACT WS-FD-DED-AMT-TO-TAKE FROM     ...
                                                dedNoTakenSum[i.intValue()] = noToTakeWs;// L:8502 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
                                                dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;// L:8503 MOVE ZERO TO DED-ARRS-CTR-SUM(I)
                                            }               // L:8504 END-IF
                                        }                   // L:8505 END-IF
                                    }                       // L:8506 END-IF
                                    // GO TO 300-319-EXIT - control flow// L:8509 GO TO 300-319-EXIT
                                } else {                    // L:8510 ELSE
                                    // STRING parse failed (no INTO): STRING "DEDUCTION "   DELIMITED BY SIZE...// L:8513 STRING "DEDUCTION "   DELIMITED BY SIZE ...
                                    wsGtnErr = "DE";        // L:8520 MOVE "DE" TO WS-GTN-ERR
                                    gtnError_800_700();     // L:8521 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                                    dedNoTakenSum[i.intValue()] = BigDecimal.ZERO;// L:8523 MOVE ZERO TO DED-NO-TAKEN-SUM(I)
                                    dedAmtWs = BigDecimal.ZERO;// L:8523 MOVE ZERO TO DED-AMT-WS
                                    dedAmtSum[i.intValue()] = dedAmtWs;// L:8525 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                                    dedArrsCtrSum[i.intValue()] = BigDecimal.valueOf(1);// L:8528 MOVE 1 TO DED-ARRS-CTR-SUM(I)
                                }                           // L:8530 END-IF
                            } else {                        // L:8531 ELSE
                                // CONTINUE                                ...// L:8533 CONTINUE
                            }                               // L:8534 END-IF
                        }                                   // L:8535 END-IF
                        if ("fn".equals(dedParaSum[i.intValue()])) {// L:8543 IF DED-PARA-SUM(I) = "FN"
                            if (dedPctSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:8544 IF DED-PCT-SUM(I) NOT = ZERO            ...
                                // DIVIDE parse failed: DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING DED-PCT-WS// L:8545 DIVIDE DED-PCT-SUM(I) BY 100.00 GIVING D...
                                if (dedPctWs.compareTo(BigDecimal.valueOf(1)) > 0) {// L:8546 IF DED-PCT-WS > 1                       ...
                                    dedPctWs = BigDecimal.valueOf(1.000000);// L:8547 MOVE 1.000000 TO DED-PCT-WS
                                }                           // L:8548 END-IF
                                ernCppNetSum = ernCppNetSum.multiply(dedPctWs);// L:8549 MULTIPLY DED-PCT-WS BY ERN-CPP-NET-SUM  ...
                                dedAmtWs = BigDecimal.ZERO; // L:8552 MOVE ZERO TO DED-AMT-WS
                                endMultiply = BigDecimal.ZERO;// L:8552 MOVE ZERO TO END-MULTIPLY
                                if (dedAmtWs.compareTo(dedOptSum[i.intValue()]) > 0 && dedOptSum[i.intValue()].compareTo(BigDecimal.ZERO) > 0) {// L:8554 IF DED-AMT-WS > DED-OPT-SUM(I) AND      ...
                                    dedAmtWs = dedOptSum[i.intValue()];// L:8556 MOVE DED-OPT-SUM(I) TO DED-AMT-WS
                                }                           // L:8557 END-IF
                                dedAmtSum[i.intValue()] = dedAmtWs;// L:8558 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                                ernCppNetSum = ernCppNetSum.subtract(dedAmtWs);// L:8559 SUBTRACT DED-AMT-WS FROM ERN-CPP-NET-SUM...
                                dedNoTakenSum[i.intValue()] = noToTakeWs;// L:8560 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
                                dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;// L:8561 MOVE ZERO TO DED-ARRS-CTR-SUM(I)
                            } else {                        // L:8562 ELSE
                                if (dedAmtWs.compareTo(ernCppNetSum) <= 0) {// L:8563 IF DED-AMT-WS <= ERN-CPP-NET-SUM        ...
                                    ernCppNetSum = ernCppNetSum.subtract(dedAmtWs);// L:8564 SUBTRACT DED-AMT-WS FROM ERN-CPP-NET-SUM...
                                    dedAmtSum[i.intValue()] = dedAmtWs;// L:8566 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                                    ernCppNetSum = ernCppNetSum.subtract(dedAmtWs);// L:8567 SUBTRACT DED-AMT-WS FROM ERN-CPP-NET-SUM...
                                    dedNoTakenSum[i.intValue()] = noToTakeWs;// L:8568 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
                                    dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;// L:8569 MOVE ZERO TO DED-ARRS-CTR-SUM(I)
                                } else {                    // L:8570 ELSE
                                    dedAmtWs = BigDecimal.ZERO;// L:8571 MOVE ZERO TO DED-AMT-WS
                                    dedAmtSum[i.intValue()] = dedAmtWs;// L:8572 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                                }                           // L:8573 END-IF
                            }                               // L:8574 END-IF
                            // GO TO 300-319-EXIT - control flow// L:8576 GO TO 300-319-EXIT
                        }                                   // L:8577 END-IF
                        if ("te".equals(dedParaSum[i.intValue()])) {// L:8579 IF DED-PARA-SUM(I) = "TE"               ...
                            if (dedBalSum[i.intValue()].compareTo(BigDecimal.valueOf(99999.99)) != 0) {// L:8607 IF DED-BAL-SUM(I) NOT = 99999.99        ...
                                if (dedAmtWs.compareTo(dedBalSum[i.intValue()]) > 0) {// L:8608 IF DED-AMT-WS > DED-BAL-SUM(I)          ...
                                    dedAmtWs = dedBalSum[i.intValue()];// L:8609 MOVE DED-BAL-SUM(I) TO DED-AMT-WS
                                }                           // L:8610 END-IF
                            }                               // L:8611 END-IF
                            dedAmtSum[i.intValue()] = dedAmtWs;// L:8613 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
                            ernCppNetSum = ernCppNetSum.subtract(dedAmtWs);// L:8614 SUBTRACT DED-AMT-WS FROM ERN-CPP-NET-SUM...
                            dedNoTakenSum[i.intValue()] = noToTakeWs;// L:8615 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
                            dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;// L:8616 MOVE ZERO TO DED-ARRS-CTR-SUM(I)
                            // GO TO 300-319-EXIT - control flow// L:8618 GO TO 300-319-EXIT
                        }                                   // L:8619 END-IF
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (!"bo".equals(dedParaSum[i.intValue()])) {       // L:8627 IF DED-PARA-SUM(I) NOT = "BO"
            if (dedBalSum[i.intValue()].compareTo(BigDecimal.valueOf(99999.99)) != 0) {// L:8628 IF DED-BAL-SUM(I) NOT = 99999.99
                if (dedAmtWs.compareTo(dedBalSum[i.intValue()]) > 0) {// L:8629 IF DED-AMT-WS > DED-BAL-SUM(I)
                    dedAmtWs = dedBalSum[i.intValue()];     // L:8630 MOVE DED-BAL-SUM(I) TO DED-AMT-WS
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if ("ec".equals(dedParaSum[i.intValue()]) || "eh".equals(dedParaSum[i.intValue()])) {// L:8638 IF DED-PARA-SUM(I) = "EC" OR            ...
            dedAmtSum[i.intValue()] = dedAmtWs;             // L:8640 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
            dedNoTakenSum[i.intValue()] = noToTakeWs;       // L:8641 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
            dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;  // L:8642 MOVE ZERO TO DED-ARRS-CTR-SUM(I)
            // GO TO 300-319-EXIT - control flow            // L:8643 GO TO 300-319-EXIT
        }  // period ends IF scope
        if (((("be".equals(dedParaSum[i.intValue()]) || "ts".equals(dedParaSum[i.intValue()]) || "te".equals(dedParaSum[i.intValue()]))) || "tip1".equals(dedNoSum[i.intValue()]))) {// L:8651 IF ((DED-PARA-SUM(I) = "BE" OR "TS" OR "...
            dedAmtSum[i.intValue()] = dedAmtWs;             // L:8654 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
            ernCppNetSum = ernCppNetSum.subtract(dedAmtWs); // L:8655 SUBTRACT DED-AMT-WS FROM ERN-CPP-NET-SUM
            dedNoTakenSum[i.intValue()] = noToTakeWs;       // L:8656 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
            dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;  // L:8657 MOVE ZERO TO DED-ARRS-CTR-SUM(I)
        }  // period ends IF scope
        if (((("be".equals(dedParaSum[i.intValue()]) || "ts".equals(dedParaSum[i.intValue()]) || "te".equals(dedParaSum[i.intValue()]))) || "tip1".equals(dedNoSum[i.intValue()]))) {// L:8659 IF ((DED-PARA-SUM(I) = "BE" OR "TS" OR "...
            // GO TO 300-319-EXIT - control flow            // L:8662 GO TO 300-319-EXIT
        }  // period ends IF scope
        if (dedAmtWs.compareTo(ernCppNetSum) <= 0) {        // L:8670 IF DED-AMT-WS NOT > ERN-CPP-NET-SUM
            dedAmtSum[i.intValue()] = dedAmtWs;             // L:8671 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
            ernCppNetSum = ernCppNetSum.subtract(dedAmtWs); // L:8672 SUBTRACT DED-AMT-WS FROM ERN-CPP-NET-SUM
            dedNoTakenSum[i.intValue()] = noToTakeWs;       // L:8673 MOVE NO-TO-TAKE-WS TO DED-NO-TAKEN-SUM(I)
            dedArrsCtrSum[i.intValue()] = BigDecimal.ZERO;  // L:8674 MOVE ZERO TO DED-ARRS-CTR-SUM(I)
        } else {                                            // L:8675 ELSE
            // STRING parse failed (no INTO): STRING "DEDUCTION "   DELIMITED BY SIZE...// L:8676 STRING "DEDUCTION "   DELIMITED BY SIZE ...
            wsGtnErr = "DE";                                // L:8682 MOVE "DE" TO WS-GTN-ERR
            gtnError_800_700();                             // L:8683 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            dedNoTakenSum[i.intValue()] = BigDecimal.ZERO;  // L:8684 MOVE ZERO TO DED-NO-TAKEN-SUM(I)
            dedAmtWs = BigDecimal.ZERO;                     // L:8684 MOVE ZERO TO DED-AMT-WS
            if ("y".equals(dedSetArrSum[i.intValue()])) {   // L:8685 IF DED-SET-ARR-SUM(I) = "Y"
                dedArrsCtrSum[i.intValue()] = BigDecimal.valueOf(1);// L:8686 MOVE 1 TO DED-ARRS-CTR-SUM(I)
            }  // period ends IF scope
        }  // period ends IF scope
        dedAmtSum[i.intValue()] = dedAmtWs;                 // L:8687 MOVE DED-AMT-WS TO DED-AMT-SUM(I)
        // 300-319-EXIT. EXIT.                              // L:8689 CODE
    }

    private void para319aFindDedOpt_300_36() {              // L:8692 300-319A-FIND-DED-OPT-36
        cn1ClientNo = prmClientNo.shortValue();             // L:8694 MOVE PRM-CLIENT-NO TO CN1-CLIENT-NO
        cn1DedNo = dedNoSum[i.intValue()];                  // L:8696 MOVE DED-NO-SUM(I) TO CN1-DED-NO
        cn1OptNo = 36;                                      // L:8697 MOVE 36 TO CN1-OPT-NO
        wsDedWithOpt36FoundSw = "N";                        // L:8698 MOVE "N" TO WS-DED-WITH-OPT-36-FOUND-SW
        // READ PAYCNLPF01                         ...      // L:8699 READ
        // GO TO 300-319A-EXIT - control flow               // L:8701 GO TO 300-319A-EXIT
        wsDedWithOpt36FoundSw = "Y";                        // L:8703 MOVE "Y" TO WS-DED-WITH-OPT-36-FOUND-SW
        // 300-319A-EXIT. EXIT.                    ...      // L:8705 CODE
    }

    private void para319bFindDedOpt_300_35() {              // L:8708 300-319B-FIND-DED-OPT-35
        cn1ClientNo = prmClientNo.shortValue();             // L:8710 MOVE PRM-CLIENT-NO TO CN1-CLIENT-NO
        cn1DedNo = dedNoSum[i.intValue()];                  // L:8712 MOVE DED-NO-SUM(I) TO CN1-DED-NO
        cn1OptNo = 35;                                      // L:8713 MOVE 35 TO CN1-OPT-NO
        wsDedWithOpt35FoundSw = "N";                        // L:8714 MOVE "N" TO WS-DED-WITH-OPT-35-FOUND-SW
        // READ PAYCNLPF01                         ...      // L:8715 READ
        // GO TO 300-319B-EXIT - control flow               // L:8717 GO TO 300-319B-EXIT
        wsDedWithOpt35FoundSw = "Y";                        // L:8719 MOVE "Y" TO WS-DED-WITH-OPT-35-FOUND-SW
        wsDedOpt35Value = new BigDecimal(cn1OptValue);      // L:8720 MOVE CN1-OPT-VALUE TO WS-DED-OPT-35-VALUE
        // 300-319B-EXIT. EXIT.                    ...      // L:8722 CODE
    }

    private void error_300_320() {                          // L:8725 300-320-ERROR
        okFlag = notOkLit;                                  // L:8726 MOVE NOT-OK-LIT TO OK-FLAG
        // STRING parse failed (no INTO): STRING "THIS DEDUCTION AMOUNT IS > 99999.99 - "...// L:8727 STRING "THIS DEDUCTION AMOUNT IS > 99999...
        wsGtnErr = "DE";                                    // L:8731 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:8732 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void dedRoutineError_300_321() {                // L:8734 300-321-DED-ROUTINE-ERROR
        okFlag = notOkLit;                                  // L:8735 MOVE NOT-OK-LIT TO OK-FLAG
        // STRING parse failed (no INTO): STRING "DEDUCTION ROUTINE ERROR-UNPREDICTABLE RESU...// L:8736 STRING "DEDUCTION ROUTINE ERROR-UNPREDIC...
        wsGtnErr = "DE";                                    // L:8739 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:8740 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
    }

    private void calcWcTax_300_330() {                      // L:8743 300-330-CALC-WC-TAX
        if ("n".equals(wcTaxOptWs)) {                       // L:8744 IF WC-TAX-OPT-WS = "N"
            // GO TO 300-330-EXIT - control flow            // L:8745 GO TO 300-330-EXIT
        }  // period ends IF scope
        wcDedAmt = BigDecimal.ZERO;                         // L:8746 MOVE 0 TO WC-DED-AMT
        wcDedNo = dedNoSum[i.intValue()];                   // L:8747 MOVE DED-NO-SUM (I) TO WC-DED-NO
        prodHrs_300_332();                                  // L:8748 PERFORM 300-332-PROD-HRS THRU 300-332-EXIT
        dedAmtSum[i.intValue()] = wcDedAmt;                 // L:8750 MOVE WC-DED-AMT TO DED-AMT-SUM(I)
        ernCppNetSum = ernCppNetSum.subtract(wcDedAmt);     // L:8751 SUBTRACT WC-DED-AMT FROM ERN-CPP-NET-SUM...
        ernCppGrsLessTxSum = ernCppGrsLessTxSum.subtract(wcDedAmt);// L:8752 SUBTRACT WC-DED-AMT FROM ERN-CPP-GRS-LES...
        // 300-330-EXIT. EXIT.                              // L:8754 CODE
    }

    private void prodHrs_300_332() {                        // L:8757 300-332-PROD-HRS
        if (hoursTrn[sub.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:8758 IF HOURS-TRN (SUB) = 0
            // GO TO 300-332-EXIT - control flow            // L:8759 GO TO 300-332-EXIT
        }  // period ends IF scope
        cClient = BigDecimal.valueOf(clnClientNo);          // L:8760 MOVE CLN-CLIENT-NO TO C-CLIENT
        cErnSeq = seqTrn[sub.intValue()];                   // L:8761 MOVE SEQ-TRN (SUB) TO C-ERN-SEQ
        cProdYn = "N";                                      // L:8762 MOVE "N" TO C-PROD-YN
        // CALL PYU5XFK                                     // L:8763 CALL "PYU5XFK" USING C-RET-CODE, C-CLIEN...
        callPyu5Xfk();
        if ("n".equals(cProdYn)) {                          // L:8765 IF C-PROD-YN = "N"
            // GO TO 300-332-EXIT - control flow            // L:8766 GO TO 300-332-EXIT
        }  // period ends IF scope
        cClient = BigDecimal.valueOf(clnClientNo);          // L:8767 MOVE CLN-CLIENT-NO TO C-CLIENT
        cComp = (short)clnCompNo;                           // L:8768 MOVE CLN-COMP-NO TO C-COMP
        cCorp = corpWrkTrn[sub.intValue()];                 // L:8769 MOVE CORP-WRK-TRN (SUB) TO C-CORP
        cStore = storeWrkTrn[sub.intValue()];               // L:8770 MOVE STORE-WRK-TRN (SUB) TO C-STORE
        cDed = wcDedNo;                                     // L:8771 MOVE WC-DED-NO TO C-DED
        cRate = BigDecimal.ZERO;                            // L:8772 MOVE 0 TO C-RATE
        // CALL PYU1XFK                                     // L:8773 CALL "PYU1XFK" USING C-RET-CODE, C-CLIEN...
        callPyu1Xfk();
        cRate = cRate.multiply(hoursTrn[sub.intValue()]);   // L:8775 MULTIPLY HOURS-TRN (SUB) BY C-RATE
        wcDedAmt = wcDedAmt.add(wsProdHrs);                 // L:8777 ADD WS-PROD-HRS TO WC-DED-AMT.
        // 300-332-EXIT. EXIT.                              // L:8779 CODE
        // /                                                // L:8780 COMMENT
    }

    private void leaveAccrual_300_400() {                   // L:8781 300-400-LEAVE-ACCRUAL
        if ("c".equals(benAnnlClass)) {                     // L:8782 IF BEN-ANNL-CLASS = "C"
            // GO TO 300-400-EXIT - control flow            // L:8783 GO TO 300-400-EXIT
        }  // period ends IF scope
        if ("r".equals(timCheckTypeHold)) {                 // L:8784 IF TIM-CHECK-TYPE-HOLD = "R"
            sickLv_300_410();                               // L:8785 PERFORM 300-410-SICK-LV THRU 300-410-EXIT
            annlLv_300_420();                               // L:8786 PERFORM 300-420-ANNL-LV THRU 300-420-EXIT
            persLv_300_430();                               // L:8787 PERFORM 300-430-PERS-LV THRU 300-430-EXIT
        }  // period ends IF scope
        // 300-400-EXIT. EXIT.                              // L:8789 CODE
    }

    private void sickLv_300_410() {                         // L:8796 300-410-SICK-LV
        if (benSickAccRte.compareTo(BigDecimal.ZERO) == 0 || benSickClass == "") {// L:8797 IF BEN-SICK-ACC-RTE = 0
            // GO TO 300-410-EXIT - control flow            // L:8800 GO TO 300-410-EXIT
        }  // period ends IF scope
        cl2ClientNo = perClientNo;                          // L:8802 MOVE PER-CLIENT-NO TO CL2-CLIENT-NO
        cl2LvClass = benSickClass;                          // L:8803 MOVE BEN-SICK-CLASS TO CL2-LV-CLASS
        // READ PAYCLNPF02                                  // L:8804 READ
        cl2SickHrs = BigDecimal.ZERO;                       // L:8806 MOVE ZERO TO CL2-SICK-HRS
        if (cl2LvFormula == "") {                           // L:8807 IF CL2-LV-FORMULA = SPACES
            lvCodesWs = "0";                                // L:8808 MOVE ZERO TO LV-CODES-WS
        }  // period ends IF scope
        if ("1".equals(cl2LvFormula)) {                     // L:8809 IF CL2-LV-FORMULA = 1
            cl2SickHrs = BigDecimal.ZERO;                   // L:8810 MOVE SPACES TO CL2-SICK-HRS
            // INSPECT CL2-SICK-HRS REPLACING ALL " " B...  // L:8811 INSPECT
        }  // period ends IF scope
        lvCodesWs = cl2SickHrs.toString();                  // L:8812 MOVE CL2-SICK-HRS TO LV-CODES-WS
        lvAccRteSum = benSickAccRte;                        // L:8813 MOVE BEN-SICK-ACC-RTE TO LV-ACC-RTE-SUM
        computeLeave_300_450();                             // L:8814 PERFORM 300-450-COMPUTE-LEAVE THRU 300-450-EXIT
        lvSickAccRteSum = lvAccRteSum;                      // L:8815 MOVE LV-ACC-RTE-SUM TO LV-SICK-ACC-RTE-SUM
        // 300-410-EXIT. EXIT.                              // L:8817 CODE
    }

    private void annlLv_300_420() {                         // L:8824 300-420-ANNL-LV
        if (benAnnlAccRte.compareTo(BigDecimal.ZERO) == 0 || benAnnlClass == "") {// L:8825 IF BEN-ANNL-ACC-RTE = 0
            // GO TO 300-420-EXIT - control flow            // L:8828 GO TO 300-420-EXIT
        }  // period ends IF scope
        cl2ClientNo = perClientNo;                          // L:8830 MOVE PER-CLIENT-NO TO CL2-CLIENT-NO
        cl2LvClass = benAnnlClass;                          // L:8831 MOVE BEN-ANNL-CLASS TO CL2-LV-CLASS
        // READ PAYCLNPF02                                  // L:8832 READ
        cl2AnnlHrs = BigDecimal.ZERO;                       // L:8834 MOVE ZERO TO CL2-ANNL-HRS
        if (cl2LvFormula == "") {                           // L:8835 IF CL2-LV-FORMULA = SPACES
            lvCodesWs = "0";                                // L:8836 MOVE ZERO TO LV-CODES-WS
        }  // period ends IF scope
        if ("1".equals(cl2LvFormula)) {                     // L:8837 IF CL2-LV-FORMULA = "1"
            cl2AnnlHrs = BigDecimal.ZERO;                   // L:8838 MOVE SPACES TO CL2-ANNL-HRS
            // INSPECT CL2-ANNL-HRS REPLACING ALL " " B...  // L:8839 INSPECT
        }  // period ends IF scope
        lvCodesWs = cl2AnnlHrs.toString();                  // L:8840 MOVE CL2-ANNL-HRS TO LV-CODES-WS
        lvAccRteSum = benAnnlAccRte;                        // L:8841 MOVE BEN-ANNL-ACC-RTE TO LV-ACC-RTE-SUM
        computeLeave_300_450();                             // L:8842 PERFORM 300-450-COMPUTE-LEAVE THRU 300-450-EXIT
        lvAnnlAccRteSum = lvAccRteSum;                      // L:8843 MOVE LV-ACC-RTE-SUM TO LV-ANNL-ACC-RTE-SUM
        // 300-420-EXIT. EXIT.                              // L:8845 CODE
    }

    private void persLv_300_430() {                         // L:8852 300-430-PERS-LV
        if (benPersAccRte.compareTo(BigDecimal.ZERO) == 0 || benPersClass == "") {// L:8853 IF BEN-PERS-ACC-RTE = 0
            // GO TO 300-430-EXIT - control flow            // L:8856 GO TO 300-430-EXIT
        }  // period ends IF scope
        cl2ClientNo = perClientNo;                          // L:8858 MOVE PER-CLIENT-NO TO CL2-CLIENT-NO
        cl2LvClass = benPersClass;                          // L:8859 MOVE BEN-PERS-CLASS TO CL2-LV-CLASS
        // READ PAYCLNPF02                                  // L:8860 READ
        cl2PersHrs = BigDecimal.ZERO;                       // L:8862 MOVE ZERO TO CL2-PERS-HRS
        if (cl2LvFormula == "") {                           // L:8863 IF CL2-LV-FORMULA = SPACES
            lvCodesWs = "0";                                // L:8864 MOVE ZERO TO LV-CODES-WS
        }  // period ends IF scope
        if ("1".equals(cl2LvFormula)) {                     // L:8865 IF CL2-LV-FORMULA = "1"
            cl2PersHrs = BigDecimal.ZERO;                   // L:8866 MOVE SPACES TO CL2-PERS-HRS
            // INSPECT CL2-PERS-HRS REPLACING ALL " " B...  // L:8867 INSPECT
        }  // period ends IF scope
        lvCodesWs = cl2PersHrs.toString();                  // L:8868 MOVE CL2-PERS-HRS TO LV-CODES-WS
        lvAccRteSum = benPersAccRte;                        // L:8869 MOVE BEN-PERS-ACC-RTE TO LV-ACC-RTE-SUM
        computeLeave_300_450();                             // L:8870 PERFORM 300-450-COMPUTE-LEAVE THRU 300-450-EXIT
        lvPersAccRteSum = lvAccRteSum;                      // L:8871 MOVE LV-ACC-RTE-SUM TO LV-PERS-ACC-RTE-SUM
        // 300-430-EXIT. EXIT.                              // L:8873 CODE
    }

    private void computeLvHours_300_440() {                 // L:8876 300-440-COMPUTE-LV-HOURS
        if ("y".equals(lvFlagsWs[j.intValue()])) {          // L:8877 IF LV-FLAGS-WS(J) = "Y"
            totLvHrsWs = totLvHrsWs.add(hrsCppSum[j.intValue()]);// L:8878 ADD HRS-CPP-SUM(J) TO TOT-LV-HRS-WS.
        }  // period ends IF scope
        // 300-440-EXIT. EXIT.                              // L:8880 CODE
    }

    private void computeLeave_300_450() {                   // L:8883 300-450-COMPUTE-LEAVE
        // INSPECT LV-HRS-TABLE REPLACING ALL "0" B...      // L:8884 INSPECT
        // INSPECT LV-HRS-TABLE REPLACING ALL "1" B...      // L:8885 INSPECT
        totLvHrsWs = BigDecimal.ZERO;                       // L:8886 MOVE ZERO TO TOT-LV-HRS-WS
        computeLvHours_300_440();                           // L:8887 PERFORM 300-440-COMPUTE-LV-HOURS THRU 300-440-EXIT
        if ("2".equals(cl2LvFormula) && totLvHrsWs.compareTo(perSchdlHrs) <= 0) {// L:8894 IF CL2-LV-FORMULA = "2"
            totLvHrsWs = perSchdlHrs;                       // L:8897 MOVE PER-SCHDL-HRS TO TOT-LV-HRS-WS
        }  // period ends IF scope
        if ("3".equals(cl2LvFormula) && totLvHrsWs.compareTo(perSchdlHrs) > 0) {// L:8903 IF CL2-LV-FORMULA = "3"
            totLvHrsWs = perSchdlHrs;                       // L:8906 MOVE PER-SCHDL-HRS TO TOT-LV-HRS-WS
        }  // period ends IF scope
        if ("4".equals(cl2LvFormula)) {                     // L:8912 IF CL2-LV-FORMULA = "4"
            totLvHrsWs = BigDecimal.valueOf(1);             // L:8913 MOVE 1 TO TOT-LV-HRS-WS
        }  // period ends IF scope
        if ("9".equals(cl2LvFormula)) {                     // L:8919 IF CL2-LV-FORMULA = "9"
            accrueHours_300_470();                          // L:8920 PERFORM 300-470-ACCRUE-HOURS THRU 300-470-EXIT
        } else {                                            // L:8921 ELSE
            lvAccRteSum = lvAccRteSum.multiply(totLvHrsWs); // L:8922 MULTIPLY TOT-LV-HRS-WS BY LV-ACC-RTE-SUM
            // 300-450-EXIT. EXIT.                          // L:8925 CODE
        }  // period ends IF scope
    }

    private void remAnnl_300_460() {                        // L:8928 300-460-REM-ANNL
        if ("c".equals(benAnnlClass)) {                     // L:8929 IF BEN-ANNL-CLASS = "C"
            // GO TO 300-460-EXIT - control flow            // L:8930 GO TO 300-460-EXIT
        }  // period ends IF scope
        accumHoursWs = BigDecimal.ZERO;                     // L:8931 INITIALIZE ACCUM-HOURS-WS.
        accumHoursWs = (lvAccRteSum).multiply(totLvHrsWs);  // L:8932 COMPUTE ACCUM-HOURS-WS = LV-ACC-RTE-SUM ...
        lvAccRteSum = accumHoursWs;                         // L:8933 MOVE ACCUM-HOURS-WS TO LV-ACC-RTE-SUM
        // 300-460-EXIT. EXIT.                              // L:8935 CODE
    }

    private void accrueHours_300_470() {                    // L:8938 300-470-ACCRUE-HOURS
        accumHoursWs = BigDecimal.ZERO;                     // L:8939 INITIALIZE ACCUM-HOURS-WS, ACCUM-HOURS-A...
        accumHoursActualWs = BigDecimal.ZERO;               // L:8939 INITIALIZE ACCUM-HOURS-WS, ACCUM-HOURS-A...
        benAnnlBal = benAnnlBal.subtract(hrsCppSum[17]);    // L:8943 SUBTRACT HRS-CPP-SUM(17) FROM BEN-ANNL-B...
        ytdLimitWs = (benAnnlLimit).divide(BigDecimal.valueOf(2), 10, RoundingMode.HALF_UP);// L:8946 COMPUTE YTD-LIMIT-WS = BEN-ANNL-LIMIT / ...
        if (annlBalWs.compareTo(benAnnlLimit) >= 0) {       // L:8947 IF ANNL-BAL-WS NOT LESS BEN-ANNL-LIMIT
            lvAccRteSum = BigDecimal.ZERO;                  // L:8948 MOVE 0 TO LV-ACC-RTE-SUM
            // GO TO 300-470-EXIT - control flow            // L:8949 GO TO 300-470-EXIT
        }  // period ends IF scope
        if (benAnnlAcrdYtd.compareTo(ytdLimitWs) >= 0) {    // L:8950 IF BEN-ANNL-ACRD-YTD NOT LESS YTD-LIMIT-...
            lvAccRteSum = BigDecimal.ZERO;                  // L:8951 MOVE 0 TO LV-ACC-RTE-SUM
            // GO TO 300-470-EXIT - control flow            // L:8952 GO TO 300-470-EXIT
        }  // period ends IF scope
        accumHoursWs = (lvAccRteSum).multiply(totLvHrsWs);  // L:8953 COMPUTE ACCUM-HOURS-WS = LV-ACC-RTE-SUM ...
        // COMPUTE incomplete (multi-line): COMPUTE TOTAL-ACCRUED-WS = ANNL-BAL-WS +// L:8954 COMPUTE TOTAL-ACCRUED-WS = ANNL-BAL-WS +
        // COMPUTE incomplete (multi-line): COMPUTE TOTAL-ACCRUED-YTD-WS = BEN-ANNL-ACRD-YTD +// L:8956 COMPUTE TOTAL-ACCRUED-YTD-WS = BEN-ANNL-...
        if (totalAccruedWs.compareTo(benAnnlLimit) > 0) {   // L:8959 IF TOTAL-ACCRUED-WS GREATER BEN-ANNL-LIM...
            // COMPUTE incomplete (multi-line): COMPUTE ACCUM-HRS-LIMIT-WS = BEN-ANNL-LIMIT -// L:8960 COMPUTE ACCUM-HRS-LIMIT-WS = BEN-ANNL-LI...
            if (totalAccruedYtdWs.compareTo(ytdLimitWs) > 0) {// L:8962 IF TOTAL-ACCRUED-YTD-WS GREATER YTD-LIMI...
                // COMPUTE incomplete (multi-line): COMPUTE ACCUM-HRS-LIMIT-YTD-WS = YTD-LIMIT-WS -// L:8963 COMPUTE ACCUM-HRS-LIMIT-YTD-WS = YTD-LIM...
                if (accumHrsLimitYtdWs.compareTo(BigDecimal.ZERO) == 0 && accumHrsLimitWs.compareTo(BigDecimal.ZERO) != 0) {// L:8966 IF ACCUM-HRS-LIMIT-YTD-WS = 0 AND
                    accumHoursActualWs = accumHrsLimitWs;   // L:8968 MOVE ACCUM-HRS-LIMIT-WS TO ACCUM-HOURS-ACTUAL-WS
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (accumHrsLimitWs.compareTo(BigDecimal.ZERO) == 0 && accumHrsLimitYtdWs.compareTo(BigDecimal.ZERO) != 0) {// L:8969 IF ACCUM-HRS-LIMIT-WS = 0 AND
            accumHoursActualWs = accumHrsLimitYtdWs;        // L:8971 MOVE ACCUM-HRS-LIMIT-YTD-WS TO ACCUM-HOURS-ACTUAL-WS
        }  // period ends IF scope
        if (accumHrsLimitWs.compareTo(BigDecimal.ZERO) != 0 && accumHrsLimitYtdWs.compareTo(BigDecimal.ZERO) != 0) {// L:8972 IF ACCUM-HRS-LIMIT-WS NOT = 0 AND
            if (accumHrsLimitWs.compareTo(accumHrsLimitYtdWs) < 0) {// L:8974 IF ACCUM-HRS-LIMIT-WS < ACCUM-HRS-LIMIT-...
                accumHoursActualWs = accumHrsLimitWs;       // L:8975 MOVE ACCUM-HRS-LIMIT-WS TO ACCUM-HOURS-ACTUAL-WS
            } else {                                        // L:8976 ELSE
                accumHoursActualWs = accumHrsLimitYtdWs;    // L:8977 MOVE ACCUM-HRS-LIMIT-YTD-WS TO ACCUM-HOURS-ACTUAL-WS
            }  // period ends IF scope
        }  // period ends IF scope
        if (accumHoursActualWs.compareTo(BigDecimal.ZERO) > 0) {// L:8979 IF ACCUM-HOURS-ACTUAL-WS > 0
            lvAccRteSum = accumHoursActualWs;               // L:8980 MOVE ACCUM-HOURS-ACTUAL-WS TO LV-ACC-RTE-SUM
        } else {                                            // L:8981 ELSE
            lvAccRteSum = accumHoursWs;                     // L:8982 MOVE ACCUM-HOURS-WS TO LV-ACC-RTE-SUM
        }  // period ends IF scope
        // 300-470-EXIT. EXIT.                              // L:8984 CODE
        // /                                                // L:8985 COMMENT
    }

    private void ctTaxCredit_300_500() {                    // L:8987 300-500-CT-TAX-CREDIT
        savCdeTaxWs = cdeTaxWs;                             // L:8988 MOVE CDE-TAX-WS TO SAV-CDE-TAX-WS
        cdeTaxWs = "PTC";                                   // L:8989 MOVE "PTC" TO CDE-TAX-WS
        taxAmtWs = BigDecimal.ZERO;                         // L:8990 MOVE 0 TO TAX-AMT-WS
        ctTaxableWage = annualWageWs;                       // L:8991 MOVE ANNUAL-WAGE-WS TO CT-TAXABLE-WAGE
        ctStateTax = taxCppSum[taxEntity.intValue()];       // L:8992 MOVE TAX-CPP-SUM (TAX-ENTITY) TO CT-STATE-TAX
        okFlag = notOkLit;                                  // L:8993 MOVE NOT-OK-LIT TO OK-FLAG
        taxKeyFlag = notOkLit;                              // L:8993 MOVE NOT-OK-LIT TO TAX-KEY-FLAG
        taxRoutineFlag = okLit;                             // L:8994 MOVE OK-LIT TO TAX-ROUTINE-FLAG
        tblIdx = 1;                                         // L:8995 SET TBL-IDX TO 1.
        control_300_501();                                  // L:8996 PERFORM 300-501-CONTROL THRU 300-501-EXIT
        if (taxKeyNotFound) {                               // L:8998 IF TAX-KEY-NOT-FOUND
            taxKeyError_300_198_1();                        // L:8999 PERFORM 300-198-1-TAX-KEY-ERROR
        }  // period ends IF scope
        taxCppSum[taxEntity.intValue()] = taxAmtWs;         // L:9000 MOVE TAX-AMT-WS TO TAX-CPP-SUM(TAX-ENTITY)
        cdeTaxWs = savCdeTaxWs;                             // L:9001 MOVE SAV-CDE-TAX-WS TO CDE-TAX-WS
        // 300-500-EXIT. EXIT.                              // L:9003 CODE
    }

    private void control_300_501() {                        // L:9006 300-501-CONTROL
        if (annualWageWs.compareTo(BigDecimal.valueOf(.1)) < 0) {// L:9007 IF ANNUAL-WAGE-WS < .01
            taxRoutineFlag = notOkLit;                      // L:9008 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            taxKeyFlag = okLit;                             // L:9009 MOVE OK-LIT TO TAX-KEY-FLAG
        } else {                                            // L:9010 ELSE
            lookup_300_502();                               // L:9011 PERFORM 300-502-LOOKUP THRU 300-502-EXIT
            if (BigDecimal.valueOf(tblIdx).compareTo(wsTblIdxLimit) > 0) {// L:9018 IF TBL-IDX > WS-TBL-IDX-LIMIT
                taxRoutineFlag = notOkLit;                  // L:9019 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            }  // period ends IF scope
        }  // period ends IF scope
        // 300-501-EXIT. EXIT.                              // L:9021 CODE
    }

    private void lookup_300_502() {                         // L:9023 300-502-LOOKUP
        if (tblWorkKey == wsTblKey[tblIdx]) {               // L:9024 IF TBL-WORK-KEY = WS-TBL-KEY (TBL-IDX)
            taxKeyFlag = okLit;                             // L:9025 MOVE OK-LIT TO TAX-KEY-FLAG
            if (ctTaxableWage.compareTo(wsLowerWageLimit[tblIdx]) >= 0) {// L:9026 IF CT-TAXABLE-WAGE NOT < WS-LOWER-WAGE-L...
                taxCredit_300_503();                        // L:9027 PERFORM 300-503-TAX-CREDIT THRU 300-503-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        if (wsTblKey[tblIdx].compareTo(tblWorkKey) > 0) {   // L:9028 IF WS-TBL-KEY (TBL-IDX) > TBL-WORK-KEY
            taxRoutineFlag = notOkLit;                      // L:9029 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
        }  // period ends IF scope
        // 300-502-EXIT. EXIT.                              // L:9031 CODE
    }

    private void taxCredit_300_503() {                      // L:9034 300-503-TAX-CREDIT
        if (wsPctExcessWage[tblIdx].compareTo(BigDecimal.ZERO) != 0) {// L:9035 IF WS-PCT-EXCESS-WAGE (TBL-IDX) NOT = 0
            ctStateTax = ctStateTax.multiply(wsPctExcessWage[tblIdx]);// L:9036 MULTIPLY WS-PCT-EXCESS-WAGE (TBL-IDX) BY...
        } else {                                            // L:9038 ELSE
            taxAmtWs = ctStateTax;                          // L:9039 MOVE CT-STATE-TAX TO TAX-AMT-WS
        }  // period ends IF scope
        if (taxAmtWs.compareTo(BigDecimal.ZERO) < 0) {      // L:9040 IF TAX-AMT-WS < ZERO
            taxAmtWs = BigDecimal.ZERO;                     // L:9041 MOVE ZERO TO TAX-AMT-WS
        }  // period ends IF scope
        // 300-503-EXIT. EXIT.                              // L:9043 CODE
        // /                                                // L:9044 COMMENT
    }

    private void directDeposit_300_600() {                  // L:9046 300-600-DIRECT-DEPOSIT
        checkForDeposit_300_610();                          // L:9047 PERFORM 300-610-CHECK-FOR-DEPOSIT THRU 300-610-EXIT
        // 300-600-EXIT. EXIT.                              // L:9049 CODE
    }

    private void checkForDeposit_300_610() {                // L:9052 300-610-CHECK-FOR-DEPOSIT
        if (perBankAbaNo[i.intValue()] != 0 && (("c".equals(perBankAcctType[i.intValue()]) || "s".equals(perBankAcctType[i.intValue()]) || "k".equals(perBankAcctType[i.intValue()]) || "v".equals(perBankAcctType[i.intValue()]) || "p".equals(perBankAcctType[i.intValue()]))) && (("s".equals(perBankPnFlag[i.intValue()]) || "w".equals(perBankPnFlag[i.intValue()]) || "r".equals(perBankPnFlag[i.intValue()]))) && (perBankAcct[i.intValue()] != "") && (perBankDepAmt[i.intValue()].compareTo(BigDecimal.ZERO) != 0)) {// L:9053 IF PER-BANK-ABA-NO(I) NOT = ZERO
            calculateDeposit_300_620();                     // L:9067 PERFORM 300-620-CALCULATE-DEPOSIT
        }  // period ends IF scope
        // 300-610-EXIT. EXIT.                              // L:9068 CODE
    }

    private void calculateDeposit_300_620() {               // L:9071 300-620-CALCULATE-DEPOSIT
        bnkAbaNo[i.intValue()] = BigDecimal.valueOf(perBankAbaNo[i.intValue()]);// L:9072 MOVE PER-BANK-ABA-NO(I) TO BNK-ABA-NO(I)
        bnkAcctType[i.intValue()] = perBankAcctType[i.intValue()];// L:9073 MOVE PER-BANK-ACCT-TYPE(I) TO BNK-ACCT-TYPE(I)
        bnkPnFlag[i.intValue()] = perBankPnFlag[i.intValue()];// L:9074 MOVE PER-BANK-PN-FLAG(I) TO BNK-PN-FLAG(I)
        bnkAcct[i.intValue()] = perBankAcct[i.intValue()];  // L:9075 MOVE PER-BANK-ACCT(I) TO BNK-ACCT(I)
        if ((("c".equals(perBankAcctType[i.intValue()]) || "s".equals(perBankAcctType[i.intValue()]) || "p".equals(perBankAcctType[i.intValue()])))) {// L:9085 IF (PER-BANK-ACCT-TYPE(I) = "C" OR "S" O...
            if ((perBankDepAmt[i.intValue()].compareTo(ernCppNetSum) <= 0 && perBankDepAmt[i.intValue()].compareTo(BigDecimal.valueOf(999999.99)) != 0)) {// L:9087 IF (PER-BANK-DEP-AMT(I) NOT > ERN-CPP-NE...
                bnkDepAmt[i.intValue()] = perBankDepAmt[i.intValue()];// L:9090 MOVE PER-BANK-DEP-AMT(I) TO BNK-DEP-AMT(I)
            } else {                                        // L:9091 ELSE
                bnkDepAmt[i.intValue()] = ernCppNetSum;     // L:9092 MOVE ERN-CPP-NET-SUM TO BNK-DEP-AMT(I)
            }  // period ends IF scope
        }  // period ends IF scope
        if ((("k".equals(perBankAcctType[i.intValue()]) || "v".equals(perBankAcctType[i.intValue()]))) && (perBankDepAmt[i.intValue()].compareTo(ernCppNetSum) <= 0)) {// L:9099 IF (PER-BANK-ACCT-TYPE(I) = "K" OR "V")
            if (perBankDepAmt[i.intValue()].compareTo(BigDecimal.valueOf(999999.99)) != 0) {// L:9102 IF PER-BANK-DEP-AMT(I) NOT = 999999.99
                bnkDepAmt[i.intValue()] = perBankDepAmt[i.intValue()];// L:9103 MOVE PER-BANK-DEP-AMT(I) TO BNK-DEP-AMT(I)
            } else {                                        // L:9104 ELSE
                messageO = "MIN TYPE (K OR V) DIRECT DEPOSIT SET TO TAKE ALL";// L:9105 MOVE "MIN TYPE (K OR V) DIRECT DEPOSIT SET TO TAKE ALL" TO MESSAGE-O
                wsGtnErr = "AM";                            // L:9107 MOVE "AM" TO WS-GTN-ERR
                gtnError_800_700();                         // L:9108 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        bnkAcctType[i.intValue()] = perBankAcctType[i.intValue()];// L:9109 MOVE PER-BANK-ACCT-TYPE(I) TO BNK-ACCT-TYPE(I)
        if ("k".equals(bnkAcctType[i.intValue()])) {        // L:9115 IF BNK-ACCT-TYPE(I) = "K" MOVE "C" TO BN...
            if ("v".equals(bnkAcctType[i.intValue()])) {    // L:9116 IF BNK-ACCT-TYPE(I) = "V" MOVE "S" TO BN...
                if ("s".equals(perBankPnFlag[i.intValue()])) {// L:9123 IF PER-BANK-PN-FLAG(I) = "S"
                    bnkDepAmt[i.intValue()] = BigDecimal.ZERO;// L:9124 MOVE ZERO TO BNK-DEP-AMT(I)
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if ("w".equals(perBankPnFlag[i.intValue()]) && "y".equals(clnDirdepWaitOptWs)) {// L:9125 IF PER-BANK-PN-FLAG(I) = "W"
            bnkDepAmt[i.intValue()] = BigDecimal.ZERO;      // L:9128 MOVE ZERO TO BNK-DEP-AMT(I)
        }  // period ends IF scope
        if ("w".equals(perBankPnFlag[i.intValue()]) && !"y".equals(clnDirdepWaitOptWs) && BigDecimal.valueOf(ernDatePaidLst).compareTo(wsDateEnd) == 0) {// L:9129 IF PER-BANK-PN-FLAG(I) = "W"
            bnkDepAmt[i.intValue()] = BigDecimal.ZERO;      // L:9134 MOVE ZERO TO BNK-DEP-AMT(I)
        }  // period ends IF scope
        ernCppNetSum = ernCppNetSum.subtract(bnkDepAmt[i.intValue()]);// L:9135 SUBTRACT BNK-DEP-AMT(I) FROM ERN-CPP-NET...
        // 300-620-EXIT. EXIT.                              // L:9137 CODE
        // /                                                // L:9138 COMMENT
    }

    private void updateYtdTrn_500_000() {                   // L:9139 500-000-UPDATE-YTD-TRN
        fieldUpdate_500_100();                              // L:9140 PERFORM 500-100-FIELD-UPDATE THRU 500-100-EXIT
        if (ernCppGrossSum.compareTo(BigDecimal.ZERO) != 0) {// L:9141 IF ERN-CPP-GROSS-SUM NOT = 0
            updatePaytrncpfl_500_200();                     // L:9142 PERFORM 500-200-UPDATE-PAYTRNCPFL THRU 500-200-EXIT
        }  // period ends IF scope
        // 500-000-EXIT. EXIT.                              // L:9144 CODE
    }

    private void fieldUpdate_500_100() {                    // L:9147 500-100-FIELD-UPDATE
        earnUpdate_500_150();                               // L:9148 PERFORM 500-150-EARN-UPDATE
        hrsUpdate_500_115();                                // L:9150 PERFORM 500-115-HRS-UPDATE
        taxUpdate_500_120();                                // L:9152 PERFORM 500-120-TAX-UPDATE
        lvUpdate_500_140();                                 // L:9154 PERFORM 500-140-LV-UPDATE THRU 500-140-EXIT
        dirDepUpdate_500_150();                             // L:9155 PERFORM 500-150-DIR-DEP-UPDATE THRU 500-150-EXIT
        // 500-100-EXIT. EXIT.                              // L:9159 CODE
    }

    private void earnUpdate_500_150() {                     // L:9162 500-150-EARN-UPDATE
        ernEarnYtd[i.intValue()] = ernEarnYtd[i.intValue()].add(ernCppSum[i.intValue()]);// L:9163 ADD ERN-CPP-SUM(I) TO ERN-EARN-YTD (I).
    }

    private void hrsUpdate_500_115() {                      // L:9165 500-115-HRS-UPDATE
        ernHrsYtd[i.intValue()] = ernHrsYtd[i.intValue()].add(hrsCppSum[i.intValue()]);// L:9166 ADD HRS-CPP-SUM(I) TO ERN-HRS-YTD (I).
    }

    private void taxUpdate_500_120() {                      // L:9168 500-120-TAX-UPDATE
        if (i.compareTo(BigDecimal.valueOf(7)) != 0) {      // L:9169 IF I NOT = 7
            ernTaxYtd[i.intValue()] = ernTaxYtd[i.intValue()].add(taxCppSum[i.intValue()]);// L:9170 ADD TAX-CPP-SUM(I) TO ERN-TAX-YTD(I)
            if (i.compareTo(BigDecimal.valueOf(7)) == 0) {  // L:9171 IF I = 7
                ernYtdAdveic = ernYtdAdveic.add(taxCppSum[i.intValue()]);// L:9172 ADD TAX-CPP-SUM(I) TO ERN-YTD-ADVEIC.
            }  // period ends IF scope
        }  // period ends IF scope
    }

    private void dedUpdate_500_130() {                      // L:9174 500-130-DED-UPDATE
        j = dedTblElementSum[i.intValue()];                 // L:9175 MOVE DED-TBL-ELEMENT-SUM (I) TO J
        if (j.compareTo(BigDecimal.valueOf(1)) < 0) {       // L:9176 IF J < 1
            // GO TO 500-130-EXIT - control flow            // L:9177 GO TO 500-130-EXIT
        }  // period ends IF scope
        if (!dedNoSum[i.intValue()].equals(String.valueOf(benDedNo[j.intValue()]))) {// L:9178 IF BEN-DED-NO(J) NOT = DED-NO-SUM(I)
            dedUpdateErr_500_131();                         // L:9179 PERFORM 500-131-DED-UPDATE-ERR
            // GO TO 500-130-EXIT - control flow            // L:9180 GO TO 500-130-EXIT
        }  // period ends IF scope
        if ((("2".equals(timCheckTypeHold) || "m".equals(timCheckTypeHold) || "v".equals(timCheckTypeHold) || "x".equals(timCheckTypeHold))) && dedNoToTakeSum[i.intValue()].compareTo(BigDecimal.ZERO) == 0) {// L:9188 IF (TIM-CHECK-TYPE-HOLD = "2" OR "M" OR ...
            // GO TO 500-130-EXIT - control flow            // L:9190 GO TO 500-130-EXIT
        }  // period ends IF scope
        wsDedTktn = BigDecimal.valueOf(benDedTktn[j.intValue()]);// L:9196 MOVE BEN-DED-TKTN(J) TO WS-DED-TKTN
        wsNoTaken = BigDecimal.ZERO;                        // L:9197 MOVE ZERO TO WS-NO-TAKEN
        if ("y".equals(dedErrSum[i.intValue()])) {          // L:9203 IF DED-ERR-SUM(I) = "Y"
            wsNoToTake = BigDecimal.ZERO;                   // L:9204 MOVE ZERO TO WS-NO-TO-TAKE
        }  // period ends IF scope
        if (!"bo".equals(dedParaSum[i.intValue()])) {       // L:9210 IF DED-PARA-SUM(I) NOT = "BO"
            if (benDedBal[j.intValue()].compareTo(BigDecimal.valueOf(99999.99)) != 0) {// L:9211 IF BEN-DED-BAL(J) NOT = 99999.99
                benDedBal[j.intValue()] = benDedBal[j.intValue()].subtract(dedAmtSum[i.intValue()]);// L:9212 SUBTRACT DED-AMT-SUM(I) FROM BEN-DED-BAL...
                if (benDedBal[j.intValue()].compareTo(BigDecimal.ZERO) <= 0) {// L:9213 IF BEN-DED-BAL(J) NOT > ZERO
                    wsNoToTake = BigDecimal.ZERO;           // L:9214 MOVE ZERO TO WS-NO-TO-TAKE
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if ("y".equals(dedSetArrSum[i.intValue()])) {       // L:9220 IF DED-SET-ARR-SUM(I) = "Y"
            benArrsCtr[j.intValue()] = benArrsCtr[j.intValue()].add(dedArrsCtrSum[i.intValue()]);// L:9221 ADD DED-ARRS-CTR-SUM(I) TO BEN-ARRS-CTR(...
        }  // period ends IF scope
        if (dedNoTakenSum[i.intValue()].compareTo(benArrsCtr[j.intValue()]) >= 0) {// L:9222 IF DED-NO-TAKEN-SUM(I) NOT < BEN-ARRS-CT...
            benArrsCtr[j.intValue()] = BigDecimal.ZERO;     // L:9223 MOVE ZERO TO BEN-ARRS-CTR(J)
        } else {                                            // L:9224 ELSE
            benArrsCtr[j.intValue()] = benArrsCtr[j.intValue()].subtract(dedNoTakenSum[i.intValue()]);// L:9225 SUBTRACT DED-NO-TAKEN-SUM(I) FROM BEN-AR...
        }  // period ends IF scope
        if (!"ba".equals(dedParaSum[i.intValue()])) {       // L:9227 IF DED-PARA-SUM (I) NOT = "BA"
            if (dedNoToTakeSum[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:9228 IF DED-NO-TO-TAKE-SUM (I) NOT = 0
                benAccYtd[j.intValue()] = benAccYtd[j.intValue()].add(dedAmtSum[i.intValue()]);// L:9229 ADD DED-AMT-SUM(I) TO BEN-ACC-YTD(J)
                benAccQtd[j.intValue()] = benAccQtd[j.intValue()].add(dedAmtSum[i.intValue()]);// L:9230 ADD DED-AMT-SUM(I) TO BEN-ACC-QTD(J).
            }  // period ends IF scope
        }  // period ends IF scope
        if ("y".equals(dedYtdPrtSum[i.intValue()]) && benAccYtd[j.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:9231 IF DED-YTD-PRT-SUM (I) = "Y" AND
            updateDedYtd_500_300();                         // L:9233 PERFORM 500-300-UPDATE-DED-YTD THRU 500-300-EXIT
        }  // period ends IF scope
        // 500-130-EXIT. EXIT.                              // L:9235 CODE
    }

    private void dedUpdateErr_500_131() {                   // L:9237 500-131-DED-UPDATE-ERR
        // STRING parse failed (no INTO): STRING "DED UPDATE ERROR - "...// L:9238 STRING "DED UPDATE ERROR - "
        wsGtnErr = "DE";                                    // L:9245 MOVE "DE" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:9246 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // 500-131-EXIT. EXIT.                              // L:9247 CODE
    }

    private void lvUpdate_500_140() {                       // L:9249 500-140-LV-UPDATE
        benAnnlBal = benAnnlBal.add(lvAnnlAccRteSum);       // L:9250 ADD LV-ANNL-ACC-RTE-SUM TO BEN-ANNL-BAL.
        if ((benAnnlClass != "" || benAnnlLimit.compareTo(BigDecimal.ZERO) != 0) && (hrsCppSum[16].compareTo(benAnnlBal) > 0 && hrsCppSum[16].compareTo(BigDecimal.ZERO) != 0)) {// L:9251 IF (BEN-ANNL-CLASS NOT = SPACES OR
            messageO = "VAC HOURS USED GREATER THAN ANNL LEAVE BALANCE";// L:9257 MOVE "VAC HOURS USED GREATER THAN ANNL LEAVE BALANCE" TO MESSAGE-O
            wsGtnErr = "LV";                                // L:9259 MOVE "LV" TO WS-GTN-ERR
            gtnError_800_700();                             // L:9260 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        benAnnlBal = benAnnlBal.subtract(hrsCppSum[17]);    // L:9261 SUBTRACT HRS-CPP-SUM(17) FROM BEN-ANNL-B...
        if (benAnnlLimit.compareTo(BigDecimal.ZERO) != 0) { // L:9262 IF BEN-ANNL-LIMIT NOT = ZERO
            if (benAnnlBal.compareTo(benAnnlLimit) > 0) {   // L:9263 IF BEN-ANNL-BAL > BEN-ANNL-LIMIT
                benAnnlBal = benAnnlLimit;                  // L:9264 MOVE BEN-ANNL-LIMIT TO BEN-ANNL-BAL
            }  // period ends IF scope
        }  // period ends IF scope
        if ("y".equals(wsCliOpt608Sw)) {                    // L:9267 IF WS-CLI-OPT-608-SW = "Y"              ...
            // COMPUTE incomplete (multi-line): COMPUTE WK-608-SICK-ACRD-TOTAL = BEN-SICK-ACRD-YTD +// L:9268 COMPUTE WK-608-SICK-ACRD-TOTAL = BEN-SIC...
            if (wk608SickAcrdTotal.compareTo(clnCtLeaveLimit) > 0) {// L:9270 IF WK-608-SICK-ACRD-TOTAL > CLN-CT-LEAVE...
                // COMPUTE parse failed: COMPUTE WK-608-SICK-ACRD-DIFF =// L:9271 COMPUTE WK-608-SICK-ACRD-DIFF =         ...
                // COMPUTE parse failed: COMPUTE LV-SICK-ACC-RTE-SUM =// L:9273 COMPUTE LV-SICK-ACC-RTE-SUM =           ...
                if (lvSickAccRteSum.compareTo(BigDecimal.valueOf(.1)) < 0) {// L:9275 IF LV-SICK-ACC-RTE-SUM < .001           ...
                    lvSickAccRteSum = BigDecimal.ZERO;      // L:9276 MOVE ZEROS TO LV-SICK-ACC-RTE-SUM
                }                                           // L:9277 END-IF
            }                                               // L:9278 END-IF
        }                                                   // L:9279 END-IF
        benSickBal = benSickBal.add(lvSickAccRteSum);       // L:9281 ADD LV-SICK-ACC-RTE-SUM TO BEN-SICK-BAL.
        xsickHoursWs = hrsCppSum[15];                       // L:9282 MOVE HRS-CPP-SUM (15) TO XSICK-HOURS-WS
        addXsickHours_1000_700();                           // L:9283 PERFORM 1000-700-ADD-XSICK-HOURS THRU 1000-700-EXIT
        if ((benSickClass != "" || benSickLimit.compareTo(BigDecimal.ZERO) != 0) && (xsickHoursWs.compareTo(benSickBal) > 0 && xsickHoursWs.compareTo(BigDecimal.ZERO) != 0)) {// L:9284 IF (BEN-SICK-CLASS NOT = SPACES OR
            messageO = "SICK HOURS USED GREATER THAN SICK LEAVE BALANCE";// L:9290 MOVE "SICK HOURS USED GREATER THAN SICK LEAVE BALANCE" TO MESSAGE-O
            wsGtnErr = "LV";                                // L:9292 MOVE "LV" TO WS-GTN-ERR
            gtnError_800_700();                             // L:9293 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        benSickBal = benSickBal.subtract(xsickHoursWs);     // L:9294 SUBTRACT XSICK-HOURS-WS FROM BEN-SICK-BA...
        if (benSickLimit.compareTo(BigDecimal.ZERO) != 0) { // L:9295 IF BEN-SICK-LIMIT NOT = ZERO
            if (benSickBal.compareTo(benSickLimit) > 0) {   // L:9296 IF BEN-SICK-BAL > BEN-SICK-LIMIT
                benSickBal = benSickLimit;                  // L:9297 MOVE BEN-SICK-LIMIT TO BEN-SICK-BAL
            }  // period ends IF scope
        }  // period ends IF scope
        benPersBal = benPersBal.add(lvPersAccRteSum);       // L:9299 ADD LV-PERS-ACC-RTE-SUM TO BEN-PERS-BAL.
        if ((benPersClass != "" || benPersLimit.compareTo(BigDecimal.ZERO) != 0) && (hrsCppSum[15].compareTo(benPersBal) > 0 && hrsCppSum[15].compareTo(BigDecimal.ZERO) != 0)) {// L:9300 IF (BEN-PERS-CLASS NOT = SPACES OR
            messageO = "PERS HOURS USED GREATER THAN PERS LEAVE BALANCE";// L:9306 MOVE "PERS HOURS USED GREATER THAN PERS LEAVE BALANCE" TO MESSAGE-O
            wsGtnErr = "LV";                                // L:9308 MOVE "LV" TO WS-GTN-ERR
            gtnError_800_700();                             // L:9309 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        benPersBal = benPersBal.subtract(hrsCppSum[16]);    // L:9310 SUBTRACT HRS-CPP-SUM (16) FROM BEN-PERS-...
        if (benPersLimit.compareTo(BigDecimal.ZERO) != 0) { // L:9311 IF BEN-PERS-LIMIT NOT = ZERO
            if (benPersBal.compareTo(benPersLimit) > 0) {   // L:9312 IF BEN-PERS-BAL > BEN-PERS-LIMIT
                benPersBal = benPersLimit;                  // L:9313 MOVE BEN-PERS-LIMIT TO BEN-PERS-BAL
            }  // period ends IF scope
        }  // period ends IF scope
        // 500-140-EXIT. EXIT.                              // L:9314 CODE
    }

    private void dirDepUpdate_500_150() {                   // L:9317 500-150-DIR-DEP-UPDATE
        if ((perBankAbaNo[depSub.intValue()] != 0) && (("c".equals(perBankAcctType[depSub.intValue()]) || "s".equals(perBankAcctType[depSub.intValue()]) || "k".equals(perBankAcctType[depSub.intValue()]) || "v".equals(perBankAcctType[depSub.intValue()]) || "p".equals(perBankAcctType[depSub.intValue()]))) && (("s".equals(perBankPnFlag[depSub.intValue()]) || "w".equals(perBankPnFlag[depSub.intValue()]) || "r".equals(perBankPnFlag[depSub.intValue()]))) && (perBankAcct[depSub.intValue()] != "") && (perBankDepAmt[depSub.intValue()].compareTo(BigDecimal.ZERO) != 0)) {// L:9318 IF (PER-BANK-ABA-NO(DEP-SUB) NOT = ZERO)
            ernErnQtdNet = ernErnQtdNet.add(bnkDepAmt[depSub.intValue()]);// L:9332 ADD BNK-DEP-AMT(DEP-SUB) TO ERN-ERN-QTD-...
            ernErnYtdNet = ernErnYtdNet.add(bnkDepAmt[depSub.intValue()]);// L:9333 ADD BNK-DEP-AMT(DEP-SUB) TO ERN-ERN-YTD-...
        }  // period ends IF scope
        // 500-150-EXIT. EXIT.                              // L:9334 CODE
    }

    private void updatePaytrncpfl_500_200() {               // L:9337 500-200-UPDATE-PAYTRNCPFL
        payrollCurrentTransRecord = "";                     // L:9338 INITIALIZE PAYROLL-CURRENT-TRANS-RECORD.
        tcpClientNo = perClientNo;                          // L:9339 MOVE PER-CLIENT-NO TO TCP-CLIENT-NO
        tcpDateEnd = wsDateEnd.intValue();                  // L:9340 MOVE WS-DATE-END TO TCP-DATE-END
        tcpEmpNo = perEmpNo;                                // L:9341 MOVE PER-EMP-NO TO TCP-EMP-NO
        tcpSeqNo = 0;                                       // L:9342 MOVE 0 TO TCP-SEQ-NO
        tcpCheckNo = timCheckNoHold.intValue();             // L:9343 MOVE TIM-CHECK-NO-HOLD TO TCP-CHECK-NO
        if ((("m".equals(timCheckTypeHold) || "v".equals(timCheckTypeHold) || "x".equals(timCheckTypeHold)))) {// L:9344 IF (TIM-CHECK-TYPE-HOLD = "M" OR "V" OR ...
            tcpDocumentNo = timCheckNoHold.toString();      // L:9345 MOVE TIM-CHECK-NO-HOLD TO TCP-DOCUMENT-NO
            tcpDocumentDate = timDateEndHold.intValue();    // L:9346 MOVE TIM-DATE-END-HOLD TO TCP-DOCUMENT-DATE
        } else {                                            // L:9347 ELSE
            tcpDocumentNo = "0";                            // L:9348 MOVE 0 TO TCP-DOCUMENT-NO
            tcpDocumentDate = 0;                            // L:9348 MOVE 0 TO TCP-DOCUMENT-DATE
        }  // period ends IF scope
        tcpCompNo = clnCompNo;                              // L:9349 MOVE CLN-COMP-NO TO TCP-COMP-NO
        tcpCorpNo = perCorpNo;                              // L:9350 MOVE PER-CORP-NO TO TCP-CORP-NO
        tcpStoreNo = perStoreNo;                            // L:9351 MOVE PER-STORE-NO TO TCP-STORE-NO
        tcpDeptNo = perDeptNo;                              // L:9352 MOVE PER-DEPT-NO TO TCP-DEPT-NO
        tcpJobClass = perJobClass;                          // L:9353 MOVE PER-JOB-CLASS TO TCP-JOB-CLASS
        tcpCorpWrk = "0";                                   // L:9354 MOVE 0 TO TCP-CORP-WRK
        tcpStoreWrk = "0";                                  // L:9354 MOVE 0 TO TCP-STORE-WRK
        tcpDeptWrk = "0";                                   // L:9354 MOVE 0 TO TCP-DEPT-WRK
        tcpCorpGl = "0";                                    // L:9355 MOVE 0 TO TCP-CORP-GL
        tcpStoreGl = "0";                                   // L:9355 MOVE 0 TO TCP-STORE-GL
        tcpDeptGl = "0";                                    // L:9356 MOVE 0 TO TCP-DEPT-GL
        tcpAcctGl = "0";                                    // L:9356 MOVE 0 TO TCP-ACCT-GL
        tcpCdeCycle = timCdeCycleHold;                      // L:9357 MOVE TIM-CDE-CYCLE-HOLD TO TCP-CDE-CYCLE
        tcpCheckType = timCheckTypeHold;                    // L:9358 MOVE TIM-CHECK-TYPE-HOLD TO TCP-CHECK-TYPE
        tcpEmpName = perEmpName;                            // L:9359 MOVE PER-EMP-NAME TO TCP-EMP-NAME
        tcpCode = "";                                       // L:9360 MOVE SPACES TO TCP-CODE
        if ("y".equals(clnDirdepVoucherOptWs) && ernCppNetSum.compareTo(BigDecimal.ZERO) == 0 && (bnkDepAmt[0].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[1].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[2].compareTo(BigDecimal.ZERO) != 0)) {// L:9361 IF CLN-DIRDEP-VOUCHER-OPT-WS = "Y"
            tcpDirDepVoucher = "Y";                         // L:9370 MOVE "Y" TO TCP-DIR-DEP-VOUCHER
            savedTcpDirDepVoucher = "Y";                    // L:9370 MOVE "Y" TO SAVED-TCP-DIR-DEP-VOUCHER
        } else {                                            // L:9372 ELSE
            tcpDirDepVoucher = "N";                         // L:9373 MOVE "N" TO TCP-DIR-DEP-VOUCHER
            savedTcpDirDepVoucher = "N";                    // L:9373 MOVE "N" TO SAVED-TCP-DIR-DEP-VOUCHER
        }                                                   // L:9375 END-IF
        tcpRate = BigDecimal.ZERO;                          // L:9376 MOVE 0 TO TCP-RATE
        tcpHours = BigDecimal.ZERO;                         // L:9376 MOVE 0 TO TCP-HOURS
        if (ernErnYtdGross.compareTo(BigDecimal.ZERO) != 0) {// L:9377 IF ERN-ERN-YTD-GROSS NOT = 0
            tcpType = "YG";                                 // L:9378 MOVE "YG" TO TCP-TYPE
            tcpCode = "GROS";                               // L:9379 MOVE "GROS" TO TCP-CODE
            tcpHours = ernHrsYtdGross;                      // L:9380 MOVE ERN-HRS-YTD-GROSS TO TCP-HOURS
            tcpAmount = ernErnYtdGross;                     // L:9381 MOVE ERN-ERN-YTD-GROSS TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9382 PERFORM 800-510-WRITE-PAYTRN
            tcpHours = BigDecimal.ZERO;                     // L:9383 MOVE 0 TO TCP-HOURS
        }  // period ends IF scope
        if (ernTaxYtdFica.compareTo(BigDecimal.ZERO) != 0) {// L:9384 IF ERN-TAX-YTD-FICA NOT = 0
            tcpType = "YA";                                 // L:9385 MOVE "YA" TO TCP-TYPE
            tcpCode = "FICA";                               // L:9386 MOVE "FICA" TO TCP-CODE
            tcpAmount = ernTaxYtdFica;                      // L:9387 MOVE ERN-TAX-YTD-FICA TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9388 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (ernTaxYtdFed.compareTo(BigDecimal.ZERO) != 0 || ernYtdAdveic.compareTo(BigDecimal.ZERO) != 0) {// L:9389 IF ERN-TAX-YTD-FED NOT = 0
            tcpType = "YF";                                 // L:9392 MOVE "YF" TO TCP-TYPE
            tcpCode = "FWT";                                // L:9393 MOVE "FWT" TO TCP-CODE
            tcpAmount = ernTaxYtdFed;                       // L:9394 MOVE ERN-TAX-YTD-FED TO TCP-AMOUNT
            tcpAmount = tcpAmount.add(ernYtdAdveic);        // L:9395 ADD ERN-YTD-ADVEIC TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9396 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (ernTaxYtdStt.compareTo(BigDecimal.ZERO) != 0) { // L:9397 IF ERN-TAX-YTD-STT NOT = 0
            tcpType = "YS";                                 // L:9398 MOVE "YS" TO TCP-TYPE
            tcpCode = perCdeStt;                            // L:9399 MOVE PER-CDE-STT TO TCP-CODE
            tcpAmount = ernTaxYtdStt;                       // L:9400 MOVE ERN-TAX-YTD-STT TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9401 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (ernTaxYtdLoc.compareTo(BigDecimal.ZERO) != 0) { // L:9402 IF ERN-TAX-YTD-LOC NOT = 0
            tcpType = "YL";                                 // L:9403 MOVE "YL" TO TCP-TYPE
            tcpCode = perCdeLoc;                            // L:9404 MOVE PER-CDE-LOC TO TCP-CODE
            tcpAmount = ernTaxYtdLoc;                       // L:9405 MOVE ERN-TAX-YTD-LOC TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9406 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (ernTaxYtdOth.compareTo(BigDecimal.ZERO) != 0) { // L:9407 IF ERN-TAX-YTD-OTH NOT = 0
            tcpType = "YO";                                 // L:9408 MOVE "YO" TO TCP-TYPE
            tcpCode = perCdeOth;                            // L:9409 MOVE PER-CDE-OTH TO TCP-CODE
            tcpAmount = ernTaxYtdOth;                       // L:9410 MOVE ERN-TAX-YTD-OTH TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9411 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (ernTaxYtdCit.compareTo(BigDecimal.ZERO) != 0) { // L:9412 IF ERN-TAX-YTD-CIT NOT = 0
            tcpType = "YC";                                 // L:9413 MOVE "YC" TO TCP-TYPE
            tcpCode = perCdeCit;                            // L:9414 MOVE PER-CDE-CIT TO TCP-CODE
            tcpAmount = ernTaxYtdCit;                       // L:9415 MOVE ERN-TAX-YTD-CIT TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9416 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (benSickBal.compareTo(BigDecimal.ZERO) != 0) {   // L:9417 IF BEN-SICK-BAL NOT = 0
            tcpType = "YV";                                 // L:9418 MOVE "YV" TO TCP-TYPE
            tcpCode = "SICK";                               // L:9419 MOVE "SICK" TO TCP-CODE
            tcpAmount = benSickBal;                         // L:9420 MOVE BEN-SICK-BAL TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9421 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (benAnnlAccRte.compareTo(BigDecimal.ZERO) != 0 || benAnnlBal.compareTo(BigDecimal.ZERO) != 0) {// L:9422 IF BEN-ANNL-ACC-RTE NOT = 0 OR
            tcpType = "YV";                                 // L:9424 MOVE "YV" TO TCP-TYPE
            tcpCode = "ANNL";                               // L:9425 MOVE "ANNL" TO TCP-CODE
            tcpAmount = benAnnlBal;                         // L:9426 MOVE BEN-ANNL-BAL TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9427 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        if (benPersBal.compareTo(BigDecimal.ZERO) != 0) {   // L:9428 IF BEN-PERS-BAL NOT = 0
            tcpType = "YV";                                 // L:9429 MOVE "YV" TO TCP-TYPE
            tcpCode = "PERS";                               // L:9430 MOVE "PERS" TO TCP-CODE
            tcpAmount = benPersBal;                         // L:9431 MOVE BEN-PERS-BAL TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9432 PERFORM 800-510-WRITE-PAYTRN
        }  // period ends IF scope
        // 500-200-EXIT. EXIT.                              // L:9434 CODE
    }

    private void updateDedYtd_500_300() {                   // L:9437 500-300-UPDATE-DED-YTD
        tcpClientNo = perClientNo;                          // L:9438 MOVE PER-CLIENT-NO TO TCP-CLIENT-NO
        tcpDateEnd = wsDateEnd.intValue();                  // L:9439 MOVE WS-DATE-END TO TCP-DATE-END
        tcpEmpNo = perEmpNo;                                // L:9440 MOVE PER-EMP-NO TO TCP-EMP-NO
        tcpSeqNo = 0;                                       // L:9441 MOVE 0 TO TCP-SEQ-NO
        if ((("m".equals(timCheckTypeHold) || "v".equals(timCheckTypeHold) || "x".equals(timCheckTypeHold)))) {// L:9442 IF (TIM-CHECK-TYPE-HOLD = "M" OR "V" OR ...
            tcpDocumentNo = timCheckNoHold.toString();      // L:9443 MOVE TIM-CHECK-NO-HOLD TO TCP-DOCUMENT-NO
            tcpDocumentDate = timDateEndHold.intValue();    // L:9444 MOVE TIM-DATE-END-HOLD TO TCP-DOCUMENT-DATE
        } else {                                            // L:9445 ELSE
            tcpDocumentNo = "0";                            // L:9446 MOVE 0 TO TCP-DOCUMENT-NO
            tcpDocumentDate = 0;                            // L:9446 MOVE 0 TO TCP-DOCUMENT-DATE
        }  // period ends IF scope
        tcpCheckNo = timCheckNoHold.intValue();             // L:9447 MOVE TIM-CHECK-NO-HOLD TO TCP-CHECK-NO
        tcpCompNo = clnCompNo;                              // L:9448 MOVE CLN-COMP-NO TO TCP-COMP-NO
        tcpCorpNo = perCorpNo;                              // L:9449 MOVE PER-CORP-NO TO TCP-CORP-NO
        tcpStoreNo = perStoreNo;                            // L:9450 MOVE PER-STORE-NO TO TCP-STORE-NO
        tcpDeptNo = perDeptNo;                              // L:9451 MOVE PER-DEPT-NO TO TCP-DEPT-NO
        tcpJobClass = perJobClass;                          // L:9452 MOVE PER-JOB-CLASS TO TCP-JOB-CLASS
        tcpCorpGl = "0";                                    // L:9453 MOVE 0 TO TCP-CORP-GL
        tcpStoreGl = "0";                                   // L:9453 MOVE 0 TO TCP-STORE-GL
        tcpDeptGl = "0";                                    // L:9454 MOVE 0 TO TCP-DEPT-GL
        tcpAcctGl = "0";                                    // L:9454 MOVE 0 TO TCP-ACCT-GL
        tcpCdeCycle = timCdeCycleHold;                      // L:9455 MOVE TIM-CDE-CYCLE-HOLD TO TCP-CDE-CYCLE
        tcpCheckType = timCheckTypeHold;                    // L:9456 MOVE TIM-CHECK-TYPE-HOLD TO TCP-CHECK-TYPE
        tcpEmpName = perEmpName;                            // L:9457 MOVE PER-EMP-NAME TO TCP-EMP-NAME
        tcpType = "YD";                                     // L:9458 MOVE "YD" TO TCP-TYPE
        tcpCode = dedNoSum[i.intValue()];                   // L:9459 MOVE DED-NO-SUM(I) TO TCP-CODE
        tcpFileSeq = dedSeqNoSum[i.intValue()].intValue();  // L:9460 MOVE DED-SEQ-NO-SUM (I) TO TCP-FILE-SEQ
        tcpAmount = benAccYtd[j.intValue()];                // L:9461 MOVE BEN-ACC-YTD(J) TO TCP-AMOUNT
        if ("y".equals(clnDirdepVoucherOptWs) && ernCppNetSum.compareTo(BigDecimal.ZERO) == 0 && (bnkDepAmt[0].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[1].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[2].compareTo(BigDecimal.ZERO) != 0)) {// L:9462 IF CLN-DIRDEP-VOUCHER-OPT-WS = "Y"
            tcpDirDepVoucher = "Y";                         // L:9471 MOVE "Y" TO TCP-DIR-DEP-VOUCHER
            savedTcpDirDepVoucher = "Y";                    // L:9471 MOVE "Y" TO SAVED-TCP-DIR-DEP-VOUCHER
        } else {                                            // L:9473 ELSE
            tcpDirDepVoucher = "N";                         // L:9474 MOVE "N" TO TCP-DIR-DEP-VOUCHER
            savedTcpDirDepVoucher = "N";                    // L:9474 MOVE "N" TO SAVED-TCP-DIR-DEP-VOUCHER
        }                                                   // L:9476 END-IF
        writePaytrn_800_510();                              // L:9477 PERFORM 800-510-WRITE-PAYTRN
        // 500-300-EXIT. EXIT.                              // L:9479 CODE
    }

    private void updateNone_500_500() {                     // L:9482 500-500-UPDATE-NONE
        payrollCurrentTransRecord = "";                     // L:9483 INITIALIZE PAYROLL-CURRENT-TRANS-RECORD.
        tcpClientNo = timClientNo;                          // L:9484 MOVE TIM-CLIENT-NO TO TCP-CLIENT-NO
        tcpDateEnd = wsDateEnd.intValue();                  // L:9485 MOVE WS-DATE-END TO TCP-DATE-END
        tcpEmpNo = timEmpNo;                                // L:9486 MOVE TIM-EMP-NO TO TCP-EMP-NO
        tcpSeqNo = 0;                                       // L:9487 MOVE 0 TO TCP-SEQ-NO
        tcpCheckNo = timCheckNoHold.intValue();             // L:9488 MOVE TIM-CHECK-NO-HOLD TO TCP-CHECK-NO
        tcpDocumentNo = "0";                                // L:9489 MOVE 0 TO TCP-DOCUMENT-NO
        tcpDocumentDate = 0;                                // L:9489 MOVE 0 TO TCP-DOCUMENT-DATE
        tcpCompNo = timCompNo;                              // L:9490 MOVE TIM-COMP-NO TO TCP-COMP-NO
        tcpCorpNo = timCorpNo;                              // L:9491 MOVE TIM-CORP-NO TO TCP-CORP-NO
        tcpStoreNo = timStoreNo;                            // L:9492 MOVE TIM-STORE-NO TO TCP-STORE-NO
        tcpDeptNo = timDeptNo;                              // L:9493 MOVE TIM-DEPT-NO TO TCP-DEPT-NO
        tcpJobClass = "";                                   // L:9494 MOVE SPACES TO TCP-JOB-CLASS
        tcpCorpWrk = "0";                                   // L:9495 MOVE 0 TO TCP-CORP-WRK
        tcpStoreWrk = "0";                                  // L:9495 MOVE 0 TO TCP-STORE-WRK
        tcpDeptWrk = "0";                                   // L:9495 MOVE 0 TO TCP-DEPT-WRK
        tcpCorpGl = "0";                                    // L:9496 MOVE 0 TO TCP-CORP-GL
        tcpStoreGl = "0";                                   // L:9496 MOVE 0 TO TCP-STORE-GL
        tcpDeptGl = "0";                                    // L:9497 MOVE 0 TO TCP-DEPT-GL
        tcpAcctGl = "0";                                    // L:9497 MOVE 0 TO TCP-ACCT-GL
        tcpCdeCycle = timCdeCycle;                          // L:9498 MOVE TIM-CDE-CYCLE TO TCP-CDE-CYCLE
        tcpCheckType = timCheckType;                        // L:9499 MOVE TIM-CHECK-TYPE TO TCP-CHECK-TYPE
        tcpEmpName = "";                                    // L:9500 MOVE SPACES TO TCP-EMP-NAME
        tcpType = "YR";                                     // L:9501 MOVE "YR" TO TCP-TYPE
        tcpCode = "NONE";                                   // L:9502 MOVE "NONE" TO TCP-CODE
        tcpDirDepVoucher = "N";                             // L:9503 MOVE "N" TO TCP-DIR-DEP-VOUCHER
        savedTcpDirDepVoucher = "N";                        // L:9503 MOVE "N" TO SAVED-TCP-DIR-DEP-VOUCHER
        tcpRate = BigDecimal.ZERO;                          // L:9505 MOVE 0 TO TCP-RATE
        tcpHours = BigDecimal.ZERO;                         // L:9505 MOVE 0 TO TCP-HOURS
        writePaytrn_800_510();                              // L:9506 PERFORM 800-510-WRITE-PAYTRN
        // 500-500-EXIT. EXIT.                              // L:9508 CODE
        // /                                                // L:9509 COMMENT
    }

    private void writeFicmTrans_500_600() {                 // L:9511 500-600-WRITE-FICM-TRANS
        // PRB00871                                         // L:9512 CODE
        payrollCurrentTransRecord = "";                     // L:9513 INITIALIZE PAYROLL-CURRENT-TRANS-RECORD....
        tcpClientNo = timClientNo;                          // L:9514 MOVE TIM-CLIENT-NO TO TCP-CLIENT-NO
        tcpDateEnd = wsDateEnd.intValue();                  // L:9515 MOVE WS-DATE-END TO TCP-DATE-END
        tcpEmpNo = timEmpNo;                                // L:9516 MOVE TIM-EMP-NO TO TCP-EMP-NO
        tcpSeqNo = 0;                                       // L:9517 MOVE 0 TO TCP-SEQ-NO
        tcpCheckNo = timCheckNo;                            // L:9520 MOVE TIM-CHECK-NO TO TCP-CHECK-NO
        if ((("m".equals(timCheckType) || "v".equals(timCheckType) || "x".equals(timCheckType)))) {// L:9521 IF (TIM-CHECK-TYPE = "M" OR "V" OR "X") ...
            tcpDocumentNo = String.valueOf(timCheckNo);     // L:9522 MOVE TIM-CHECK-NO TO TCP-DOCUMENT-NO
            tcpDocumentDate = timDateEndHold.intValue();    // L:9523 MOVE TIM-DATE-END-HOLD TO TCP-DOCUMENT-DATE
        } else {                                            // L:9524 ELSE
            tcpDocumentNo = "0";                            // L:9525 MOVE 0 TO TCP-DOCUMENT-NO
            tcpDocumentDate = 0;                            // L:9525 MOVE 0 TO TCP-DOCUMENT-DATE
            tcpCompNo = timCompNo;                          // L:9526 MOVE TIM-COMP-NO TO TCP-COMP-NO
            tcpCorpNo = timCorpNo;                          // L:9527 MOVE TIM-CORP-NO TO TCP-CORP-NO
            tcpStoreNo = timStoreNo;                        // L:9528 MOVE TIM-STORE-NO TO TCP-STORE-NO
            tcpDeptNo = timDeptNo;                          // L:9529 MOVE TIM-DEPT-NO TO TCP-DEPT-NO
            tcpJobClass = perJobClass;                      // L:9530 MOVE PER-JOB-CLASS TO TCP-JOB-CLASS
            tcpCorpWrk = timCorpWrk;                        // L:9532 MOVE TIM-CORP-WRK TO TCP-CORP-WRK
            tcpStoreWrk = timStoreWrk;                      // L:9533 MOVE TIM-STORE-WRK TO TCP-STORE-WRK
            tcpDeptWrk = timDeptWrk;                        // L:9534 MOVE TIM-DEPT-WRK TO TCP-DEPT-WRK
            tcpCorpGl = "0";                                // L:9535 MOVE 0 TO TCP-CORP-GL
            tcpStoreGl = "0";                               // L:9535 MOVE 0 TO TCP-STORE-GL
            tcpDeptGl = "0";                                // L:9536 MOVE 0 TO TCP-DEPT-GL
            tcpAcctGl = "0";                                // L:9536 MOVE 0 TO TCP-ACCT-GL
            tcpCdeCycle = timCdeCycle;                      // L:9537 MOVE TIM-CDE-CYCLE TO TCP-CDE-CYCLE
            tcpCheckType = timCheckType;                    // L:9538 MOVE TIM-CHECK-TYPE TO TCP-CHECK-TYPE
            tcpEmpName = perEmpName;                        // L:9539 MOVE PER-EMP-NAME TO TCP-EMP-NAME
            tcpType = timType;                              // L:9540 MOVE TIM-TYPE TO TCP-TYPE
            tcpCode = "FICA";                               // L:9541 MOVE "FICA" TO TCP-CODE
            if ("y".equals(clnDirdepVoucherOptWs) && ernCppNetSum.compareTo(BigDecimal.ZERO) == 0 && (bnkDepAmt[0].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[1].compareTo(BigDecimal.ZERO) != 0 || bnkDepAmt[2].compareTo(BigDecimal.ZERO) != 0)) {// L:9544 IF CLN-DIRDEP-VOUCHER-OPT-WS = "Y"      ...
                tcpDirDepVoucher = "Y";                     // L:9553 MOVE "Y" TO TCP-DIR-DEP-VOUCHER
            } else {                                        // L:9554 ELSE
                tcpDirDepVoucher = "N";                     // L:9555 MOVE "N" TO TCP-DIR-DEP-VOUCHER
            }                                               // L:9556 END-IF
            tcpRate = BigDecimal.ZERO;                      // L:9557 MOVE 0 TO TCP-RATE
            tcpHours = BigDecimal.ZERO;                     // L:9557 MOVE 0 TO TCP-HOURS
            tcpAmount = timAmount;                          // L:9558 MOVE TIM-AMOUNT TO TCP-AMOUNT
            writePaytrn_800_510();                          // L:9559 PERFORM 800-510-WRITE-PAYTRN
            savedTcpSeqNo = BigDecimal.valueOf(tcpSeqNo);   // L:9560 MOVE TCP-SEQ-NO TO SAVED-TCP-SEQ-NO
            wsFicmYtd = wsFicmYtd.add(timAmount);           // L:9562 ADD TIM-AMOUNT TO WS-FICM-YTD.          ...
            // 500-600-EXIT. EXIT.                     ...  // L:9564 CODE
        }  // auto-close unclosed IF
    }

    private void getTfw4Info_666() {                        // L:9567 666-GET-TFW4-INFO
        w4rtn = "";                                         // L:9570 MOVE SPACES TO W4RTN
        w40001 = BigDecimal.valueOf(perClientNo);           // L:9571 MOVE PER-CLIENT-NO TO W40001
        w40002 = BigDecimal.valueOf(perEmpNo);              // L:9572 MOVE PER-EMP-NO TO W40002
        w40003 = annualWageWs;                              // L:9574 MOVE ANNUAL-WAGE-WS TO W40003
        w40004 = "";                                        // L:9576 MOVE SPACES TO W40004
        w40005 = "";                                        // L:9576 MOVE SPACES TO W40005
        w40006 = "";                                        // L:9576 MOVE SPACES TO W40006
        w40007 = "";                                        // L:9576 MOVE SPACES TO W40007
        w40008 = BigDecimal.ZERO;                           // L:9580 MOVE ZEROS TO W40008
        w40009 = BigDecimal.ZERO;                           // L:9580 MOVE ZEROS TO W40009
        w40010 = BigDecimal.ZERO;                           // L:9580 MOVE ZEROS TO W40010
        w40011 = BigDecimal.ZERO;                           // L:9580 MOVE ZEROS TO W40011
        // CALL PYERXFK                                     // L:9584 CALL "PYERXFK" USING W4RTN,             ...
        callPyerxfk();
        annualWageWs = w40003;                              // L:9598 MOVE W40003 TO ANNUAL-WAGE-WS
        // ID-139                                           // L:9600 CODE
        // 666-EXIT. EXIT.                         ...      // L:9601 CODE
        // /                                                // L:9602 COMMENT
    }

    private void closeFiles_800_200() {                     // L:9603 800-200-CLOSE-FILES
        // CLOSE PAYCLNFILE PAYTIMFILE PAYPERFILE P...      // L:9604 CLOSE
        // CLOSE PAYTRNCPFL PAYCNLFILE PAYCNLPF01           // L:9607 CLOSE
    }

    private void readPaycln_800_320() {                     // L:9612 800-320-READ-PAYCLN
        clnStat = ioBusy;                                   // L:9613 MOVE IO-BUSY TO CLN-STAT
        readPaycln_800_321();                               // L:9614 PERFORM 800-321-READ-PAYCLN
    }

    private void readPaycln_800_321() {                     // L:9615 800-321-READ-PAYCLN
        // READ PAYCLNFILE INVALID KEY MOVE IO-BAD-...      // L:9616 READ
    }

    private void startPaytim_800_330() {                    // L:9618 800-330-START-PAYTIM
        timStat = ioBusy;                                   // L:9619 MOVE IO-BUSY TO TIM-STAT
        startPaytim_800_331();                              // L:9620 PERFORM 800-331-START-PAYTIM
    }

    private void startPaytim_800_331() {                    // L:9621 800-331-START-PAYTIM
        // START PAYTIMFILE KEY NOT < TIM-KEY INVAL...      // L:9622 CODE
        timStat = ioAtEnd;                                  // L:9623 MOVE IO-AT-END TO TIM-STAT
    }

    private void readPaytim_800_335() {                     // L:9625 800-335-READ-PAYTIM
        timStat = ioBusy;                                   // L:9626 MOVE IO-BUSY TO TIM-STAT
        readPaytim_800_336();                               // L:9627 PERFORM 800-336-READ-PAYTIM THRU 800-336-EXIT
    }

    private void readPaytim_800_336() {                     // L:9629 800-336-READ-PAYTIM
        // READ PAYTIMFILE NEXT                             // L:9630 READ
        timStat = ioAtEnd;                                  // L:9632 MOVE IO-AT-END TO TIM-STAT
        // payrollTimeRecord = default; // INITIALIZE PAYROLL-TIME-RECORD// L:9633 INITIALIZE PAYROLL-TIME-RECORD.
        if ("none".equals(timCode)) {                       // L:9634 IF TIM-CODE = "NONE"
            updateNone_500_500();                           // L:9635 PERFORM 500-500-UPDATE-NONE THRU 500-500-EXIT
            timStat = ioBusy;                               // L:9636 MOVE IO-BUSY TO TIM-STAT
        }  // period ends IF scope
        if (BigDecimal.valueOf(timClientNo).compareTo(prmClientNo) != 0) {// L:9637 IF TIM-CLIENT-NO NOT = PRM-CLIENT-NO
            timStat = ioAtEnd;                              // L:9638 MOVE IO-AT-END TO TIM-STAT
        }  // period ends IF scope
        // 800-336-EXIT. EXIT.                              // L:9639 CODE
    }

    private void readPaytbl_800_340() {                     // L:9641 800-340-READ-PAYTBL
        tblStat = ioBusy;                                   // L:9642 MOVE IO-BUSY TO TBL-STAT
        readPaytbl_800_341();                               // L:9643 PERFORM 800-341-READ-PAYTBL
    }

    private void readPaytbl_800_341() {                     // L:9644 800-341-READ-PAYTBL
        // READ PAYTBLFILE INVALID KEY MOVE IO-BAD-...      // L:9645 READ
    }

    private void startPaytbl_800_345() {                    // L:9647 800-345-START-PAYTBL
        tblStat = ioBusy;                                   // L:9648 MOVE IO-BUSY TO TBL-STAT
        startPaytbl_800_346();                              // L:9649 PERFORM 800-346-START-PAYTBL
    }

    private void startPaytbl_800_346() {                    // L:9650 800-346-START-PAYTBL
        // START PAYTBLFILE                                 // L:9651 CODE
        // KEY NOT LESS THAN TBL-KEY                        // L:9652 CODE
        // INVALID KEY                                      // L:9653 CODE
        tblStat = ioAtEnd;                                  // L:9654 MOVE IO-AT-END TO TBL-STAT
    }

    private void rdNxtPaytbl_800_350() {                    // L:9656 800-350-RD-NXT-PAYTBL
        tblStat = ioBusy;                                   // L:9657 MOVE IO-BUSY TO TBL-STAT
        rdNxtPaytbl_800_351();                              // L:9658 PERFORM 800-351-RD-NXT-PAYTBL
    }

    private void rdNxtPaytbl_800_351() {                    // L:9659 800-351-RD-NXT-PAYTBL
        // READ PAYTBLFILE NEXT AT END MOVE IO-AT-E...      // L:9660 READ
    }

    private void startPaycnl_800_370() {                    // L:9663 800-370-START-PAYCNL
        recOk = "Y";                                        // L:9664 MOVE "Y" TO REC-OK
        // START PAYCNLFILE KEY NOT < CNL-KEY               // L:9665 CODE
        // INVALID KEY                                      // L:9666 CODE
        recOk = "N";                                        // L:9667 MOVE "N" TO REC-OK
        if ("9D".equals(cnlStat)) {                         // L:9668 IF CNL-STAT = "9D" GO TO 800-370-START-P...
            // 800-370-EXIT. EXIT.                          // L:9670 CODE
        }  // period ends IF scope
    }

    private void readPaycnl_800_375() {                     // L:9673 800-375-READ-PAYCNL
        recOk = "Y";                                        // L:9674 MOVE "Y" TO REC-OK
        // READ PAYCNLFILE NEXT                             // L:9675 READ
        recOk = "N";                                        // L:9677 MOVE "N" TO REC-OK
        if ("9D".equals(cnlStat)) {                         // L:9678 IF CNL-STAT = "9D" GO TO 800-375-READ-PA...
            // 800-375-EXIT. EXIT.                          // L:9680 CODE
        }  // period ends IF scope
    }

    private void writePaydep_800_390() {                    // L:9683 800-390-WRITE-PAYDEP
        recOk = "Y";                                        // L:9684 MOVE "Y" TO REC-OK
        // WRITE PAYROLL-DEPOSIT-RECORD                     // L:9685 WRITE
        recOk = "N";                                        // L:9687 MOVE "N" TO REC-OK
        if ("22".equals(fsw) && "n".equals(recOk)) {        // L:9688 IF FSW = "22" AND
            depSeqNo = depSeqNo + 1;                        // L:9690 ADD 1 TO DEP-SEQ-NO
            // GO TO 800-390-WRITE-PAYDEP - control flow    // L:9691 GO TO 800-390-WRITE-PAYDEP
        }  // period ends IF scope
        if ("9D".equals(fsw)) {                             // L:9692 IF FSW = "9D" GO TO 800-390-WRITE-PAYDEP...
            // 800-390-EXIT. EXIT.                          // L:9694 CODE
        }  // period ends IF scope
    }

    private void readPayper_800_400() {                     // L:9697 800-400-READ-PAYPER
        perStat = ioBusy;                                   // L:9698 MOVE IO-BUSY TO PER-STAT
        readPayper_800_401();                               // L:9699 PERFORM 800-401-READ-PAYPER
        readPayperpf01_22000_000();                         // L:9700 PERFORM 22000-000-READ-PAYPERPF01 THRU 22000-000-EXIT
        if ("n".equals(skipDirDep)) {                       // L:9701 IF SKIP-DIR-DEP = "N"
            readPayperpf02_23000_000();                     // L:9702 PERFORM 23000-000-READ-PAYPERPF02 THRU 23000-000-EXIT
        } else {                                            // L:9703 ELSE
            // wsBankAccountRecord = default; // INITIALIZE WS-BANK-ACCOUNT-RECORD// L:9704 INITIALIZE WS-BANK-ACCOUNT-RECORD.
        }  // period ends IF scope
        // 800-400-EXIT. EXIT.                              // L:9706 CODE
    }

    private void readPayper_800_401() {                     // L:9709 800-401-READ-PAYPER
        // READ PAYPERFILE INVALID KEY MOVE IO-BAD-...      // L:9710 READ
        // 800-401-EXIT. EXIT.                              // L:9712 CODE
    }

    private void readPaype3_800_403() {                     // L:9715 800-403-READ-PAYPE3
        recOk = "Y";                                        // L:9716 MOVE "Y" TO REC-OK
        // READ PAYPERPF03                                  // L:9717 READ
        recOk = "N";                                        // L:9719 MOVE "N" TO REC-OK
        if ("9D".equals(fsw)) {                             // L:9720 IF FSW = "9D" GO TO 800-403-READ-PAYPE3.
            // 800-403-EXIT. EXIT.                          // L:9722 CODE
        }  // period ends IF scope
    }

    private void readPayben_800_405() {                     // L:9725 800-405-READ-PAYBEN
        readPaybenfile_20000_000();                         // L:9726 PERFORM 20000-000-READ-PAYBENFILE THRU 20000-000-EXIT
        readPaybenpf01_21000_000();                         // L:9727 PERFORM 21000-000-READ-PAYBENPF01 THRU 21000-000-EXIT
        // 800-405-EXIT. EXIT.                              // L:9729 CODE
    }

    private void readPayern_800_410() {                     // L:9732 800-410-READ-PAYERN
        ernStat = ioBusy;                                   // L:9733 MOVE IO-BUSY TO ERN-STAT
        readPayern_800_411();                               // L:9734 PERFORM 800-411-READ-PAYERN
        readPayernpf01_24000_000();                         // L:9735 PERFORM 24000-000-READ-PAYERNPF01 THRU 24000-000-EXIT
        // 800-410-EXIT. EXIT.                              // L:9737 CODE
    }

    private void readPayern_800_411() {                     // L:9739 800-411-READ-PAYERN
        // READ PAYERNFILE INVALID KEY MOVE IO-BAD-...      // L:9740 READ
        // 800-411-EXIT. EXIT.                              // L:9742 CODE
    }

    private void readPaycal_800_450() {                     // L:9745 800-450-READ-PAYCAL
        calStat = ioBusy;                                   // L:9746 MOVE IO-BUSY TO CAL-STAT
        readPaycal_800_451();                               // L:9747 PERFORM 800-451-READ-PAYCAL
        // 800-450-EXIT. EXIT.                              // L:9749 CODE
    }

    private void readPaycal_800_451() {                     // L:9752 800-451-READ-PAYCAL
        // READ PAYCALFILE INVALID KEY MOVE IO-BAD-...      // L:9753 READ
        // 800-451-EXIT. EXIT.                              // L:9755 CODE
    }

    private void writePaytrn_800_510() {                    // L:9758 800-510-WRITE-PAYTRN
        tcpBankComp = clnBankCompNo;                        // L:9759 MOVE CLN-BANK-COMP-NO TO TCP-BANK-COMP
        tcpBankCode = clnBankCode;                          // L:9760 MOVE CLN-BANK-CODE TO TCP-BANK-CODE
        tcpUpdateYn = "";                                   // L:9761 MOVE SPACE TO TCP-UPDATE-YN
        saveTransactionRecord = payrollCurrentTransRecord;  // L:9762 MOVE PAYROLL-CURRENT-TRANS-RECORD TO SAVE-TRANSACTION-RECORD
        tcpStat = ioBusy;                                   // L:9763 MOVE IO-BUSY TO TCP-STAT
        readPaytrn_800_512();                               // L:9764 PERFORM 800-512-READ-PAYTRN THRU 800-512-EXIT
        payrollCurrentTransRecord = saveTransactionRecord;  // L:9766 MOVE SAVE-TRANSACTION-RECORD TO PAYROLL-CURRENT-TRANS-RECORD
        tcpSeqNo = saveSeqNo.intValue();                    // L:9767 MOVE SAVE-SEQ-NO TO TCP-SEQ-NO
        tcpStat = ioBusy;                                   // L:9768 MOVE IO-BUSY TO TCP-STAT
        writePaytrn_800_511();                              // L:9769 PERFORM 800-511-WRITE-PAYTRN
        if (tcpStat == ioDupKey) {                          // L:9770 IF TCP-STAT = IO-DUP-KEY
            messageO = "SEQUENCE NO EXCEEDED FOR EMPLOYEE"; // L:9771 MOVE "SEQUENCE NO EXCEEDED FOR EMPLOYEE" TO MESSAGE-O
            wsGtnErr = "IO";                                // L:9773 MOVE "IO" TO WS-GTN-ERR
            gtnError_800_700();                             // L:9774 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        // 800-510-EXIT. EXIT.                              // L:9776 CODE
    }

    private void writePaytrn_800_511() {                    // L:9779 800-511-WRITE-PAYTRN
        saveStat = "";                                      // L:9780 MOVE SPACES TO SAVE-STAT
        // WRITE PAYROLL-CURRENT-TRANS-RECORD               // L:9781 WRITE
        tcpStat = ioDupKey;                                 // L:9783 MOVE IO-DUP-KEY TO TCP-STAT
        if ((tcpStat == ioDupKey && tcpSeqNo != 9999)) {    // L:9784 IF (TCP-STAT = IO-DUP-KEY AND TCP-SEQ-NO...
            tcpStat = ioBusy;                               // L:9785 MOVE IO-BUSY TO TCP-STAT
        }  // period ends IF scope
        // 800-511-EXIT. EXIT.                              // L:9787 CODE
    }

    private void readPaytrn_800_512() {                     // L:9790 800-512-READ-PAYTRN
        tcpSeqNo = tcpSeqNo + 1;                            // L:9791 ADD 1 TO TCP-SEQ-NO.
        // READ PAYTRNCPFL INVALID KEY                      // L:9792 READ
        saveSeqNo = BigDecimal.valueOf(tcpSeqNo);           // L:9793 MOVE TCP-SEQ-NO TO SAVE-SEQ-NO
        // GO TO 800-512-EXIT - control flow                // L:9794 GO TO 800-512-EXIT
        tcpStat = ioBusy;                                   // L:9795 MOVE IO-BUSY TO TCP-STAT
        // 800-512-EXIT. EXIT.                              // L:9797 CODE
    }

    private void rewritePaytrn_800_513() {                  // L:9800 800-513-REWRITE-PAYTRN
        tcpSeqNo = savedTcpSeqNo.intValue();                // L:9801 MOVE SAVED-TCP-SEQ-NO TO TCP-SEQ-NO
        // READ PAYTRNCPFL                         ...      // L:9802 READ
        messageO = "FICM RECORD NOT REWRITTEN";             // L:9804 MOVE "FICM RECORD NOT REWRITTEN" TO MESSAGE-O
        wsGtnErr = "IO";                                    // L:9805 MOVE "IO" TO WS-GTN-ERR
        gtnError_800_700();                                 // L:9806 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        // GO TO 800-513-EXIT - control flow                // L:9807 GO TO 800-513-EXIT
        tcpDirDepVoucher = savedTcpDirDepVoucher;           // L:9808 MOVE SAVED-TCP-DIR-DEP-VOUCHER TO TCP-DIR-DEP-VOUCHER
        // REWRITE PAYROLL-CURRENT-TRANS-RECORD    ...      // L:9809 CODE
        // INVALID KEY                             ...      // L:9810 CODE
        // GO TO 800-513-EXIT - control flow                // L:9811 GO TO 800-513-EXIT
        // 800-513-EXIT. EXIT.                     ...      // L:9813 CODE
    }

    private void gtnError_800_700() {                       // L:9816 800-700-GTN-ERROR
        grossNetErrorCntWs = grossNetErrorCntWs.add(BigDecimal.valueOf(1));// L:9817 ADD 1 TO GROSS-NET-ERROR-CNT-WS.
        gtnProfile = sdexco;                                // L:9818 MOVE SDEXCO TO GTN-PROFILE
        gtnClientNo = prmClientNo.shortValue();             // L:9819 MOVE PRM-CLIENT-NO TO GTN-CLIENT-NO
        gtnEmpNo = errEmpNo.intValue();                     // L:9820 MOVE ERR-EMP-NO TO GTN-EMP-NO
        gtnEndDate = errDateEnd.intValue();                 // L:9821 MOVE ERR-DATE-END TO GTN-END-DATE
        gtnErrorType = wsGtnErr;                            // L:9822 MOVE WS-GTN-ERR TO GTN-ERROR-TYPE
        if ("ab".equals(wsGtnErr)) {                        // L:9823 IF WS-GTN-ERR = "AB"
            gtnEnd = "Y";                                   // L:9824 MOVE "Y" TO GTN-END
        }  // period ends IF scope
        gtnSeqNo = 1;                                       // L:9825 MOVE 1 TO GTN-SEQ-NO
    }

    private void readError_800_700() {                      // L:9827 800-700-READ-ERROR
        // READ PAYGTNFILE                                  // L:9828 READ
        writeError_800_710();                               // L:9830 PERFORM 800-710-WRITE-ERROR THRU 800-710-EXIT
        // GO TO 800-700-EXIT - control flow                // L:9831 GO TO 800-700-EXIT
        gtnSeqNo = gtnSeqNo + 1;                            // L:9832 ADD 1 TO GTN-SEQ-NO.
        // GO TO 800-700-READ-ERROR - control flow          // L:9833 GO TO 800-700-READ-ERROR
        // 800-700-EXIT. EXIT.                              // L:9835 CODE
    }

    private void writeError_800_710() {                     // L:9838 800-710-WRITE-ERROR
        gtnText = messageO;                                 // L:9839 MOVE MESSAGE-O TO GTN-TEXT
        // WRITE PAYROLL-GTN-FILE                           // L:9840 WRITE
        // GO TO 800-710-EXIT - control flow                // L:9842 GO TO 800-710-EXIT
        messageO = "";                                      // L:9843 MOVE SPACES TO MESSAGE-O
        wsGtnErr = "";                                      // L:9844 MOVE SPACE TO WS-GTN-ERR
        // 800-710-EXIT. EXIT.                              // L:9846 CODE
        // /                                                // L:9848 COMMENT
    }

    private void housekeepingControl_1000_000() {           // L:9849 1000-000-HOUSEKEEPING-CONTROL
        xprogName = "PAYROLL GROSS TO NET";                 // L:9850 MOVE "PAYROLL GROSS TO NET" TO XPROG-NAME
        loadTaxTable_1000_300();                            // L:9851 PERFORM 1000-300-LOAD-TAX-TABLE
        if (taxRoutineError) {                              // L:9852 IF TAX-ROUTINE-ERROR
            wsGtnErr = "AB";                                // L:9853 MOVE "AB" TO WS-GTN-ERR
            messageO = "UABLE TO LOAD TAX TABLE - ABORTED.";// L:9854 MOVE "UABLE TO LOAD TAX TABLE - ABORTED." TO MESSAGE-O
            gtnError_800_700();                             // L:9856 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        // 1000-000-EXIT. EXIT.                             // L:9858 CODE
        // /                                                // L:9859 COMMENT
    }

    private void loadTaxTable_1000_300() {                  // L:9860 1000-300-LOAD-TAX-TABLE
        taxRoutineFlag = okLit;                             // L:9861 MOVE OK-LIT TO TAX-ROUTINE-FLAG
        // OPEN INPUT PAYTBLFILE PAYTBLPF01.                // L:9862 OPEN
        initTable_1000_310();                               // L:9863 PERFORM 1000-310-INIT-TABLE
        readTable_1000_320();                               // L:9864 PERFORM 1000-320-READ-TABLE
        wsTblIdxLimit = BigDecimal.valueOf(tblIdx);         // L:9873 SET WS-TBL-IDX-LIMIT TO TBL-IDX.
        if (wsTblIdxLimit.compareTo(BigDecimal.valueOf(6000)) > 0) {// L:9876 IF WS-TBL-IDX-LIMIT > 6000              ...
            taxRoutineFlag = notOkLit;                      // L:9877 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            messageO = "TAX TABLE OVERFLOW";                // L:9878 MOVE "TAX TABLE OVERFLOW" TO MESSAGE-O
            gtnError_800_700();                             // L:9879 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        tblRem = wsTblIdxLimit.subtract(BigDecimal.valueOf(1));// L:9880 SUBTRACT 1 FROM WS-TBL-IDX-LIMIT GIVING ...
        loop_1000_310();                                    // L:9881 PERFORM 1000-310-LOOP THRU 1000-310-EXIT
        ficaInfo_1000_330();                                // L:9886 PERFORM 1000-330-FICA-INFO
        minWage_1000_340();                                 // L:9887 PERFORM 1000-340-MIN-WAGE
        // CLOSE PAYTBLFILE PAYTBLPF01.                     // L:9888 CLOSE
    }

    private void initTable_1000_310() {                     // L:9891 1000-310-INIT-TABLE
        // Initialize WS-TBL-TABLE-AREA                     // L:9892 INITIALIZE WS-TBL-TABLE-AREA.
        wsFicaUprTaxLimitYtd = BigDecimal.ZERO;
        wsFicaUprTaxLimitYtd1 = BigDecimal.ZERO;
        wsFicaUprTaxLimitYtd2 = BigDecimal.ZERO;
        wsFicaUprTaxLimitYtd3 = BigDecimal.ZERO;
        wsFicaLwrTaxLimitYtd = BigDecimal.ZERO;
        wsFicaLwrTaxLimitYtd1 = BigDecimal.ZERO;
        wsFicaLwrTaxLimitYtd2 = BigDecimal.ZERO;
        wsFicaLwrTaxLimitYtd3 = BigDecimal.ZERO;
        wsFicaUprWageLimitYtd = BigDecimal.ZERO;
        wsFicaUprWageLimitYtd1 = BigDecimal.ZERO;
        wsFicaUprWageLimitYtd2 = BigDecimal.ZERO;
        wsFicaUprWageLimitYtd3 = BigDecimal.ZERO;
        wsFicaLwrWageLimitYtd = BigDecimal.ZERO;
        wsFicaLwrWageLimitYtd1 = BigDecimal.ZERO;
        wsFicaLwrWageLimitYtd2 = BigDecimal.ZERO;
        wsFicaLwrWageLimitYtd3 = BigDecimal.ZERO;
        wsFicaUprPercent = BigDecimal.ZERO;
        wsFicaUprPercent1 = BigDecimal.ZERO;
        wsFicaUprPercent2 = BigDecimal.ZERO;
        wsFicaUprPercent3 = BigDecimal.ZERO;
        wsFicaLwrPercent = BigDecimal.ZERO;
        wsFicaLwrPercent2 = BigDecimal.ZERO;
        wsFicaLwrPercent3 = BigDecimal.ZERO;
        wsFicmUprTaxLimitYtd = BigDecimal.ZERO;
        wsFicmLwrTaxLimitYtd = BigDecimal.ZERO;
        wsFicmUprWageLimitYtd = BigDecimal.ZERO;
        wsFicmLwrWageLimitYtd = BigDecimal.ZERO;
        wsFicmUprPercent = BigDecimal.ZERO;
        wsFicmLwrPercent = BigDecimal.ZERO;
        wsFicmYtd = BigDecimal.ZERO;
        wsMinWageRteHourly = BigDecimal.ZERO;
        tblRem = BigDecimal.ZERO;
        tblCnt = BigDecimal.ZERO;
        wsTblIdxLimit = BigDecimal.ZERO;
        wsFicaUprTaxLimitYtd = BigDecimal.valueOf(999999999.99);// L:9893 MOVE 999999999.99 TO WS-FICA-UPR-TAX-LIMIT-YTD
        wsFicaUprTaxLimitYtd1 = BigDecimal.valueOf(999999999.99);// L:9894 MOVE 999999999.99 TO WS-FICA-UPR-TAX-LIMIT-YTD-1
        wsFicaUprTaxLimitYtd2 = BigDecimal.valueOf(999999999.99);// L:9895 MOVE 999999999.99 TO WS-FICA-UPR-TAX-LIMIT-YTD-2
        wsFicaLwrTaxLimitYtd = BigDecimal.valueOf(999999999.99);// L:9896 MOVE 999999999.99 TO WS-FICA-LWR-TAX-LIMIT-YTD
        wsFicaLwrTaxLimitYtd1 = BigDecimal.valueOf(999999999.99);// L:9897 MOVE 999999999.99 TO WS-FICA-LWR-TAX-LIMIT-YTD-1
        wsFicaLwrTaxLimitYtd2 = BigDecimal.valueOf(999999999.99);// L:9898 MOVE 999999999.99 TO WS-FICA-LWR-TAX-LIMIT-YTD-2
        wsFicaUprWageLimitYtd = BigDecimal.valueOf(999999999.99);// L:9899 MOVE 999999999.99 TO WS-FICA-UPR-WAGE-LIMIT-YTD
        wsFicaUprWageLimitYtd1 = BigDecimal.valueOf(999999999.99);// L:9900 MOVE 999999999.99 TO WS-FICA-UPR-WAGE-LIMIT-YTD-1
        wsFicaUprWageLimitYtd2 = BigDecimal.valueOf(999999999.99);// L:9901 MOVE 999999999.99 TO WS-FICA-UPR-WAGE-LIMIT-YTD-2
        wsFicaLwrWageLimitYtd = BigDecimal.valueOf(999999999.99);// L:9902 MOVE 999999999.99 TO WS-FICA-LWR-WAGE-LIMIT-YTD
        wsFicaLwrWageLimitYtd1 = BigDecimal.valueOf(999999999.99);// L:9903 MOVE 999999999.99 TO WS-FICA-LWR-WAGE-LIMIT-YTD-1
        wsFicaLwrWageLimitYtd2 = BigDecimal.valueOf(999999999.99);// L:9904 MOVE 999999999.99 TO WS-FICA-LWR-WAGE-LIMIT-YTD-2
        wsFicaLwrWageLimitYtd3 = BigDecimal.valueOf(999999999.99);// L:9905 MOVE 999999999.99 TO WS-FICA-LWR-WAGE-LIMIT-YTD-3
        wsFicaUprPercent = BigDecimal.valueOf(.9999999);    // L:9906 MOVE .9999999 TO WS-FICA-UPR-PERCENT
        wsFicaUprPercent1 = BigDecimal.valueOf(.9999999);   // L:9907 MOVE .9999999 TO WS-FICA-UPR-PERCENT-1
        wsFicaUprPercent2 = BigDecimal.valueOf(.9999999);   // L:9908 MOVE .9999999 TO WS-FICA-UPR-PERCENT-2
        wsFicaLwrPercent = BigDecimal.valueOf(.9999999);    // L:9909 MOVE .9999999 TO WS-FICA-LWR-PERCENT
        wsFicaLwrPercent2 = BigDecimal.valueOf(.9999999);   // L:9910 MOVE .9999999 TO WS-FICA-LWR-PERCENT-2
        wsFicaLwrPercent3 = BigDecimal.valueOf(.9999999);   // L:9911 MOVE .9999999 TO WS-FICA-LWR-PERCENT-3
        wsMinWageRteHourly = BigDecimal.valueOf(999999999.99);// L:9912 MOVE 999999999.99 TO WS-MIN-WAGE-RTE-HOURLY
        wsTblIdxLimit = BigDecimal.valueOf(9999);           // L:9913 MOVE 9999 TO WS-TBL-IDX-LIMIT
        tblKey = "";                                        // L:9914 INITIALIZE TBL-KEY.
        startPaytbl_800_345();                              // L:9915 PERFORM 800-345-START-PAYTBL
        if (tblStat.compareTo(ioOk) != 0) {                 // L:9916 IF TBL-STAT NOT = IO-OK
            taxRoutineFlag = notOkLit;                      // L:9917 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            messageO = "NO TAX TABLES";                     // L:9918 MOVE "NO TAX TABLES" TO MESSAGE-O
            wsGtnErr = "AB";                                // L:9919 MOVE "AB" TO WS-GTN-ERR
            gtnError_800_700();                             // L:9920 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
    }

    private void loop_1000_310() {                          // L:9922 1000-310-LOOP
        // INSPECT WS-CDE-TAX(TBL-IDX)                      // L:9923 INSPECT
        // INSPECT WS-MAR-STATUS(TBL-IDX)                   // L:9925 INSPECT
        wsLevel[tblIdx] = BigDecimal.valueOf(99);           // L:9927 MOVE 99 TO WS-LEVEL(TBL-IDX)
        wsLowerWageLimit[tblIdx] = BigDecimal.valueOf(999999999.99);// L:9928 MOVE 999999999.99 TO WS-LOWER-WAGE-LIMIT(TBL-IDX)
        wsPctExcessWage[tblIdx] = BigDecimal.valueOf(.9999999);// L:9929 MOVE .9999999 TO WS-PCT-EXCESS-WAGE(TBL-IDX)
        wsFlatTaxAmt[tblIdx] = BigDecimal.valueOf(99999999999.99);// L:9930 MOVE 99999999999.99 TO WS-FLAT-TAX-AMT(TBL-IDX)
        wsExemptAmt[tblIdx] = BigDecimal.valueOf(99999999999.99);// L:9931 MOVE 99999999999.99 TO WS-EXEMPT-AMT(TBL-IDX)
        wsStdDedAmt[tblIdx] = BigDecimal.valueOf(99999999999.99);// L:9932 MOVE 99999999999.99 TO WS-STD-DED-AMT(TBL-IDX)
        wsStdDedPct[tblIdx] = BigDecimal.valueOf(.9999999); // L:9933 MOVE .9999999 TO WS-STD-DED-PCT(TBL-IDX)
        wsUnempLimit[tblIdx] = BigDecimal.valueOf(99999999999.99);// L:9934 MOVE 99999999999.99 TO WS-UNEMP-LIMIT(TBL-IDX)
        wsTaxLimitYtd[tblIdx] = BigDecimal.valueOf(99999999999.99);// L:9935 MOVE 99999999999.99 TO WS-TAX-LIMIT-YTD(TBL-IDX)
        wsWageLimitYtd[tblIdx] = BigDecimal.valueOf(99999999999.99);// L:9936 MOVE 99999999999.99 TO WS-WAGE-LIMIT-YTD(TBL-IDX)
        wsTaxLimitCpp[tblIdx] = BigDecimal.valueOf(99999999999.99);// L:9937 MOVE 99999999999.99 TO WS-TAX-LIMIT-CPP(TBL-IDX)
        wsExemptAddlAmt[tblIdx] = BigDecimal.valueOf(99999);// L:9938 MOVE 99999 TO WS-EXEMPT-ADDL-AMT(TBL-IDX)
        wsTaxCreditYn[tblIdx] = "N";                        // L:9939 MOVE "N" TO WS-TAX-CREDIT-YN(TBL-IDX)
        // 1000-310-EXIT. EXIT.                             // L:9940 CODE
    }

    private void readTable_1000_320() {                     // L:9943 1000-320-READ-TABLE
        rdNxtPaytbl_800_350();                              // L:9944 PERFORM 800-350-RD-NXT-PAYTBL
        if (tblStat == ioOk) {                              // L:9945 IF TBL-STAT = IO-OK
            wsTblRecord[tblIdx] = payrollTaxTableRecord;    // L:9946 MOVE PAYROLL-TAX-TABLE-RECORD TO WS-TBL-RECORD(TBL-IDX)
            tblCnt = tblCnt.add(BigDecimal.valueOf(1));     // L:9947 ADD 1 TO TBL-CNT
            wsExemptAddlAmt[tblIdx] = tblExemptAddlAmt;     // L:9948 MOVE TBL-EXEMPT-ADDL-AMT TO WS-EXEMPT-ADDL-AMT(TBL-IDX)
        }  // period ends IF scope
        if (tblStat == ioOk) {                              // L:9949 IF TBL-STAT = IO-OK
            if (tblTaxLimitYtd.compareTo(BigDecimal.ZERO) == 0) {// L:9950 IF TBL-TAX-LIMIT-YTD = ZERO
                wsTaxLimitYtd[tblIdx] = BigDecimal.valueOf(99999999.99);// L:9951 MOVE 99999999.99 TO WS-TAX-LIMIT-YTD(TBL-IDX)
            } else {                                        // L:9952 ELSE
                wsTaxLimitYtd[tblIdx] = tblTaxLimitYtd;     // L:9953 MOVE TBL-TAX-LIMIT-YTD TO WS-TAX-LIMIT-YTD(TBL-IDX)
            }  // period ends IF scope
        }  // period ends IF scope
        if (tblStat == ioOk) {                              // L:9954 IF TBL-STAT = IO-OK
            if (tblWageLimitYtd.compareTo(BigDecimal.ZERO) == 0) {// L:9955 IF TBL-WAGE-LIMIT-YTD = ZERO
                wsWageLimitYtd[tblIdx] = BigDecimal.valueOf(99999999.99);// L:9956 MOVE 99999999.99 TO WS-WAGE-LIMIT-YTD(TBL-IDX)
            } else {                                        // L:9957 ELSE
                wsWageLimitYtd[tblIdx] = tblWageLimitYtd;   // L:9958 MOVE TBL-WAGE-LIMIT-YTD TO WS-WAGE-LIMIT-YTD(TBL-IDX)
                if (tblStat == ioOk) {                      // L:9960 IF TBL-STAT = IO-OK
                    if (tblTaxLimitCpp.compareTo(BigDecimal.ZERO) == 0) {// L:9961 IF TBL-TAX-LIMIT-CPP = ZERO
                        wsTaxLimitCpp[tblIdx] = BigDecimal.valueOf(99999999.99);// L:9962 MOVE 99999999.99 TO WS-TAX-LIMIT-CPP(TBL-IDX)
                    } else {                                // L:9963 ELSE
                        wsTaxLimitCpp[tblIdx] = tblTaxLimitCpp;// L:9964 MOVE TBL-TAX-LIMIT-CPP TO WS-TAX-LIMIT-CPP(TBL-IDX)
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if (tblStat == ioOk) {                              // L:9965 IF TBL-STAT = IO-OK
            loadOptions_1000_325();                         // L:9966 PERFORM 1000-325-LOAD-OPTIONS THRU 1000-325-EXIT
        }  // period ends IF scope
        // 1000-320-EXIT. EXIT.                             // L:9968 CODE
    }

    private void loadOptions_1000_325() {                   // L:9971 1000-325-LOAD-OPTIONS
        wsTaxCreditYn[tblIdx] = "N";                        // L:9972 MOVE "N" TO WS-TAX-CREDIT-YN(TBL-IDX)
        tb1CdeTax = tblCdeTax;                              // L:9973 MOVE TBL-CDE-TAX TO TB1-CDE-TAX
        tb1MarStatus = tblMarStatus;                        // L:9974 MOVE TBL-MAR-STATUS TO TB1-MAR-STATUS
        tb1Level = tblLevel;                                // L:9975 MOVE TBL-LEVEL TO TB1-LEVEL
        // START PAYTBLPF01 KEY NOT < TB1-KEY               // L:9976 CODE
        // INVALID KEY                                      // L:9977 CODE
        // GO TO 1000-325-EXIT - control flow               // L:9978 GO TO 1000-325-EXIT
    }

    private void readOptions_1000_325() {                   // L:9980 1000-325-READ-OPTIONS
        // READ PAYTBLPF01 NEXT                             // L:9981 READ
        // GO TO 1000-325-EXIT - control flow               // L:9983 GO TO 1000-325-EXIT
        if (tblCdeTax.compareTo(tb1CdeTax) != 0 || tblMarStatus.compareTo(tb1MarStatus) != 0 || tblLevel != tb1Level) {// L:9984 IF TBL-CDE-TAX NOT = TB1-CDE-TAX OR
            // GO TO 1000-325-EXIT - control flow           // L:9987 GO TO 1000-325-EXIT
        }  // period ends IF scope
        if ((tb1OptId == 1 && "nj".equals(tb1CdeTax))) {    // L:9988 IF (TB1-OPT-ID = 01 AND TB1-CDE-TAX = "N...
            njBaseWeekLimit = new BigDecimal(tb1OptValue);  // L:9989 MOVE TB1-OPT-VALUE TO NJ-BASE-WEEK-LIMIT
        }  // period ends IF scope
        if ((tb1OptId == 1 && "pa".equals(tb1CdeTax))) {    // L:9990 IF (TB1-OPT-ID = 01 AND TB1-CDE-TAX = "P...
            paBaseWeekLimit = new BigDecimal(tb1OptValue);  // L:9991 MOVE TB1-OPT-VALUE TO PA-BASE-WEEK-LIMIT
        }  // period ends IF scope
        if (tb1OptId == 2 && "mopt".equals(tb1CdeTax)) {    // L:9992 IF TB1-OPT-ID = 02 AND
            paMoptLowWageLimit = new BigDecimal(tb1OptValue);// L:9994 MOVE TB1-OPT-VALUE TO PA-MOPT-LOW-WAGE-LIMIT
        }  // period ends IF scope
        if (tb1OptId == 2 && "lopt".equals(tb1CdeTax)) {    // L:9995 IF TB1-OPT-ID = 02 AND
            paLoptLowWageLimit = new BigDecimal(tb1OptValue);// L:9997 MOVE TB1-OPT-VALUE TO PA-LOPT-LOW-WAGE-LIMIT
        }  // period ends IF scope
        if (tb1OptId == 2 && "sopt".equals(tb1CdeTax)) {    // L:9998 IF TB1-OPT-ID = 02 AND
            paSoptLowWageLimit = new BigDecimal(tb1OptValue);// L:10000 MOVE TB1-OPT-VALUE TO PA-SOPT-LOW-WAGE-LIMIT
        }  // period ends IF scope
        if (tb1OptId == 2 && "sopu".equals(tb1CdeTax)) {    // L:10001 IF TB1-OPT-ID = 02 AND
            paSopuLowWageLimit = new BigDecimal(tb1OptValue);// L:10003 MOVE TB1-OPT-VALUE TO PA-SOPU-LOW-WAGE-LIMIT
        }  // period ends IF scope
        if (tb1OptId == 3 && "copt".equals(tb1CdeTax)) {    // L:10004 IF TB1-OPT-ID = 03 AND
            paCoptLowWageLimit = new BigDecimal(tb1OptValue);// L:10006 MOVE TB1-OPT-VALUE TO PA-COPT-LOW-WAGE-LIMIT
        }  // period ends IF scope
        if (tb1OptId == 3 && "eopt".equals(tb1CdeTax)) {    // L:10007 IF TB1-OPT-ID = 03 AND
            paEoptLowWageLimit = new BigDecimal(tb1OptValue);// L:10009 MOVE TB1-OPT-VALUE TO PA-EOPT-LOW-WAGE-LIMIT
        }  // period ends IF scope
        if (tb1OptId == 4) {                                // L:10010 IF TB1-OPT-ID = 04
            iaStdDedTier = new BigDecimal(tb1OptValue);     // L:10011 MOVE TB1-OPT-VALUE TO IA-STD-DED-TIER
        }  // period ends IF scope
        if (tb1OptId == 5) {                                // L:10012 IF TB1-OPT-ID = 05
            mdMinStdDed = new BigDecimal(tb1OptValue);      // L:10013 MOVE TB1-OPT-VALUE TO MD-MIN-STD-DED
        }  // period ends IF scope
        if (tb1OptId == 7) {                                // L:10014 IF TB1-OPT-ID = 07
            wiLowWageTaxRate = new BigDecimal(tb1OptValue); // L:10015 MOVE TB1-OPT-VALUE TO WI-LOW-WAGE-TAX-RATE
        }  // period ends IF scope
        if (tb1OptId == 8) {                                // L:10016 IF TB1-OPT-ID = 08
            wsTaxCreditYn[tblIdx] = "Y";                    // L:10017 MOVE "Y" TO WS-TAX-CREDIT-YN(TBL-IDX)
        }  // period ends IF scope
        if (tb1OptId == 9 && "||".equals(tb1CdeTax)) {      // L:10018 IF TB1-OPT-ID = 09 AND
            orFedWithLimit = new BigDecimal(tb1OptValue);   // L:10020 MOVE TB1-OPT-VALUE TO OR-FED-WITH-LIMIT
        }  // period ends IF scope
        if (tb1OptId == 9 && "mo".equals(tb1CdeTax) && "s".equals(tb1MarStatus)) {// L:10021 IF TB1-OPT-ID = 09 AND
            moFedWithLimitS = new BigDecimal(tb1OptValue);  // L:10024 MOVE TB1-OPT-VALUE TO MO-FED-WITH-LIMIT-S
        }  // period ends IF scope
        if (tb1OptId == 9 && "mo".equals(tb1CdeTax) && ("m".equals(tb1MarStatus) || "h".equals(tb1MarStatus))) {// L:10025 IF TB1-OPT-ID = 09 AND
            moFedWithLimitM = new BigDecimal(tb1OptValue);  // L:10030 MOVE TB1-OPT-VALUE TO MO-FED-WITH-LIMIT-M
        }  // period ends IF scope
        // GO TO 1000-325-READ-OPTIONS - control flow       // L:10031 GO TO 1000-325-READ-OPTIONS
        // 1000-325-EXIT. EXIT.                             // L:10033 CODE
    }

    private void ficaInfo_1000_330() {                      // L:10035 1000-330-FICA-INFO
        tblKey = "";                                        // L:10036 MOVE SPACES TO TBL-KEY
        tblCdeTax = "FICA";                                 // L:10037 MOVE "FICA" TO TBL-CDE-TAX
        tblMarStatus = "S";                                 // L:10038 MOVE "S" TO TBL-MAR-STATUS
        ws3TaxLevelsExist = "N";                            // L:10043 MOVE "N" TO WS-3-TAX-LEVELS-EXIST
        tblLevel = 3;                                       // L:10044 MOVE 3 TO TBL-LEVEL
        readPaytbl_800_340();                               // L:10045 PERFORM 800-340-READ-PAYTBL
        if (tblStat.compareTo(ioOk) != 0) {                 // L:10046 IF TBL-STAT NOT = IO-OK                 ...
            ws3TaxLevelsExist = "N";                        // L:10047 MOVE "N" TO WS-3-TAX-LEVELS-EXIST
        } else {                                            // L:10048 ELSE
            ws3TaxLevelsExist = "Y";                        // L:10049 MOVE "Y" TO WS-3-TAX-LEVELS-EXIST
        }                                                   // L:10050 END-IF
        if ("y".equals(ws3TaxLevelsExist)) {                // L:10051 IF WS-3-TAX-LEVELS-EXIST = "Y"          ...
            levels_1000_331_3();                            // L:10052 PERFORM 1000-331-3-LEVELS
        } else {                                            // L:10053 ELSE
            levels_1000_332_2();                            // L:10054 PERFORM 1000-332-2-LEVELS
        }                                                   // L:10055 END-IF
        tblKey = "";                                        // L:10057 MOVE SPACES TO TBL-KEY
        tblCdeTax = "FICM";                                 // L:10058 MOVE "FICM" TO TBL-CDE-TAX
        tblMarStatus = "S";                                 // L:10059 MOVE "S" TO TBL-MAR-STATUS
        tblLevel = 1;                                       // L:10060 MOVE 1 TO TBL-LEVEL
        readPaytbl_800_340();                               // L:10061 PERFORM 800-340-READ-PAYTBL
        if (tblStat.compareTo(ioOk) != 0) {                 // L:10062 IF TBL-STAT NOT = IO-OK                 ...
            taxRoutineFlag = notOkLit;                      // L:10063 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            messageO = "MISSING FICA EMPR RECORD-FICM/S/01";// L:10064 MOVE "MISSING FICA EMPR RECORD-FICM/S/01" TO MESSAGE-O
            wsGtnErr = "TX";                                // L:10065 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:10066 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            wsFicmLwrWageLimitYtd = tblFicaLimit;           // L:10067 MOVE TBL-FICA-LIMIT TO WS-FICM-LWR-WAGE-LIMIT-YTD
            wsFicmUprPercent = tblFicaPct;                  // L:10068 MOVE TBL-FICA-PCT TO WS-FICM-UPR-PERCENT
            wsFicmUprTaxLimitYtd = tblTaxLimitYtd;          // L:10069 MOVE TBL-TAX-LIMIT-YTD TO WS-FICM-UPR-TAX-LIMIT-YTD
            wsFicmUprWageLimitYtd = tblWageLimitYtd;        // L:10070 MOVE TBL-WAGE-LIMIT-YTD TO WS-FICM-UPR-WAGE-LIMIT-YTD
            wsFicmLwrTaxLimitYtd = tblFlatTaxAmt;           // L:10071 MOVE TBL-FLAT-TAX-AMT TO WS-FICM-LWR-TAX-LIMIT-YTD
            tblLevel = 2;                                   // L:10073 MOVE 2 TO TBL-LEVEL
            readPaytbl_800_340();                           // L:10074 PERFORM 800-340-READ-PAYTBL
            if (tblStat.compareTo(ioOk) != 0) {             // L:10075 IF TBL-STAT NOT = IO-OK                 ...
                taxRoutineFlag = notOkLit;                  // L:10076 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
                messageO = "MISSING FICA EMPR RECORD-FICM/S/02";// L:10077 MOVE "MISSING FICA EMPR RECORD-FICM/S/02" TO MESSAGE-O
                wsGtnErr = "TX";                            // L:10078 MOVE "TX" TO WS-GTN-ERR
                gtnError_800_700();                         // L:10079 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                wsFicmLwrPercent = tblFicaPct;              // L:10080 MOVE TBL-FICA-PCT TO WS-FICM-LWR-PERCENT
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void levels_1000_331_3() {                      // L:10082 1000-331-3-LEVELS
        tblLevel = 1;                                       // L:10083 MOVE 1 TO TBL-LEVEL
        readPaytbl_800_340();                               // L:10084 PERFORM 800-340-READ-PAYTBL
        if (tblStat.compareTo(ioOk) != 0) {                 // L:10085 IF TBL-STAT NOT = IO-OK                 ...
            taxRoutineFlag = notOkLit;                      // L:10086 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            messageO = "MISSING FICA RECORD-FICA/S/01";     // L:10087 MOVE "MISSING FICA RECORD-FICA/S/01" TO MESSAGE-O
            wsGtnErr = "TX";                                // L:10088 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:10089 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            wsFicaLwrWageLimitYtd1 = tblFicaLimit;          // L:10090 MOVE TBL-FICA-LIMIT TO WS-FICA-LWR-WAGE-LIMIT-YTD-1
            wsFicaUprPercent1 = tblFicaPct;                 // L:10091 MOVE TBL-FICA-PCT TO WS-FICA-UPR-PERCENT-1
            wsFicaUprTaxLimitYtd1 = tblTaxLimitYtd;         // L:10092 MOVE TBL-TAX-LIMIT-YTD TO WS-FICA-UPR-TAX-LIMIT-YTD-1
            wsFicaUprWageLimitYtd1 = tblWageLimitYtd;       // L:10093 MOVE TBL-WAGE-LIMIT-YTD TO WS-FICA-UPR-WAGE-LIMIT-YTD-1
            wsFicaLwrTaxLimitYtd1 = tblFlatTaxAmt;          // L:10094 MOVE TBL-FLAT-TAX-AMT TO WS-FICA-LWR-TAX-LIMIT-YTD-1
            tblLevel = 2;                                   // L:10096 MOVE 2 TO TBL-LEVEL
            readPaytbl_800_340();                           // L:10097 PERFORM 800-340-READ-PAYTBL
            if (tblStat.compareTo(ioOk) != 0) {             // L:10098 IF TBL-STAT NOT = IO-OK                 ...
                taxRoutineFlag = notOkLit;                  // L:10099 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
                messageO = "MISSING FICA RECORD-FICA/S/02"; // L:10100 MOVE "MISSING FICA RECORD-FICA/S/02" TO MESSAGE-O
                wsGtnErr = "TX";                            // L:10101 MOVE "TX" TO WS-GTN-ERR
                gtnError_800_700();                         // L:10102 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                wsFicaLwrPercent2 = tblFicaPct;             // L:10103 MOVE TBL-FICA-PCT TO WS-FICA-LWR-PERCENT-2
                tblLevel = 2;                               // L:10105 MOVE 2 TO TBL-LEVEL
                readPaytbl_800_340();                       // L:10106 PERFORM 800-340-READ-PAYTBL
                if (tblStat.compareTo(ioOk) != 0) {         // L:10107 IF TBL-STAT NOT = IO-OK                 ...
                    taxRoutineFlag = notOkLit;              // L:10108 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
                    messageO = "MISSING FICA RECORD-FICA/S/02";// L:10109 MOVE "MISSING FICA RECORD-FICA/S/02" TO MESSAGE-O
                    wsGtnErr = "TX";                        // L:10110 MOVE "TX" TO WS-GTN-ERR
                    gtnError_800_700();                     // L:10111 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                    wsFicaLwrWageLimitYtd2 = tblFicaLimit;  // L:10112 MOVE TBL-FICA-LIMIT TO WS-FICA-LWR-WAGE-LIMIT-YTD-2
                    wsFicaUprPercent2 = tblFicaPct;         // L:10113 MOVE TBL-FICA-PCT TO WS-FICA-UPR-PERCENT-2
                    wsFicaUprTaxLimitYtd2 = tblTaxLimitYtd; // L:10114 MOVE TBL-TAX-LIMIT-YTD TO WS-FICA-UPR-TAX-LIMIT-YTD-2
                    wsFicaUprWageLimitYtd2 = tblWageLimitYtd;// L:10115 MOVE TBL-WAGE-LIMIT-YTD TO WS-FICA-UPR-WAGE-LIMIT-YTD-2
                    wsFicaLwrTaxLimitYtd2 = tblFlatTaxAmt;  // L:10116 MOVE TBL-FLAT-TAX-AMT TO WS-FICA-LWR-TAX-LIMIT-YTD-2
                    tblLevel = 3;                           // L:10118 MOVE 3 TO TBL-LEVEL
                    readPaytbl_800_340();                   // L:10119 PERFORM 800-340-READ-PAYTBL
                    if (tblStat.compareTo(ioOk) != 0) {     // L:10120 IF TBL-STAT NOT = IO-OK                 ...
                        taxRoutineFlag = notOkLit;          // L:10121 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
                        messageO = "MISSING FICA RECORD-FICA/S/03";// L:10122 MOVE "MISSING FICA RECORD-FICA/S/03" TO MESSAGE-O
                        wsGtnErr = "TX";                    // L:10123 MOVE "TX" TO WS-GTN-ERR
                        gtnError_800_700();                 // L:10124 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                        wsFicaLwrPercent3 = tblFicaPct;     // L:10125 MOVE TBL-FICA-PCT TO WS-FICA-LWR-PERCENT-3
                        tblLevel = 3;                       // L:10127 MOVE 3 TO TBL-LEVEL
                        readPaytbl_800_340();               // L:10128 PERFORM 800-340-READ-PAYTBL
                        if (tblStat.compareTo(ioOk) != 0) { // L:10129 IF TBL-STAT NOT = IO-OK                 ...
                            taxRoutineFlag = notOkLit;      // L:10130 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
                            messageO = "MISSING FICA RECORD-FICA/S/03";// L:10131 MOVE "MISSING FICA RECORD-FICA/S/03" TO MESSAGE-O
                            wsGtnErr = "TX";                // L:10132 MOVE "TX" TO WS-GTN-ERR
                            gtnError_800_700();             // L:10133 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
                            wsFicaLwrWageLimitYtd3 = tblFicaLimit;// L:10134 MOVE TBL-FICA-LIMIT TO WS-FICA-LWR-WAGE-LIMIT-YTD-3
                            wsFicaUprPercent3 = tblFicaPct; // L:10135 MOVE TBL-FICA-PCT TO WS-FICA-UPR-PERCENT-3
                            wsFicaUprTaxLimitYtd3 = tblTaxLimitYtd;// L:10136 MOVE TBL-TAX-LIMIT-YTD TO WS-FICA-UPR-TAX-LIMIT-YTD-3
                            wsFicaUprWageLimitYtd3 = tblWageLimitYtd;// L:10137 MOVE TBL-WAGE-LIMIT-YTD TO WS-FICA-UPR-WAGE-LIMIT-YTD-3
                            wsFicaLwrTaxLimitYtd3 = tblFlatTaxAmt;// L:10138 MOVE TBL-FLAT-TAX-AMT TO WS-FICA-LWR-TAX-LIMIT-YTD-3
                        }  // auto-close unclosed IF
                    }  // auto-close unclosed IF
                }  // auto-close unclosed IF
            }  // auto-close unclosed IF
        }  // auto-close unclosed IF
    }

    private void levels_1000_332_2() {                      // L:10140 1000-332-2-LEVELS
        tblLevel = 1;                                       // L:10141 MOVE 1 TO TBL-LEVEL
        readPaytbl_800_340();                               // L:10142 PERFORM 800-340-READ-PAYTBL
        if (tblStat.compareTo(ioOk) != 0) {                 // L:10143 IF TBL-STAT NOT = IO-OK
            taxRoutineFlag = notOkLit;                      // L:10144 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            messageO = "MISSING FICA RECORD-FICA/S/01";     // L:10145 MOVE "MISSING FICA RECORD-FICA/S/01" TO MESSAGE-O
            wsGtnErr = "TX";                                // L:10146 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:10147 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        wsFicaLwrWageLimitYtd = tblFicaLimit;               // L:10148 MOVE TBL-FICA-LIMIT TO WS-FICA-LWR-WAGE-LIMIT-YTD
        wsFicaUprPercent = tblFicaPct;                      // L:10149 MOVE TBL-FICA-PCT TO WS-FICA-UPR-PERCENT
        wsFicaUprTaxLimitYtd = tblTaxLimitYtd;              // L:10150 MOVE TBL-TAX-LIMIT-YTD TO WS-FICA-UPR-TAX-LIMIT-YTD
        wsFicaUprWageLimitYtd = tblWageLimitYtd;            // L:10151 MOVE TBL-WAGE-LIMIT-YTD TO WS-FICA-UPR-WAGE-LIMIT-YTD
        wsFicaLwrTaxLimitYtd = tblFlatTaxAmt;               // L:10152 MOVE TBL-FLAT-TAX-AMT TO WS-FICA-LWR-TAX-LIMIT-YTD
        tblLevel = 2;                                       // L:10154 MOVE 2 TO TBL-LEVEL
        readPaytbl_800_340();                               // L:10155 PERFORM 800-340-READ-PAYTBL
        if (tblStat.compareTo(ioOk) != 0) {                 // L:10156 IF TBL-STAT NOT = IO-OK
            taxRoutineFlag = notOkLit;                      // L:10157 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            messageO = "MISSING FICA RECORD-FICA/S/02";     // L:10158 MOVE "MISSING FICA RECORD-FICA/S/02" TO MESSAGE-O
            wsGtnErr = "TX";                                // L:10159 MOVE "TX" TO WS-GTN-ERR
            gtnError_800_700();                             // L:10160 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        wsFicaLwrPercent = tblFicaPct;                      // L:10161 MOVE TBL-FICA-PCT TO WS-FICA-LWR-PERCENT
    }

    private void minWage_1000_340() {                       // L:10163 1000-340-MIN-WAGE
        tblKey = "";                                        // L:10164 MOVE SPACES TO TBL-KEY
        tblCdeTax = "MINW";                                 // L:10165 MOVE "MINW" TO TBL-CDE-TAX
        tblMarStatus = "S";                                 // L:10166 MOVE "S" TO TBL-MAR-STATUS
        tblLevel = 1;                                       // L:10167 MOVE 1 TO TBL-LEVEL
        readPaytbl_800_340();                               // L:10168 PERFORM 800-340-READ-PAYTBL
        if (tblStat.compareTo(ioOk) != 0) {                 // L:10169 IF TBL-STAT NOT = IO-OK
            taxRoutineFlag = notOkLit;                      // L:10170 MOVE NOT-OK-LIT TO TAX-ROUTINE-FLAG
            messageO = "MISSING MIN. WAGE RATE-MINW/S/01."; // L:10171 MOVE "MISSING MIN. WAGE RATE-MINW/S/01." TO MESSAGE-O
            wsGtnErr = "AB";                                // L:10172 MOVE "AB" TO WS-GTN-ERR
            gtnError_800_700();                             // L:10173 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        wsMinWageRteHourly = tblLowerWageLimit;             // L:10174 MOVE TBL-LOWER-WAGE-LIMIT TO WS-MIN-WAGE-RTE-HOURLY
        // 1000-399-EXIT. EXIT.                             // L:10176 CODE
        // /                                                // L:10177 COMMENT
    }

    private void getYtdFicm_1000_450() {                    // L:10178 1000-450-GET-YTD-FICM
        ojbfnu = prmClientNo.toString();                    // L:10179 MOVE PRM-CLIENT-NO TO OJBFNU
        ojacnu = String.valueOf(perEmpNo);                  // L:10180 MOVE PER-EMP-NO TO OJACNU
        ojewsb = new BigDecimal("T");                       // L:10181 MOVE "T" TO OJEWSB
        ojt3co = "FICM";                                    // L:10182 MOVE "FICM" TO OJT3CO
        // READ PYOJCPL1                           ...      // L:10183 READ
        ernTaxYtdFicm = ojnlvu;                             // L:10185 MOVE OJNLVU TO ERN-TAX-YTD-FICM
        ernTaxYtdFicm = ernTaxYtdFicm.add(wsFicmYtd);       // L:10187 ADD WS-FICM-YTD TO ERN-TAX-YTD-FICM.    ...
        // /                                                // L:10189 COMMENT
    }

    private void loadDed_1000_500() {                       // L:10190 1000-500-LOAD-DED
        // deductionControlTable = default; // INITIALIZE DEDUCTION-CONTROL-TABLE// L:10191 INITIALIZE DEDUCTION-CONTROL-TABLE.
        // OPEN INPUT PAYCNLFILE, PAYCNLPF01.               // L:10192 OPEN
        // cnlKey = default; // INITIALIZE CNL-KEY          // L:10193 INITIALIZE CNL-KEY.
        cnlClientNo = prmClientNo.shortValue();             // L:10194 MOVE PRM-CLIENT-NO TO CNL-CLIENT-NO
        startPaycnl_800_370();                              // L:10195 PERFORM 800-370-START-PAYCNL THRU 800-370-EXIT
        if ("n".equals(recOk)) {                            // L:10196 IF REC-OK = "N"
            messageO = "NO DEDUCTIONS FOR THIS CLIENT";     // L:10197 MOVE "NO DEDUCTIONS FOR THIS CLIENT" TO MESSAGE-O
            wsGtnErr = "AB";                                // L:10199 MOVE "AB" TO WS-GTN-ERR
            gtnError_800_700();                             // L:10200 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // CLOSE PAYCNLFILE PAYCNLPF01                  // L:10201 CLOSE
            // GO TO 1000-500-EXIT - control flow           // L:10202 GO TO 1000-500-EXIT
        }  // period ends IF scope
        readCnl_1000_510();                                 // L:10204 PERFORM 1000-510-READ-CNL THRU 1000-510-EXIT
        if (cnlIdxWs > 200) {                               // L:10210 IF CNL-IDX-WS > 200
            messageO = "DEDUCTION CONTROL TABLE OVERFLOW";  // L:10211 MOVE "DEDUCTION CONTROL TABLE OVERFLOW" TO MESSAGE-O
            wsGtnErr = "AB";                                // L:10213 MOVE "AB" TO WS-GTN-ERR
            gtnError_800_700();                             // L:10214 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
        }  // period ends IF scope
        // 1000-500-EXIT. EXIT.                             // L:10216 CODE
    }

    private void readCnl_1000_510() {                       // L:10219 1000-510-READ-CNL
        readPaycnl_800_375();                               // L:10220 PERFORM 800-375-READ-PAYCNL THRU 800-375-EXIT
        if ("n".equals(recOk) || cnlClientNo != clnClientNo) {// L:10221 IF REC-OK = "N"
            recOk = "N";                                    // L:10224 MOVE "N" TO REC-OK
            // GO TO 1000-510-EXIT - control flow           // L:10225 GO TO 1000-510-EXIT
        }  // period ends IF scope
        cnlNoWs[cnlIdxWs] = cnlDedNo;                       // L:10227 MOVE CNL-DED-NO TO CNL-NO-WS(CNL-IDX-WS)
        cnlTypeTableWs[cnlIdxWs] = cnlTypeTable;            // L:10228 MOVE CNL-TYPE-TABLE TO CNL-TYPE-TABLE-WS(CNL-IDX-WS)
        cnlFreqWs[cnlIdxWs] = cnlCycleFreq;                 // L:10229 MOVE CNL-CYCLE-FREQ TO CNL-FREQ-WS(CNL-IDX-WS)
        cnlOrderWs[cnlIdxWs] = BigDecimal.valueOf(cnlOrderNo);// L:10230 MOVE CNL-ORDER-NO TO CNL-ORDER-WS(CNL-IDX-WS)
        cnlSetArrWs[cnlIdxWs] = cnlSetArrFlg;               // L:10231 MOVE CNL-SET-ARR-FLG TO CNL-SET-ARR-WS(CNL-IDX-WS)
        cnlAssocDedNoWs[cnlIdxWs] = cnlAssocDedNo;          // L:10232 MOVE CNL-ASSOC-DED-NO TO CNL-ASSOC-DED-NO-WS(CNL-IDX-WS)
        cnlTaxblFedWs[cnlIdxWs] = cnlTaxblFed;              // L:10233 MOVE CNL-TAXBL-FED TO CNL-TAXBL-FED-WS(CNL-IDX-WS)
        cnlTaxblSttWs[cnlIdxWs] = cnlTaxblStt;              // L:10234 MOVE CNL-TAXBL-STT TO CNL-TAXBL-STT-WS(CNL-IDX-WS)
        cnlTaxblLocWs[cnlIdxWs] = cnlTaxblLoc;              // L:10235 MOVE CNL-TAXBL-LOC TO CNL-TAXBL-LOC-WS(CNL-IDX-WS)
        cnlTaxblCitWs[cnlIdxWs] = cnlTaxblCit;              // L:10236 MOVE CNL-TAXBL-CIT TO CNL-TAXBL-CIT-WS(CNL-IDX-WS)
        cnlTaxblOthWs[cnlIdxWs] = cnlTaxblOth;              // L:10237 MOVE CNL-TAXBL-OTH TO CNL-TAXBL-OTH-WS(CNL-IDX-WS)
        cnlTaxblFicaWs[cnlIdxWs] = cnlTaxblFica;            // L:10238 MOVE CNL-TAXBL-FICA TO CNL-TAXBL-FICA-WS(CNL-IDX-WS)
        cnlTaxblEicWs[cnlIdxWs] = cnlTaxblFed;              // L:10239 MOVE CNL-TAXBL-FED TO CNL-TAXBL-EIC-WS(CNL-IDX-WS)
        cnlActFlgWs[cnlIdxWs] = cnlActFlg;                  // L:10240 MOVE CNL-ACT-FLG TO CNL-ACT-FLG-WS(CNL-IDX-WS)
        cnlYtdPrtWs[cnlIdxWs] = cnlYtdPrt;                  // L:10241 MOVE CNL-YTD-PRT TO CNL-YTD-PRT-WS(CNL-IDX-WS)
        if ("r".equals(cnlTaxblFedWs[cnlIdxWs])) {          // L:10242 IF CNL-TAXBL-FED-WS(CNL-IDX-WS) = "R"
            cnlTaxblFedWs[cnlIdxWs] = "N";                  // L:10243 MOVE "N" TO CNL-TAXBL-FED-WS(CNL-IDX-WS)
        }  // period ends IF scope
        if ("r".equals(cnlTaxblSttWs[cnlIdxWs])) {          // L:10244 IF CNL-TAXBL-STT-WS(CNL-IDX-WS) = "R"
            cnlTaxblSttWs[cnlIdxWs] = "N";                  // L:10245 MOVE "N" TO CNL-TAXBL-STT-WS(CNL-IDX-WS)
        }  // period ends IF scope
        if ("r".equals(cnlTaxblLocWs[cnlIdxWs])) {          // L:10246 IF CNL-TAXBL-LOC-WS(CNL-IDX-WS) = "R"
            cnlTaxblLocWs[cnlIdxWs] = "N";                  // L:10247 MOVE "N" TO CNL-TAXBL-LOC-WS(CNL-IDX-WS)
        }  // period ends IF scope
        if ("r".equals(cnlTaxblCitWs[cnlIdxWs])) {          // L:10248 IF CNL-TAXBL-CIT-WS(CNL-IDX-WS) = "R"
            cnlTaxblCitWs[cnlIdxWs] = "N";                  // L:10249 MOVE "N" TO CNL-TAXBL-CIT-WS(CNL-IDX-WS)
        }  // period ends IF scope
        if ("r".equals(cnlTaxblOthWs[cnlIdxWs])) {          // L:10250 IF CNL-TAXBL-OTH-WS(CNL-IDX-WS) = "R"
            cnlTaxblOthWs[cnlIdxWs] = "N";                  // L:10251 MOVE "N" TO CNL-TAXBL-OTH-WS(CNL-IDX-WS)
        }  // period ends IF scope
        if ("r".equals(cnlTaxblFicaWs[cnlIdxWs])) {         // L:10252 IF CNL-TAXBL-FICA-WS(CNL-IDX-WS) = "R"
            cnlTaxblFicaWs[cnlIdxWs] = "N";                 // L:10253 MOVE "N" TO CNL-TAXBL-FICA-WS(CNL-IDX-WS)
        }  // period ends IF scope
        if ("r".equals(cnlTaxblEicWs[cnlIdxWs])) {          // L:10254 IF CNL-TAXBL-EIC-WS(CNL-IDX-WS) = "R"
            cnlTaxblEicWs[cnlIdxWs] = "N";                  // L:10255 MOVE "N" TO CNL-TAXBL-EIC-WS(CNL-IDX-WS)
        }  // period ends IF scope
        cnlOptNoWs[cnlIdxWs] = BigDecimal.ZERO;             // L:10256 MOVE 0 TO CNL-OPT-NO-WS(CNL-IDX-WS)
        // cn1Key = default; // INITIALIZE CN1-KEY          // L:10257 INITIALIZE CN1-KEY.
        cn1ClientNo = cnlClientNo;                          // L:10258 MOVE CNL-CLIENT-NO TO CN1-CLIENT-NO
        cn1DedNo = cnlDedNo;                                // L:10260 MOVE CNL-DED-NO TO CN1-DED-NO
        // START PAYCNLPF01 KEY NOT < CN1-KEY               // L:10263 CODE
        // INVALID KEY                                      // L:10264 CODE
        // GO TO 1000-510-EXIT - control flow               // L:10266 GO TO 1000-510-EXIT
        // READ PAYCNLPF01 NEXT                             // L:10268 READ
        cn1OptNo = 0;                                       // L:10271 MOVE 0 TO CN1-OPT-NO
        if (cnlClientNo != cn1ClientNo || cnlDedNo.compareTo(cn1DedNo) != 0) {// L:10272 IF CNL-CLIENT-NO NOT = CN1-CLIENT-NO
            // GO TO 1000-510-EXIT - control flow           // L:10275 GO TO 1000-510-EXIT
        }  // period ends IF scope
        cnlOptNoWs[cnlIdxWs] = BigDecimal.valueOf(cn1OptNo);// L:10276 MOVE CN1-OPT-NO TO CNL-OPT-NO-WS(CNL-IDX-WS)
        if (cn1OptNo == 3) {                                // L:10278 IF CN1-OPT-NO = 3
            readPct_1000_520();                             // L:10279 PERFORM 1000-520-READ-PCT THRU 1000-520-EXIT
        } else {                                            // L:10280 ELSE
            cnlL1PctWs[cnlIdxWs] = BigDecimal.ZERO;         // L:10281 MOVE 0 TO CNL-L1-PCT-WS(CNL-IDX-WS)
            cnlL1MatWs[cnlIdxWs] = BigDecimal.ZERO;         // L:10282 MOVE 0 TO CNL-L1-MAT-WS(CNL-IDX-WS)
            cnlL2PctWs[cnlIdxWs] = BigDecimal.ZERO;         // L:10283 MOVE 0 TO CNL-L2-PCT-WS(CNL-IDX-WS)
            cnlL2MatWs[cnlIdxWs] = BigDecimal.ZERO;         // L:10284 MOVE 0 TO CNL-L2-MAT-WS(CNL-IDX-WS)
        }  // period ends IF scope
        if (cn1OptNo == 30) {                               // L:10286 IF CN1-OPT-NO = 30                      ...
            cnlMaxArrears[cnlIdxWs] = new BigDecimal(cn1OptValue);// L:10287 MOVE CN1-OPT-VALUE TO CNL-MAX-ARREARS(CNL-IDX-WS)
            wsClientDedOpt30Sw = "Y";                       // L:10288 MOVE "Y" TO WS-CLIENT-DED-OPT-30-SW
        }                                                   // L:10291 END-IF
        if (cn1OptNo == 36) {                               // L:10294 IF CN1-OPT-NO = 36                      ...
            wsClientDedOpt36Sw = "Y";                       // L:10295 MOVE "Y" TO WS-CLIENT-DED-OPT-36-SW
        }                                                   // L:10297 END-IF
        // deductionOptionsTable = default; // INITIALIZE DEDUCTION-OPTIONS-TABLE// L:10343 INITIALIZE DEDUCTION-OPTIONS-TABLE.     ...
        cn1IdxWs = 1;                                       // L:10344 SET CN1-IDX-WS TO 1.                    ...
        // CN1-LOOP.                               ...      // L:10345 CODE
        cn1NoWs[cn1IdxWs] = cnlDedNo;                       // L:10346 MOVE CNL-DED-NO TO CN1-NO-WS(CN1-IDX-WS)
        cn1OptNoWs[cn1IdxWs] = BigDecimal.valueOf(cn1OptNo);// L:10347 MOVE CN1-OPT-NO TO CN1-OPT-NO-WS(CN1-IDX-WS)
        // READ PAYCNLPF01 NEXT                    ...      // L:10348 READ
        // GO TO 1000-510-EXIT - control flow               // L:10350 GO TO 1000-510-EXIT
        cn1IdxWs = cn1IdxWs + 1;                            // L:10351 SET CN1-IDX-WS UP BY 1.                 ...
        if (cn1IdxWs > 30) {                                // L:10353 IF CN1-IDX-WS > 30                      ...
            // GO TO 1000-510-EXIT - control flow           // L:10354 GO TO 1000-510-EXIT
            if (cn1OptNo == 30) {                           // L:10355 IF CN1-OPT-NO = 30                      ...
                cnlMaxArrears[cnlIdxWs] = new BigDecimal(cn1OptValue);// L:10356 MOVE CN1-OPT-VALUE TO CNL-MAX-ARREARS(CNL-IDX-WS)
                wsClientDedOpt30Sw = "Y";                   // L:10357 MOVE "Y" TO WS-CLIENT-DED-OPT-30-SW
            }                                               // L:10358 END-IF
            if (cn1OptNo == 36) {                           // L:10359 IF CN1-OPT-NO = 36                      ...
                wsClientDedOpt36Sw = "Y";                   // L:10360 MOVE "Y" TO WS-CLIENT-DED-OPT-36-SW
            }                                               // L:10362 END-IF
            // GO TO CN1-LOOP - control flow                // L:10363 GO TO CN1-LOOP
            // 1000-510-EXIT. EXIT.                         // L:10367 CODE
        }  // period ends IF scope
    }

    private void readPct_1000_520() {                       // L:10370 1000-520-READ-PCT
        if ("n".equals(pctOpen)) {                          // L:10371 IF PCT-OPEN = "N"
            // OPEN INPUT PYJJREL1                          // L:10372 OPEN
            pctOpen = "Y";                                  // L:10373 MOVE "Y" TO PCT-OPEN
        }  // period ends IF scope
        jjbfnu = String.valueOf(cnlClientNo);               // L:10374 MOVE CNL-CLIENT-NO TO JJBFNU
        jjbhco = cnlDedNo;                                  // L:10375 MOVE CNL-DED-NO TO JJBHCO
        jjf7nu = "3";                                       // L:10376 MOVE 3 TO JJF7NU
        // READ PYJJREL1                                    // L:10377 READ
        jjaapt = BigDecimal.valueOf(3.00);                  // L:10379 MOVE 3.00 TO JJAAPT
        jjabpt = BigDecimal.valueOf(100.00);                // L:10380 MOVE 100.00 TO JJABPT
        jjacpt = BigDecimal.valueOf(2.00);                  // L:10381 MOVE 2.00 TO JJACPT
        jjadpt = BigDecimal.valueOf(25.00);                 // L:10382 MOVE 25.00 TO JJADPT
        cnlL1PctWs[cnlIdxWs] = jjaapt.divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP);// L:10383 DIVIDE JJAAPT BY 100 GIVING CNL-L1-PCT-W...
        cnlL1MatWs[cnlIdxWs] = jjabpt.divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP);// L:10384 DIVIDE JJABPT BY 100 GIVING CNL-L1-MAT-W...
        cnlL2PctWs[cnlIdxWs] = jjacpt.divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP);// L:10385 DIVIDE JJACPT BY 100 GIVING CNL-L2-PCT-W...
        cnlL2MatWs[cnlIdxWs] = jjadpt.divide(BigDecimal.valueOf(100), 10, RoundingMode.HALF_UP);// L:10386 DIVIDE JJADPT BY 100 GIVING CNL-L2-MAT-W...
        // 1000-520-EXIT. EXIT.                             // L:10388 CODE
        // /                                                // L:10389 COMMENT
    }

    private void verifyPurge_1000_600() {                   // L:10396 1000-600-VERIFY-PURGE
        purgeFlag = okLit;                                  // L:10397 MOVE OK-LIT TO PURGE-FLAG
    }

    private void readPayclnfile_1000_615() {                // L:10399 1000-615-READ-PAYCLNFILE
        clnClientNo = prmClientNo.shortValue();             // L:10400 MOVE PRM-CLIENT-NO TO CLN-CLIENT-NO
        readPaycln_800_320();                               // L:10401 PERFORM 800-320-READ-PAYCLN
        if (clnStat.compareTo(ioOk) != 0) {                 // L:10402 IF CLN-STAT NOT = IO-OK
            // GO TO 1000-699-EXIT - control flow           // L:10403 GO TO 1000-699-EXIT
        }  // period ends IF scope
        if (clnCppNo == 1) {                                // L:10411 IF CLN-CPP-NO = 1
            endOfYr = "Y";                                  // L:10412 MOVE "Y" TO END-OF-YR
            // GO TO 1000-650-EOQ-EOY-FOUND - control flow  // L:10413 GO TO 1000-650-EOQ-EOY-FOUND
        }  // period ends IF scope
        if ("n".equals(endOfQtr)) {                         // L:10414 IF END-OF-QTR = "N"
            // GO TO 1000-699-EXIT - control flow           // L:10415 GO TO 1000-699-EXIT
        } else {                                            // L:10416 ELSE
            // GO TO 1000-650-EOQ-EOY-FOUND - control flow  // L:10417 GO TO 1000-650-EOQ-EOY-FOUND
        }  // period ends IF scope
    }

    private void eoqEoyFound_1000_650() {                   // L:10424 1000-650-EOQ-EOY-FOUND
        empCount = BigDecimal.ZERO;                         // L:10425 MOVE 0 TO EMP-COUNT
        // timKey = default; // INITIALIZE TIM-KEY          // L:10426 INITIALIZE TIM-KEY.
        timClientNo = prmClientNo.shortValue();             // L:10427 MOVE PRM-CLIENT-NO TO TIM-CLIENT-NO
        startPaytim_800_330();                              // L:10428 PERFORM 800-330-START-PAYTIM
        if (timStat == ioAtEnd) {                           // L:10429 IF TIM-STAT = IO-AT-END
            wsGtnErr = "AB";                                // L:10430 MOVE "AB" TO WS-GTN-ERR
            messageO = "CANNOT READ EMPLOYEE FOR EOQ";      // L:10431 MOVE "CANNOT READ EMPLOYEE FOR EOQ" TO MESSAGE-O
            errEmpNo = BigDecimal.ZERO;                     // L:10433 MOVE 0 TO ERR-EMP-NO
            gtnError_800_700();                             // L:10434 PERFORM 800-700-GTN-ERROR THRU 800-700-EXIT
            // GO TO 1000-699-EXIT - control flow           // L:10435 GO TO 1000-699-EXIT
        }  // period ends IF scope
    }

    private void getPerBenErn_1000_655() {                  // L:10437 1000-655-GET-PER-BEN-ERN
        readPaytim_800_335();                               // L:10438 PERFORM 800-335-READ-PAYTIM
        if (timStat == ioAtEnd) {                           // L:10439 IF TIM-STAT = IO-AT-END
            // GO TO 1000-699-EXIT - control flow           // L:10440 GO TO 1000-699-EXIT
        }  // period ends IF scope
        if (BigDecimal.valueOf(timClientNo).compareTo(prmClientNo) != 0) {// L:10441 IF TIM-CLIENT-NO NOT = PRM-CLIENT-NO
            // GO TO 1000-699-EXIT - control flow           // L:10442 GO TO 1000-699-EXIT
        }  // period ends IF scope
        perClientNo = timClientNo;                          // L:10443 MOVE TIM-CLIENT-NO TO PER-CLIENT-NO
        perEmpNo = timEmpNo;                                // L:10444 MOVE TIM-EMP-NO TO PER-EMP-NO
        benKey = perKey;                                    // L:10445 MOVE PER-KEY TO BEN-KEY
        ernKey = perKey;                                    // L:10445 MOVE PER-KEY TO ERN-KEY
        readPayper_800_400();                               // L:10446 PERFORM 800-400-READ-PAYPER
        readPayben_800_405();                               // L:10447 PERFORM 800-405-READ-PAYBEN
        readPayern_800_410();                               // L:10448 PERFORM 800-410-READ-PAYERN
        if (perStat.compareTo(ioOk) != 0 || ernStat.compareTo(ioOk) != 0) {// L:10449 IF PER-STAT NOT = IO-OK
            // GO TO 1000-680-SKIP-TO-NEXT-EMP-NO - control flow// L:10452 GO TO 1000-680-SKIP-TO-NEXT-EMP-NO
        }  // period ends IF scope
        if (wsDateEnd.compareTo(BigDecimal.valueOf(ernDatePaidLst)) == 0) {// L:10459 IF WS-DATE-END = ERN-DATE-PAID-LST
            // GO TO 1000-699-EXIT - control flow           // L:10460 GO TO 1000-699-EXIT
        }  // period ends IF scope
        scanErn_1000_660();                                 // L:10462 PERFORM 1000-660-SCAN-ERN THRU 1000-660-EXIT
        if (purgeOk) {                                      // L:10464 IF PURGE-OK
            scanBen_1000_670();                             // L:10465 PERFORM 1000-670-SCAN-BEN THRU 1000-670-EXIT
            if (purgeError) {                               // L:10467 IF PURGE-ERROR
                messageO = "";                              // L:10468 MOVE SPACES TO MESSAGE-O
                errEmpNo = BigDecimal.valueOf(perEmpNo);    // L:10469 MOVE PER-EMP-NO TO ERR-EMP-NO
                if ("y".equals(endOfYr)) {                  // L:10470 IF END-OF-YR = "Y"
                    messageO = "P/R IMPOSSIBLE--MUST RUN EOQ/EOY PURGE.";// L:10471 MOVE "P/R IMPOSSIBLE--MUST RUN EOQ/EOY PURGE." TO MESSAGE-O
                } else {                                    // L:10473 ELSE
                    messageO = "P/R IMPOSSIBLE--MUST RUN EOQ PURGE.";// L:10474 MOVE "P/R IMPOSSIBLE--MUST RUN EOQ PURGE." TO MESSAGE-O
                    // GO TO 1000-699-EXIT - control flow   // L:10476 GO TO 1000-699-EXIT
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        if ("a".equals(perActive)) {                        // L:10484 IF PER-ACTIVE = "A"
            empCount = empCount.add(BigDecimal.valueOf(1)); // L:10485 ADD 1 TO EMP-COUNT.
        }  // period ends IF scope
        if (empCount.compareTo(BigDecimal.valueOf(10)) < 0) {// L:10486 IF EMP-COUNT < 10
            // GO TO 1000-680-SKIP-TO-NEXT-EMP-NO - control flow// L:10487 GO TO 1000-680-SKIP-TO-NEXT-EMP-NO
        } else {                                            // L:10488 ELSE
            // GO TO 1000-699-EXIT - control flow           // L:10489 GO TO 1000-699-EXIT
        }  // period ends IF scope
    }

    private void scanErn_1000_660() {                       // L:10491 1000-660-SCAN-ERN
        if (ernEarnQtd[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:10492 IF ERN-EARN-QTD(I) NOT = 0
            purgeFlag = notOkLit;                           // L:10493 MOVE NOT-OK-LIT TO PURGE-FLAG
            // GO TO 1000-660-EXIT - control flow           // L:10494 GO TO 1000-660-EXIT
        }  // period ends IF scope
        if (i.compareTo(BigDecimal.valueOf(34)) < 0) {      // L:10495 IF I < 34
            if (ernHrsQtd[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:10496 IF ERN-HRS-QTD(I) NOT = 0
                purgeFlag = notOkLit;                       // L:10497 MOVE NOT-OK-LIT TO PURGE-FLAG
                // GO TO 1000-660-EXIT - control flow       // L:10498 GO TO 1000-660-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        if (i.compareTo(BigDecimal.valueOf(7)) < 0) {       // L:10499 IF I < 7
            if (ernTaxQtd[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:10500 IF ERN-TAX-QTD(I) NOT = 0
                purgeFlag = notOkLit;                       // L:10501 MOVE NOT-OK-LIT TO PURGE-FLAG
                // GO TO 1000-660-EXIT - control flow       // L:10502 GO TO 1000-660-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        if ("n".equals(endOfYr)) {                          // L:10503 IF END-OF-YR = "N"
            // GO TO 1000-660-EXIT - control flow           // L:10504 GO TO 1000-660-EXIT
        }  // period ends IF scope
        if (ernEarnYtd[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:10505 IF ERN-EARN-YTD(I) NOT = 0
            purgeFlag = notOkLit;                           // L:10506 MOVE NOT-OK-LIT TO PURGE-FLAG
            // GO TO 1000-660-EXIT - control flow           // L:10507 GO TO 1000-660-EXIT
        }  // period ends IF scope
        if (i.compareTo(BigDecimal.valueOf(35)) < 0) {      // L:10508 IF I < 35
            if (ernHrsYtd[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:10509 IF ERN-HRS-YTD(I) NOT = 0
                purgeFlag = notOkLit;                       // L:10510 MOVE NOT-OK-LIT TO PURGE-FLAG
                // GO TO 1000-660-EXIT - control flow       // L:10511 GO TO 1000-660-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        if (i.compareTo(BigDecimal.valueOf(7)) < 0) {       // L:10512 IF I < 7
            if (ernTaxYtd[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:10513 IF ERN-TAX-YTD(I) NOT = 0
                purgeFlag = notOkLit;                       // L:10514 MOVE NOT-OK-LIT TO PURGE-FLAG
                // GO TO 1000-660-EXIT - control flow       // L:10515 GO TO 1000-660-EXIT
            }  // period ends IF scope
        }  // period ends IF scope
        // 1000-660-EXIT. EXIT.                             // L:10516 CODE
    }

    private void scanBen_1000_670() {                       // L:10518 1000-670-SCAN-BEN
        if (benAccQtd[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:10519 IF BEN-ACC-QTD(I) NOT = 0
            purgeFlag = notOkLit;                           // L:10520 MOVE NOT-OK-LIT TO PURGE-FLAG
            // GO TO 1000-670-EXIT - control flow           // L:10521 GO TO 1000-670-EXIT
        }  // period ends IF scope
        if ("n".equals(endOfYr)) {                          // L:10522 IF END-OF-YR = "N"
            // GO TO 1000-670-EXIT - control flow           // L:10523 GO TO 1000-670-EXIT
        }  // period ends IF scope
        if (benAccYtd[i.intValue()].compareTo(BigDecimal.ZERO) != 0) {// L:10524 IF BEN-ACC-YTD(I) NOT = 0
            purgeFlag = notOkLit;                           // L:10525 MOVE NOT-OK-LIT TO PURGE-FLAG
            // GO TO 1000-670-EXIT - control flow           // L:10526 GO TO 1000-670-EXIT
        }  // period ends IF scope
        // 1000-670-EXIT. EXIT.                             // L:10527 CODE
    }

    private void skipToNextEmpNo_1000_680() {               // L:10529 1000-680-SKIP-TO-NEXT-EMP-NO
        timSeqNo = 9999;                                    // L:10530 MOVE 9999 TO TIM-SEQ-NO
        startPaytim_800_330();                              // L:10531 PERFORM 800-330-START-PAYTIM
        if (timStat == ioOk) {                              // L:10532 IF TIM-STAT = IO-OK
            readPaytim_800_335();                           // L:10533 PERFORM 800-335-READ-PAYTIM
        }  // period ends IF scope
        if (timStat.compareTo(ioOk) != 0) {                 // L:10534 IF TIM-STAT NOT = IO-OK
            // CLOSE PAYTIMFILE                             // L:10535 CLOSE
            // OPEN INPUT PAYTIMFILE                        // L:10536 OPEN
            // clnKey = default; // INITIALIZE CLN-KEY      // L:10537 INITIALIZE CLN-KEY, TIM-KEY, PER-KEY, ER...
            // timKey = default; // INITIALIZE TIM-KEY      // L:10537 INITIALIZE CLN-KEY, TIM-KEY, PER-KEY, ER...
            perKey = "";                                    // L:10537 INITIALIZE CLN-KEY, TIM-KEY, PER-KEY, ER...
            ernKey = "";                                    // L:10537 INITIALIZE CLN-KEY, TIM-KEY, PER-KEY, ER...
            // GO TO 1000-699-EXIT - control flow           // L:10539 GO TO 1000-699-EXIT
        }  // period ends IF scope
        if (BigDecimal.valueOf(timClientNo).compareTo(prmClientNo) != 0) {// L:10540 IF TIM-CLIENT-NO NOT = PRM-CLIENT-NO
            // GO TO 1000-699-EXIT - control flow           // L:10541 GO TO 1000-699-EXIT
        }  // period ends IF scope
        if (timEmpNo != perEmpNo) {                         // L:10542 IF TIM-EMP-NO NOT = PER-EMP-NO
            // GO TO 1000-655-GET-PER-BEN-ERN - control flow// L:10543 GO TO 1000-655-GET-PER-BEN-ERN
        }  // period ends IF scope
        // GO TO 1000-680-SKIP-TO-NEXT-EMP-NO - control flow// L:10544 GO TO 1000-680-SKIP-TO-NEXT-EMP-NO
        // 1000-699-EXIT. EXIT.                             // L:10545 CODE
        // /                                                // L:10546 COMMENT
    }

    private void addXsickHours_1000_700() {                 // L:10550 1000-700-ADD-XSICK-HOURS
        if (clnXsickSeq01.compareTo(BigDecimal.ZERO) != 0) {// L:10551 IF CLN-XSICK-SEQ01 NOT = ZERO           ...
            xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq01.intValue()]);// L:10552 ADD HRS-CPP-SUM (CLN-XSICK-SEQ01) TO XSI...
            if (clnXsickSeq02.compareTo(BigDecimal.ZERO) != 0) {// L:10553 IF CLN-XSICK-SEQ02 NOT = ZERO           ...
                xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq02.intValue()]);// L:10554 ADD HRS-CPP-SUM (CLN-XSICK-SEQ02) TO XSI...
                if (clnXsickSeq03.compareTo(BigDecimal.ZERO) != 0) {// L:10555 IF CLN-XSICK-SEQ03 NOT = ZERO           ...
                    xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq03.intValue()]);// L:10556 ADD HRS-CPP-SUM (CLN-XSICK-SEQ03) TO XSI...
                    if (clnXsickSeq04.compareTo(BigDecimal.ZERO) != 0) {// L:10557 IF CLN-XSICK-SEQ04 NOT = ZERO           ...
                        xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq04.intValue()]);// L:10558 ADD HRS-CPP-SUM (CLN-XSICK-SEQ04) TO XSI...
                        if (clnXsickSeq05.compareTo(BigDecimal.ZERO) != 0) {// L:10559 IF CLN-XSICK-SEQ05 NOT = ZERO           ...
                            xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq05.intValue()]);// L:10560 ADD HRS-CPP-SUM (CLN-XSICK-SEQ05) TO XSI...
                            if (clnXsickSeq06.compareTo(BigDecimal.ZERO) != 0) {// L:10561 IF CLN-XSICK-SEQ06 NOT = ZERO           ...
                                xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq06.intValue()]);// L:10562 ADD HRS-CPP-SUM (CLN-XSICK-SEQ06) TO XSI...
                                if (clnXsickSeq07.compareTo(BigDecimal.ZERO) != 0) {// L:10563 IF CLN-XSICK-SEQ07 NOT = ZERO           ...
                                    xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq07.intValue()]);// L:10564 ADD HRS-CPP-SUM (CLN-XSICK-SEQ07) TO XSI...
                                    if (clnXsickSeq08.compareTo(BigDecimal.ZERO) != 0) {// L:10565 IF CLN-XSICK-SEQ08 NOT = ZERO           ...
                                        xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq08.intValue()]);// L:10566 ADD HRS-CPP-SUM (CLN-XSICK-SEQ08) TO XSI...
                                        if (clnXsickSeq09.compareTo(BigDecimal.ZERO) != 0) {// L:10567 IF CLN-XSICK-SEQ09 NOT = ZERO           ...
                                            xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq09.intValue()]);// L:10568 ADD HRS-CPP-SUM (CLN-XSICK-SEQ09) TO XSI...
                                            if (clnXsickSeq10.compareTo(BigDecimal.ZERO) != 0) {// L:10569 IF CLN-XSICK-SEQ10 NOT = ZERO           ...
                                                xsickHoursWs = xsickHoursWs.add(hrsCppSum[clnXsickSeq10.intValue()]);// L:10570 ADD HRS-CPP-SUM (CLN-XSICK-SEQ10) TO XSI...
                                                // 1000-700-EXIT. EXIT.                    ...// L:10571 CODE
                                                // COPY PAYBENFIRD.// L:10575 CODE
                                            }  // period ends IF scope
                                        }  // period ends IF scope
                                    }  // period ends IF scope
                                }  // period ends IF scope
                            }  // period ends IF scope
                        }  // period ends IF scope
                    }  // period ends IF scope
                }  // period ends IF scope
            }  // period ends IF scope
        }  // period ends IF scope
        // COPY PAYBENP1RD.                                 // L:10576 CODE
        // COPY PAYPERP2RD.                                 // L:10579 CODE
        // COPY PAYERNP1RD.                                 // L:10580 CODE
    }

    private void readPayperpf01_22000_000() {               // L:10591 22000-000-READ-PAYPERPF01
        // wsTaxRecord = default; // INITIALIZE WS-TAX-RECORD// L:10592 INITIALIZE WS-TAX-RECORD.
        perMarStatLoc = "";                                 // L:10593 INITIALIZE PER-MAR-STAT-LOC
        // pe1Key = default; // INITIALIZE PE1-KEY          // L:10596 INITIALIZE PE1-KEY.
        pe1ClientNo = perClientNo;                          // L:10597 MOVE PER-CLIENT-NO TO PE1-CLIENT-NO
        pe1EmpNo = perEmpNo;                                // L:10598 MOVE PER-EMP-NO TO PE1-EMP-NO
        startPe1_22000_000();                               // L:10599 PERFORM 22000-000-START-PE1
        if ("n".equals(pe1Ok)) {                            // L:10600 IF PE1-OK = "N"
            // GO TO 22000-000-EXIT - control flow          // L:10601 GO TO 22000-000-EXIT
        }  // period ends IF scope
    }

    private void readLoop_22000_000() {                     // L:10604 22000-000-READ-LOOP
        readPe1Seq_22000_000();                             // L:10605 PERFORM 22000-000-READ-PE1-SEQ
        if ("n".equals(pe1Ok) || pe1ClientNo != perClientNo || pe1EmpNo != perEmpNo) {// L:10606 IF PE1-OK = "N"
            // GO TO 22000-000-EXIT - control flow          // L:10611 GO TO 22000-000-EXIT
        }  // period ends IF scope
        pe1Inx = pe1SeqNo;                                  // L:10612 MOVE PE1-SEQ-NO TO PE1-INX
        if (pe1Inx == 1) {                                  // L:10613 IF PE1-INX = 1
            perMarStatFed = pe1MarStat;                     // L:10614 MOVE PE1-MAR-STAT TO PER-MAR-STAT-FED
        }  // period ends IF scope
        if (pe1Inx == 2) {                                  // L:10615 IF PE1-INX = 2
            perMarStatStt = pe1MarStat;                     // L:10616 MOVE PE1-MAR-STAT TO PER-MAR-STAT-STT
        }  // period ends IF scope
        if (pe1Inx == 3) {                                  // L:10617 IF PE1-INX = 3
            perMarStatLoc = pe1MarStat;                     // L:10618 MOVE PE1-MAR-STAT TO PER-MAR-STAT-LOC
        }  // period ends IF scope
        if (pe1Inx == 4) {                                  // L:10619 IF PE1-INX = 4
            perMarStatCit = pe1MarStat;                     // L:10620 MOVE PE1-MAR-STAT TO PER-MAR-STAT-CIT
        }  // period ends IF scope
        if (pe1Inx == 5) {                                  // L:10621 IF PE1-INX = 5
            perMarStatOth = pe1MarStat;                     // L:10622 MOVE PE1-MAR-STAT TO PER-MAR-STAT-OTH
        }  // period ends IF scope
        perCdeTax[pe1Inx] = pe1TaxCde;                      // L:10623 MOVE PE1-TAX-CDE TO PER-CDE-TAX(PE1-INX)
        perExmCnt[pe1Inx] = pe1TaxExm;                      // L:10624 MOVE PE1-TAX-EXM TO PER-EXM-CNT(PE1-INX)
        perTaxFlg[pe1Inx] = pe1TaxFlg;                      // L:10625 MOVE PE1-TAX-FLG TO PER-TAX-FLG(PE1-INX)
        perTaxPara[pe1Inx] = new BigDecimal(pe1TaxPara);    // L:10626 MOVE PE1-TAX-PARA TO PER-TAX-PARA(PE1-INX)
        ernTaxQtd[pe1Inx] = pe1TaxQtd;                      // L:10627 MOVE PE1-TAX-QTD TO ERN-TAX-QTD(PE1-INX)
        ernTaxYtd[pe1Inx] = pe1TaxYtd;                      // L:10628 MOVE PE1-TAX-YTD TO ERN-TAX-YTD(PE1-INX)
        // GO TO 22000-000-READ-LOOP - control flow         // L:10629 GO TO 22000-000-READ-LOOP
        // 22000-000-EXIT. EXIT.                            // L:10631 CODE
    }

    private void startPe1_22000_000() {                     // L:10634 22000-000-START-PE1
        pe1Ok = "Y";                                        // L:10635 MOVE "Y" TO PE1-OK
        // START PAYPERPF01 KEY NOT < PE1-KEY INVAL...      // L:10636 CODE
        pe1Ok = "N";                                        // L:10637 MOVE "N" TO PE1-OK
        if ("9D".equals(fsw)) {                             // L:10638 IF FSW = "9D" GO TO 22000-000-START-PE1.
        }  // auto-close unclosed IF
    }

    private void readPe1Seq_22000_000() {                   // L:10641 22000-000-READ-PE1-SEQ
        pe1Ok = "Y";                                        // L:10642 MOVE "Y" TO PE1-OK
        // READ PAYPERPF01 NEXT AT END                      // L:10643 READ
        pe1Ok = "N";                                        // L:10644 MOVE "N" TO PE1-OK
        if ("9D".equals(fsw)) {                             // L:10645 IF FSW = "9D" GO TO 22000-000-READ-PE1-S...
        }  // auto-close unclosed IF
    }

    // === EXTERNAL PROGRAM STUBS ===
    // === MISSING PARAGRAPH STUBS ===
    // These paragraphs exist in COBOL but weren't parsed - need full procedure parsing

    private void callPze1Xfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyxcxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPytdupc() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPydoxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyd1Xfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callFmhmupk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPydmxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPya8Xfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPydxxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyerxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyfwxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyizxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyjkxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyn4Xfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyooxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyopxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyu1Xfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPyu5Xfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void callPzalxfk() {  // External CALL stub
        // TODO: Implement CALL to external program
    }

    private void readPaybenfile_20000_000() {  // Stub for 20000-000-READ-PAYBENFILE
        // TODO: Parse and implement 20000-000-READ-PAYBENFILE
    }

    private void readPaybenpf01_21000_000() {  // Stub for 21000-000-READ-PAYBENPF01
        // TODO: Parse and implement 21000-000-READ-PAYBENPF01
    }

    private void readPayperpf02_23000_000() {  // Stub for 23000-000-READ-PAYPERPF02
        // TODO: Parse and implement 23000-000-READ-PAYPERPF02
    }

    private void readPayernpf01_24000_000() {  // Stub for 24000-000-READ-PAYERNPF01
        // TODO: Parse and implement 24000-000-READ-PAYERNPF01
    }

    private void mainControl() {  // Stub for 000-MAIN-CONTROL
        // TODO: Parse and implement 000-MAIN-CONTROL
    }

}