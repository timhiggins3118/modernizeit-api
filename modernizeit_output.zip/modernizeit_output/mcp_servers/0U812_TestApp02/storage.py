"""
Storage abstraction for MCP server.

Supports:
- Local filesystem (development)
- S3 (production)

Configure via environment variables:
  STORAGE_MODE: "local" or "s3"

For local:
  LOCAL_SOURCE_PATH: Path to source files
  LOCAL_ARTIFACTS_PATH: Path to artifacts

For S3:
  S3_BUCKET: Bucket name
  S3_PREFIX: Prefix for this project (e.g., "code-transformation-v2/ACME/App1")
  AWS_REGION: AWS region (default: us-east-1)
"""

import os
import fnmatch
from pathlib import Path
from typing import List, Dict, Any, Optional
from abc import ABC, abstractmethod


class StorageProvider(ABC):
    """Abstract base class for storage providers."""

    @abstractmethod
    def list_files(self, prefix: str, pattern: str = "*") -> List[Dict[str, Any]]:
        """List files matching pattern under prefix."""
        pass

    @abstractmethod
    def read_file(self, prefix: str, file_path: str) -> str:
        """Read file contents."""
        pass

    @abstractmethod
    def search_files(self, prefix: str, query: str, pattern: str = "*", max_results: int = 50) -> List[Dict[str, Any]]:
        """Search for text in files."""
        pass


class LocalStorage(StorageProvider):
    """Local filesystem storage provider."""

    def __init__(self):
        self.source_path = Path(os.getenv("LOCAL_SOURCE_PATH", "/data/source"))
        self.artifacts_path = Path(os.getenv("LOCAL_ARTIFACTS_PATH", "/data/artifacts"))

    def _get_base_path(self, prefix: str) -> Path:
        if prefix.startswith("source"):
            return self.source_path / prefix.replace("source", "", 1).lstrip("/")
        elif prefix.startswith("artifacts"):
            return self.artifacts_path / prefix.replace("artifacts", "", 1).lstrip("/")
        return self.source_path / prefix

    def list_files(self, prefix: str, pattern: str = "*") -> List[Dict[str, Any]]:
        base_path = self._get_base_path(prefix)
        if not base_path.exists():
            return []

        files = []
        for f in base_path.rglob(pattern):
            if f.is_file():
                files.append({
                    "path": str(f.relative_to(base_path)),
                    "size": f.stat().st_size,
                    "extension": f.suffix.lower()
                })
        return files

    def read_file(self, prefix: str, file_path: str) -> str:
        base_path = self._get_base_path(prefix)
        full_path = base_path / file_path

        # Security: prevent path traversal
        if not str(full_path.resolve()).startswith(str(base_path.resolve())):
            raise ValueError("Access denied: path outside allowed directory")

        if not full_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        return full_path.read_text(encoding="utf-8", errors="replace")

    def search_files(self, prefix: str, query: str, pattern: str = "*", max_results: int = 50) -> List[Dict[str, Any]]:
        base_path = self._get_base_path(prefix)
        if not base_path.exists():
            return []

        results = []
        query_lower = query.lower()

        for f in base_path.rglob(pattern):
            if not f.is_file():
                continue
            try:
                content = f.read_text(encoding="utf-8", errors="replace")
                for i, line in enumerate(content.splitlines()):
                    if query_lower in line.lower():
                        results.append({
                            "file": str(f.relative_to(base_path)),
                            "line": i + 1,
                            "content": line.strip()[:200]
                        })
                        if len(results) >= max_results:
                            return results
            except Exception:
                continue

        return results


class S3Storage(StorageProvider):
    """S3 storage provider."""

    def __init__(self):
        import boto3

        self.bucket = os.getenv("S3_BUCKET")
        self.prefix = os.getenv("S3_PREFIX", "").rstrip("/")
        region = os.getenv("AWS_REGION", "us-east-1")

        if not self.bucket:
            raise ValueError("S3_BUCKET environment variable is required")

        self.s3 = boto3.client("s3", region_name=region)

    def _get_s3_prefix(self, prefix: str) -> str:
        if self.prefix:
            return f"{self.prefix}/{prefix}"
        return prefix

    def list_files(self, prefix: str, pattern: str = "*") -> List[Dict[str, Any]]:
        s3_prefix = self._get_s3_prefix(prefix)

        files = []
        paginator = self.s3.get_paginator("list_objects_v2")

        for page in paginator.paginate(Bucket=self.bucket, Prefix=s3_prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                relative_path = key[len(s3_prefix):].lstrip("/")

                # Apply pattern filter
                if fnmatch.fnmatch(relative_path, pattern) or fnmatch.fnmatch(Path(relative_path).name, pattern):
                    files.append({
                        "path": relative_path,
                        "size": obj["Size"],
                        "extension": Path(relative_path).suffix.lower()
                    })

        return files

    def read_file(self, prefix: str, file_path: str) -> str:
        s3_prefix = self._get_s3_prefix(prefix)
        key = f"{s3_prefix}/{file_path}".replace("//", "/")

        response = self.s3.get_object(Bucket=self.bucket, Key=key)
        return response["Body"].read().decode("utf-8", errors="replace")

    def search_files(self, prefix: str, query: str, pattern: str = "*", max_results: int = 50) -> List[Dict[str, Any]]:
        # List all matching files first
        files = self.list_files(prefix, pattern)

        results = []
        query_lower = query.lower()

        for file_info in files:
            if len(results) >= max_results:
                break

            try:
                content = self.read_file(prefix, file_info["path"])
                for i, line in enumerate(content.splitlines()):
                    if query_lower in line.lower():
                        results.append({
                            "file": file_info["path"],
                            "line": i + 1,
                            "content": line.strip()[:200]
                        })
                        if len(results) >= max_results:
                            break
            except Exception:
                continue

        return results


def get_storage() -> StorageProvider:
    """Get the appropriate storage provider based on configuration."""
    mode = os.getenv("STORAGE_MODE", "local").lower()

    if mode == "s3":
        return S3Storage()
    else:
        return LocalStorage()
