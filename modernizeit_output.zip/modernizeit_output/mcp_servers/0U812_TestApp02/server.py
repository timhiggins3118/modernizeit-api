#!/usr/bin/env python3
"""
MCP Server for 0U812/TestApp02

A real MCP server that runs in Docker with HTTP/SSE transport.
Can read from S3 (production) or local filesystem (development).

Run modes:
  HTTP (for API): python server.py --transport http --port 8080
  SSE (for API):  python server.py --transport sse --port 8080
  STDIO (Claude): python server.py --transport stdio

Environment variables:
  STORAGE_MODE: "local" or "s3"
  S3_BUCKET: S3 bucket name (when STORAGE_MODE=s3)
  S3_PREFIX: S3 prefix for this project
  LOCAL_SOURCE_PATH: Local path to source files
  LOCAL_ARTIFACTS_PATH: Local path to artifacts
"""

import argparse
import json
import os
from mcp.server.fastmcp import FastMCP
from storage import get_storage

# Configuration from environment
ACCOUNT_ID = os.getenv("ACCOUNT_ID", "0U812")
APP_NAME = os.getenv("APP_NAME", "TestApp02")

# Initialize FastMCP server
mcp = FastMCP(f"ModernizeIT - {ACCOUNT_ID}/{APP_NAME}")

# Initialize storage (S3 or local based on STORAGE_MODE env var)
storage = get_storage()


# =============================================================================
# Source Code Tools
# =============================================================================

@mcp.tool()
async def list_source_files(pattern: str = "*") -> str:
    """
    List source files in the project.

    Args:
        pattern: Glob pattern to filter files (e.g., "*.cbl", "*.java")

    Returns:
        JSON list of matching files with paths and sizes
    """
    try:
        files = storage.list_files("source", pattern)
        return json.dumps({
            "pattern": pattern,
            "count": len(files),
            "files": files[:100]
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def read_source_file(file_path: str) -> str:
    """
    Read a source file's contents.

    Args:
        file_path: Path relative to source directory (e.g., "MAIN.cbl")

    Returns:
        File contents with line numbers
    """
    try:
        content = storage.read_file("source", file_path)
        lines = content.splitlines()
        numbered = [f"{i+1:6d} | {line}" for i, line in enumerate(lines)]
        return json.dumps({
            "file": file_path,
            "lines": len(lines),
            "content": "\n".join(numbered)
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def search_source_code(query: str, file_pattern: str = "*") -> str:
    """
    Search for text in source files.

    Args:
        query: Text to search for (case-insensitive)
        file_pattern: Glob pattern to filter files (e.g., "*.cbl")

    Returns:
        Matching lines with file paths and line numbers
    """
    try:
        results = storage.search_files("source", query, file_pattern, max_results=50)
        return json.dumps({
            "query": query,
            "pattern": file_pattern,
            "count": len(results),
            "matches": results
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


# =============================================================================
# Artifact Tools
# =============================================================================

@mcp.tool()
async def list_artifacts(flow: str = "") -> str:
    """
    List analysis artifact files.

    Args:
        flow: Filter by analysis flow (e.g., "code_analysis", "dependency_mapper")

    Returns:
        List of JSON artifact files
    """
    try:
        prefix = f"artifacts/{flow}" if flow else "artifacts"
        files = storage.list_files(prefix, "*.json")
        return json.dumps({
            "flow_filter": flow or "all",
            "count": len(files),
            "artifacts": files[:100]
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def read_artifact(artifact_path: str) -> str:
    """
    Read an artifact JSON file.

    Args:
        artifact_path: Path relative to artifacts directory

    Returns:
        JSON contents of the artifact
    """
    try:
        content = storage.read_file("artifacts", artifact_path)
        data = json.loads(content)

        # Truncate if too large
        content_str = json.dumps(data, indent=2)
        if len(content_str) > 50000:
            return json.dumps({
                "artifact": artifact_path,
                "truncated": True,
                "message": "Artifact too large, showing keys only",
                "keys": list(data.keys()) if isinstance(data, dict) else f"Array with {len(data)} items"
            }, indent=2)

        return json.dumps({
            "artifact": artifact_path,
            "data": data
        }, indent=2)
    except json.JSONDecodeError as e:
        return json.dumps({"error": f"Invalid JSON: {e}"})
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def search_artifacts(query: str) -> str:
    """
    Search across all artifact JSON files.

    Args:
        query: Text to search for in artifact contents

    Returns:
        Artifacts containing the query text
    """
    try:
        results = storage.search_files("artifacts", query, "*.json", max_results=20)
        return json.dumps({
            "query": query,
            "count": len(results),
            "matching_artifacts": results
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


# =============================================================================
# Project Info Tools
# =============================================================================

@mcp.tool()
async def get_project_info() -> str:
    """
    Get information about this project.

    Returns:
        Project metadata including account, app name, and file counts
    """
    try:
        source_files = storage.list_files("source", "*")
        artifact_files = storage.list_files("artifacts", "*.json")

        return json.dumps({
            "account_id": ACCOUNT_ID,
            "application_name": APP_NAME,
            "storage_mode": os.getenv("STORAGE_MODE", "local"),
            "source_file_count": len(source_files),
            "artifact_file_count": len(artifact_files)
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def get_analysis_summary() -> str:
    """
    Get a summary of all analysis results for this project.

    Returns:
        Summary of available artifacts by analysis type
    """
    try:
        summary = {
            "account_id": ACCOUNT_ID,
            "application_name": APP_NAME,
            "analyses": {}
        }

        analysis_types = [
            "code_analysis",
            "dependency_mapper",
            "monolith_identifier",
            "data_analysis",
            "discovery",
            "architecture"
        ]

        for analysis in analysis_types:
            try:
                files = storage.list_files(f"artifacts/{analysis}", "*.json")
                if files:
                    summary["analyses"][analysis] = {
                        "artifact_count": len(files),
                        "artifacts": [f["path"] for f in files[:10]]
                    }
            except Exception:
                pass

        return json.dumps(summary, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


# =============================================================================
# Custom Tools
# =============================================================================

@mcp.tool()
async def ibm_cobol_java() -> str:
    """
    This is IBM's rules list of convereting COBOL to Java datatypes

    Fetches and returns the content from: https://www.ibm.com/docs/en/i/7.6.0?topic=programs-cobol-java-data-types
    """
    import httpx
    from html.parser import HTMLParser

    class TextExtractor(HTMLParser):
        def __init__(self):
            super().__init__()
            self.text = []
            self.skip = False
        def handle_starttag(self, tag, attrs):
            if tag in ('script', 'style', 'nav', 'header', 'footer'):
                self.skip = True
        def handle_endtag(self, tag):
            if tag in ('script', 'style', 'nav', 'header', 'footer'):
                self.skip = False
        def handle_data(self, data):
            if not self.skip:
                text = data.strip()
                if text:
                    self.text.append(text)

    try:
        async with httpx.AsyncClient(follow_redirects=True) as client:
            response = await client.get("https://www.ibm.com/docs/en/i/7.6.0?topic=programs-cobol-java-data-types", headers={"User-Agent": "Mozilla/5.0"})
            response.raise_for_status()
            html = response.text

            # Extract text from HTML
            parser = TextExtractor()
            parser.feed(html)
            content = "\n".join(parser.text)

            # Truncate if too long
            if len(content) > 50000:
                content = content[:50000] + "\n... [truncated]"

            return json.dumps({
                "url": "https://www.ibm.com/docs/en/i/7.6.0?topic=programs-cobol-java-data-types",
                "content": content
            }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})

@mcp.tool()
async def ibm_cobol_java() -> str:
    """
    This is IBM's Cobol to java data types

    Fetches and returns the content from: https://www.ibm.com/docs/en/i/7.6.0?topic=programs-cobol-java-data-types
    """
    import httpx
    from html.parser import HTMLParser

    class TextExtractor(HTMLParser):
        def __init__(self):
            super().__init__()
            self.text = []
            self.skip = False
        def handle_starttag(self, tag, attrs):
            if tag in ('script', 'style', 'nav', 'header', 'footer'):
                self.skip = True
        def handle_endtag(self, tag):
            if tag in ('script', 'style', 'nav', 'header', 'footer'):
                self.skip = False
        def handle_data(self, data):
            if not self.skip:
                text = data.strip()
                if text:
                    self.text.append(text)

    try:
        async with httpx.AsyncClient(follow_redirects=True) as client:
            response = await client.get("https://www.ibm.com/docs/en/i/7.6.0?topic=programs-cobol-java-data-types", headers={"User-Agent": "Mozilla/5.0"})
            response.raise_for_status()
            html = response.text

            # Extract text from HTML
            parser = TextExtractor()
            parser.feed(html)
            content = "\n".join(parser.text)

            # Truncate if too long
            if len(content) > 50000:
                content = content[:50000] + "\n... [truncated]"

            return json.dumps({
                "url": "https://www.ibm.com/docs/en/i/7.6.0?topic=programs-cobol-java-data-types",
                "content": content
            }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})

# =============================================================================
# Entry Point
# =============================================================================

if __name__ == "__main__":
    import uvicorn

    parser = argparse.ArgumentParser(description="MCP Server for 0U812/TestApp02")
    parser.add_argument("--transport", choices=["stdio", "sse"], default="sse",
                        help="Transport mode (default: sse)")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8080, help="Port to bind (default: 8080)")

    args = parser.parse_args()

    if args.transport == "stdio":
        mcp.run()
    else:
        # Run SSE server using uvicorn
        app = mcp.sse_app()
        uvicorn.run(app, host=args.host, port=args.port)
